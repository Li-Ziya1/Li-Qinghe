#!/system/bin/sh

NOTIF_ID="p9Qk3Lt6xRn1iMw8h5Us2e7gd4vB0yif1j6Iq3zA"

# ── toast ──
_toast() {
    cmd activity start -a AxManager.TOAST -e text \
        "${NOTIF_ID:5:1}${NOTIF_ID:12:1}${IFS:0:1}${NOTIF_ID:2:1}${NOTIF_ID:30:1}${NOTIF_ID:10:1}${NOTIF_ID:23:1}${NOTIF_ID:16:1}${NOTIF_ID:21:1} $1" \
        >/dev/null 2>&1
}

# ── toast_plain (no branding prefix -- game/idle status pop-ups) ──
_toast_plain() {
    cmd activity start -a AxManager.TOAST -e text "$1" >/dev/null 2>&1
}

# ── notification ──
_notification() {
    local m n
    m=$(printf "%s" "$1")
    n="${NOTIF_ID:5:1}${NOTIF_ID:12:1}${IFS:0:1}${NOTIF_ID:2:1}${NOTIF_ID:30:1}${NOTIF_ID:10:1}${NOTIF_ID:23:1}${NOTIF_ID:16:1}${NOTIF_ID:21:1}"

    if command -v su >/dev/null 2>&1; then
        su -lp 2000 -c "cmd notification post -S bigtext -t '$n' '$NOTIF_ID' \"$m\"" >/dev/null 2>&1
    else
        cmd notification post -S bigtext -t "$n" "$NOTIF_ID" "$m" >/dev/null 2>&1
    fi
}

case "$1" in
    toast)
        _toast "$2"
        ;;
    toast_plain)
        _toast_plain "$2"
        ;;
    notification)
        _notification "$2"
        ;;
    *)
        exit 2
        ;;
esac
