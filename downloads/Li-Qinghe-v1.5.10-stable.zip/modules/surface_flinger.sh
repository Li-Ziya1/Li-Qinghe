#!/system/bin/sh

LQ_SF_RESET_MIN_NS=8000000
LQ_SF_RESET_MAX_NS=10000000
LQ_SF_MIN_PCT=50
LQ_SF_MAX_PCT=100

LQ_SF_BACKUP_DIR="$LQ_TMP_DIR/surface_flinger_backup"
LQ_SF_REFRESH_CACHE="$LQ_TMP_DIR/surface_flinger_refresh_cache"

# ── _lq_sf_backup_setting() ──
_lq_sf_backup_setting() {
    local ns="$1" key="$2" id value
    [ -d "$LQ_SF_BACKUP_DIR" ] || mkdir -p "$LQ_SF_BACKUP_DIR" >/dev/null 2>&1 || return 1
    id="$(printf '%s__%s' "$ns" "$key" | tr '/:.' '___')"
    [ -e "$LQ_SF_BACKUP_DIR/${id}.present" ] && return 0
    value="$(settings get "$ns" "$key" 2>/dev/null | tr -d '\r')"
    if [ -z "$value" ] || [ "$value" = "null" ]; then
        : > "$LQ_SF_BACKUP_DIR/${id}.missing"
    else
        printf '%s\n' "$value" > "$LQ_SF_BACKUP_DIR/${id}.value" || return 1
    fi
    printf '%s\n%s\n' "$ns" "$key" > "$LQ_SF_BACKUP_DIR/${id}.meta" || return 1
    : > "$LQ_SF_BACKUP_DIR/${id}.present"
}

# ── _lq_sf_backup_persistent() ──
_lq_sf_backup_persistent() {
    _lq_sf_backup_setting global liqinghe_surface_flinger_value || true
    _lq_sf_backup_setting secure match_content_frame_rate || true
}

# ── _lq_sf_restore_persistent() ──
_lq_sf_restore_persistent() {
    local meta ns key id value
    for meta in "$LQ_SF_BACKUP_DIR"/*.meta; do
        [ -f "$meta" ] || continue
        id="${meta%.meta}"
        ns="$(sed -n '1p' "$meta" 2>/dev/null)"
        key="$(sed -n '2p' "$meta" 2>/dev/null)"
        if [ -f "${id}.value" ]; then
            value="$(cat "${id}.value" 2>/dev/null)"
            settings put "$ns" "$key" "$value" >/dev/null 2>&1 || true
        else
            settings delete "$ns" "$key" >/dev/null 2>&1 || true
        fi
        rm -f "${id}.present" "${id}.value" "${id}.missing" "${id}.meta" >/dev/null 2>&1 || true
    done
    rmdir "$LQ_SF_BACKUP_DIR" >/dev/null 2>&1 || true
}

# ── _lq_sf_reset() ──
_lq_sf_reset() {
    _lq_sf_backup_persistent
    local refresh frame_ns safe_ns
    refresh="$(_lq_sf_refresh)"
    frame_ns=$((1000000000 / refresh))
    safe_ns="$frame_ns"
    [ "$safe_ns" -lt "$LQ_SF_RESET_MIN_NS" ] && safe_ns="$LQ_SF_RESET_MIN_NS"
    [ "$safe_ns" -gt "$LQ_SF_RESET_MAX_NS" ] && safe_ns="$LQ_SF_RESET_MAX_NS"

    _lq_write_state "$LQ_SURFACE_FLINGER_PROFILE_FILE" 0 >/dev/null 2>&1 || true
    setprop debug.sf.early.app.duration "$safe_ns"
    setprop debug.sf.earlyGl.app.duration "$safe_ns"
    setprop debug.sf.late.app.duration "$safe_ns"
    setprop debug.sf.early.sf.duration "$safe_ns"
    setprop debug.sf.earlyGl.sf.duration "$safe_ns"
    setprop debug.sf.late.sf.duration "$safe_ns"
    setprop debug.sf.use_phase_offsets_as_durations 0
    setprop debug.sf.enable_gl_backpressure 0
    setprop debug.sf.latch_unsignaled 0
    setprop debug.sf.enable_hwc_vds 0
    cmd display set-match-content-frame-rate-pref 0 >/dev/null 2>&1 || true
    settings delete secure match_content_frame_rate >/dev/null 2>&1 || true
    settings delete global liqinghe_surface_flinger_value >/dev/null 2>&1 || true
}

# ── _lq_sf_refresh() ──
_lq_sf_refresh() {
    local r
    # dumpsys display is slow (can take several hundred ms+), and this ran
    # on every single Apply/Reset before. The display's max refresh rate is
    # a fixed hardware property that doesn't change mid-session, so cache
    # it to disk once and reuse it. _lq_sf_refresh_invalidate (called once
    # at boot in service.sh) clears the cache so a fresh value is picked up
    # after every reboot, in case the connected display changed.
    if [ -f "$LQ_SF_REFRESH_CACHE" ]; then
        r="$(cat "$LQ_SF_REFRESH_CACHE" 2>/dev/null | tr -d '\r')"
        case "$r" in ''|*[!0-9]*) r="" ;; esac
        if [ -n "$r" ] && [ "$r" -ge 30 ] 2>/dev/null; then
            printf '%s\n' "$r"
            return 0
        fi
    fi
    r="$(dumpsys display 2>/dev/null |
        grep -oE 'fps=[0-9]+(\.[0-9]+)?' |
        cut -d= -f2 | sort -nu | tail -n1 |
        awk '{printf("%.0f\n",$1)}')"
    [ -n "$r" ] || r=60
    [ "$r" -ge 30 ] || r=60
    printf '%s\n' "$r" > "$LQ_SF_REFRESH_CACHE" 2>/dev/null || true
    printf '%s\n' "$r"
}

# ── _lq_sf_refresh_invalidate() ──
_lq_sf_refresh_invalidate() {
    rm -f "$LQ_SF_REFRESH_CACHE" >/dev/null 2>&1 || true
}

# ── _lq_sf_apply() ──
_lq_sf_apply() {
    local value="$1" refresh frame_ns duration
    _lq_sf_backup_persistent
    if [ "$value" = "0" ]; then
        _lq_sf_reset
        return 0
    fi
    case "$value" in ''|*[!0-9]*) return 2 ;; esac
    [ "$value" -ge "$LQ_SF_MIN_PCT" ] 2>/dev/null || return 2
    [ "$value" -le "$LQ_SF_MAX_PCT" ] 2>/dev/null || return 2

    refresh="$(_lq_sf_refresh)"
    frame_ns=$((1000000000 / refresh))
    duration=$((frame_ns * value / 100))

    setprop debug.sf.early.app.duration "$duration"
    setprop debug.sf.earlyGl.app.duration "$duration"
    setprop debug.sf.late.app.duration "$duration"
    setprop debug.sf.early.sf.duration "$duration"
    setprop debug.sf.earlyGl.sf.duration "$duration"
    setprop debug.sf.late.sf.duration "$duration"
    setprop debug.sf.use_phase_offsets_as_durations 1
    setprop debug.sf.enable_gl_backpressure 1
    setprop debug.sf.latch_unsignaled 1
    setprop debug.sf.enable_hwc_vds 0
    settings put global liqinghe_surface_flinger_value "$value" >/dev/null 2>&1 || true
    _lq_write_state "$LQ_SURFACE_FLINGER_PROFILE_FILE" "$value" >/dev/null 2>&1 || true
}

# ── _lq_sf_detect() ──
_lq_sf_detect() {
    local persisted saved flag

    persisted="$(_lq_read_state surface_flinger off 2>/dev/null | tr -d '\r')"
    case "$persisted" in
        ''|off|null) persisted="" ;;
    esac
    if [ -n "$persisted" ] && { [ "$persisted" = "0" ] || { [ "$persisted" -ge "$LQ_SF_MIN_PCT" ] 2>/dev/null && [ "$persisted" -le "$LQ_SF_MAX_PCT" ] 2>/dev/null; }; }; then
        printf '%s\n' "$persisted"
        return 0
    fi

    flag="$(getprop debug.sf.use_phase_offsets_as_durations 2>/dev/null | tr -d '\r')"
    [ "$flag" = "0" ] && { printf '0\n'; return 0; }

    saved="$(settings get global liqinghe_surface_flinger_value 2>/dev/null | tr -d '\r')"
    if [ -n "$saved" ] && [ "$saved" -ge 1 ] 2>/dev/null && [ "$saved" -le 100 ] 2>/dev/null; then
        printf '%s\n' "$saved"
    else
        printf '0\n'
    fi
}
