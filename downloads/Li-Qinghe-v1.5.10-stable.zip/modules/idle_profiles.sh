#!/system/bin/sh

: "${LQ_TMP_DIR:=/data/local/tmp/liqinghe}"
: "${LQ_IDLE_PROFILE_FILE:=$LQ_TMP_DIR/idle_profile}"
: "${LQ_IDLE_BACKUP_DIR:=$LQ_TMP_DIR/idle_battery_backup}"
_LQ_CR="$(printf '\r')"
[ -d "$LQ_TMP_DIR" ] || mkdir -p "$LQ_TMP_DIR" >/dev/null 2>&1 || true


# ── _lq_idle_backup_setting() ──
_lq_idle_backup_setting() {
    local name="$1" value
    [ -e "$LQ_IDLE_BACKUP_DIR/${name}.present" ] && return 0
    [ -d "$LQ_IDLE_BACKUP_DIR" ] || mkdir -p "$LQ_IDLE_BACKUP_DIR" >/dev/null 2>&1 || return 1
    value="$(settings get global "$name" 2>/dev/null)"
    value=${value%"$_LQ_CR"}
    if [ "$value" = "null" ] || [ -z "$value" ]; then
        : > "$LQ_IDLE_BACKUP_DIR/${name}.missing"
    else
        printf '%s\n' "$value" > "$LQ_IDLE_BACKUP_DIR/${name}.value" || return 1
    fi
    : > "$LQ_IDLE_BACKUP_DIR/${name}.present"
}

# ── _lq_idle_restore_setting() ──
_lq_idle_restore_setting() {
    local name="$1" value
    [ -e "$LQ_IDLE_BACKUP_DIR/${name}.present" ] || return 0
    if [ -e "$LQ_IDLE_BACKUP_DIR/${name}.value" ]; then
        IFS= read -r value < "$LQ_IDLE_BACKUP_DIR/${name}.value" 2>/dev/null
        settings put global "$name" "$value" >/dev/null 2>&1 || true
    else
        settings delete global "$name" >/dev/null 2>&1 || true
    fi
    rm -f "$LQ_IDLE_BACKUP_DIR/${name}.present" \
          "$LQ_IDLE_BACKUP_DIR/${name}.value" \
          "$LQ_IDLE_BACKUP_DIR/${name}.missing" >/dev/null 2>&1 || true
}

# ── _lq_idle_backup_device_config() ──
_lq_idle_backup_device_config() {
    local ns="$1" key="$2" id value
    id="$(printf '%s_%s' "$ns" "$key" | tr '/:.' '___')"
    [ -e "$LQ_IDLE_BACKUP_DIR/dc_${id}.present" ] && return 0
    [ -d "$LQ_IDLE_BACKUP_DIR" ] || mkdir -p "$LQ_IDLE_BACKUP_DIR" >/dev/null 2>&1 || return 1
    value="$(device_config get "$ns" "$key" 2>/dev/null)"
    value=${value%"$_LQ_CR"}
    if [ "$value" = "null" ] || [ -z "$value" ]; then
        : > "$LQ_IDLE_BACKUP_DIR/dc_${id}.missing"
    else
        printf '%s\n' "$value" > "$LQ_IDLE_BACKUP_DIR/dc_${id}.value" || return 1
    fi
    printf '%s\n%s\n' "$ns" "$key" > "$LQ_IDLE_BACKUP_DIR/dc_${id}.meta" || return 1
    : > "$LQ_IDLE_BACKUP_DIR/dc_${id}.present"
}

# ── _lq_idle_restore_device_config() ──
_lq_idle_restore_device_config() {
    local ns key id value
    for meta in "$LQ_IDLE_BACKUP_DIR"/dc_*.meta; do
        [ -f "$meta" ] || continue
        id="${meta%.meta}"
        { IFS= read -r ns; IFS= read -r key; } < "$meta" 2>/dev/null
        if [ -f "${id}.value" ]; then
            IFS= read -r value < "${id}.value" 2>/dev/null
            device_config put "$ns" "$key" "$value" >/dev/null 2>&1 || true
        else
            device_config delete "$ns" "$key" >/dev/null 2>&1 || true
        fi
        rm -f "${id}.present" "${id}.value" "${id}.missing" "${id}.meta" >/dev/null 2>&1 || true
    done
}

# ── _lq_q() ──
# Run a command quietly and never fail (replaces the repeated
# `>/dev/null 2>&1 || true` suffix).
_lq_q() { "$@" >/dev/null 2>&1 || true; }

# ── _lq_battery_saver_backup() ──
# Snapshot the original values Battery Saver is about to change.
# Idempotent: an existing backup is never overwritten, so it is safe to call
# before every enable. Kept separate from enable so enable only applies.
_lq_battery_saver_backup() {
    for key in \
        app_standby_constants \
        battery_saver_constants \
        job_scheduler_constants \
        app_standby_enabled \
        adaptive_battery_management_enabled; do
        _lq_idle_backup_setting "$key"
    done
    _lq_idle_backup_device_config activity_manager low_swap_threshold_percent
}

# ── _lq_battery_saver_enable() ──
# Apply only. Call _lq_battery_saver_backup first.
# NOTE: Doze (device_idle_constants + deviceidle enable-all + its own curated
# whitelist) is no longer owned by Battery Saver. It now lives in System
# Tuning as an independent toggle (`doze` group in system_tuning.sh) so it
# can be turned on/off without pulling in the rest of this profile.
# `settings put global low_power/power_save_mode` were dropped: `cmd power
# set-mode` already covers them.
_lq_battery_saver_enable() {
    _lq_q settings put global app_standby_enabled 1
    _lq_q cmd power set-fixed-performance-mode-enabled false
    _lq_q cmd power set-adaptive-power-saver-enabled true
    _lq_q cmd power set-mode 1
    _lq_q settings put global adaptive_battery_management_enabled 1
    _lq_battery_whitelist_enable

    _lq_q settings put global app_standby_constants \
        "strong_usage_duration=7200000,notification_seen_duration=86400000,system_interaction_duration=300000,prediction_timeout=43200000"
    _lq_battery_saver_refresh
    _lq_q settings put global job_scheduler_constants \
        "max_job_count_active=80,bg_normal_job_count=6,bg_moderate_job_count=12,bg_low_job_count=20,min_ready_jobs_count=2"
    _lq_q cmd thermalservice override-status 2
    _lq_q cmd device_config put activity_manager low_swap_threshold_percent 0.4
}

# ── _lq_battery_saver_disable() ──
# Restore only.
_lq_battery_saver_disable() {
    _lq_q cmd power set-mode 0
    _lq_q cmd power set-adaptive-power-saver-enabled true
    _lq_q cmd power set-fixed-performance-mode-enabled false

    _lq_idle_restore_setting app_standby_enabled
    _lq_idle_restore_setting adaptive_battery_management_enabled
    _lq_idle_restore_setting app_standby_constants
    _lq_idle_restore_setting battery_saver_constants
    _lq_idle_restore_setting job_scheduler_constants
    _lq_idle_restore_device_config
    _lq_battery_whitelist_disable

    _lq_q cmd thermalservice override-status 0
}

# Apply the shared package whitelist to DeviceIdle while Battery Saver is active.
# Only packages actually added by Li Qinghe are recorded, so disabling the
# profile never removes pre-existing/system whitelist entries.
_lq_battery_whitelist_enable() {
    local file="${LQ_WHITELIST_FILE:-$LQ_TMP_DIR/whitelist.txt}"
    local applied="$LQ_TMP_DIR/battery_whitelist_applied"
    local nl='
'
    local line pkg wl pkgs
    [ -f "$file" ] || return 0
    : > "$applied" 2>/dev/null || true

    # Fetch the DeviceIdle whitelist and the installed-package list ONCE, as
    # newline-delimited tokens, and match with `case` inside the loop. This
    # replaces a dumpsys|grep and up to two `cmd package path` calls (each a
    # fork/exec, the dumpsys a full service dump) per whitelist line.
    wl="$nl$(dumpsys deviceidle whitelist 2>/dev/null | tr ', \t\r' '\n\n\n\n')$nl"
    pkgs="$(cmd package list packages 2>/dev/null)"
    # Retry once on failure (an empty list means the call itself failed).
    [ -n "$pkgs" ] || pkgs="$(cmd package list packages 2>/dev/null)"
    pkgs="$nl$(printf '%s' "$pkgs" | tr -d '\r')$nl"

    while IFS= read -r line; do
        pkg=${line%%#*}
        pkg=${pkg#"${pkg%%[![:space:]]*}"}
        pkg=${pkg%"${pkg##*[![:space:]]}"}
        [ -n "$pkg" ] || continue
        case "$pkg" in *.*) ;; *) continue ;; esac
        case "$wl" in *"${nl}${pkg}${nl}"*) continue ;; esac
        case "$pkgs" in *"${nl}package:${pkg}${nl}"*) ;; *) continue ;; esac
        dumpsys deviceidle whitelist +"$pkg" >/dev/null 2>&1 || continue
        printf '%s\n' "$pkg" >> "$applied"
    done < "$file"
    return 0
}

_lq_battery_whitelist_disable() {
    local applied="$LQ_TMP_DIR/battery_whitelist_applied"
    local pkg
    [ -f "$applied" ] || return 0
    while IFS= read -r pkg; do
        [ -n "$pkg" ] || continue
        dumpsys deviceidle whitelist -"$pkg" >/dev/null 2>&1 || true
    done < "$applied"
    rm -f "$applied" >/dev/null 2>&1 || true
}

# ── _lq_idle_profile() ──
# Deliberately the simplest possible form: no `local`, no nested if/case,
# no early `return`. On at least one device this file's original wrapper
# (using `local` + `if` + `case` + `return` together) came back completely
# empty from inside a command substitution even though the on-disk file
# read correctly moments later in the same shell -- pointing at a shell
# (toybox/mksh) quirk with that combination rather than anything about the
# stored value itself. This form avoids every one of those constructs.
_lq_idle_profile() {
    case "$(cat "$LQ_IDLE_PROFILE_FILE" 2>/dev/null)" in
        battery-saver) printf '%s\n' battery-saver ;;
        *) printf '%s\n' normal ;;
    esac
}

# ── _lq_idle_profile_set() ──
_lq_idle_profile_set() {
    case "$1" in
        normal|battery-saver) ;;
        *) return 2 ;;
    esac
    printf '%s\n' "$1" > "$LQ_IDLE_PROFILE_FILE" 2>/dev/null || return 1
    chmod 666 "$LQ_IDLE_PROFILE_FILE" >/dev/null 2>&1 || true
}
