#!/system/bin/sh
MODDIR=${MODDIR:-$(cd "$(dirname "$0")/.." 2>/dev/null && pwd)}
BASE="$MODDIR/modules"
umask 000
# ── debug log (send /data/local/tmp/liqinghe/debug.log when something fails) ──
_LQ_DBG_FILE=/data/local/tmp/liqinghe/debug.log
_lq_dbg(){ printf '%s uid=%s %s\n' "$(date +%m-%d_%H:%M:%S 2>/dev/null)" "$(id -u 2>/dev/null)" "$*" >> "$_LQ_DBG_FILE" 2>/dev/null; }
[ "$(wc -c < "$_LQ_DBG_FILE" 2>/dev/null || echo 0)" -gt 262144 ] && { tail -c 65536 "$_LQ_DBG_FILE" > "$_LQ_DBG_FILE.tmp" 2>/dev/null && mv -f "$_LQ_DBG_FILE.tmp" "$_LQ_DBG_FILE" 2>/dev/null; }
chmod 666 "$_LQ_DBG_FILE" >/dev/null 2>&1
_lq_dbg "run: $*"
trap '_lq_dbg "exit=$? args=$*"' EXIT
chmod 777 /data/local/tmp/liqinghe >/dev/null 2>&1 || true
# Load shared runtime/helper functions (including Tctl/Fily).
# This bridge is used by WebUI commands; the helper functions themselves do not
# start anything until explicitly requested.
. "$MODDIR/common.sh"
. "$BASE/state.sh"
. "$BASE/idle_profiles.sh"
. "$BASE/surface_flinger.sh"
. "$BASE/display_tuning.sh"
. "$BASE/trace_guard.sh"

# Refresh the hardware-derived profile for this WebUI/backend shell too.
# JobScheduler defaults use the same classification as the runtime HWUI profile.
_detect_hwui_profile >/dev/null 2>&1 || true

# ── ok() ──
ok(){ printf '%s\n' '__LQ_OK__'; }
# ── err() ──
err(){ printf '%s\n' "__LQ_ERR__ $1"; _lq_dbg "ERR $1 (args=$*)"; }

. "$BASE/system_tuning.sh"
# If this shell is root, keep the state folder writable for a shell-uid WebUI too.
[ "$(id -u 2>/dev/null)" = "0" ] && chmod -R a+rwX "$LQ_SYSTEM_TUNING_DIR" >/dev/null 2>&1

# Every change command needs the watcher's PID. If it is not running, Liziya
# --start is tried first (it is the switch for the service); if that fails the
# command is refused with the reason instead of running against a dead service.
case "$1" in
  set-*|reset-*|trace-off-all)
    # _lq_lz_start lives in other/runtime.sh, which this script never loaded: every change
    # command died with "_lq_lz_start: not found". Load it here, like pkgmgr.sh does.
    if [ -f "$MODDIR/other/runtime.sh" ]; then
      . "$MODDIR/other/runtime.sh"
      _lq_gate="$(_lq_lz_start)" || { err "no-service-$_lq_gate"; exit 3; }
    fi
    ;;
esac

case "$1" in
  get-state|check-state)
    printf 'idle_profile=%s\n' "$(_lq_idle_profile)"
    printf 'surface_flinger=%s\n' "$(_lq_sf_detect)"
    printf 'display_refresh=%s\n' "$(_lq_disp_refresh_get)"
    printf 'display_renderer=%s\n' "$(_lq_disp_renderer_get)"
    printf 'display_rates=%s\n' "$(_lq_disp_rates)"
    printf 'display_adaptive=%s\n' "$(_lq_disp_adaptive_known)"
    printf 'trace_guard_count=%s\n' "$(_lq_trace_guard_count_active)"
    printf 'trace_guard_preset=%s\n' "$(_lq_trace_guard_preset)"
    printf 'perf_one_click_optimization=%s\n' "$(_lq_one_click_enabled)"
    printf 'helper_fily=%s\n' "$(_lq_fily_enabled)"
    printf 'helper_tctl=%s\n' "$(_lq_tctl_enabled)"
    for _g in job-scheduler multitasking sqlite-tuning app-standby low-swap persist-log-tags logging-diagnostics selected-diagnostics debug-props doze long-press-latency oem-tuning compile-keyboard; do
        _gsafe=$(printf '%s' "$_g" | tr '-' '_')
        if [ -f "$LQ_SYSTEM_TUNING_MANUAL_DIR/${_gsafe}.state" ]; then _gv=$(cat "$LQ_SYSTEM_TUNING_MANUAL_DIR/${_gsafe}.state" 2>/dev/null); else _gv=0; fi
        case "$_gv" in 1) _gv=1;; *) _gv=0;; esac
        printf 'perf_%s=%s\n' "$_gsafe" "$_gv"
    done
    for _sv in job-scheduler:max_job_count_active multitasking:preset sqlite-tuning:wal_checkpoint sqlite-tuning:journal_size app-standby:strong_usage_duration low-swap:threshold_percent long-press-latency:timeout_ms; do
        _sg=${_sv%%:*}; _sk=${_sv#*:}; _sfk=$(printf '%s' "$_sg" | tr '-' '_'); _vv=$(tuning_get_value "$_sg" "$_sk");
        # Nothing stored yet: report the value computed for this device (never a fixed guess)
        [ -n "$_vv" ] || _vv=$(_lq_recommended_get "recommended_value_${_sfk}_${_sk}")
        printf 'value_%s_%s=%s\n' "$_sfk" "$_sk" "$_vv";
        _rv=$(_lq_recommended_get "recommended_value_${_sfk}_${_sk}")
        [ -n "$_rv" ] && printf 'recommended_value_%s_%s=%s\n' "$_sfk" "$_sk" "$_rv"
    done
    ;;

  # ── detect-recommended-profile ──
  # Run by the WebUI's "Detect profile" button. This reads the device's specs
  # (RAM, CPU, storage, refresh rate, brand), computes a value for every tunable
  # straight from them, saves the profile, and prints it as
  # key=value lines for the detect popup. Applying is a separate step
  # (set-one-click-optimization 1).
  detect-recommended-profile)
    _lq_build_recommended_profile >/dev/null 2>&1 || { err detect-failed; exit 1; }
    [ -f "$LQ_RECOMMENDED_PROFILE_FILE" ] || { err detect-failed; exit 1; }
    cat "$LQ_RECOMMENDED_PROFILE_FILE" 2>/dev/null ;;

  # ── get-value / get-group-state ──
  # Targeted resync helpers used by the WebUI after a single toggle/apply so
  # it doesn't have to re-run the entire check-state scan (idle profile +
  # surface flinger + trace guard + every System Tuning group + battery
  # profile) just to confirm the ONE thing that just changed. Each of these
  # only touches the specific file/setting it needs to answer.
  get-value)
    case "$2" in
        surface_flinger) _lq_sf_detect ;;
        display_refresh) _lq_disp_refresh_get ;;
        display_adaptive) _lq_disp_adaptive_known ;;
        display_renderer) _lq_disp_renderer_get ;;
        display_pipeline) _lq_disp_pipeline ;;
        helper_fily) _lq_fily_enabled ;;
        helper_tctl) _lq_tctl_enabled ;;
        perf_one_click_optimization) _lq_one_click_enabled ;;
        # read-backs used by the WebUI to confirm a change before it shows it
        idle_profile) _lq_idle_profile ;;
        trace_guard_preset) _lq_trace_guard_preset ;;
        trace_guard_count) _lq_trace_guard_count_active ;;
        perf_job_scheduler|perf_multitasking|perf_sqlite_tuning|perf_app_standby|perf_low_swap|perf_persist_log_tags|perf_logging_diagnostics|perf_selected_diagnostics|perf_debug_props|perf_doze|perf_long_press_latency|perf_oem_tuning|perf_compile_keyboard)
            if [ -f "$LQ_SYSTEM_TUNING_MANUAL_DIR/${2#perf_}.state" ]; then _gv=$(cat "$LQ_SYSTEM_TUNING_MANUAL_DIR/${2#perf_}.state" 2>/dev/null); else _gv=0; fi
            case "$_gv" in 1) printf '1\n' ;; *) printf '0\n' ;; esac ;;
        *) err unknown-value; exit 2 ;;
    esac
    ;;
  get-group-state)
    case "$2" in job-scheduler|multitasking|sqlite-tuning|app-standby|low-swap|persist-log-tags|logging-diagnostics|selected-diagnostics|debug-props|doze|long-press-latency|oem-tuning|compile-keyboard) ;; *) err invalid-extra-group; exit 1;; esac
    _gsafe=$(printf '%s' "$2" | tr '-' '_')
    if [ -f "$LQ_SYSTEM_TUNING_MANUAL_DIR/${_gsafe}.state" ]; then _gv=$(cat "$LQ_SYSTEM_TUNING_MANUAL_DIR/${_gsafe}.state" 2>/dev/null); else _gv=0; fi
    case "$_gv" in 1) _gv=1;; *) _gv=0;; esac
    printf 'perf_%s=%s\n' "$_gsafe" "$_gv"
    case "$2" in
        job-scheduler) printf 'value_job_scheduler_max_job_count_active=%s\n' "$(tuning_get_value job-scheduler max_job_count_active)" ;;
        multitasking) printf 'value_multitasking_preset=%s\n' "$(tuning_get_value multitasking preset)" ;;
        sqlite-tuning)
            printf 'value_sqlite_tuning_wal_checkpoint=%s\n' "$(tuning_get_value sqlite-tuning wal_checkpoint)"
            printf 'value_sqlite_tuning_journal_size=%s\n' "$(tuning_get_value sqlite-tuning journal_size)" ;;
        app-standby) printf 'value_app_standby_strong_usage_duration=%s\n' "$(tuning_get_value app-standby strong_usage_duration)" ;;
        low-swap) printf 'value_low_swap_threshold_percent=%s\n' "$(tuning_get_value low-swap threshold_percent)" ;;
        long-press-latency) printf 'value_long_press_latency_timeout_ms=%s\n' "$(tuning_get_value long-press-latency timeout_ms)" ;;
    esac
    ;;
  set-idle-profile)
    case "$2" in normal|battery-saver) ;; *) err invalid-idle-profile; exit 1;; esac
    _lq_idle_profile_set "$2" || exit 1
    mode="$(cat "$LQ_TMP_DIR/lq.mode" 2>/dev/null)"
    if [ "$2" = "battery-saver" ]; then
        [ "$mode" = performance ] || {
            # Battery Saver owns these same system domains. Force the manual
            # duplicates off before enabling the profile to avoid collisions.
            tuning_set_group job-scheduler 0 >/dev/null 2>&1 || true
            tuning_set_group app-standby 0 >/dev/null 2>&1 || true
            tuning_set_group low-swap 0 >/dev/null 2>&1 || true
            _lq_battery_saver_backup
            _lq_battery_saver_enable
        }
    elif [ "$mode" != "performance" ]; then
        _lq_battery_saver_disable
    fi
    # Keep the idle-mode notification in sync when the profile is changed
    # while the device is already idle (not mid game->idle transition).
    # Without this, the banner keeps showing whatever profile was active
    # at the last transition until the next game->idle switch happens.
    if [ "$mode" != "performance" ]; then
        case "$2" in
            battery-saver) _LQ_IDLE_PROFILE_LABEL="Battery Saver" ;;
            *) _LQ_IDLE_PROFILE_LABEL="Normal" ;;
        esac
        _lq_notify "$(printf '%s\n%s' \
            "All perf tweaks reverted" \
            "Profile: $_LQ_IDLE_PROFILE_LABEL")"
    fi
    ok ;;

  set-helper-fily)
    case "$2" in 0|1) ;; *) err invalid-helper-state; exit 1;; esac
    if [ "$2" = 1 ] && [ -f "$LQ_SYSTEM_TUNING_MANUAL_DIR/multitasking.state" ] && [ "$(cat "$LQ_SYSTEM_TUNING_MANUAL_DIR/multitasking.state" 2>/dev/null)" = "1" ]; then
        err fily-multitasking-conflict; exit 1
    fi
    _fily_bin="$(_lq_fily_bin 2>/dev/null)"
    [ -n "$_fily_bin" ] && [ -x "$_fily_bin" ] || { err fily-binary-missing; exit 1; }
    if [ "$2" = 1 ]; then
        [ -x "$LQ_TMP_DIR/ven" ] || _lq_sync_ven_bin >/dev/null 2>&1
        "$_fily_bin" start >/dev/null 2>&1 || { err fily-start-failed; exit 1; }
    else
        "$_fily_bin" stop >/dev/null 2>&1 || { err fily-stop-failed; exit 1; }
    fi
    ok ;;
  set-helper-tctl)
    case "$2" in 0|1) ;; *) err invalid-helper-state; exit 1;; esac
    if [ "$2" = 1 ]; then
        # Tctl enable state is persistent and independent from runtime target
        # detection. Match Fily: write ON first and verify the file. Runtime
        # apply is attempted only when the automatic profile is actually in
        # performance mode; a missing target must NOT roll the saved toggle
        # back to OFF.
        _lq_write_state "$LQ_TCTL_STATE_FILE" 1 || { err tctl-state-write-failed; exit 1; }
        [ "$(_lq_read_state tctl_enabled 0)" = "1" ] || { err tctl-state-verify-failed; exit 1; }

        if [ "$(cat "$CURRENT_MODE_FILE" 2>/dev/null)" = "performance" ]; then
            if _tctl_init >/dev/null 2>&1 && [ -n "$TCTL_PROP_KEY" ]; then
                _tctl_apply >/dev/null 2>&1 || true
            fi
        fi
    else
        # Explicit disable: restore any runtime-owned value, then persist OFF.
        if [ -f "$TCTL_STATE_FILE" ]; then
            _tctl_restore >/dev/null 2>&1 || true
        fi
        _lq_write_state "$LQ_TCTL_STATE_FILE" 0 || { err tctl-state-write-failed; exit 1; }
        [ "$(_lq_read_state tctl_enabled 1)" = "0" ] || { err tctl-state-verify-failed; exit 1; }
    fi
    ok ;;
  set-one-click-optimization)
    case "$2" in 0|1) ;; *) err invalid-one-click-state; exit 1;; esac
    if [ "$2" = 1 ]; then
        # Apply-only: this reads the profile _lq_build_recommended_profile
        # already computed and saved at service startup. No detection or
        # recalculation happens here.
        tuning_apply_recommended_profile || { err one-click-apply-failed; exit 1; }
    else
        # Revert only whichever groups are currently on -- a group nobody
        # turned on (recommended or manual) is left untouched.
        tuning_revert_recommended_profile || { err one-click-revert-failed; exit 1; }
    fi
    _lq_write_state "$LQ_ONE_CLICK_STATE_FILE" "$2" || { err one-click-state-write-failed; exit 1; }
    ok ;;
  set-extra-value)
    case "$2:$3" in
      job-scheduler:max_job_count_active|sqlite-tuning:wal_checkpoint|sqlite-tuning:journal_size|app-standby:strong_usage_duration|low-swap:threshold_percent|long-press-latency:timeout_ms|multitasking:preset) ;;
      *) err invalid-extra-value; exit 1 ;;
    esac
    case "$2:$3" in
      multitasking:preset) case "$4" in lowest|low|medium|high|highest) ;; *) err invalid-extra-value; exit 1;; esac ;;
      *) case "$4" in ''|*[!0-9.]*) err invalid-extra-value; exit 1;; esac ;;
    esac
    _transition_lock_on
    if ! tuning_set_value "$2" "$3" "$4"; then
        _transition_lock_off
        exit 1
    fi
    # Without this, Liziya keeps watching the snapshot from the last mode
    # transition/boot, which still has the OLD value for this property --
    # so the value the slider just applied looks like an unexpected/foreign
    # change instead of Li Qinghe's own intentional update, and gets treated
    # as a conflict instead of becoming the new expected value.
    case "$(cat "$CURRENT_MODE_FILE" 2>/dev/null)" in
        performance) _lq_conflict_snapshot_refresh "game" ;;
        *) _lq_conflict_snapshot_refresh "idle" ;;
    esac
    _transition_lock_off
    ok ;;
  set-extra-values)
    # Same as set-extra-value, but applies every field of one group's
    # sliders (e.g. sqlite-tuning's wal_checkpoint + journal_size) in a
    # single shell round-trip and a single _lq_conflict_snapshot_refresh rebuild afterwards, instead
    # of the WebUI making one exec() call per field. Each exec() call is a
    # full root-shell round-trip; on a throttled/low-clock device that
    # round-trip cost dominates, so halving the call count for a 2-field
    # group roughly halves that group's Apply/Reset time.
    _group="$2"
    case "$_group" in job-scheduler|multitasking|sqlite-tuning|app-standby|low-swap|long-press-latency) ;; *) err invalid-extra-group; exit 1;; esac
    shift 2
    _transition_lock_on
    _bad=0
    while [ "$#" -ge 2 ]; do
        _k="$1"; _v="$2"; shift 2
        case "$_group:$_k" in
            job-scheduler:max_job_count_active|sqlite-tuning:wal_checkpoint|sqlite-tuning:journal_size|app-standby:strong_usage_duration|low-swap:threshold_percent|long-press-latency:timeout_ms|multitasking:preset) ;;
            *) _bad=1; break ;;
        esac
        case "$_group:$_k" in
            multitasking:preset) case "$_v" in lowest|low|medium|high|highest) ;; *) _bad=1; break;; esac ;;
            *) case "$_v" in ''|*[!0-9.]*) _bad=1; break;; esac ;;
        esac
        tuning_set_value "$_group" "$_k" "$_v" || { _bad=1; break; }
    done
    if [ "$_bad" = "1" ]; then
        _transition_lock_off
        err invalid-extra-value; exit 1
    fi
    case "$(cat "$CURRENT_MODE_FILE" 2>/dev/null)" in
        performance) _lq_conflict_snapshot_refresh "game" ;;
        *) _lq_conflict_snapshot_refresh "idle" ;;
    esac
    _transition_lock_off
    ok ;;
  set-extra-group)
    case "$2" in job-scheduler|multitasking|sqlite-tuning|app-standby|low-swap|persist-log-tags|logging-diagnostics|selected-diagnostics|debug-props|doze|long-press-latency|oem-tuning|compile-keyboard) ;; *) err invalid-extra-group; exit 1;; esac
    case "$3" in 0|1) ;; *) err invalid-extra-state; exit 1;; esac
    if [ "$2" = "multitasking" ] && [ "$3" = "1" ] && [ "$(_lq_fily_enabled 2>/dev/null)" = "1" ]; then
        err multitasking-fily-conflict; exit 1
    fi
    _transition_lock_on
    if ! tuning_set_group "$2" "$3"; then
        _transition_lock_off
        exit 1
    fi
    _gstate=$(printf '%s' "$2" | tr '-' '_')
    printf '%s\n' "$3" > "$LQ_SYSTEM_TUNING_MANUAL_DIR/${_gstate}.state" 2>/dev/null || true
    # Same reasoning as set-extra-value above -- toggling a group on/off
    # changes (or clears) a Liziya-tracked property too, so the watcher's
    # snapshot needs to be resynced right away instead of on the next
    # unrelated mode transition.
    case "$(cat "$CURRENT_MODE_FILE" 2>/dev/null)" in
        performance) _lq_conflict_snapshot_refresh "game" ;;
        *) _lq_conflict_snapshot_refresh "idle" ;;
    esac
    _transition_lock_off
    ok ;;
  set-surface-flinger)
    case "$2" in
        0) ;;
        ''|*[!0-9]*) err invalid-surface-flinger-value; exit 1 ;;
    esac
    if [ "$2" != "0" ] && { [ "$2" -lt 1 ] 2>/dev/null || [ "$2" -gt 100 ] 2>/dev/null; }; then
        err invalid-surface-flinger-value; exit 1
    fi
    _transition_lock_on
    if ! _lq_sf_apply "$2"; then
        _transition_lock_off
        exit 1
    fi
    case "$(cat "$CURRENT_MODE_FILE" 2>/dev/null)" in
        performance) _lq_conflict_snapshot_refresh "game" ;;
        *) _lq_conflict_snapshot_refresh "idle" ;;
    esac
    _transition_lock_off
    ok ;;

  # "Soft reboot" (power button): the same method as the Kazuyoo renderer plugins (from @HoyoSlave):
  # screen off, force-stop every app (the media module is left out), screen on. The system itself
  # keeps running, so SurfaceFlinger is not restarted. The answer is sent first and the work runs
  # detached, because force-stopping the apps also closes the WebUI.
  soft-reboot)
    ok
    ( sleep 2
      input keyevent 26
      eval "$(cmd package list packages | grep -v 'ia.mo' | sed 's/package:/cmd activity force-stop /g' | sed 's/$/\&/g')"
      input keyevent 26
    ) >/dev/null 2>&1 </dev/null &
    ;;
  set-display-refresh)
    case "$2" in ''|*[!0-9]*) err invalid-refresh-rate; exit 1 ;; esac
    if [ "$2" != "0" ] && { [ "$2" -lt 30 ] 2>/dev/null || [ "$2" -gt 240 ] 2>/dev/null; }; then
        err invalid-refresh-rate; exit 1
    fi
    _lq_disp_refresh_set "$2" || { err display-refresh-failed; exit 1; }
    ok ;;
  set-display-renderer)
    case "$2" in default|skiavk|skiavkthreaded|skiagl|skiaglthreaded|gles|glesthreaded) ;; *) err invalid-renderer; exit 1 ;; esac
    _lq_disp_renderer_set "$2" || { err display-renderer-failed; exit 1; }
    case "$(cat "$CURRENT_MODE_FILE" 2>/dev/null)" in
        performance) _lq_conflict_snapshot_refresh "game" ;;
        *) _lq_conflict_snapshot_refresh "idle" ;;
    esac
    ok ;;
  # prints which refresh-rate keys exist on this device and their values (for debugging a ROM)
  get-display-keys)
    for _e in $LQ_DISP_RR_KEYS; do
        _ns="${_e%%:*}"; _k="${_e#*:}"; _k="${_k%%:*}"
        printf '%s.%s=%s\n' "$_ns" "$_k" "$(settings get "$_ns" "$_k" 2>/dev/null | tr -d '\r')"
    done
    printf 'rates=%s\n' "$(_lq_disp_rates)"
    printf 'renderer_hwui=%s\n' "$(getprop debug.hwui.renderer)"
    printf 'renderer_backend=%s\n' "$(getprop debug.renderengine.backend)"
    ;;

  set-trace-preset)
    case "$2" in default|lite|medium|high|maximum) ;; *) err invalid-trace-preset; exit 1;; esac
    _lq_trace_guard_apply_preset "$2" || exit 1
    ok ;;
  get-trace-preset)
    _lq_trace_guard_preset
    ;;
  trace-count)
    _lq_trace_guard_count_active
    ;;
  trace-off-all)
    _lq_trace_guard_off_all
    ok ;;
  reset-surface-flinger)
    _transition_lock_on
    _lq_write_state "$LQ_SURFACE_FLINGER_PROFILE_FILE" 0
    _lq_sf_reset
    case "$(cat "$CURRENT_MODE_FILE" 2>/dev/null)" in
        performance) _lq_conflict_snapshot_refresh "game" ;;
        *) _lq_conflict_snapshot_refresh "idle" ;;
    esac
    _transition_lock_off
    ok ;;
  reset-trace-guard)
    _lq_write_state "$LQ_TRACE_PROFILE_FILE" 0
    _lq_trace_guard_off_all
    settings put global liqinghe_trace_guard_preset default >/dev/null 2>&1 || true
    ok ;;
  *) err unknown-command; exit 2;;
esac
