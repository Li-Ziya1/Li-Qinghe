#!/system/bin/sh
# Group: logging-diagnostics (Logging Limits)

# tuning_toggle_logging_limits <1|0>
tuning_toggle_logging_limits() {
    local keys="activity_starts_logging_enabled dropbox_age_seconds dropbox_max_files dropbox_quota_kb dropbox_quota_percent enable_diskstats_logging foreground_service_starts_logging_enabled"
    local key
    if [ "$1" = "1" ]; then
        for key in $keys; do
            tuning_backup_setting global "$key"
            settings put global "$key" 0 >/dev/null 2>&1 || true
        done
        tuning_backup_setting global binder_calls_stats
        settings put global binder_calls_stats 'detailed_tracking=false,enabled=false,upload_data=false,collect_latency_data=false,track_calling_uid=false' >/dev/null 2>&1 || true
    else
        for key in $keys; do
            tuning_restore_setting global "$key"
        done
        tuning_restore_setting global binder_calls_stats
    fi
}
