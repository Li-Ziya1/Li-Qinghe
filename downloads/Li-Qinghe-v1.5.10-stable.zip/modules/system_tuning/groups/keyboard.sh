#!/system/bin/sh
# Group: compile-keyboard (one-shot, nothing to undo)

# tuning_compile_keyboard
# Compiles the current default keyboard (IME) in "speed" mode.
tuning_compile_keyboard() {
    local ime
    ime="$(settings get secure default_input_method 2>/dev/null | cut -d'/' -f1)"
    [ -n "$ime" ] || return 1
    pm compile -m speed "$ime" >/dev/null 2>&1
}
