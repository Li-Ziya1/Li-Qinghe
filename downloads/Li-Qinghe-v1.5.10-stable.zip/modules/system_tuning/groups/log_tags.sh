#!/system/bin/sh
# Group: persist-log-tags (Silent Log Tags)

# tuning_toggle_silent_log_tags <1|0>
tuning_toggle_silent_log_tags() {
    local state="$1" prop_name
    local props_file="$LQ_SYSTEM_TUNING_MANUAL_DIR/persist_log_tags.list"
    local catalog="$LQ_SYSTEM_TUNING_MANUAL_DIR/persist_log_tags.catalog"

    if [ "$state" != "1" ]; then
        if [ -f "$props_file" ]; then
            while IFS= read -r prop_name; do
                [ -n "$prop_name" ] || continue
                tuning_restore_prop "$prop_name"
            done < "$props_file"
            rm -f "$props_file"
        fi
        return 0
    fi

    # Normally built once per boot in service.sh (right before the "Ready"
    # toast) so this toggle only reads a file instead of scanning every
    # property on the device. Re-scan here only as a fallback.
    if [ ! -f "$catalog" ]; then
        : > "$catalog"
        getprop 2>/dev/null | sed -n 's/^\[\(persist\.log\.tag[^]]*\)\]:.*/\1/p' > "$catalog"
        chmod 644 "$catalog" >/dev/null 2>&1
    fi

    : > "$props_file"
    while IFS= read -r prop_name; do
        [ -n "$prop_name" ] || continue
        printf '%s\n' "$prop_name" >> "$props_file"
        tuning_backup_prop "$prop_name"
        if command -v resetprop >/dev/null 2>&1; then
            resetprop "$prop_name" S >/dev/null 2>&1 || setprop "$prop_name" S >/dev/null 2>&1 || true
        else
            setprop "$prop_name" S >/dev/null 2>&1 || true
        fi
    done < "$catalog"
}
