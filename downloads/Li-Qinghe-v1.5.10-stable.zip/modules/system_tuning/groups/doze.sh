#!/system/bin/sh
# Group: doze (Doze Tuning)

# tuning_toggle_doze <1|0>
tuning_toggle_doze() {
    local state_key=device_idle_constants
    local applied="$LQ_SYSTEM_TUNING_MANUAL_DIR/doze_whitelist_applied"
    local pkg raw line whitelist
    local nl='
'
    if [ "$1" = "1" ]; then
        tuning_backup_setting global "$state_key"
        settings put global device_idle_constants \
            "inactive_to=600000,sensing_to=0,locating_to=0,idle_after_inactive_to=1800000,idle_to=10800000,quick_doze_delay_to=60000,light_after_inactive_to=180000,wait_for_unlock=true" \
            >/dev/null 2>&1 || return 1
        dumpsys deviceidle enable all >/dev/null 2>&1 || true

        # Dynamic Doze whitelist: enumerate this device's own system packages
        # and keep only telephony, telecom, dialer, IMS/VoLTE and messaging
        # stacks (the packages whose delayed SMS/MMS and late calls are the
        # documented Doze side effect). Covers OEM packages that don't use
        # the AOSP names without becoming a general "exempt everything" list.
        raw="$(cmd package list packages -s 2>/dev/null)"
        # A device always has system packages, so an empty list means the call
        # itself failed: try once more.
        [ -n "$raw" ] || raw="$(cmd package list packages -s 2>/dev/null)"

        # One DeviceIdle whitelist dump for the whole run instead of a
        # dumpsys|grep per package.
        whitelist="$nl$(dumpsys deviceidle whitelist 2>/dev/null | tr ', \t\r' '\n\n\n\n')$nl"
        : > "$applied" 2>/dev/null || true
        while IFS= read -r line; do
            pkg=${line#package:}
            pkg=${pkg#"${pkg%%[![:space:]]*}"}
            pkg=${pkg%"${pkg##*[![:space:]]}"}
            [ -n "$pkg" ] || continue
            case "$pkg" in
                *telephony*|*telecom*|*dialer*|*\.ims|*\.ims.*|*\.phone|*\.sms|*\.mms) ;;
                *) continue ;;
            esac
            case "$whitelist" in *"${nl}${pkg}${nl}"*) continue ;; esac
            dumpsys deviceidle whitelist +"$pkg" >/dev/null 2>&1 || continue
            printf '%s\n' "$pkg" >> "$applied"
        done <<EOF2
$raw
EOF2
        # A while loop returns the status of its last body command (an
        # `|| continue` after a failed dumpsys leaks non-zero). The caller
        # treats non-zero as "failed", so end the branch explicitly.
        return 0
    else
        tuning_restore_setting global "$state_key"
        if [ -f "$applied" ]; then
            while IFS= read -r pkg; do
                [ -n "$pkg" ] || continue
                dumpsys deviceidle whitelist -"$pkg" >/dev/null 2>&1 || true
            done < "$applied"
            rm -f "$applied" >/dev/null 2>&1 || true
        fi
    fi
}
