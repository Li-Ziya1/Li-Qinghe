#!/system/bin/sh
# Group: multitasking (ported from CMD-Tweaks' mtask presets)
# Scales the live ActivityManager max/min tunables (from `dumpsys activity
# settings`) by a per-preset multiplier and pairs it with a memory-factor
# level. The device_config activity_manager namespace is shared with the Low
# Swap group, so low_swap_threshold_percent is excluded from the reset pass.

# tuning_multitasking_snap <preset | number>
# The preset is always one of the five names. A plain number (a multiplier saved
# by an earlier build) is snapped to the nearest preset; a name passes through
# unchanged and anything else is returned as-is so validation rejects it.
tuning_multitasking_snap() {
    case "$1" in
        lowest|low|medium|high|highest) printf '%s\n' "$1" ;;
        ''|*[!0-9.]*|.*|*.|*.*.*) printf '%s\n' "$1" ;;
        *) awk -v m="$1" 'BEGIN{ print (m<0.625) ? "lowest" : (m<0.875) ? "low" : (m<1.125) ? "medium" : (m<1.375) ? "high" : "highest" }' ;;
    esac
}

# tuning_multitasking_multiplier <preset>
tuning_multitasking_multiplier() {
    case "$1" in
        highest) printf '%s\n' 1.5 ;;
        high)    printf '%s\n' 1.25 ;;
        medium)  printf '%s\n' 1 ;;
        low)     printf '%s\n' 0.75 ;;
        lowest)  printf '%s\n' 0.5 ;;
        *) return 2 ;;
    esac
}

# tuning_multitasking_memory_factor <preset>
tuning_multitasking_memory_factor() {
    case "$1" in
        highest|high) printf '%s\n' 0 ;;
        medium)       printf '%s\n' 1 ;;
        low)          printf '%s\n' 2 ;;
        lowest)       printf '%s\n' 3 ;;
        *) return 2 ;;
    esac
}

# tuning_multitasking_reset
tuning_multitasking_reset() {
    local entry
    settings delete global activity_manager_constants >/dev/null 2>&1 || true
    for entry in $(cmd device_config list 2>/dev/null | grep activity_manager | grep -v low_swap_threshold_percent | cut -f1 -d=); do
        device_config delete "${entry%/*}" "${entry#*/}" >/dev/null 2>&1 || true
    done
}

# tuning_multitasking_apply_preset <lowest|low|medium|high|highest>
# No reset pass first: every key below is re-written with the new value
# anyway, and each device_config/cmd/settings call cold-starts a JVM process
# (slow on low-clock devices). The reset is only needed when the group is
# switched fully OFF (see tuning_group_multitasking).
tuning_multitasking_apply_preset() {
    local preset="$1" multiplier memory_factor keyval="" line key val
    multiplier="$(tuning_multitasking_multiplier "$preset")" || return 2
    memory_factor="$(tuning_multitasking_memory_factor "$preset")" || return 2
    for line in $(dumpsys activity settings 2>/dev/null | grep -E 'max|min'); do
        key="${line%%=*}"
        val="$(printf '%s\n' "${line#*=}*$multiplier" | bc 2>/dev/null | cut -f1 -d.)"
        [ -n "$val" ] || continue
        keyval="$keyval,$key=$val"
        device_config put activity_manager "$key" "$val" >/dev/null 2>&1 || true
    done
    settings put global activity_manager_constants "background_settle_time=0$keyval" default >/dev/null 2>&1 || return 1
    cmd activity memory-factor set "$memory_factor" >/dev/null 2>&1 || return 1
}
