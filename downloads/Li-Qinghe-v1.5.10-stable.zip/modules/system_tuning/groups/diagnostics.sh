#!/system/bin/sh
# Group: selected-diagnostics (Selected Diagnostics)

# tuning_toggle_diagnostics <1|0>
tuning_toggle_diagnostics() {
    local spec ns key
    for spec in \
        "global:upload_apk_enable" \
        "secure:screensaver_enabled" \
        "secure:screensaver_activate_on_dock" \
        "system:nearby_scanning_enabled"; do
        ns="${spec%%:*}"
        key="${spec#*:}"
        if [ "$1" = "1" ]; then
            tuning_backup_setting "$ns" "$key"
            settings put "$ns" "$key" 0 >/dev/null 2>&1 || true
        else
            tuning_restore_setting "$ns" "$key"
        fi
    done
}
