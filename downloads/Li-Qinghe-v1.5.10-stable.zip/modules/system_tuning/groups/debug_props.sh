#!/system/bin/sh
# Group: debug-props (Debug Properties)

# tuning_toggle_debug_props <1|0>
# ON: scans the framework/HWUI binaries for known debug.* switches and turns
# them off. OFF: just forgets the scan result (the properties reset on reboot).
tuning_toggle_debug_props() {
    local out="$LQ_SYSTEM_TUNING_MANUAL_DIR/debug_props" key value
    [ "$1" = "1" ] || { rm -f "$out"; return 0; }
    : > "$out"
    dyn_check "/system/framework/services.jar /system/framework/framework.jar /system/lib*/libhwui.so" \
        "debug\.thirdpartylogs\.enabled|debug\.hwui\.vulkan\.validation|debug\.hbmc\.log|debug\.skia\.force_sw_gles|debug\.enable_brella_analytics|debug\.miui\.perf|debug\.ocl\.trace|debug\.miui\.activity\.log" "false" > "$out" 2>/dev/null || true
    while read -r key value; do
        [ -n "$key" ] || continue
        tuning_backup_prop "$key"
        setprop "$key" "$value" >/dev/null 2>&1 || true
    done < "$out"
}
