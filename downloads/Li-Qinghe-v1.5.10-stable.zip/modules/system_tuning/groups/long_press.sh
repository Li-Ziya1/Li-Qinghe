#!/system/bin/sh
# Group: long-press-latency (Long Press Latency)

# tuning_toggle_long_press <1|0>
# ON derives a timeout from the display refresh rate; OFF restores the saved
# original. (The WebUI slider itself goes through tuning_set_value.)
tuning_toggle_long_press() {
    local file="$LQ_SYSTEM_TUNING_MANUAL_DIR/longpress" hz
    if [ "$1" = "1" ]; then
        [ -f "$file" ] || settings get secure long_press_timeout > "$file"
        hz="$(dumpsys display 2>/dev/null | awk -F'fps=' 'NF>1{v=$2+0;if(v>m)m=v}END{print int(m)}')"
        case "$hz" in ''|0|*[!0-9]*) hz=60 ;; esac
        # same derivation as the recommended value: 210 ms + two frames, to the nearest 5 ms
        settings put secure long_press_timeout "$(awk -v hz="$hz" 'BEGIN{printf "%d", int((210+2*(1000/hz))/5+0.5)*5}')" >/dev/null 2>&1 || true
    else
        [ -f "$file" ] && settings put secure long_press_timeout "$(cat "$file")" >/dev/null 2>&1 || true
        rm -f "$file"
    fi
}
