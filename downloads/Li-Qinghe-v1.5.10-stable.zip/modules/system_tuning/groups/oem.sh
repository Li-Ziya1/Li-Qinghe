#!/system/bin/sh
# Group: oem-tuning (OEM Tuning, Xiaomi family and Samsung only)

# tuning_toggle_oem_tweaks <1|0>
# Returns 2 on a device from any other manufacturer.
tuning_toggle_oem_tweaks() {
    local oem
    oem="$(_lq_oem_family)"
    [ "$oem" = other ] && return 2
    case "$1:$oem" in
        1:xiaomi)
            tuning_backup_setting system cloud_wireless_network_diagnostics_enabled
            settings put system cloud_wireless_network_diagnostics_enabled 0 >/dev/null 2>&1 || true ;;
        1:samsung)
            tuning_backup_setting system mastermotion
            tuning_backup_setting system motionengine
            settings put system mastermotion 0 >/dev/null 2>&1 || true
            settings put system motionengine 0 >/dev/null 2>&1 || true ;;
        0:*)
            tuning_restore_setting system cloud_wireless_network_diagnostics_enabled
            tuning_restore_setting system mastermotion
            tuning_restore_setting system motionengine ;;
    esac
}
