#!/system/bin/sh
# Brand detection shared by the recommended-profile builder (common.sh), the OEM
# Tuning group and uninstall.sh. Sourced from both common.sh and system_tuning.sh.

# _lq_oem_family
# Prints xiaomi (Xiaomi / Redmi / POCO), samsung, or other. Looks at the
# manufacturer AND the brand props, because a POCO or Redmi phone can report
# "Xiaomi" as manufacturer and its own name as brand (or the other way round on
# some regional / ported builds).
_lq_oem_family() {
    local ids
    ids="$(getprop ro.product.manufacturer 2>/dev/null) $(getprop ro.product.brand 2>/dev/null) $(getprop ro.product.system.brand 2>/dev/null) $(getprop ro.product.vendor.brand 2>/dev/null)"
    ids="$(printf '%s' "$ids" | tr '[:upper:]' '[:lower:]')"
    case "$ids" in
        *xiaomi*|*redmi*|*poco*) printf '%s\n' xiaomi ;;
        *samsung*)               printf '%s\n' samsung ;;
        *)                       printf '%s\n' other ;;
    esac
}
