#!/system/bin/sh
# Backup and restore of settings / system properties.
# The first backup wins: if a backup file already exists it is kept, so the
# original (pre-module) value survives repeated enabling.

# tuning_backup_setting <namespace> <key>
tuning_backup_setting() {
    local ns="$1" key="$2" file value
    file="$LQ_SYSTEM_TUNING_MANUAL_DIR/settings_${ns}_${key}"
    [ -e "$file" ] && return 0
    value="$(settings get "$ns" "$key" 2>/dev/null | tr -d '\r')"
    printf '%s\n' "$value" > "$file"
}

# tuning_restore_setting <namespace> <key>
tuning_restore_setting() {
    local ns="$1" key="$2" file value
    file="$LQ_SYSTEM_TUNING_MANUAL_DIR/settings_${ns}_${key}"
    [ -e "$file" ] || return 0
    value="$(cat "$file" 2>/dev/null)"
    case "$value" in
        null|'') settings delete "$ns" "$key" >/dev/null 2>&1 || true ;;
        *)       settings put "$ns" "$key" "$value" >/dev/null 2>&1 || true ;;
    esac
    rm -f "$file"
}

# tuning_backup_prop <property>
tuning_backup_prop() {
    local key="$1" file
    file="$LQ_SYSTEM_TUNING_MANUAL_DIR/prop_$(echo "$key" | tr './' '__')"
    [ -e "$file" ] && return 0
    getprop "$key" 2>/dev/null > "$file"
}

# tuning_restore_prop <property>
tuning_restore_prop() {
    local key="$1" file value
    file="$LQ_SYSTEM_TUNING_MANUAL_DIR/prop_$(echo "$key" | tr './' '__')"
    [ -e "$file" ] || return 0
    value="$(cat "$file" 2>/dev/null)"
    [ -n "$value" ] && setprop "$key" "$value" >/dev/null 2>&1 || true
    rm -f "$file"
}
