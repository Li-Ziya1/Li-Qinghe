#!/system/bin/sh
# One-Click Optimization: applies or reverts the recommended profile.
# No detection happens here; the profile was computed once at service start
# by _lq_build_recommended_profile and is only read from
# $LQ_RECOMMENDED_PROFILE_FILE.

# tuning_refresh_conflict_snapshot
# Rebuilds the conflict watcher's expected-property snapshot for the current
# mode. Called while holding the transition lock, after the groups settled, so
# Liziya doesn't flag our own changes as a foreign property change.
tuning_refresh_conflict_snapshot() {
    case "$(cat "$CURRENT_MODE_FILE" 2>/dev/null)" in
        performance) _lq_conflict_snapshot_refresh "game" ;;
        *)           _lq_conflict_snapshot_refresh "idle" ;;
    esac
}

# ── What the profile itself switched on ─────────────────────
# Revert must only undo what Apply did, never something the user had already turned
# on by hand, so every group/helper Apply switches on is recorded here as
# "group:<name>" or "helper:<name>". The file's mere presence also marks that the
# current profile was applied by a build that tracks this.
tuning_recommended_applied_file() {
    printf '%s\n' "$LQ_SYSTEM_TUNING_MANUAL_DIR/recommended_applied"
}

tuning_recommended_track() {
    local f
    f="$(tuning_recommended_applied_file)"
    grep -qxF "$1" "$f" 2>/dev/null || printf '%s\n' "$1" >> "$f"
}

# ── Helpers (Fily / Tctl), same actions as the WebUI toggles, minus the output ──

# tuning_helper_fily_set <1|0>
tuning_helper_fily_set() {
    local bin
    bin="$(_lq_fily_bin 2>/dev/null)"
    [ -n "$bin" ] && [ -x "$bin" ] || return 1
    if [ "$1" = 1 ]; then
        [ -x "$LQ_TMP_DIR/ven" ] || _lq_sync_ven_bin >/dev/null 2>&1
        "$bin" start >/dev/null 2>&1 || return 1
    else
        "$bin" stop >/dev/null 2>&1 || return 1
    fi
}

# tuning_helper_tctl_set <1|0>
# The enable state is saved first and a missing thermal target must not roll it
# back; the runtime apply only happens while the automatic profile is in
# performance mode (same rules as set-helper-tctl).
tuning_helper_tctl_set() {
    if [ "$1" = 1 ]; then
        _lq_write_state "$LQ_TCTL_STATE_FILE" 1 || return 1
        [ "$(_lq_read_state tctl_enabled 0)" = "1" ] || return 1
        if [ "$(cat "$CURRENT_MODE_FILE" 2>/dev/null)" = "performance" ]; then
            if _tctl_init >/dev/null 2>&1 && [ -n "$TCTL_PROP_KEY" ]; then
                _tctl_apply >/dev/null 2>&1 || true
            fi
        fi
    else
        if [ -f "$TCTL_STATE_FILE" ]; then _tctl_restore >/dev/null 2>&1 || true; fi
        _lq_write_state "$LQ_TCTL_STATE_FILE" 0 || return 1
    fi
}

# tuning_apply_recommended_profile
# Switches on whatever the recommended profile asks for and is not already on:
#  - a group (or helper) that is already active, whether the user turned it on by
#    hand or an earlier Apply did, is left completely alone, value included, so
#    nothing gets re-applied for no reason;
#  - a group the profile does not ask for is never touched;
#  - for the rest, the recommended value is only SAVED first and the group switch
#    then applies it once (setting it live and then switching the group on would
#    apply every value twice);
#  - Fily and Multitasking exclude each other: if the one the profile does not want
#    is already running, the profile's choice is skipped instead of replacing it.
tuning_apply_recommended_profile() {
    [ -f "$LQ_RECOMMENDED_PROFILE_FILE" ] || return 1
    local spec vgroup key group gsafe changed=0 applied_file

    applied_file="$(tuning_recommended_applied_file)"
    [ -f "$applied_file" ] || : > "$applied_file" 2>/dev/null

    _transition_lock_on

    for group in $LQ_TUNING_GROUPS; do
        gsafe="$(tuning_group_slug "$group")"
        [ "$(_lq_recommended_get "recommended_perf_${gsafe}")" = "1" ] || continue
        [ "$(cat "$LQ_SYSTEM_TUNING_MANUAL_DIR/${gsafe}.state" 2>/dev/null)" = "1" ] && continue
        if [ "$group" = multitasking ] && [ "$(_lq_fily_enabled 2>/dev/null)" = "1" ]; then
            continue
        fi

        for spec in $LQ_TUNING_VALUE_SPECS; do
            vgroup="${spec%%:*}"
            [ "$vgroup" = "$group" ] || continue
            key="${spec#*:}"
            want="$(_lq_recommended_get "recommended_value_${gsafe}_${key}")"
            [ -n "$want" ] && tuning_store_value "$group" "$key" "$want" >/dev/null 2>&1
        done

        tuning_set_group "$group" 1 >/dev/null 2>&1
        printf '1\n' > "$LQ_SYSTEM_TUNING_MANUAL_DIR/${gsafe}.state" 2>/dev/null
        tuning_recommended_track "group:$group"
        changed=1
    done

    if [ "$(_lq_recommended_get recommended_helper_fily)" = "1" ] \
       && [ "$(_lq_fily_enabled 2>/dev/null)" != "1" ] \
       && [ "$(cat "$LQ_SYSTEM_TUNING_MANUAL_DIR/multitasking.state" 2>/dev/null)" != "1" ]; then
        if tuning_helper_fily_set 1; then tuning_recommended_track "helper:fily"; changed=1; fi
    fi
    if [ "$(_lq_recommended_get recommended_helper_tctl)" = "1" ] \
       && [ "$(_lq_tctl_enabled 2>/dev/null)" != "1" ]; then
        if tuning_helper_tctl_set 1; then tuning_recommended_track "helper:tctl"; changed=1; fi
    fi

    [ "$changed" = 1 ] && tuning_refresh_conflict_snapshot
    _transition_lock_off
    return 0
}

# tuning_revert_recommended_profile
# Undoes only what Apply switched on (see the applied file), and only if it is
# still on. Anything the user had turned on themselves before Apply is left alone.
# A profile applied by an older build has no applied file; for that one fall back
# to the old behaviour (switch off every active group).
tuning_revert_recommended_profile() {
    local group gsafe active tok applied_file
    applied_file="$(tuning_recommended_applied_file)"

    _transition_lock_on
    if [ -f "$applied_file" ]; then
        while IFS= read -r tok; do
            case "$tok" in
                group:*)
                    group="${tok#group:}"
                    gsafe="$(tuning_group_slug "$group")"
                    active="$(cat "$LQ_SYSTEM_TUNING_MANUAL_DIR/${gsafe}.state" 2>/dev/null)"
                    [ "$active" = "1" ] || continue
                    tuning_set_group "$group" 0 >/dev/null 2>&1
                    printf '0\n' > "$LQ_SYSTEM_TUNING_MANUAL_DIR/${gsafe}.state" 2>/dev/null
                    ;;
                helper:fily)
                    [ "$(_lq_fily_enabled 2>/dev/null)" = "1" ] && tuning_helper_fily_set 0
                    ;;
                helper:tctl)
                    [ "$(_lq_tctl_enabled 2>/dev/null)" = "1" ] && tuning_helper_tctl_set 0
                    ;;
            esac
        done < "$applied_file"
        rm -f "$applied_file" >/dev/null 2>&1
    else
        for group in $LQ_TUNING_GROUPS; do
            gsafe="$(tuning_group_slug "$group")"
            active="$(cat "$LQ_SYSTEM_TUNING_MANUAL_DIR/${gsafe}.state" 2>/dev/null)"
            [ "$active" = "1" ] || continue
            tuning_set_group "$group" 0 >/dev/null 2>&1
            printf '0\n' > "$LQ_SYSTEM_TUNING_MANUAL_DIR/${gsafe}.state" 2>/dev/null
        done
    fi
    tuning_refresh_conflict_snapshot
    _transition_lock_off
    return 0
}
