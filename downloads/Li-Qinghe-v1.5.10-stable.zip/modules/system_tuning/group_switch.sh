#!/system/bin/sh
# Turns one tuning group ON or OFF. This only applies the change to the
# system; the .state file bookkeeping is done by the callers (tweaks.sh and
# the profile functions).

# ── Groups that have an adjustable value ─────────────────────
# ON applies the stored value (or the recommended one if nothing is stored).

tuning_group_job_scheduler() {
    if [ "$1" = 1 ]; then
        tuning_apply_saved_value job-scheduler max_job_count_active
    else
        settings delete global job_scheduler_constants
    fi
}

tuning_group_multitasking() {
    if [ "$1" = 1 ]; then
        tuning_apply_saved_value multitasking preset
    else
        cmd activity memory-factor reset >/dev/null 2>&1 || am memory-factor reset >/dev/null 2>&1 || true
        tuning_multitasking_reset
    fi
}

tuning_group_sqlite() {
    if [ "$1" = 1 ]; then
        tuning_apply_saved_value sqlite-tuning wal_checkpoint || return 1
        tuning_apply_saved_value sqlite-tuning journal_size || return 1
        setprop debug.sqlite.journalmode PERSIST
    else
        setprop debug.sqlite.journalmode DELETE
    fi
}

tuning_group_app_standby() {
    if [ "$1" = 1 ]; then
        tuning_apply_saved_value app-standby strong_usage_duration
    else
        settings delete global app_standby_constants
    fi
}

tuning_group_low_swap() {
    if [ "$1" = 1 ]; then
        tuning_apply_saved_value low-swap threshold_percent
    else
        device_config delete activity_manager low_swap_threshold_percent
    fi
}

tuning_group_long_press() {
    if [ "$1" = 1 ]; then
        tuning_apply_saved_value long-press-latency timeout_ms
    else
        tuning_toggle_long_press 0
    fi
}

# compile-keyboard is one-shot: turning it OFF does nothing.
tuning_group_compile_keyboard() {
    [ "$1" = 1 ] && tuning_compile_keyboard || true
}

# ── Entry point ──────────────────────────────────────────────

# tuning_set_group <group> <1|0>
# Returns 2 for an unknown group.
tuning_set_group() {
    local group="$1" state="$2"
    case "$group" in
        job-scheduler)        tuning_group_job_scheduler "$state" ;;
        multitasking)         tuning_group_multitasking "$state" ;;
        sqlite-tuning)        tuning_group_sqlite "$state" ;;
        app-standby)          tuning_group_app_standby "$state" ;;
        low-swap)             tuning_group_low_swap "$state" ;;
        persist-log-tags)     tuning_toggle_silent_log_tags "$state" ;;
        logging-diagnostics)  tuning_toggle_logging_limits "$state" ;;
        selected-diagnostics) tuning_toggle_diagnostics "$state" ;;
        debug-props)          tuning_toggle_debug_props "$state" ;;
        doze)                 tuning_toggle_doze "$state" ;;
        long-press-latency)   tuning_group_long_press "$state" ;;
        oem-tuning)           tuning_toggle_oem_tweaks "$state" ;;
        compile-keyboard)     tuning_group_compile_keyboard "$state" ;;
        *) return 2 ;;
    esac
}
