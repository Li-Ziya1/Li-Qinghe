#!/system/bin/sh
# Adjustable values of the tuning groups (sliders in the WebUI).
# Each value is stored in $LQ_SYSTEM_TUNING_MANUAL_DIR/value_<group>_<key>.

# tuning_group_slug <group>   ->  "sqlite-tuning" becomes "sqlite_tuning"
tuning_group_slug() {
    printf '%s' "$1" | tr '-' '_'
}

# tuning_value_path <group> <key>   ->  path of the file that stores the value
tuning_value_path() {
    printf '%s\n' "$LQ_SYSTEM_TUNING_MANUAL_DIR/value_$(tuning_group_slug "$1")_${2}"
}

# tuning_get_value <group> <key>   ->  stored value (fails if nothing stored)
tuning_get_value() {
    local file
    file="$(tuning_value_path "$1" "$2")"
    [ -f "$file" ] && cat "$file" 2>/dev/null
}

# tuning_value_in_range <value> <min> <max> <int|dec>
# Plain non-negative number within [min, max]: the safe range of that slider. The
# sliders are free inside the range (no fixed steps); this only guards against
# nonsense. The WebUI uses the same ranges.
tuning_value_in_range() {
    case "$1" in ''|*[!0-9.]*|.*|*.|*.*.*) return 1 ;; esac
    if [ "$4" = int ]; then case "$1" in *.*) return 1 ;; esac; fi
    awk -v v="$1" -v lo="$2" -v hi="$3" 'BEGIN{ exit !(v+0>=lo && v+0<=hi) }'
}

# tuning_validate_value <group> <key> <value>
# Prints the value normalised (a multitasking number is snapped to its preset)
# when it is inside the safe range of that tunable. Returns 2 otherwise.
tuning_validate_value() {
    local value="$3"
    case "$1:$2" in
        job-scheduler:max_job_count_active)  tuning_value_in_range "$value" 24 120 int || return 2 ;;
        multitasking:preset)
            value="$(tuning_multitasking_snap "$value")"
            case "$value" in lowest|low|medium|high|highest) ;; *) return 2 ;; esac ;;
        sqlite-tuning:wal_checkpoint)        tuning_value_in_range "$value" 16 512 int || return 2 ;;
        sqlite-tuning:journal_size)          tuning_value_in_range "$value" 65536 2097152 int || return 2 ;;
        app-standby:strong_usage_duration)   tuning_value_in_range "$value" 3600000 259200000 int || return 2 ;;
        low-swap:threshold_percent)          tuning_value_in_range "$value" 0.05 1 dec || return 2 ;;
        long-press-latency:timeout_ms)       tuning_value_in_range "$value" 150 800 int || return 2 ;;
        *) return 2 ;;
    esac
    printf '%s\n' "$value"
}

# tuning_store_value <group> <key> <value>
# Validates and only saves the value, without touching the system. Used by the
# recommended profile right before it switches a group on: switching the group
# on applies the saved value, so applying it here too would do the same work twice.
tuning_store_value() {
    local value
    value="$(tuning_validate_value "$1" "$2" "$3")" || return 2
    printf '%s\n' "$value" > "$(tuning_value_path "$1" "$2")" || return 1
}

# tuning_set_value <group> <key> <value>
# Validates the value against its allowed range, applies it, then stores it.
# Returns 2 for an invalid value or unknown key, 1 if applying failed.
tuning_set_value() {
    local group="$1" key="$2" value file
    value="$(tuning_validate_value "$group" "$key" "$3")" || return 2
    file="$(tuning_value_path "$group" "$key")"
    case "$group:$key" in
        job-scheduler:max_job_count_active)
            settings put global job_scheduler_constants "max_job_count_active=$value,bg_normal_job_count=${JOB_SCHED_BG_NORM:-3},bg_moderate_job_count=${JOB_SCHED_BG_MOD:-6},bg_low_job_count=${JOB_SCHED_BG_LOW:-10},min_ready_jobs_count=${JOB_SCHED_MIN_READY:-4}" >/dev/null 2>&1 || return 1 ;;
        multitasking:preset)
            tuning_multitasking_apply_preset "$value" || return 1 ;;
        sqlite-tuning:wal_checkpoint)
            setprop debug.sqlite.wal.autocheckpoint "$value" || return 1 ;;
        sqlite-tuning:journal_size)
            setprop debug.sqlite.journalsizelimit "$value" || return 1 ;;
        app-standby:strong_usage_duration)
            settings put global app_standby_constants "strong_usage_duration=$value,notification_seen_duration=1209600000,system_interaction_duration=900000,prediction_timeout=172800000" >/dev/null 2>&1 || return 1 ;;
        low-swap:threshold_percent)
            device_config put activity_manager low_swap_threshold_percent "$value" >/dev/null 2>&1 || return 1 ;;
        long-press-latency:timeout_ms)
            settings put secure long_press_timeout "$value" >/dev/null 2>&1 || return 1 ;;
    esac
    printf '%s\n' "$value" > "$file" || return 1
    return 0
}

# tuning_apply_saved_value <group> <key>
# Applies the stored value; if none is stored yet, falls back to the value
# recommended for this device. Fails if neither exists.
tuning_apply_saved_value() {
    local group="$1" key="$2" value
    value="$(tuning_get_value "$group" "$key")"
    [ -n "$value" ] || value="$(_lq_wait_recommended_value "recommended_value_$(tuning_group_slug "$group")_${key}")"
    [ -n "$value" ] || return 1
    tuning_set_value "$group" "$key" "$value" || return 1
}

# tuning_seed_default_values
# First-run seed for each tunable. The seed comes ONLY from the recommended
# profile that _lq_build_recommended_profile computed for this device; there
# are no hardcoded fallbacks. A tunable whose recommended value never becomes
# available is left unseeded instead of being seeded with a wrong number.
tuning_seed_default_values() {
    local spec group key value
    for spec in $LQ_TUNING_VALUE_SPECS; do
        group="${spec%%:*}"
        key="${spec#*:}"
        value="$(_lq_wait_recommended_value "recommended_value_$(tuning_group_slug "$group")_${key}")"
        [ -n "$value" ] || continue
        tuning_get_value "$group" "$key" >/dev/null 2>&1 \
            || printf '%s\n' "$value" > "$(tuning_value_path "$group" "$key")"
    done
}
