#!/system/bin/sh

: "${LQ_TMP_DIR:=/data/local/tmp/liqinghe}"
: "${LQ_TRACE_GUARD_STATE_DIR:=$LQ_TMP_DIR/trace_guard_state}"
: "${LQ_TRACE_GUARD_ACTIVE_FILE:=$LQ_TMP_DIR/trace_guard_active.sh}"
[ -d "$LQ_TRACE_GUARD_STATE_DIR" ] || mkdir -p "$LQ_TRACE_GUARD_STATE_DIR" >/dev/null 2>&1 || true

LQ_TRACE_GUARD_ORIGINALS_DIR="$LQ_TMP_DIR/trace_guard_originals"

# ── _lq_trace_guard_backup_original() ──
_lq_trace_guard_backup_original() {
    local ns="$1" key="$2" id value
    [ -d "$LQ_TRACE_GUARD_ORIGINALS_DIR" ] || mkdir -p "$LQ_TRACE_GUARD_ORIGINALS_DIR" >/dev/null 2>&1 || return 1
    id="$(printf '%s__%s' "$ns" "$key" | tr '/:.' '___')"
    [ -e "$LQ_TRACE_GUARD_ORIGINALS_DIR/${id}.present" ] && return 0
    value="$(device_config get "$ns" "$key" 2>/dev/null | tr -d '\r')"
    if [ -z "$value" ] || [ "$value" = "null" ]; then
        : > "$LQ_TRACE_GUARD_ORIGINALS_DIR/${id}.missing"
    else
        printf '%s\n' "$value" > "$LQ_TRACE_GUARD_ORIGINALS_DIR/${id}.value" || return 1
    fi
    printf '%s\n%s\n' "$ns" "$key" > "$LQ_TRACE_GUARD_ORIGINALS_DIR/${id}.meta" || return 1
    : > "$LQ_TRACE_GUARD_ORIGINALS_DIR/${id}.present"
}

# ── _lq_trace_guard_snapshot_all() ──
_lq_trace_guard_snapshot_all() {
    # Snapshot originals only once per active Trace Guard session.
    # Re-checking all 100+ keys on every manual click was the main source of
    # the noticeable apply delay. The .complete marker is written only after
    # the full snapshot succeeds; restore removes the whole directory.
    if [ -f "$LQ_TRACE_GUARD_ORIGINALS_DIR/.complete" ]; then
        return 0
    fi
    _lq_trace_guard_backup_original 'adservices' 'adservice_system_service_enabled' || true
    _lq_trace_guard_backup_original 'adservices' 'cobalt_logging_enabled' || true
    _lq_trace_guard_backup_original 'adservices' 'enable_logged_topic' || true
    _lq_trace_guard_backup_original 'adservices' 'adservice_error_logging_enabled' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_enable_app_package_name_logging' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_enable_source_debug_report' || true
    _lq_trace_guard_backup_original 'adservices' 'fledge_app_package_name_logging' || true
    _lq_trace_guard_backup_original 'adservices' 'fledge_auction_server_enable_debug_reporting' || true
    _lq_trace_guard_backup_original 'adservices' 'fledge_auction_server_api_usage_metrics_enabled' || true
    _lq_trace_guard_backup_original 'adservices' 'fledge_auction_server_enabled_for_report_event' || true
    _lq_trace_guard_backup_original 'adservices' 'fledge_auction_server_enabled_for_report_impression' || true
    _lq_trace_guard_backup_original 'adservices' 'fledge_auction_server_enabled_for_select_ads_mediation' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_verbose_debug_reporting_job_required_network_type' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_debug_reporting_fallback_job_required_network_type' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_debug_reporting_job_required_network_type' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_aggregate_fallback_reporting_job_required_network_type' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_aggregate_reporting_job_required_network_type' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_async_registration_fallback_job_required_network_type' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_async_registration_queue_job_required_network_type' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_event_fallback_reporting_job_required_network_type' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_event_reporting_job_required_network_type' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_job_aggregate_fallback_reporting_kill_switch' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_job_aggregate_reporting_kill_switch' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_job_event_fallback_reporting_kill_switch' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_job_event_reporting_kill_switch' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_flex_api_max_event_reports' || true
    _lq_trace_guard_backup_original 'adservices' 'measurement_flex_api_max_event_report_windows' || true
    _lq_trace_guard_backup_original 'adservices' 'mdd_android_sharing_sample_interval' || true
    _lq_trace_guard_backup_original 'adservices' 'mdd_api_logging_sample_interval' || true
    _lq_trace_guard_backup_original 'adservices' 'mdd_default_sample_interval' || true
    _lq_trace_guard_backup_original 'adservices' 'mdd_download_events_sample_interval' || true
    _lq_trace_guard_backup_original 'adservices' 'mdd_group_stats_logging_sample_interval' || true
    _lq_trace_guard_backup_original 'adservices' 'mdd_mobstore_file_service_stats_sample_interval' || true
    _lq_trace_guard_backup_original 'adservices' 'mdd_network_stats_logging_sample_interval' || true
    _lq_trace_guard_backup_original 'adservices' 'mdd_storage_stats_logging_sample_interval' || true
    _lq_trace_guard_backup_original 'aicore' 'AicModels__network_stats_log_sample_interval' || true
    _lq_trace_guard_backup_original 'aicore' 'AicModels__group_stats_log_sample_interval' || true
    _lq_trace_guard_backup_original 'aicore' 'AicModels__storage_stats_log_sample_interval' || true
    _lq_trace_guard_backup_original 'aicore' 'AicModels__api_log_sample_interval' || true
    _lq_trace_guard_backup_original 'aicore' 'AicModels__default_log_sample_interval' || true
    _lq_trace_guard_backup_original 'runtime_native' 'metrics.reporting-mods' || true
    _lq_trace_guard_backup_original 'runtime_native' 'metrics.reporting-mods-server' || true
    _lq_trace_guard_backup_original 'runtime_native' 'metrics.reporting-num-mods' || true
    _lq_trace_guard_backup_original 'runtime_native' 'metrics.reporting-num-mods-server' || true
    _lq_trace_guard_backup_original 'runtime_native' 'metrics.write-to-statsd' || true
    _lq_trace_guard_backup_original 'runtime_native' 'metrics.reporting-spec' || true
    _lq_trace_guard_backup_original 'runtime_native' 'metrics.reporting-spec-server' || true
    _lq_trace_guard_backup_original 'on_device_personalization' 'odp_enable_client_error_logging' || true
    _lq_trace_guard_backup_original 'on_device_personalization' 'odp_background_jobs_logging_enabled' || true
    _lq_trace_guard_backup_original 'on_device_personalization' 'odp_background_job_sampling_logging_rate' || true
    _lq_trace_guard_backup_original 'on_device_personalization' 'fcp_enable_client_error_logging' || true
    _lq_trace_guard_backup_original 'on_device_personalization' 'fcp_enable_background_jobs_logging' || true
    _lq_trace_guard_backup_original 'on_device_personalization' 'fcp_background_job_logging_sampling_rate' || true
    _lq_trace_guard_backup_original 'odad' 'westworld_logging' || true
    _lq_trace_guard_backup_original 'odad' 'log_error_model_id_westworld_enabled' || true
    _lq_trace_guard_backup_original 'odad' 'log_model_id_westworld' || true
    _lq_trace_guard_backup_original 'odad' 'log_model_version_westworld' || true
    _lq_trace_guard_backup_original 'odad' 'log_classification_latency_westworld' || true
    _lq_trace_guard_backup_original 'odad' 'moirai_additional_metrics_enabled' || true
    _lq_trace_guard_backup_original 'odad' 'mismatch_metrics_v2_enabled' || true
    _lq_trace_guard_backup_original 'device_personalization_services' 'Logging__enable_aiai_clearcut_logging' || true
    _lq_trace_guard_backup_original 'device_personalization_services' 'AutofillVC__enable_clearcut_log' || true
    _lq_trace_guard_backup_original 'device_personalization_services' 'Captions__enable_clearcut_logging' || true
    _lq_trace_guard_backup_original 'device_personalization_services' 'PlatformLogging__enable_metric_wise_populations' || true
    _lq_trace_guard_backup_original 'device_personalization_services' 'Superpacks__use_logging_listener' || true
    _lq_trace_guard_backup_original 'device_personalization_services' 'Overview__enable_pir_clearcut_logging' || true
    _lq_trace_guard_backup_original 'device_personalization_services' 'Overview__enable_pir_westworld_logging' || true
    _lq_trace_guard_backup_original 'device_personalization_services' 'StatsLog__active_users_logger_enabled' || true
    _lq_trace_guard_backup_original 'device_personalization_services' 'StatsLog__active_users_logger_non_persistent' || true
    _lq_trace_guard_backup_original 'device_personalization_services' 'StatsLog__enable_new_logger_api' || true
    _lq_trace_guard_backup_original 'activity_manager' 'fgs_start_allowed_log_sample_rate' || true
    _lq_trace_guard_backup_original 'activity_manager' 'fgs_start_denied_log_sample_rate' || true
    _lq_trace_guard_backup_original 'activity_manager' 'fgs_atom_sample_rate' || true
    _lq_trace_guard_backup_original 'activity_manager' 'compact_statsd_sample_rate' || true
    _lq_trace_guard_backup_original 'activity_manager' 'freeze_statsd_sample_rate' || true
    _lq_trace_guard_backup_original 'activity_manager' 'disable_app_profiler_pss_profiling' || true
    _lq_trace_guard_backup_original 'interaction_jank_monitor' 'enabled' || true
    _lq_trace_guard_backup_original 'interaction_jank_monitor' 'sampling_interval' || true
    _lq_trace_guard_backup_original 'interaction_jank_monitor' 'trace_threshold_frame_time_millis' || true
    _lq_trace_guard_backup_original 'interaction_jank_monitor' 'trace_threshold_missed_frames' || true
    _lq_trace_guard_backup_original 'window_manager' 'system_gesture_exclusion_log_debounce_millis' || true
    _lq_trace_guard_backup_original 'latency_tracker' 'enabled' || true
    _lq_trace_guard_backup_original 'latency_tracker' 'sampling_interval' || true
    _lq_trace_guard_backup_original 'latency_tracker' 'action_show_voice_interaction_enable' || true
    _lq_trace_guard_backup_original 'latency_tracker' 'action_show_voice_interaction_sample_interval' || true
    _lq_trace_guard_backup_original 'telephony' 'logcat_read_timeout_millis' || true
    _lq_trace_guard_backup_original 'telephony' 'dumpsys_read_timeout_millis' || true
    _lq_trace_guard_backup_original 'telephony' 'logcat_proc_timeout_millis' || true
    _lq_trace_guard_backup_original 'telephony' 'dumpsys_proc_timeout_millis' || true
    _lq_trace_guard_backup_original 'telephony' 'max_logcat_lines_low_mem' || true
    _lq_trace_guard_backup_original 'telephony' 'max_logcat_lines' || true
    _lq_trace_guard_backup_original 'settings_ui' 'event_logging_enabled' || true
    _lq_trace_guard_backup_original 'textclassifier' 'smart_select_animation_enabled' || true
    _lq_trace_guard_backup_original 'tethering' 'netstats_store_files_in_apexdata' || true
    _lq_trace_guard_backup_original 'tethering' 'netstats_import_legacy_target_attempts' || true
    _lq_trace_guard_backup_original 'lmkd_native' 'use_minfree_levels' || true
    _lq_trace_guard_backup_original 'lmkd_native' 'thrashing_limit_critical' || true
    _lq_trace_guard_backup_original 'content_capture' 'log_history_size' || true
    _lq_trace_guard_backup_original 'content_capture' 'max_buffer_size' || true
    : > "$LQ_TRACE_GUARD_ORIGINALS_DIR/.complete" 2>/dev/null || true
}

# ── _lq_trace_guard_restore_originals() ──
_lq_trace_guard_restore_originals() {
    local meta ns key id value
    for meta in "$LQ_TRACE_GUARD_ORIGINALS_DIR"/*.meta; do
        [ -f "$meta" ] || continue
        id="${meta%.meta}"
        ns="$(sed -n '1p' "$meta" 2>/dev/null)"
        key="$(sed -n '2p' "$meta" 2>/dev/null)"
        if [ -f "${id}.value" ]; then
            value="$(cat "${id}.value" 2>/dev/null)"
            device_config put "$ns" "$key" "$value" >/dev/null 2>&1 || true
        else
            device_config delete "$ns" "$key" >/dev/null 2>&1 || true
        fi
        rm -f "${id}.present" "${id}.value" "${id}.missing" "${id}.meta" >/dev/null 2>&1 || true
    done
    rmdir "$LQ_TRACE_GUARD_ORIGINALS_DIR" >/dev/null 2>&1 || true
}

# ── _lq_trace_guard_apply_item() ──
# Boolean/cmd items are handled here.
_lq_trace_guard_apply_item() {
    local id="$1" mode="$2"
    case "$id" in
        ads_sys_service)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'adservice_system_service_enabled' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'adservice_system_service_enabled'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_cobalt)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'cobalt_logging_enabled' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'cobalt_logging_enabled'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_logged_topic)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'enable_logged_topic' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'enable_logged_topic'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_error_logging)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'adservice_error_logging_enabled' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'adservice_error_logging_enabled'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_pkg_logging)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_enable_app_package_name_logging' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_enable_app_package_name_logging'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_source_debug)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_enable_source_debug_report' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_enable_source_debug_report'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_fledge_pkg)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'fledge_app_package_name_logging' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'fledge_app_package_name_logging'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_fledge_debug)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'fledge_auction_server_enable_debug_reporting' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'fledge_auction_server_enable_debug_reporting'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_fledge_usage)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'fledge_auction_server_api_usage_metrics_enabled' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'fledge_auction_server_api_usage_metrics_enabled'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_fledge_event)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'fledge_auction_server_enabled_for_report_event' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'fledge_auction_server_enabled_for_report_event'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_fledge_impr)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'fledge_auction_server_enabled_for_report_impression' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'fledge_auction_server_enabled_for_report_impression'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_fledge_med)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'fledge_auction_server_enabled_for_select_ads_mediation' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'fledge_auction_server_enabled_for_select_ads_mediation'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_net_verbose)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_verbose_debug_reporting_job_required_network_type' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_verbose_debug_reporting_job_required_network_type'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_net_dbg_fb)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_debug_reporting_fallback_job_required_network_type' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_debug_reporting_fallback_job_required_network_type'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_net_dbg)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_debug_reporting_job_required_network_type' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_debug_reporting_job_required_network_type'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_net_agg_fb)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_aggregate_fallback_reporting_job_required_network_type' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_aggregate_fallback_reporting_job_required_network_type'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_net_agg)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_aggregate_reporting_job_required_network_type' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_aggregate_reporting_job_required_network_type'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_net_async_fb)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_async_registration_fallback_job_required_network_type' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_async_registration_fallback_job_required_network_type'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_net_async)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_async_registration_queue_job_required_network_type' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_async_registration_queue_job_required_network_type'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_net_evt_fb)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_event_fallback_reporting_job_required_network_type' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_event_fallback_reporting_job_required_network_type'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_net_evt)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_event_reporting_job_required_network_type' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_event_reporting_job_required_network_type'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_ks_agg_fb)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_job_aggregate_fallback_reporting_kill_switch' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_job_aggregate_fallback_reporting_kill_switch'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_ks_agg)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_job_aggregate_reporting_kill_switch' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_job_aggregate_reporting_kill_switch'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_ks_evt_fb)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_job_event_fallback_reporting_kill_switch' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_job_event_fallback_reporting_kill_switch'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_ks_evt)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_job_event_reporting_kill_switch' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_job_event_reporting_kill_switch'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_flex_reports)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_flex_api_max_event_reports' '0'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_flex_api_max_event_reports'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        ads_flex_windows)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'measurement_flex_api_max_event_report_windows' '0'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'measurement_flex_api_max_event_report_windows'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        mdd_sharing)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'mdd_android_sharing_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'mdd_android_sharing_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        mdd_api)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'mdd_api_logging_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'mdd_api_logging_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        mdd_default)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'mdd_default_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'mdd_default_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        mdd_download)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'mdd_download_events_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'mdd_download_events_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        mdd_group)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'mdd_group_stats_logging_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'mdd_group_stats_logging_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        mdd_mobstore)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'mdd_mobstore_file_service_stats_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'mdd_mobstore_file_service_stats_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        mdd_netstats)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'mdd_network_stats_logging_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'mdd_network_stats_logging_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        mdd_storage)
            if [ "$mode" = "1" ]; then
        device_config put 'adservices' 'mdd_storage_stats_logging_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'adservices' 'mdd_storage_stats_logging_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        aic_net)
            if [ "$mode" = "1" ]; then
        device_config put 'aicore' 'AicModels__network_stats_log_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'aicore' 'AicModels__network_stats_log_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        aic_group)
            if [ "$mode" = "1" ]; then
        device_config put 'aicore' 'AicModels__group_stats_log_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'aicore' 'AicModels__group_stats_log_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        aic_storage)
            if [ "$mode" = "1" ]; then
        device_config put 'aicore' 'AicModels__storage_stats_log_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'aicore' 'AicModels__storage_stats_log_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        aic_api)
            if [ "$mode" = "1" ]; then
        device_config put 'aicore' 'AicModels__api_log_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'aicore' 'AicModels__api_log_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        aic_default)
            if [ "$mode" = "1" ]; then
        device_config put 'aicore' 'AicModels__default_log_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'aicore' 'AicModels__default_log_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        rt_mods)
            if [ "$mode" = "1" ]; then
        device_config put 'runtime_native' 'metrics.reporting-mods' '0'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'runtime_native' 'metrics.reporting-mods'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        rt_mods_srv)
            if [ "$mode" = "1" ]; then
        device_config put 'runtime_native' 'metrics.reporting-mods-server' '0'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'runtime_native' 'metrics.reporting-mods-server'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        rt_nummods)
            if [ "$mode" = "1" ]; then
        device_config put 'runtime_native' 'metrics.reporting-num-mods' '0'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'runtime_native' 'metrics.reporting-num-mods'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        rt_nummods_srv)
            if [ "$mode" = "1" ]; then
        device_config put 'runtime_native' 'metrics.reporting-num-mods-server' '0'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'runtime_native' 'metrics.reporting-num-mods-server'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        rt_statsd)
            if [ "$mode" = "1" ]; then
        device_config put 'runtime_native' 'metrics.write-to-statsd' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'runtime_native' 'metrics.write-to-statsd'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        rt_spec)
            if [ "$mode" = "1" ]; then
        device_config put 'runtime_native' 'metrics.reporting-spec' ''
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'runtime_native' 'metrics.reporting-spec'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        rt_spec_srv)
            if [ "$mode" = "1" ]; then
        device_config put 'runtime_native' 'metrics.reporting-spec-server' ''
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'runtime_native' 'metrics.reporting-spec-server'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        odp_err)
            if [ "$mode" = "1" ]; then
        device_config put 'on_device_personalization' 'odp_enable_client_error_logging' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'on_device_personalization' 'odp_enable_client_error_logging'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        odp_bgjobs)
            if [ "$mode" = "1" ]; then
        device_config put 'on_device_personalization' 'odp_background_jobs_logging_enabled' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'on_device_personalization' 'odp_background_jobs_logging_enabled'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        odp_bgjobs_rate)
            if [ "$mode" = "1" ]; then
        device_config put 'on_device_personalization' 'odp_background_job_sampling_logging_rate' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'on_device_personalization' 'odp_background_job_sampling_logging_rate'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        fcp_err)
            if [ "$mode" = "1" ]; then
        device_config put 'on_device_personalization' 'fcp_enable_client_error_logging' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'on_device_personalization' 'fcp_enable_client_error_logging'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        fcp_bgjobs)
            if [ "$mode" = "1" ]; then
        device_config put 'on_device_personalization' 'fcp_enable_background_jobs_logging' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'on_device_personalization' 'fcp_enable_background_jobs_logging'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        fcp_bgjobs_rate)
            if [ "$mode" = "1" ]; then
        device_config put 'on_device_personalization' 'fcp_background_job_logging_sampling_rate' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'on_device_personalization' 'fcp_background_job_logging_sampling_rate'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        odad_westworld)
            if [ "$mode" = "1" ]; then
        device_config put 'odad' 'westworld_logging' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'odad' 'westworld_logging'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        odad_err_id)
            if [ "$mode" = "1" ]; then
        device_config put 'odad' 'log_error_model_id_westworld_enabled' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'odad' 'log_error_model_id_westworld_enabled'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        odad_model_id)
            if [ "$mode" = "1" ]; then
        device_config put 'odad' 'log_model_id_westworld' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'odad' 'log_model_id_westworld'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        odad_model_ver)
            if [ "$mode" = "1" ]; then
        device_config put 'odad' 'log_model_version_westworld' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'odad' 'log_model_version_westworld'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        odad_latency)
            if [ "$mode" = "1" ]; then
        device_config put 'odad' 'log_classification_latency_westworld' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'odad' 'log_classification_latency_westworld'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        odad_moirai)
            if [ "$mode" = "1" ]; then
        device_config put 'odad' 'moirai_additional_metrics_enabled' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'odad' 'moirai_additional_metrics_enabled'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        odad_mismatch)
            if [ "$mode" = "1" ]; then
        device_config put 'odad' 'mismatch_metrics_v2_enabled' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'odad' 'mismatch_metrics_v2_enabled'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        dps_aiai)
            if [ "$mode" = "1" ]; then
        device_config put 'device_personalization_services' 'Logging__enable_aiai_clearcut_logging' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'device_personalization_services' 'Logging__enable_aiai_clearcut_logging'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        dps_autofill)
            if [ "$mode" = "1" ]; then
        device_config put 'device_personalization_services' 'AutofillVC__enable_clearcut_log' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'device_personalization_services' 'AutofillVC__enable_clearcut_log'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        dps_captions)
            if [ "$mode" = "1" ]; then
        device_config put 'device_personalization_services' 'Captions__enable_clearcut_logging' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'device_personalization_services' 'Captions__enable_clearcut_logging'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        dps_platform)
            if [ "$mode" = "1" ]; then
        device_config put 'device_personalization_services' 'PlatformLogging__enable_metric_wise_populations' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'device_personalization_services' 'PlatformLogging__enable_metric_wise_populations'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        dps_superpacks)
            if [ "$mode" = "1" ]; then
        device_config put 'device_personalization_services' 'Superpacks__use_logging_listener' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'device_personalization_services' 'Superpacks__use_logging_listener'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        dps_overview_clearcut)
            if [ "$mode" = "1" ]; then
        device_config put 'device_personalization_services' 'Overview__enable_pir_clearcut_logging' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'device_personalization_services' 'Overview__enable_pir_clearcut_logging'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        dps_overview_ww)
            if [ "$mode" = "1" ]; then
        device_config put 'device_personalization_services' 'Overview__enable_pir_westworld_logging' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'device_personalization_services' 'Overview__enable_pir_westworld_logging'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        dps_stats_active)
            if [ "$mode" = "1" ]; then
        device_config put 'device_personalization_services' 'StatsLog__active_users_logger_enabled' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'device_personalization_services' 'StatsLog__active_users_logger_enabled'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        dps_stats_nonpersist)
            if [ "$mode" = "1" ]; then
        device_config put 'device_personalization_services' 'StatsLog__active_users_logger_non_persistent' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'device_personalization_services' 'StatsLog__active_users_logger_non_persistent'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        dps_stats_newapi)
            if [ "$mode" = "1" ]; then
        device_config put 'device_personalization_services' 'StatsLog__enable_new_logger_api' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'device_personalization_services' 'StatsLog__enable_new_logger_api'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        am_fgs_allow)
            if [ "$mode" = "1" ]; then
        device_config put 'activity_manager' 'fgs_start_allowed_log_sample_rate' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'activity_manager' 'fgs_start_allowed_log_sample_rate'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        am_fgs_deny)
            if [ "$mode" = "1" ]; then
        device_config put 'activity_manager' 'fgs_start_denied_log_sample_rate' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'activity_manager' 'fgs_start_denied_log_sample_rate'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        am_fgs_atom)
            if [ "$mode" = "1" ]; then
        device_config put 'activity_manager' 'fgs_atom_sample_rate' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'activity_manager' 'fgs_atom_sample_rate'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        am_compact)
            if [ "$mode" = "1" ]; then
        device_config put 'activity_manager' 'compact_statsd_sample_rate' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'activity_manager' 'compact_statsd_sample_rate'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        am_freeze)
            if [ "$mode" = "1" ]; then
        device_config put 'activity_manager' 'freeze_statsd_sample_rate' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'activity_manager' 'freeze_statsd_sample_rate'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        am_pss)
            if [ "$mode" = "1" ]; then
        device_config put 'activity_manager' 'disable_app_profiler_pss_profiling' 'true'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'activity_manager' 'disable_app_profiler_pss_profiling'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        jank_enabled)
            if [ "$mode" = "1" ]; then
        device_config put 'interaction_jank_monitor' 'enabled' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'interaction_jank_monitor' 'enabled'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        jank_sampling)
            if [ "$mode" = "1" ]; then
        device_config put 'interaction_jank_monitor' 'sampling_interval' '60000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'interaction_jank_monitor' 'sampling_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        jank_frametime)
            if [ "$mode" = "1" ]; then
        device_config put 'interaction_jank_monitor' 'trace_threshold_frame_time_millis' '200'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'interaction_jank_monitor' 'trace_threshold_frame_time_millis'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        jank_missedframes)
            if [ "$mode" = "1" ]; then
        device_config put 'interaction_jank_monitor' 'trace_threshold_missed_frames' '24'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'interaction_jank_monitor' 'trace_threshold_missed_frames'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        wm_gesture_debounce)
            if [ "$mode" = "1" ]; then
        device_config put 'window_manager' 'system_gesture_exclusion_log_debounce_millis' '10000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'window_manager' 'system_gesture_exclusion_log_debounce_millis'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        lat_enabled)
            if [ "$mode" = "1" ]; then
        device_config put 'latency_tracker' 'enabled' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'latency_tracker' 'enabled'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        lat_sampling)
            if [ "$mode" = "1" ]; then
        device_config put 'latency_tracker' 'sampling_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'latency_tracker' 'sampling_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        lat_voice_enable)
            if [ "$mode" = "1" ]; then
        device_config put 'latency_tracker' 'action_show_voice_interaction_enable' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'latency_tracker' 'action_show_voice_interaction_enable'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        lat_voice_sampling)
            if [ "$mode" = "1" ]; then
        device_config put 'latency_tracker' 'action_show_voice_interaction_sample_interval' '86400000'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'latency_tracker' 'action_show_voice_interaction_sample_interval'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        tel_logcat_read)
            if [ "$mode" = "1" ]; then
        device_config put 'telephony' 'logcat_read_timeout_millis' '200'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'telephony' 'logcat_read_timeout_millis'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        tel_dumpsys_read)
            if [ "$mode" = "1" ]; then
        device_config put 'telephony' 'dumpsys_read_timeout_millis' '200'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'telephony' 'dumpsys_read_timeout_millis'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        tel_logcat_proc)
            if [ "$mode" = "1" ]; then
        device_config put 'telephony' 'logcat_proc_timeout_millis' '200'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'telephony' 'logcat_proc_timeout_millis'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        tel_dumpsys_proc)
            if [ "$mode" = "1" ]; then
        device_config put 'telephony' 'dumpsys_proc_timeout_millis' '200'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'telephony' 'dumpsys_proc_timeout_millis'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        tel_lines_lowmem)
            if [ "$mode" = "1" ]; then
        device_config put 'telephony' 'max_logcat_lines_low_mem' '500'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'telephony' 'max_logcat_lines_low_mem'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        tel_lines)
            if [ "$mode" = "1" ]; then
        device_config put 'telephony' 'max_logcat_lines' '500'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'telephony' 'max_logcat_lines'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        misc_settings_evt)
            if [ "$mode" = "1" ]; then
        device_config put 'settings_ui' 'event_logging_enabled' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'settings_ui' 'event_logging_enabled'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        misc_smartselect_anim)
            if [ "$mode" = "1" ]; then
        device_config put 'textclassifier' 'smart_select_animation_enabled' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'textclassifier' 'smart_select_animation_enabled'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        net_apexdata)
            if [ "$mode" = "1" ]; then
        device_config put 'tethering' 'netstats_store_files_in_apexdata' 'false'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'tethering' 'netstats_store_files_in_apexdata'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        net_legacy_import)
            if [ "$mode" = "1" ]; then
        device_config put 'tethering' 'netstats_import_legacy_target_attempts' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'tethering' 'netstats_import_legacy_target_attempts'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        lmkd_minfree)
            if [ "$mode" = "1" ]; then
        device_config put 'lmkd_native' 'use_minfree_levels' 'true'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'lmkd_native' 'use_minfree_levels'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        lmkd_thrash)
            if [ "$mode" = "1" ]; then
        device_config put 'lmkd_native' 'thrashing_limit_critical' '70'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'lmkd_native' 'thrashing_limit_critical'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        cap_history)
            if [ "$mode" = "1" ]; then
        device_config put 'content_capture' 'log_history_size' '1'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'content_capture' 'log_history_size'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        cap_buffer)
            if [ "$mode" = "1" ]; then
        device_config put 'content_capture' 'max_buffer_size' '8'
        [ $? -eq 0 ] || return 1
            else
        device_config delete 'content_capture' 'max_buffer_size'
        [ $? -eq 0 ] || return 1
            fi
            return 0
            ;;
        *) return 2 ;;
    esac
}

# ── _lq_trace_guard_emit_on() ──
# Emit a replayable command for a persisted slider level. _lq_trace_guard_persist
# must WRITE commands into the startup script rather than execute them while
# building that script.
_lq_trace_guard_emit_slider() {
    local id="$1" level="$2" ns key value
    case "$id" in
        mdd_sharing) ns=adservices; key=mdd_android_sharing_sample_interval ;;
        mdd_api) ns=adservices; key=mdd_api_logging_sample_interval ;;
        mdd_default) ns=adservices; key=mdd_default_sample_interval ;;
        mdd_download) ns=adservices; key=mdd_download_events_sample_interval ;;
        mdd_group) ns=adservices; key=mdd_group_stats_logging_sample_interval ;;
        mdd_mobstore) ns=adservices; key=mdd_mobstore_file_service_stats_sample_interval ;;
        mdd_netstats) ns=adservices; key=mdd_network_stats_logging_sample_interval ;;
        mdd_storage) ns=adservices; key=mdd_storage_stats_logging_sample_interval ;;
        aic_net) ns=aicore; key=AicModels__network_stats_log_sample_interval ;;
        aic_group) ns=aicore; key=AicModels__group_stats_log_sample_interval ;;
        aic_storage) ns=aicore; key=AicModels__storage_log_sample_interval ;;
        aic_api) ns=aicore; key=AicModels__api_log_sample_interval ;;
        aic_default) ns=aicore; key=AicModels__default_log_sample_interval ;;
        jank_sampling) ns=interaction_jank_monitor; key=sampling_interval ;;
        jank_frametime) ns=interaction_jank_monitor; key=trace_threshold_frame_time_millis ;;
        jank_missedframes) ns=interaction_jank_monitor; key=trace_threshold_missed_frames ;;
        wm_gesture_debounce) ns=window_manager; key=system_gesture_exclusion_log_debounce_millis ;;
        lat_sampling) ns=latency_tracker; key=sampling_interval ;;
        lat_voice_sampling) ns=latency_tracker; key=action_show_voice_interaction_sample_interval ;;
        tel_logcat_read) ns=telephony; key=logcat_read_timeout_millis ;;
        tel_dumpsys_read) ns=telephony; key=dumpsys_read_timeout_millis ;;
        tel_logcat_proc) ns=telephony; key=logcat_proc_timeout_millis ;;
        tel_dumpsys_proc) ns=telephony; key=dumpsys_proc_timeout_millis ;;
        tel_lines_lowmem) ns=telephony; key=max_logcat_lines_low_mem ;;
        tel_lines) ns=telephony; key=max_logcat_lines ;;
        lmkd_thrash) ns=lmkd_native; key=thrashing_limit_critical ;;
        cap_history) ns=content_capture; key=log_history_size ;;
        cap_buffer) ns=content_capture; key=max_buffer_size ;;
        *) return 2 ;;
    esac
    case "$id:$level" in
        mdd_sharing:[1-4]|mdd_api:[1-4]|mdd_default:[1-4]|mdd_download:[1-4]|mdd_group:[1-4]|mdd_mobstore:[1-4]|mdd_netstats:[1-4]|mdd_storage:[1-4]|aic_net:[1-4]|aic_group:[1-4]|aic_storage:[1-4]|aic_api:[1-4]|aic_default:[1-4]|lat_sampling:[1-4]|lat_voice_sampling:[1-4])
            case "$level" in 1) value=3600000;; 2) value=21600000;; 3) value=43200000;; 4) value=86400000;; esac ;;
        jank_sampling:1) value=1000;; jank_sampling:2) value=5000;; jank_sampling:3) value=30000;; jank_sampling:4) value=60000;;
        jank_frametime:1) value=80;; jank_frametime:2) value=120;; jank_frametime:3) value=160;; jank_frametime:4) value=200;;
        jank_missedframes:1) value=8;; jank_missedframes:2) value=12;; jank_missedframes:3) value=16;; jank_missedframes:4) value=24;;
        wm_gesture_debounce:1) value=1000;; wm_gesture_debounce:2) value=3000;; wm_gesture_debounce:3) value=6000;; wm_gesture_debounce:4) value=10000;;
        tel_logcat_read:1|tel_dumpsys_read:1|tel_logcat_proc:1|tel_dumpsys_proc:1) value=2000;;
        tel_logcat_read:2|tel_dumpsys_read:2|tel_logcat_proc:2|tel_dumpsys_proc:2) value=1000;;
        tel_logcat_read:3|tel_dumpsys_read:3|tel_logcat_proc:3|tel_dumpsys_proc:3) value=500;;
        tel_logcat_read:4|tel_dumpsys_read:4|tel_logcat_proc:4|tel_dumpsys_proc:4) value=200;;
        tel_lines_lowmem:1|tel_lines:1) value=2000;; tel_lines_lowmem:2|tel_lines:2) value=1500;; tel_lines_lowmem:3|tel_lines:3) value=1000;; tel_lines_lowmem:4|tel_lines:4) value=500;;
        lmkd_thrash:1) value=40;; lmkd_thrash:2) value=50;; lmkd_thrash:3) value=60;; lmkd_thrash:4) value=70;;
        cap_history:1) value=10;; cap_history:2) value=8;; cap_history:3) value=4;; cap_history:4) value=1;;
        cap_buffer:1) value=32;; cap_buffer:2) value=24;; cap_buffer:3) value=16;; cap_buffer:4) value=8;;
        *) return 2 ;;
    esac
    printf '%s\n' "device_config put '$ns' '$key' '$value'"
    return 0
}

_lq_trace_guard_emit_on() {
    case "$1" in
        # Slider-backed items are persisted as their exact selected level.
        cap_buffer|cap_history|mdd_api|mdd_mobstore|mdd_group|mdd_sharing|mdd_default|mdd_download|mdd_storage|mdd_netstats|jank_sampling|jank_missedframes|jank_frametime|wm_gesture_debounce|lat_sampling|lat_voice_sampling|tel_logcat_read|tel_logcat_proc|tel_dumpsys_proc|tel_lines|tel_lines_lowmem|tel_dumpsys_read|lmkd_thrash|aic_group|aic_net|aic_default|aic_storage|aic_api)
            _lq_trace_guard_emit_slider "$1" "$(cat "$LQ_TRACE_GUARD_STATE_DIR/$1" 2>/dev/null)"
            ;;
        
        ads_sys_service)
            device_config put 'adservices' 'adservice_system_service_enabled' 'false'
            ;;
        ads_cobalt)
            device_config put 'adservices' 'cobalt_logging_enabled' 'false'
            ;;
        ads_logged_topic)
            device_config put 'adservices' 'enable_logged_topic' 'false'
            ;;
        ads_error_logging)
            device_config put 'adservices' 'adservice_error_logging_enabled' 'false'
            ;;
        ads_pkg_logging)
            device_config put 'adservices' 'measurement_enable_app_package_name_logging' 'false'
            ;;
        ads_source_debug)
            device_config put 'adservices' 'measurement_enable_source_debug_report' 'false'
            ;;
        ads_fledge_pkg)
            device_config put 'adservices' 'fledge_app_package_name_logging' 'false'
            ;;
        ads_fledge_debug)
            device_config put 'adservices' 'fledge_auction_server_enable_debug_reporting' 'false'
            ;;
        ads_fledge_usage)
            device_config put 'adservices' 'fledge_auction_server_api_usage_metrics_enabled' 'false'
            ;;
        ads_fledge_event)
            device_config put 'adservices' 'fledge_auction_server_enabled_for_report_event' 'false'
            ;;
        ads_fledge_impr)
            device_config put 'adservices' 'fledge_auction_server_enabled_for_report_impression' 'false'
            ;;
        ads_fledge_med)
            device_config put 'adservices' 'fledge_auction_server_enabled_for_select_ads_mediation' 'false'
            ;;
        ads_net_verbose)
            device_config put 'adservices' 'measurement_verbose_debug_reporting_job_required_network_type' '1'
            ;;
        ads_net_dbg_fb)
            device_config put 'adservices' 'measurement_debug_reporting_fallback_job_required_network_type' '1'
            ;;
        ads_net_dbg)
            device_config put 'adservices' 'measurement_debug_reporting_job_required_network_type' '1'
            ;;
        ads_net_agg_fb)
            device_config put 'adservices' 'measurement_aggregate_fallback_reporting_job_required_network_type' '1'
            ;;
        ads_net_agg)
            device_config put 'adservices' 'measurement_aggregate_reporting_job_required_network_type' '1'
            ;;
        ads_net_async_fb)
            device_config put 'adservices' 'measurement_async_registration_fallback_job_required_network_type' '1'
            ;;
        ads_net_async)
            device_config put 'adservices' 'measurement_async_registration_queue_job_required_network_type' '1'
            ;;
        ads_net_evt_fb)
            device_config put 'adservices' 'measurement_event_fallback_reporting_job_required_network_type' '1'
            ;;
        ads_net_evt)
            device_config put 'adservices' 'measurement_event_reporting_job_required_network_type' '1'
            ;;
        ads_ks_agg_fb)
            device_config put 'adservices' 'measurement_job_aggregate_fallback_reporting_kill_switch' 'false'
            ;;
        ads_ks_agg)
            device_config put 'adservices' 'measurement_job_aggregate_reporting_kill_switch' 'false'
            ;;
        ads_ks_evt_fb)
            device_config put 'adservices' 'measurement_job_event_fallback_reporting_kill_switch' 'false'
            ;;
        ads_ks_evt)
            device_config put 'adservices' 'measurement_job_event_reporting_kill_switch' 'false'
            ;;
        ads_flex_reports)
            device_config put 'adservices' 'measurement_flex_api_max_event_reports' '0'
            ;;
        ads_flex_windows)
            device_config put 'adservices' 'measurement_flex_api_max_event_report_windows' '0'
            ;;
        mdd_sharing)
            device_config put 'adservices' 'mdd_android_sharing_sample_interval' '86400000'
            ;;
        mdd_api)
            device_config put 'adservices' 'mdd_api_logging_sample_interval' '86400000'
            ;;
        mdd_default)
            device_config put 'adservices' 'mdd_default_sample_interval' '86400000'
            ;;
        mdd_download)
            device_config put 'adservices' 'mdd_download_events_sample_interval' '86400000'
            ;;
        mdd_group)
            device_config put 'adservices' 'mdd_group_stats_logging_sample_interval' '86400000'
            ;;
        mdd_mobstore)
            device_config put 'adservices' 'mdd_mobstore_file_service_stats_sample_interval' '86400000'
            ;;
        mdd_netstats)
            device_config put 'adservices' 'mdd_network_stats_logging_sample_interval' '86400000'
            ;;
        mdd_storage)
            device_config put 'adservices' 'mdd_storage_stats_logging_sample_interval' '86400000'
            ;;
        aic_net)
            device_config put 'aicore' 'AicModels__network_stats_log_sample_interval' '86400000'
            ;;
        aic_group)
            device_config put 'aicore' 'AicModels__group_stats_log_sample_interval' '86400000'
            ;;
        aic_storage)
            device_config put 'aicore' 'AicModels__storage_stats_log_sample_interval' '86400000'
            ;;
        aic_api)
            device_config put 'aicore' 'AicModels__api_log_sample_interval' '86400000'
            ;;
        aic_default)
            device_config put 'aicore' 'AicModels__default_log_sample_interval' '86400000'
            ;;
        rt_mods)
            device_config put 'runtime_native' 'metrics.reporting-mods' '0'
            ;;
        rt_mods_srv)
            device_config put 'runtime_native' 'metrics.reporting-mods-server' '0'
            ;;
        rt_nummods)
            device_config put 'runtime_native' 'metrics.reporting-num-mods' '0'
            ;;
        rt_nummods_srv)
            device_config put 'runtime_native' 'metrics.reporting-num-mods-server' '0'
            ;;
        rt_statsd)
            device_config put 'runtime_native' 'metrics.write-to-statsd' 'false'
            ;;
        rt_spec)
            device_config put 'runtime_native' 'metrics.reporting-spec' ''
            ;;
        rt_spec_srv)
            device_config put 'runtime_native' 'metrics.reporting-spec-server' ''
            ;;
        odp_err)
            device_config put 'on_device_personalization' 'odp_enable_client_error_logging' 'false'
            ;;
        odp_bgjobs)
            device_config put 'on_device_personalization' 'odp_background_jobs_logging_enabled' 'false'
            ;;
        odp_bgjobs_rate)
            device_config put 'on_device_personalization' 'odp_background_job_sampling_logging_rate' '1'
            ;;
        fcp_err)
            device_config put 'on_device_personalization' 'fcp_enable_client_error_logging' 'false'
            ;;
        fcp_bgjobs)
            device_config put 'on_device_personalization' 'fcp_enable_background_jobs_logging' 'false'
            ;;
        fcp_bgjobs_rate)
            device_config put 'on_device_personalization' 'fcp_background_job_logging_sampling_rate' '1'
            ;;
        odad_westworld)
            device_config put 'odad' 'westworld_logging' 'false'
            ;;
        odad_err_id)
            device_config put 'odad' 'log_error_model_id_westworld_enabled' 'false'
            ;;
        odad_model_id)
            device_config put 'odad' 'log_model_id_westworld' 'false'
            ;;
        odad_model_ver)
            device_config put 'odad' 'log_model_version_westworld' 'false'
            ;;
        odad_latency)
            device_config put 'odad' 'log_classification_latency_westworld' 'false'
            ;;
        odad_moirai)
            device_config put 'odad' 'moirai_additional_metrics_enabled' 'false'
            ;;
        odad_mismatch)
            device_config put 'odad' 'mismatch_metrics_v2_enabled' 'false'
            ;;
        dps_aiai)
            device_config put 'device_personalization_services' 'Logging__enable_aiai_clearcut_logging' 'false'
            ;;
        dps_autofill)
            device_config put 'device_personalization_services' 'AutofillVC__enable_clearcut_log' 'false'
            ;;
        dps_captions)
            device_config put 'device_personalization_services' 'Captions__enable_clearcut_logging' 'false'
            ;;
        dps_platform)
            device_config put 'device_personalization_services' 'PlatformLogging__enable_metric_wise_populations' 'false'
            ;;
        dps_superpacks)
            device_config put 'device_personalization_services' 'Superpacks__use_logging_listener' 'false'
            ;;
        dps_overview_clearcut)
            device_config put 'device_personalization_services' 'Overview__enable_pir_clearcut_logging' 'false'
            ;;
        dps_overview_ww)
            device_config put 'device_personalization_services' 'Overview__enable_pir_westworld_logging' 'false'
            ;;
        dps_stats_active)
            device_config put 'device_personalization_services' 'StatsLog__active_users_logger_enabled' 'false'
            ;;
        dps_stats_nonpersist)
            device_config put 'device_personalization_services' 'StatsLog__active_users_logger_non_persistent' 'false'
            ;;
        dps_stats_newapi)
            device_config put 'device_personalization_services' 'StatsLog__enable_new_logger_api' 'false'
            ;;
        am_fgs_allow)
            device_config put 'activity_manager' 'fgs_start_allowed_log_sample_rate' '1'
            ;;
        am_fgs_deny)
            device_config put 'activity_manager' 'fgs_start_denied_log_sample_rate' '1'
            ;;
        am_fgs_atom)
            device_config put 'activity_manager' 'fgs_atom_sample_rate' '1'
            ;;
        am_compact)
            device_config put 'activity_manager' 'compact_statsd_sample_rate' '1'
            ;;
        am_freeze)
            device_config put 'activity_manager' 'freeze_statsd_sample_rate' '1'
            ;;
        am_pss)
            device_config put 'activity_manager' 'disable_app_profiler_pss_profiling' 'true'
            ;;
        jank_enabled)
            device_config put 'interaction_jank_monitor' 'enabled' 'false'
            ;;
        jank_sampling)
            device_config put 'interaction_jank_monitor' 'sampling_interval' '60000'
            ;;
        jank_frametime)
            device_config put 'interaction_jank_monitor' 'trace_threshold_frame_time_millis' '200'
            ;;
        jank_missedframes)
            device_config put 'interaction_jank_monitor' 'trace_threshold_missed_frames' '24'
            ;;
        wm_gesture_debounce)
            device_config put 'window_manager' 'system_gesture_exclusion_log_debounce_millis' '10000'
            ;;
        lat_enabled)
            device_config put 'latency_tracker' 'enabled' 'false'
            ;;
        lat_sampling)
            device_config put 'latency_tracker' 'sampling_interval' '86400000'
            ;;
        lat_voice_enable)
            device_config put 'latency_tracker' 'action_show_voice_interaction_enable' 'false'
            ;;
        lat_voice_sampling)
            device_config put 'latency_tracker' 'action_show_voice_interaction_sample_interval' '86400000'
            ;;
        tel_logcat_read)
            device_config put 'telephony' 'logcat_read_timeout_millis' '200'
            ;;
        tel_dumpsys_read)
            device_config put 'telephony' 'dumpsys_read_timeout_millis' '200'
            ;;
        tel_logcat_proc)
            device_config put 'telephony' 'logcat_proc_timeout_millis' '200'
            ;;
        tel_dumpsys_proc)
            device_config put 'telephony' 'dumpsys_proc_timeout_millis' '200'
            ;;
        tel_lines_lowmem)
            device_config put 'telephony' 'max_logcat_lines_low_mem' '500'
            ;;
        tel_lines)
            device_config put 'telephony' 'max_logcat_lines' '500'
            ;;
        misc_settings_evt)
            device_config put 'settings_ui' 'event_logging_enabled' 'false'
            ;;
        misc_smartselect_anim)
            device_config put 'textclassifier' 'smart_select_animation_enabled' 'false'
            ;;
        net_apexdata)
            device_config put 'tethering' 'netstats_store_files_in_apexdata' 'false'
            ;;
        net_legacy_import)
            device_config put 'tethering' 'netstats_import_legacy_target_attempts' '1'
            ;;
        lmkd_minfree)
            device_config put 'lmkd_native' 'use_minfree_levels' 'true'
            ;;
        lmkd_thrash)
            device_config put 'lmkd_native' 'thrashing_limit_critical' '70'
            ;;
        cap_history)
            device_config put 'content_capture' 'log_history_size' '1'
            ;;
        cap_buffer)
            device_config put 'content_capture' 'max_buffer_size' '8'
            ;;
        *) return 2 ;;
    esac
}

# ── _lq_trace_guard_apply_preset_default() ──
_lq_trace_guard_apply_preset_default() {
    device_config delete 'adservices' 'adservice_system_service_enabled' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'cobalt_logging_enabled' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'enable_logged_topic' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'adservice_error_logging_enabled' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_enable_app_package_name_logging' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_enable_source_debug_report' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'fledge_app_package_name_logging' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'fledge_auction_server_enable_debug_reporting' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'fledge_auction_server_api_usage_metrics_enabled' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'fledge_auction_server_enabled_for_report_event' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'fledge_auction_server_enabled_for_report_impression' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'fledge_auction_server_enabled_for_select_ads_mediation' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_verbose_debug_reporting_job_required_network_type' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_debug_reporting_fallback_job_required_network_type' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_debug_reporting_job_required_network_type' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_aggregate_fallback_reporting_job_required_network_type' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_aggregate_reporting_job_required_network_type' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_async_registration_fallback_job_required_network_type' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_async_registration_queue_job_required_network_type' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_event_fallback_reporting_job_required_network_type' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_event_reporting_job_required_network_type' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_job_aggregate_fallback_reporting_kill_switch' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_job_aggregate_reporting_kill_switch' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_job_event_fallback_reporting_kill_switch' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_job_event_reporting_kill_switch' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_flex_api_max_event_reports' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'measurement_flex_api_max_event_report_windows' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'mdd_android_sharing_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'mdd_api_logging_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'mdd_default_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'mdd_download_events_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'mdd_group_stats_logging_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'mdd_mobstore_file_service_stats_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'mdd_network_stats_logging_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'adservices' 'mdd_storage_stats_logging_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'aicore' 'AicModels__network_stats_log_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'aicore' 'AicModels__group_stats_log_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'aicore' 'AicModels__storage_stats_log_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'aicore' 'AicModels__api_log_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'aicore' 'AicModels__default_log_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'runtime_native' 'metrics.reporting-mods' >/dev/null 2>&1 || true
    device_config delete 'runtime_native' 'metrics.reporting-mods-server' >/dev/null 2>&1 || true
    device_config delete 'runtime_native' 'metrics.reporting-num-mods' >/dev/null 2>&1 || true
    device_config delete 'runtime_native' 'metrics.reporting-num-mods-server' >/dev/null 2>&1 || true
    device_config delete 'runtime_native' 'metrics.write-to-statsd' >/dev/null 2>&1 || true
    device_config delete 'runtime_native' 'metrics.reporting-spec' >/dev/null 2>&1 || true
    device_config delete 'runtime_native' 'metrics.reporting-spec-server' >/dev/null 2>&1 || true
    device_config delete 'on_device_personalization' 'odp_enable_client_error_logging' >/dev/null 2>&1 || true
    device_config delete 'on_device_personalization' 'odp_background_jobs_logging_enabled' >/dev/null 2>&1 || true
    device_config delete 'on_device_personalization' 'odp_background_job_sampling_logging_rate' >/dev/null 2>&1 || true
    device_config delete 'on_device_personalization' 'fcp_enable_client_error_logging' >/dev/null 2>&1 || true
    device_config delete 'on_device_personalization' 'fcp_enable_background_jobs_logging' >/dev/null 2>&1 || true
    device_config delete 'on_device_personalization' 'fcp_background_job_logging_sampling_rate' >/dev/null 2>&1 || true
    device_config delete 'odad' 'westworld_logging' >/dev/null 2>&1 || true
    device_config delete 'odad' 'log_error_model_id_westworld_enabled' >/dev/null 2>&1 || true
    device_config delete 'odad' 'log_model_id_westworld' >/dev/null 2>&1 || true
    device_config delete 'odad' 'log_model_version_westworld' >/dev/null 2>&1 || true
    device_config delete 'odad' 'log_classification_latency_westworld' >/dev/null 2>&1 || true
    device_config delete 'odad' 'moirai_additional_metrics_enabled' >/dev/null 2>&1 || true
    device_config delete 'odad' 'mismatch_metrics_v2_enabled' >/dev/null 2>&1 || true
    device_config delete 'device_personalization_services' 'Logging__enable_aiai_clearcut_logging' >/dev/null 2>&1 || true
    device_config delete 'device_personalization_services' 'AutofillVC__enable_clearcut_log' >/dev/null 2>&1 || true
    device_config delete 'device_personalization_services' 'Captions__enable_clearcut_logging' >/dev/null 2>&1 || true
    device_config delete 'device_personalization_services' 'PlatformLogging__enable_metric_wise_populations' >/dev/null 2>&1 || true
    device_config delete 'device_personalization_services' 'Superpacks__use_logging_listener' >/dev/null 2>&1 || true
    device_config delete 'device_personalization_services' 'Overview__enable_pir_clearcut_logging' >/dev/null 2>&1 || true
    device_config delete 'device_personalization_services' 'Overview__enable_pir_westworld_logging' >/dev/null 2>&1 || true
    device_config delete 'device_personalization_services' 'StatsLog__active_users_logger_enabled' >/dev/null 2>&1 || true
    device_config delete 'device_personalization_services' 'StatsLog__active_users_logger_non_persistent' >/dev/null 2>&1 || true
    device_config delete 'device_personalization_services' 'StatsLog__enable_new_logger_api' >/dev/null 2>&1 || true
    device_config delete 'activity_manager' 'fgs_start_allowed_log_sample_rate' >/dev/null 2>&1 || true
    device_config delete 'activity_manager' 'fgs_start_denied_log_sample_rate' >/dev/null 2>&1 || true
    device_config delete 'activity_manager' 'fgs_atom_sample_rate' >/dev/null 2>&1 || true
    device_config delete 'activity_manager' 'compact_statsd_sample_rate' >/dev/null 2>&1 || true
    device_config delete 'activity_manager' 'freeze_statsd_sample_rate' >/dev/null 2>&1 || true
    device_config delete 'activity_manager' 'disable_app_profiler_pss_profiling' >/dev/null 2>&1 || true
    device_config delete 'interaction_jank_monitor' 'enabled' >/dev/null 2>&1 || true
    device_config delete 'interaction_jank_monitor' 'sampling_interval' >/dev/null 2>&1 || true
    device_config delete 'interaction_jank_monitor' 'trace_threshold_frame_time_millis' >/dev/null 2>&1 || true
    device_config delete 'interaction_jank_monitor' 'trace_threshold_missed_frames' >/dev/null 2>&1 || true
    device_config delete 'window_manager' 'system_gesture_exclusion_log_debounce_millis' >/dev/null 2>&1 || true
    device_config delete 'latency_tracker' 'enabled' >/dev/null 2>&1 || true
    device_config delete 'latency_tracker' 'sampling_interval' >/dev/null 2>&1 || true
    device_config delete 'latency_tracker' 'action_show_voice_interaction_enable' >/dev/null 2>&1 || true
    device_config delete 'latency_tracker' 'action_show_voice_interaction_sample_interval' >/dev/null 2>&1 || true
    device_config delete 'telephony' 'logcat_read_timeout_millis' >/dev/null 2>&1 || true
    device_config delete 'telephony' 'dumpsys_read_timeout_millis' >/dev/null 2>&1 || true
    device_config delete 'telephony' 'logcat_proc_timeout_millis' >/dev/null 2>&1 || true
    device_config delete 'telephony' 'dumpsys_proc_timeout_millis' >/dev/null 2>&1 || true
    device_config delete 'telephony' 'max_logcat_lines_low_mem' >/dev/null 2>&1 || true
    device_config delete 'telephony' 'max_logcat_lines' >/dev/null 2>&1 || true
    device_config delete 'settings_ui' 'event_logging_enabled' >/dev/null 2>&1 || true
    device_config delete 'textclassifier' 'smart_select_animation_enabled' >/dev/null 2>&1 || true
    device_config delete 'tethering' 'netstats_store_files_in_apexdata' >/dev/null 2>&1 || true
    device_config delete 'tethering' 'netstats_import_legacy_target_attempts' >/dev/null 2>&1 || true
    device_config delete 'lmkd_native' 'use_minfree_levels' >/dev/null 2>&1 || true
    device_config delete 'lmkd_native' 'thrashing_limit_critical' >/dev/null 2>&1 || true
    device_config delete 'content_capture' 'log_history_size' >/dev/null 2>&1 || true
    device_config delete 'content_capture' 'max_buffer_size' >/dev/null 2>&1 || true
    return 0
}

# ── preset profile value helpers ──
_lq_trace_guard_apply_profile_slider() {
    local id="$1" profile="${LQ_TRACE_GUARD_PROFILE:-maximum}" value="" ns="" key=""
    case "$id" in
        cap_buffer)
            ns='content_capture'; key='max_buffer_size'
            case "$profile" in
                lite) value=24 ;;
                medium) value=16 ;;
                high) value=16 ;;
                maximum) value=8 ;;
                *) return 2 ;;
            esac
            ;;
        cap_history)
            ns='content_capture'; key='log_history_size'
            case "$profile" in
                lite) value=8 ;;
                medium) value=4 ;;
                high) value=4 ;;
                maximum) value=1 ;;
                *) return 2 ;;
            esac
            ;;
        mdd_api)
            ns='adservices'; key='mdd_api_logging_sample_interval'
            case "$profile" in
                lite) value=21600000 ;;
                medium) value=43200000 ;;
                high) value=86400000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        mdd_mobstore)
            ns='adservices'; key='mdd_mobstore_file_service_stats_sample_interval'
            case "$profile" in
                lite) value=21600000 ;;
                medium) value=43200000 ;;
                high) value=86400000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        mdd_group)
            ns='adservices'; key='mdd_group_stats_logging_sample_interval'
            case "$profile" in
                lite) value=21600000 ;;
                medium) value=43200000 ;;
                high) value=86400000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        mdd_sharing)
            ns='adservices'; key='mdd_android_sharing_sample_interval'
            case "$profile" in
                lite) value=21600000 ;;
                medium) value=43200000 ;;
                high) value=86400000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        mdd_default)
            ns='adservices'; key='mdd_default_sample_interval'
            case "$profile" in
                lite) value=21600000 ;;
                medium) value=43200000 ;;
                high) value=86400000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        mdd_download)
            ns='adservices'; key='mdd_download_events_sample_interval'
            case "$profile" in
                lite) value=21600000 ;;
                medium) value=43200000 ;;
                high) value=86400000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        mdd_storage)
            ns='adservices'; key='mdd_storage_stats_logging_sample_interval'
            case "$profile" in
                lite) value=21600000 ;;
                medium) value=43200000 ;;
                high) value=86400000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        mdd_netstats)
            ns='adservices'; key='mdd_network_stats_logging_sample_interval'
            case "$profile" in
                lite) value=21600000 ;;
                medium) value=43200000 ;;
                high) value=86400000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        jank_sampling)
            ns='interaction_jank_monitor'; key='sampling_interval'
            case "$profile" in
                medium) value=5000 ;;
                high) value=30000 ;;
                maximum) value=60000 ;;
                *) return 2 ;;
            esac
            ;;
        jank_missedframes)
            ns='interaction_jank_monitor'; key='trace_threshold_missed_frames'
            case "$profile" in
                medium) value=12 ;;
                high) value=16 ;;
                maximum) value=24 ;;
                *) return 2 ;;
            esac
            ;;
        jank_frametime)
            ns='interaction_jank_monitor'; key='trace_threshold_frame_time_millis'
            case "$profile" in
                medium) value=120 ;;
                high) value=160 ;;
                maximum) value=200 ;;
                *) return 2 ;;
            esac
            ;;
        wm_gesture_debounce)
            ns='window_manager'; key='system_gesture_exclusion_log_debounce_millis'
            case "$profile" in
                medium) value=3000 ;;
                high) value=6000 ;;
                maximum) value=10000 ;;
                *) return 2 ;;
            esac
            ;;
        lat_sampling)
            ns='latency_tracker'; key='sampling_interval'
            case "$profile" in
                medium) value=21600000 ;;
                high) value=43200000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        lat_voice_sampling)
            ns='latency_tracker'; key='action_show_voice_interaction_sample_interval'
            case "$profile" in
                medium) value=21600000 ;;
                high) value=43200000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        tel_logcat_read)
            ns='telephony'; key='logcat_read_timeout_millis'
            case "$profile" in
                medium) value=1000 ;;
                high) value=500 ;;
                maximum) value=200 ;;
                *) return 2 ;;
            esac
            ;;
        tel_logcat_proc)
            ns='telephony'; key='logcat_proc_timeout_millis'
            case "$profile" in
                medium) value=1000 ;;
                high) value=500 ;;
                maximum) value=200 ;;
                *) return 2 ;;
            esac
            ;;
        tel_dumpsys_proc)
            ns='telephony'; key='dumpsys_proc_timeout_millis'
            case "$profile" in
                medium) value=1000 ;;
                high) value=500 ;;
                maximum) value=200 ;;
                *) return 2 ;;
            esac
            ;;
        tel_lines)
            ns='telephony'; key='max_logcat_lines'
            case "$profile" in
                medium) value=1500 ;;
                high) value=1000 ;;
                maximum) value=500 ;;
                *) return 2 ;;
            esac
            ;;
        tel_lines_lowmem)
            ns='telephony'; key='max_logcat_lines_low_mem'
            case "$profile" in
                medium) value=1500 ;;
                high) value=1000 ;;
                maximum) value=500 ;;
                *) return 2 ;;
            esac
            ;;
        tel_dumpsys_read)
            ns='telephony'; key='dumpsys_read_timeout_millis'
            case "$profile" in
                medium) value=1000 ;;
                high) value=500 ;;
                maximum) value=200 ;;
                *) return 2 ;;
            esac
            ;;
        lmkd_thrash)
            ns='lmkd_native'; key='thrashing_limit_critical'
            case "$profile" in
                high) value=60 ;;
                maximum) value=70 ;;
                *) return 2 ;;
            esac
            ;;
        aic_group)
            ns='aicore'; key='AicModels__group_stats_log_sample_interval'
            case "$profile" in
                lite) value=21600000 ;;
                medium) value=43200000 ;;
                high) value=86400000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        aic_net)
            ns='aicore'; key='AicModels__network_stats_log_sample_interval'
            case "$profile" in
                lite) value=21600000 ;;
                medium) value=43200000 ;;
                high) value=86400000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        aic_default)
            ns='aicore'; key='AicModels__default_log_sample_interval'
            case "$profile" in
                lite) value=21600000 ;;
                medium) value=43200000 ;;
                high) value=86400000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        aic_storage)
            ns='aicore'; key='AicModels__storage_stats_log_sample_interval'
            case "$profile" in
                lite) value=21600000 ;;
                medium) value=43200000 ;;
                high) value=86400000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        aic_api)
            ns='aicore'; key='AicModels__api_log_sample_interval'
            case "$profile" in
                lite) value=21600000 ;;
                medium) value=43200000 ;;
                high) value=86400000 ;;
                maximum) value=86400000 ;;
                *) return 2 ;;
            esac
            ;;
        *) return 2 ;;
    esac
    [ -n "$value" ] || return 2
    device_config put "$ns" "$key" "$value" >/dev/null 2>&1 || true
    return 0
}

_lq_trace_guard_apply_selected_profile() {
    local f id profile="${LQ_TRACE_GUARD_PROFILE:-maximum}"
    for f in "$LQ_TRACE_GUARD_STATE_DIR"/*; do
        [ -f "$f" ] || continue
        id="${f##*/}"
        case "$id" in cap_buffer|cap_history|mdd_api|mdd_mobstore|mdd_group|mdd_sharing|mdd_default|mdd_download|mdd_storage|mdd_netstats|jank_sampling|jank_missedframes|jank_frametime|wm_gesture_debounce|lat_sampling|lat_voice_sampling|tel_logcat_read|tel_logcat_proc|tel_dumpsys_proc|tel_lines|tel_lines_lowmem|tel_dumpsys_read|lmkd_thrash|aic_group|aic_net|aic_default|aic_storage|aic_api) _lq_trace_guard_apply_profile_slider "$id" "$profile" >/dev/null 2>&1 || true ;; *) _lq_trace_guard_apply_item "$id" 1 >/dev/null 2>&1 || true ;; esac
    done
}

_lq_trace_guard_apply_profile_lite() { LQ_TRACE_GUARD_PROFILE=lite; _lq_trace_guard_apply_selected_profile; }
_lq_trace_guard_apply_profile_medium() { LQ_TRACE_GUARD_PROFILE=medium; _lq_trace_guard_apply_selected_profile; }
_lq_trace_guard_apply_profile_high() { LQ_TRACE_GUARD_PROFILE=high; _lq_trace_guard_apply_selected_profile; }
_lq_trace_guard_apply_profile_maximum() { LQ_TRACE_GUARD_PROFILE=maximum; _lq_trace_guard_apply_selected_profile; }
# ── _lq_trace_guard_mark_profile() ──
_lq_trace_guard_mark_profile() {
    local preset="$1"
    [ -d "$LQ_TRACE_GUARD_STATE_DIR" ] || mkdir -p "$LQ_TRACE_GUARD_STATE_DIR" >/dev/null 2>&1 || return 1
    rm -f "$LQ_TRACE_GUARD_STATE_DIR"/* >/dev/null 2>&1 || true
    case "$preset" in
        default)
            :
            ;;
        lite)
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_sys_service"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_cobalt"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_logged_topic"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_error_logging"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_pkg_logging"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_source_debug"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_pkg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_debug"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_usage"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_event"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_impr"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_med"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_verbose"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_dbg_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_dbg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_agg_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_agg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_async_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_async"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_evt_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_evt"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_agg_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_agg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_evt_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_evt"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_flex_reports"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_flex_windows"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_sharing"
            ;;
        medium)
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_sys_service"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_cobalt"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_logged_topic"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_error_logging"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_pkg_logging"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_source_debug"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_pkg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_debug"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_usage"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_event"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_impr"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_med"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_verbose"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_dbg_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_dbg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_agg_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_agg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_async_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_async"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_evt_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_evt"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_agg_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_agg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_evt_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_evt"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_flex_reports"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_flex_windows"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_sharing"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_api"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_default"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_download"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_group"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_mobstore"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_netstats"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_storage"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_net"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_group"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_storage"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_api"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_default"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_mods"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_mods_srv"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_nummods"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_nummods_srv"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_statsd"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_spec"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_spec_srv"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odp_err"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odp_bgjobs"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odp_bgjobs_rate"
            : > "$LQ_TRACE_GUARD_STATE_DIR/fcp_err"
            : > "$LQ_TRACE_GUARD_STATE_DIR/fcp_bgjobs"
            : > "$LQ_TRACE_GUARD_STATE_DIR/fcp_bgjobs_rate"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_westworld"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_err_id"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_model_id"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_model_ver"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_latency"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_moirai"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_mismatch"
            ;;
        high)
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_sys_service"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_cobalt"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_logged_topic"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_error_logging"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_pkg_logging"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_source_debug"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_pkg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_debug"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_usage"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_event"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_impr"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_med"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_verbose"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_dbg_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_dbg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_agg_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_agg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_async_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_async"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_evt_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_evt"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_agg_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_agg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_evt_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_evt"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_flex_reports"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_flex_windows"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_sharing"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_api"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_default"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_download"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_group"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_mobstore"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_netstats"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_storage"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_net"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_group"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_storage"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_api"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_default"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_mods"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_mods_srv"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_nummods"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_nummods_srv"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_statsd"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_spec"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_spec_srv"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odp_err"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odp_bgjobs"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odp_bgjobs_rate"
            : > "$LQ_TRACE_GUARD_STATE_DIR/fcp_err"
            : > "$LQ_TRACE_GUARD_STATE_DIR/fcp_bgjobs"
            : > "$LQ_TRACE_GUARD_STATE_DIR/fcp_bgjobs_rate"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_westworld"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_err_id"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_model_id"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_model_ver"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_latency"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_moirai"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_mismatch"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_aiai"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_autofill"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_captions"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_platform"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_superpacks"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_overview_clearcut"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_overview_ww"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_stats_active"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_stats_nonpersist"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_stats_newapi"
            : > "$LQ_TRACE_GUARD_STATE_DIR/am_fgs_allow"
            : > "$LQ_TRACE_GUARD_STATE_DIR/am_fgs_deny"
            : > "$LQ_TRACE_GUARD_STATE_DIR/am_fgs_atom"
            : > "$LQ_TRACE_GUARD_STATE_DIR/am_compact"
            : > "$LQ_TRACE_GUARD_STATE_DIR/am_freeze"
            : > "$LQ_TRACE_GUARD_STATE_DIR/am_pss"
            : > "$LQ_TRACE_GUARD_STATE_DIR/jank_enabled"
            : > "$LQ_TRACE_GUARD_STATE_DIR/jank_sampling"
            : > "$LQ_TRACE_GUARD_STATE_DIR/jank_frametime"
            : > "$LQ_TRACE_GUARD_STATE_DIR/jank_missedframes"
            : > "$LQ_TRACE_GUARD_STATE_DIR/wm_gesture_debounce"
            : > "$LQ_TRACE_GUARD_STATE_DIR/lat_enabled"
            : > "$LQ_TRACE_GUARD_STATE_DIR/lat_sampling"
            : > "$LQ_TRACE_GUARD_STATE_DIR/lat_voice_enable"
            : > "$LQ_TRACE_GUARD_STATE_DIR/lat_voice_sampling"
            ;;
        maximum)
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_sys_service"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_cobalt"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_logged_topic"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_error_logging"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_pkg_logging"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_source_debug"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_pkg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_debug"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_usage"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_event"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_impr"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_fledge_med"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_verbose"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_dbg_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_dbg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_agg_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_agg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_async_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_async"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_evt_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_net_evt"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_agg_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_agg"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_evt_fb"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_ks_evt"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_flex_reports"
            : > "$LQ_TRACE_GUARD_STATE_DIR/ads_flex_windows"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_sharing"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_api"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_default"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_download"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_group"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_mobstore"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_netstats"
            : > "$LQ_TRACE_GUARD_STATE_DIR/mdd_storage"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_net"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_group"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_storage"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_api"
            : > "$LQ_TRACE_GUARD_STATE_DIR/aic_default"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_mods"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_mods_srv"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_nummods"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_nummods_srv"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_statsd"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_spec"
            : > "$LQ_TRACE_GUARD_STATE_DIR/rt_spec_srv"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odp_err"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odp_bgjobs"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odp_bgjobs_rate"
            : > "$LQ_TRACE_GUARD_STATE_DIR/fcp_err"
            : > "$LQ_TRACE_GUARD_STATE_DIR/fcp_bgjobs"
            : > "$LQ_TRACE_GUARD_STATE_DIR/fcp_bgjobs_rate"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_westworld"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_err_id"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_model_id"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_model_ver"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_latency"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_moirai"
            : > "$LQ_TRACE_GUARD_STATE_DIR/odad_mismatch"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_aiai"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_autofill"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_captions"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_platform"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_superpacks"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_overview_clearcut"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_overview_ww"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_stats_active"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_stats_nonpersist"
            : > "$LQ_TRACE_GUARD_STATE_DIR/dps_stats_newapi"
            : > "$LQ_TRACE_GUARD_STATE_DIR/am_fgs_allow"
            : > "$LQ_TRACE_GUARD_STATE_DIR/am_fgs_deny"
            : > "$LQ_TRACE_GUARD_STATE_DIR/am_fgs_atom"
            : > "$LQ_TRACE_GUARD_STATE_DIR/am_compact"
            : > "$LQ_TRACE_GUARD_STATE_DIR/am_freeze"
            : > "$LQ_TRACE_GUARD_STATE_DIR/am_pss"
            : > "$LQ_TRACE_GUARD_STATE_DIR/jank_enabled"
            : > "$LQ_TRACE_GUARD_STATE_DIR/jank_sampling"
            : > "$LQ_TRACE_GUARD_STATE_DIR/jank_frametime"
            : > "$LQ_TRACE_GUARD_STATE_DIR/jank_missedframes"
            : > "$LQ_TRACE_GUARD_STATE_DIR/wm_gesture_debounce"
            : > "$LQ_TRACE_GUARD_STATE_DIR/lat_enabled"
            : > "$LQ_TRACE_GUARD_STATE_DIR/lat_sampling"
            : > "$LQ_TRACE_GUARD_STATE_DIR/lat_voice_enable"
            : > "$LQ_TRACE_GUARD_STATE_DIR/lat_voice_sampling"
            : > "$LQ_TRACE_GUARD_STATE_DIR/tel_logcat_read"
            : > "$LQ_TRACE_GUARD_STATE_DIR/tel_dumpsys_read"
            : > "$LQ_TRACE_GUARD_STATE_DIR/tel_logcat_proc"
            : > "$LQ_TRACE_GUARD_STATE_DIR/tel_dumpsys_proc"
            : > "$LQ_TRACE_GUARD_STATE_DIR/tel_lines_lowmem"
            : > "$LQ_TRACE_GUARD_STATE_DIR/tel_lines"
            : > "$LQ_TRACE_GUARD_STATE_DIR/misc_settings_evt"
            : > "$LQ_TRACE_GUARD_STATE_DIR/misc_smartselect_anim"
            : > "$LQ_TRACE_GUARD_STATE_DIR/net_apexdata"
            : > "$LQ_TRACE_GUARD_STATE_DIR/net_legacy_import"
            : > "$LQ_TRACE_GUARD_STATE_DIR/lmkd_minfree"
            : > "$LQ_TRACE_GUARD_STATE_DIR/lmkd_thrash"
            : > "$LQ_TRACE_GUARD_STATE_DIR/cap_history"
            : > "$LQ_TRACE_GUARD_STATE_DIR/cap_buffer"
            ;;
        *) return 2 ;;
    esac
    return 0
}

# ── _lq_trace_guard_clear_all() ──
_lq_trace_guard_clear_all() {
    local f id
    for f in "$LQ_TRACE_GUARD_STATE_DIR"/*; do
        [ -f "$f" ] || continue
        id="${f##*/}"
        _lq_trace_guard_apply_item "$id" 0 >/dev/null 2>&1 || true
        rm -f "$f" >/dev/null 2>&1 || true
    done
    _lq_trace_guard_persist >/dev/null 2>&1 || true
}
# ── _lq_trace_guard_apply_preset() ──
_lq_trace_guard_apply_preset() {
    local preset="$1"
    case "$preset" in
        default|lite|medium|high|maximum) ;;
        *) return 2 ;;
    esac
    _lq_trace_guard_snapshot_all
    _lq_trace_guard_clear_all
    _lq_trace_guard_mark_profile "$preset" || return 1
    case "$preset" in
        default) _lq_trace_guard_apply_preset_default ;;
        lite) _lq_trace_guard_apply_profile_lite ;;
        medium) _lq_trace_guard_apply_profile_medium ;;
        high) _lq_trace_guard_apply_profile_high ;;
        maximum) _lq_trace_guard_apply_profile_maximum ;;
    esac
    settings put global liqinghe_trace_guard_preset "$preset" >/dev/null 2>&1 || true
    _lq_trace_guard_persist >/dev/null 2>&1 || true
    return 0
}

# ── _lq_trace_guard_persist() ──
_lq_trace_guard_persist() {
    local tmp="$LQ_TRACE_GUARD_ACTIVE_FILE.tmp.$$" any=0 f id
    [ -d "$LQ_TMP_DIR" ] && [ -d "$LQ_TRACE_GUARD_STATE_DIR" ] || mkdir -p "$LQ_TMP_DIR" "$LQ_TRACE_GUARD_STATE_DIR" >/dev/null 2>&1 || return 1
    printf '%s\n' '#!/system/bin/sh' > "$tmp" || return 1

    # _lq_trace_guard_emit_on contains the actual runtime commands. During persistence
    # we must CAPTURE those commands into the replay script, not execute them
    # a second time. Shadow the two Android command frontends locally so the
    # existing mapping can be reused without duplicating 100+ cases.
    device_config() { printf 'device_config'; printf ' %s' "$@"; printf '\n'; }
    cmd() { printf 'cmd'; printf ' %s' "$@"; printf '\n'; }

    for f in "$LQ_TRACE_GUARD_STATE_DIR"/*; do
        [ -f "$f" ] || continue
        id="${f##*/}"
        any=1
        _lq_trace_guard_emit_on "$id" >> "$tmp" || { unset -f device_config cmd 2>/dev/null || true; rm -f "$tmp"; return 1; }
    done

    unset -f device_config cmd 2>/dev/null || true
    chmod 755 "$tmp" || return 1
    mv -f "$tmp" "$LQ_TRACE_GUARD_ACTIVE_FILE" || return 1
    settings put global liqinghe_trace_guard_active "$any" >/dev/null 2>&1 || return 1
    return 0
}

# ── _lq_trace_guard_count_active() ──
_lq_trace_guard_count_active() {
    find "$LQ_TRACE_GUARD_STATE_DIR" -type f 2>/dev/null | wc -l | tr -d ' '
}

# ── _lq_trace_guard_restore_active() ──
_lq_trace_guard_restore_active() {
    [ "$(settings get global liqinghe_trace_guard_active 2>/dev/null | tr -d '\r')" = "1" ] || return 0
    [ -f "$LQ_TRACE_GUARD_ACTIVE_FILE" ] && sh "$LQ_TRACE_GUARD_ACTIVE_FILE" >/dev/null 2>&1 || true
}

# ── _lq_trace_guard_off_all() ──
_lq_trace_guard_off_all() {
    local f id
    for f in "$LQ_TRACE_GUARD_STATE_DIR"/*; do
        [ -f "$f" ] || continue
        id="${f##*/}"
        _lq_trace_guard_apply_item "$id" 0 >/dev/null 2>&1 || true
        rm -f "$f" >/dev/null 2>&1 || true
    done
    _lq_trace_guard_persist >/dev/null 2>&1 || true
}

# ── _lq_trace_guard_preset() ──
_lq_trace_guard_preset() {
    case "$(settings get global liqinghe_trace_guard_preset 2>/dev/null | tr -d '\r')" in
        default|lite|medium|high|maximum) settings get global liqinghe_trace_guard_preset 2>/dev/null | tr -d '\r' ;;
        *) printf 'default\n' ;;
    esac
}
