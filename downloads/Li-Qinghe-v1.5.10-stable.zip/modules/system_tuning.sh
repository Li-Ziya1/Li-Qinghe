#!/system/bin/sh
# System Tuning backend (loader).
#
# Sourced by tweaks.sh (WebUI commands), service.sh (boot) and uninstall.sh.
# The code lives in modules/system_tuning/:
#
#   storage.sh          backup and restore of settings / properties
#   values.sh           adjustable values (get / set / seed defaults)
#   groups/*.sh         one file per tuning group
#   group_switch.sh     tuning_set_group: turn one group ON or OFF
#   profile.sh          One-Click Optimization (apply / revert recommended)

: "${LQ_TMP_DIR:=/data/local/tmp/liqinghe}"
# Single consolidated state folder (see LQ_SYSTEM_TUNING_DIR in common.sh).
# LQ_SYSTEM_TUNING_MANUAL_DIR is kept as a second name for the same folder.
: "${LQ_SYSTEM_TUNING_DIR:=$LQ_TMP_DIR/system_tuning}"
[ -d "$LQ_SYSTEM_TUNING_DIR" ] || mkdir -p "$LQ_SYSTEM_TUNING_DIR" >/dev/null 2>&1 || true
LQ_SYSTEM_TUNING_MANUAL_DIR="$LQ_SYSTEM_TUNING_DIR"

: "${MODDIR:=$(cd "$(dirname "$0")/.." 2>/dev/null && pwd)}"
LQ_TUNING_CODE_DIR="$MODDIR/modules/system_tuning"

# Every tuning group, in the order they are applied.
LQ_TUNING_GROUPS="job-scheduler multitasking sqlite-tuning app-standby low-swap \
persist-log-tags logging-diagnostics selected-diagnostics debug-props \
doze long-press-latency oem-tuning compile-keyboard"

# Groups that have an adjustable value, as <group>:<key>.
LQ_TUNING_VALUE_SPECS="job-scheduler:max_job_count_active multitasking:preset \
sqlite-tuning:wal_checkpoint sqlite-tuning:journal_size \
app-standby:strong_usage_duration low-swap:threshold_percent \
long-press-latency:timeout_ms"

for _lq_tuning_part in \
    oem_family storage values \
    groups/log_tags groups/logging_limits groups/diagnostics groups/debug_props \
    groups/doze groups/oem groups/keyboard groups/long_press groups/multitasking \
    group_switch profile; do
    . "$LQ_TUNING_CODE_DIR/${_lq_tuning_part}.sh"
done
unset _lq_tuning_part

# First-run seeding of the adjustable values (needs the recommended profile
# to exist already, see service.sh).
tuning_seed_default_values
