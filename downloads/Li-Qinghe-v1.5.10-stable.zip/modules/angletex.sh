#!/system/bin/sh
# Angle Texture, the part that runs while games are played (called from zi.sh whenever a game comes to the front).
#
# debug.angle.feature_overrides_enabled is one global property, so "different settings per game" means switching it when the game changes.
# other/pkgmgr.sh keeps the table (`package|flags|mode`, mode = stop | apply) in $LQ_ANGLETEX_CONF. When a game comes to the front:
#   - the property already is this game's list  -> nothing at all (no setprop, no force stop)
#   - otherwise the property is set to it (a game with no line gets the empty list = default)
#       mode=stop  -> the game is force-stopped once, so its next start uses it
#       mode=apply -> nothing else; the game keeps running, close it and open it again to see the change
#   Manual game (mode=skip) -> nothing at all, whatever the property is
# While the same game stays the same, nothing is repeated, because the property then already matches.
# With no table (the feature was never used, or everything was reset) this is a single file test.
: "${LQ_ANGLETEX_CONF:=${LQ_TMP_DIR:-/data/local/tmp/liqinghe}/angletex.conf}"

_lq_atx_enter() {
    local pkg="$1" want="" mode="apply" p f m cur found=0
    [ -s "$LQ_ANGLETEX_CONF" ] || return 0
    [ -n "$pkg" ] || return 0
    while IFS='|' read -r p f m; do
        if [ "$p" = "$pkg" ]; then want="$f"; mode="$m"; found=1; break; fi
    done < "$LQ_ANGLETEX_CONF"
    # Manual (mode skip): the module never touches this game, whatever the property is
    [ "$found" = "1" ] && [ "$mode" = "skip" ] && return 0
    cur="$(getprop debug.angle.feature_overrides_enabled 2>/dev/null | tr -d '\r')"
    [ "$cur" = "$want" ] && return 0
    setprop debug.angle.feature_overrides_enabled "$want" >/dev/null 2>&1 || return 1
    if [ "$mode" = "stop" ]; then
        am force-stop "$pkg" >/dev/null 2>&1
    fi
    return 0
}
