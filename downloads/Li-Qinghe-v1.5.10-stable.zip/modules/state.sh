
#!/system/bin/sh
: "${LQ_TMP_DIR:=/data/local/tmp/liqinghe}"
: "${LQ_SYSTEM_TUNING_DIR:=$LQ_TMP_DIR/system_tuning}"
: "${LQ_IDLE_PROFILE_FILE:=$LQ_TMP_DIR/idle_profile}"
: "${LQ_FILY_STATE_FILE:=$LQ_TMP_DIR/fily_enabled}"
: "${LQ_TCTL_STATE_FILE:=$LQ_TMP_DIR/tctl_enabled}"
: "${LQ_SURFACE_FLINGER_PROFILE_FILE:=$LQ_TMP_DIR/surface_flinger_profile}"
: "${LQ_TRACE_PROFILE_FILE:=$LQ_TMP_DIR/trace_guard_profile}"
: "${LQ_ONE_CLICK_STATE_FILE:=$LQ_SYSTEM_TUNING_DIR/one_click_optimization}"
LQ_TRACE_GUARD_STATE_DIR="$LQ_TMP_DIR/trace_guard_state"

# One-time migration from pre-rename state storage.
legacy_trace_guard_dir="$LQ_TMP_DIR/trace""_killer_state"
legacy_tk_profile="$LQ_TMP_DIR/trace""_killer_profile"
[ -d "$legacy_trace_guard_dir" ] && [ ! -d "$LQ_TRACE_GUARD_STATE_DIR" ] && mv "$legacy_trace_guard_dir" "$LQ_TRACE_GUARD_STATE_DIR" 2>/dev/null
[ -f "$legacy_tk_profile" ] && [ ! -f "$LQ_TRACE_PROFILE_FILE" ] && mv "$legacy_tk_profile" "$LQ_TRACE_PROFILE_FILE" 2>/dev/null

[ -d "$LQ_TMP_DIR" ] || mkdir -p "$LQ_TMP_DIR" >/dev/null 2>&1 || true
chmod 777 "$LQ_TMP_DIR" >/dev/null 2>&1 || true

# ── _lq_read_state() ──
_lq_read_state() {
    local key="$1" default="$2" value=""
    case "$key" in
        idle_profile) value="$(cat "$LQ_IDLE_PROFILE_FILE" 2>/dev/null)" ;;
        fily_enabled) value="$(cat "$LQ_FILY_STATE_FILE" 2>/dev/null)" ;;
        tctl_enabled) value="$(cat "$LQ_TCTL_STATE_FILE" 2>/dev/null)" ;;
        surface_flinger) value="$(cat "$LQ_SURFACE_FLINGER_PROFILE_FILE" 2>/dev/null)" ;;
        trace_guard) value="$(cat "$LQ_TRACE_PROFILE_FILE" 2>/dev/null)" ;;
        one_click_optimization) value="$(cat "$LQ_ONE_CLICK_STATE_FILE" 2>/dev/null)" ;;
    esac
    [ -n "$value" ] && printf '%s\n' "$value" || printf '%s\n' "$default"
}
# ── _lq_write_state() ──
_lq_write_state() {
    local file="$1" value="$2"
    [ -d "${file%/*}" ] || mkdir -p "${file%/*}" >/dev/null 2>&1 || return 1
    chmod 777 "${file%/*}" >/dev/null 2>&1 || true
    # WebUI backend may run as shell/AxManager rather than module root.
    # Keep state files directly writable so toggles can persist reliably.
    if ! printf '%s\n' "$value" > "$file" 2>/dev/null; then
        chmod 666 "$file" >/dev/null 2>&1 || true
        printf '%s\n' "$value" > "$file" 2>/dev/null || return 1
    fi
    chmod 666 "$file" >/dev/null 2>&1 || true
    return 0
}
# ── _lq_idle_profile() ──
_lq_idle_profile(){ _lq_read_state idle_profile normal; }
# ── _lq_fily_enabled() ──
_lq_fily_enabled(){ _lq_read_state fily_enabled 0; }
# ── _lq_tctl_enabled() ──
_lq_tctl_enabled(){ _lq_read_state tctl_enabled 0; }
# ── _lq_one_click_enabled() ──
_lq_one_click_enabled(){ _lq_read_state one_click_optimization 0; }
# ── _lq_init_tweak_state() ──
_lq_init_tweak_state(){
    chmod 777 "$LQ_TMP_DIR" >/dev/null 2>&1 || true
    [ -f "$LQ_IDLE_PROFILE_FILE" ] || _lq_write_state "$LQ_IDLE_PROFILE_FILE" normal
    [ -f "$LQ_FILY_STATE_FILE" ] || _lq_write_state "$LQ_FILY_STATE_FILE" 0
    [ -f "$LQ_TCTL_STATE_FILE" ] || _lq_write_state "$LQ_TCTL_STATE_FILE" 0
    [ -f "$LQ_SURFACE_FLINGER_PROFILE_FILE" ] || _lq_write_state "$LQ_SURFACE_FLINGER_PROFILE_FILE" off
    [ -f "$LQ_TRACE_PROFILE_FILE" ] || _lq_write_state "$LQ_TRACE_PROFILE_FILE" off
    [ -f "$LQ_ONE_CLICK_STATE_FILE" ] || _lq_write_state "$LQ_ONE_CLICK_STATE_FILE" 0
    for _sf in "$LQ_IDLE_PROFILE_FILE" "$LQ_FILY_STATE_FILE" "$LQ_TCTL_STATE_FILE" "$LQ_SURFACE_FLINGER_PROFILE_FILE" "$LQ_TRACE_PROFILE_FILE" "$LQ_ONE_CLICK_STATE_FILE"; do
        [ -f "$_sf" ] && chmod 666 "$_sf" >/dev/null 2>&1 || true
    done
}
_lq_init_tweak_state
