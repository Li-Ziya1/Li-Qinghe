#!/system/bin/sh
# Display tuning: refresh rate lock + HWUI renderer, used by the two tiles on the Tweaks page.
#
# Refresh rate: Android reads the wanted rate from a few settings, and every ROM family uses its own.
# The list below is FIXED (keys Stellar writes + keys confirmed in open-source Adaptive-Hz / AOSP docs);
# nothing is discovered from the device, so no unknown key is ever touched.
#   kind "always"  written on every device (AOSP, every ROM honours them)
#   kind "hz"      only if the key already exists (value not null); value = Hz, keeps its int/float format
#   kind "mode"    only if the key already exists; value is a MODE, not Hz (see _lq_disp_mode_value)
#
#   system  min_refresh_rate / peak_refresh_rate   AOSP                                  always
#   system  tran_refresh_mode                      Transsion HiOS/XOS/itel: Hz, or 10000 = Adaptive   hz
#   system  last_tran_refresh_mode_in_refresh_setting  Transsion, mirrors tran_refresh_mode (HiOS Settings reads it)  hz
#   (tran_need_recovery_refresh_rate stays 120 in every HiOS mode, so it is never touched)
#   secure  miui_refresh_rate (+ system)           Xiaomi HyperOS 2/3, MIUI (Hz)         hz
#   secure/global/system  user_refresh_rate        Xiaomi HyperOS 1 (0=min 1=max) or Hz  hz   (special-cased below)
#   secure  refresh_rate_mode                      Samsung One UI: 0=normal 1=adaptive 2=high   mode
# Locking means every key above = the chosen rate. The original values are saved first and
# "Default" puts them back (a key that did not exist is deleted again).
# ROM keys go FIRST and the AOSP min/peak pair LAST: a ROM observer that reacts to its own key (HiOS
# tran_refresh_mode, MIUI miui_refresh_rate) may rewrite min/peak, so the pair must be the final word.
LQ_DISP_RR_KEYS="system:last_tran_refresh_mode_in_refresh_setting:hz system:tran_refresh_mode:hz secure:miui_refresh_rate:hz system:miui_refresh_rate:hz secure:user_refresh_rate:hz global:user_refresh_rate:hz system:user_refresh_rate:hz secure:refresh_rate_mode:mode system:min_refresh_rate:always system:peak_refresh_rate:always"

LQ_DISP_BACKUP_DIR="$LQ_TMP_DIR/display_backup"
LQ_DISP_RATES_CACHE="$LQ_TMP_DIR/display_rates_cache"
: "${LQ_DISP_RENDERER_FILE=$LQ_TMP_DIR/display_renderer}"

# ── _lq_disp_bname() <ns> <key> -- backup file stem (system keys keep the plain key name) ──
_lq_disp_bname() {
    if [ "$1" = "system" ]; then printf '%s\n' "$2"; else printf '%s__%s\n' "$1" "$2"; fi
}

# ── _lq_disp_backup() <ns> <key> ──
_lq_disp_backup() {
    local ns="$1" key="$2" value b
    b="$(_lq_disp_bname "$ns" "$key")"
    [ -d "$LQ_DISP_BACKUP_DIR" ] || mkdir -p "$LQ_DISP_BACKUP_DIR" >/dev/null 2>&1 || return 1
    chmod 777 "$LQ_DISP_BACKUP_DIR" >/dev/null 2>&1 || true
    [ -e "$LQ_DISP_BACKUP_DIR/$b.present" ] && return 0
    value="$(settings get "$ns" "$key" 2>/dev/null | tr -d '\r')"
    if [ -z "$value" ] || [ "$value" = "null" ]; then
        : > "$LQ_DISP_BACKUP_DIR/$b.missing"
    else
        printf '%s\n' "$value" > "$LQ_DISP_BACKUP_DIR/$b.value" || return 1
    fi
    : > "$LQ_DISP_BACKUP_DIR/$b.present"
}

# ── _lq_disp_restore() ──
_lq_disp_restore() {
    local entry ns key kind value b
    for entry in $LQ_DISP_RR_KEYS; do
        ns="${entry%%:*}"; key="${entry#*:}"; key="${key%%:*}"
        b="$(_lq_disp_bname "$ns" "$key")"
        [ -e "$LQ_DISP_BACKUP_DIR/$b.present" ] || continue
        if [ -f "$LQ_DISP_BACKUP_DIR/$b.value" ]; then
            value="$(cat "$LQ_DISP_BACKUP_DIR/$b.value" 2>/dev/null)"
            settings put "$ns" "$key" "$value" >/dev/null 2>&1 || true
        else
            settings delete "$ns" "$key" >/dev/null 2>&1 || true
        fi
        rm -f "$LQ_DISP_BACKUP_DIR/$b.present" "$LQ_DISP_BACKUP_DIR/$b.value" "$LQ_DISP_BACKUP_DIR/$b.missing" >/dev/null 2>&1 || true
    done
    rmdir "$LQ_DISP_BACKUP_DIR" >/dev/null 2>&1 || true
}

# ── _lq_disp_rates() -- supported refresh rates, comma separated (cached until reboot) ──
_lq_disp_rates() {
    local r
    if [ -s "$LQ_DISP_RATES_CACHE" ]; then
        cat "$LQ_DISP_RATES_CACHE" 2>/dev/null
        return 0
    fi
    r="$(dumpsys display 2>/dev/null | grep -oE 'fps=[0-9]+(\.[0-9]+)?' | cut -d= -f2 |
        awk '{v=int($1+0.5); if(v>=30&&v<=240)print v}' | sort -nu | tr '\n' ',' | sed 's/,$//')"
    [ -n "$r" ] || r=60
    printf '%s\n' "$r" > "$LQ_DISP_RATES_CACHE" 2>/dev/null || true
    chmod 666 "$LQ_DISP_RATES_CACHE" >/dev/null 2>&1 || true
    printf '%s\n' "$r"
}

# ── _lq_disp_rates_invalidate() (boot) ──
_lq_disp_rates_invalidate() { rm -f "$LQ_DISP_RATES_CACHE" >/dev/null 2>&1 || true; }

# ── _lq_disp_num() <settings value> -- "90.0" / "90" -> 90, anything else -> empty ──
_lq_disp_num() {
    case "$1" in
        ''|null|*[!0-9.]*) return 0 ;;
    esac
    awk -v v="$1" 'BEGIN{printf "%d\n", v+0.5}'
}

# ── _lq_disp_refresh_get() -- the locked rate, or 0 when no lock is set ──
# Locked = peak is a real rate AND (min == peak, or the ROM's own key agrees with peak). The second
# case covers ROMs that keep their own floor in min_refresh_rate but follow tran_refresh_mode.
_lq_disp_refresh_get() {
    local mn pk tr
    mn="$(_lq_disp_num "$(settings get system min_refresh_rate 2>/dev/null | tr -d '\r')")"
    pk="$(_lq_disp_num "$(settings get system peak_refresh_rate 2>/dev/null | tr -d '\r')")"
    tr="$(_lq_disp_num "$(settings get system tran_refresh_mode 2>/dev/null | tr -d '\r')")"
    if [ -n "$pk" ] && [ "$pk" -ge 30 ] 2>/dev/null && { [ "$mn" = "$pk" ] || [ "$tr" = "$pk" ]; }; then
        printf '%s\n' "$pk"
    else
        printf '0\n'
    fi
}

# ── _lq_disp_mode_value() <key> <hz> -- value of a "mode" key for a rate; empty = cannot express it ──
# Samsung refresh_rate_mode only knows 0 (normal, lowest) / 1 (adaptive) / 2 (high, highest), so a
# rate in between has no mode: the AOSP min/peak keys still carry it.
_lq_disp_mode_value() {
    local hz="$1" lo hi
    lo="$(_lq_disp_rates | cut -d, -f1)"; hi="$(_lq_disp_rates | awk -F, '{print $NF}')"
    [ "$hz" = "$hi" ] && { printf '2\n'; return 0; }
    [ "$hz" = "$lo" ] && { printf '0\n'; return 0; }
    return 1
}

# ── _lq_disp_adaptive_known() -- 1 when this ROM's Adaptive value is known (Transsion, Samsung), else 0 ──
# Elsewhere the UI shows only the Hz choices; tapping the rate that is currently locked releases it.
_lq_disp_adaptive_known() {
    local v
    for v in "system tran_refresh_mode" "secure refresh_rate_mode"; do
        # shellcheck disable=SC2086
        case "$(settings get $v 2>/dev/null | tr -d '\r')" in ''|null) ;; *) printf '1\n'; return 0 ;; esac
    done
    printf '0\n'
}

# ── _lq_disp_adaptive() -- "Adaptive" (menu value 0) ──
# Transsion HiOS has a real Adaptive mode, read from the phone itself:
#   tran_refresh_mode = last_tran_refresh_mode_in_refresh_setting = 10000
#   min_refresh_rate  = lowest rate (60.0)     peak_refresh_rate = highest rate + 0.00001 (120.00001)
# Samsung One UI: secure refresh_rate_mode 1 = adaptive (0 normal, 2 high), after the originals are back.
# Every other ROM (AOSP/Pixel, Xiaomi, Oppo, ...): Adaptive = the values the ROM had before any lock.
# AOSP documents min_refresh_rate default as 0 (no minimum) and the peak default as the ROM's own
# config, so a ROM that never had these keys gets them deleted again, which is its adaptive state.
# No Xiaomi value is invented: user/miui_refresh_rate 0 is "minimum" on HyperOS 1, so those just go back.
_lq_disp_adaptive() {
    local cur lo hi
    cur="$(settings get system tran_refresh_mode 2>/dev/null | tr -d '\r')"
    case "$cur" in
        ''|null)
            _lq_disp_restore
            cur="$(settings get secure refresh_rate_mode 2>/dev/null | tr -d '\r')"
            case "$cur" in ''|null) ;; *) settings put secure refresh_rate_mode 1 >/dev/null 2>&1 || return 1 ;; esac
            return 0 ;;
    esac
    lo="$(_lq_disp_rates | cut -d, -f1)"; hi="$(_lq_disp_rates | awk -F, '{print $NF}')"
    settings put system last_tran_refresh_mode_in_refresh_setting 10000 >/dev/null 2>&1 || true
    settings put system tran_refresh_mode 10000 >/dev/null 2>&1 || return 1
    sleep 0.3 >/dev/null 2>&1 || true
    settings put system min_refresh_rate "${lo}.0" >/dev/null 2>&1 || return 1
    settings put system peak_refresh_rate "${hi}.00001" >/dev/null 2>&1 || return 1
    # Adaptive is now the saved state, an older backup of a locked state must not come back later
    rm -rf "$LQ_DISP_BACKUP_DIR" >/dev/null 2>&1 || true
    return 0
}

# ── _lq_disp_refresh_set() <hz|0> -- 0 = Adaptive ──
# Back up every key of the fixed list first, then write the rate. "hz" / "mode" keys are only touched
# when the device already has them. HyperOS 1 user_refresh_rate holding 0 or 1 uses special values
# (0 = lowest, 1 = highest); any other value is plain Hz.
_lq_disp_refresh_set() {
    local hz="$1" entry ns key kind cur val lo hi rc=0
    if [ "$hz" = "0" ]; then
        _lq_disp_adaptive
        return $?
    fi
    for entry in $LQ_DISP_RR_KEYS; do
        ns="${entry%%:*}"; key="${entry#*:}"; key="${key%%:*}"; kind="${entry##*:}"
        cur="$(settings get "$ns" "$key" 2>/dev/null | tr -d '\r')"
        if [ "$kind" != "always" ]; then
            case "$cur" in ''|null) continue ;; esac
        fi
        case "$kind" in
            mode) val="$(_lq_disp_mode_value "$hz")" || continue ;;
            *)
                if [ "$key" = "user_refresh_rate" ] && { [ "$cur" = "0" ] || [ "$cur" = "1" ]; }; then
                    lo="$(_lq_disp_rates | cut -d, -f1)"; hi="$(_lq_disp_rates | awk -F, '{print $NF}')"
                    if [ "$hz" = "$hi" ]; then val=1
                    elif [ "$hz" = "$lo" ]; then val=0
                    else continue; fi
                else
                    case "$cur" in
                        ''|null|*.*) val="${hz}.0" ;;
                        *)           val="$hz" ;;
                    esac
                fi ;;
        esac
        _lq_disp_backup "$ns" "$key" || { rc=1; continue; }
        # the two AOSP keys decide whether the lock worked; the ROM-specific ones are best effort
        if ! settings put "$ns" "$key" "$val" >/dev/null 2>&1; then
            [ "$kind" = "always" ] && return 1
        fi
    done
    # let ROM observers settle, then make sure the AOSP pair still holds (they may have rewritten it)
    sleep 0.3 >/dev/null 2>&1 || true
    settings put system min_refresh_rate "${hz}.0" >/dev/null 2>&1 || true
    settings put system peak_refresh_rate "${hz}.0" >/dev/null 2>&1 || true
    return $rc
}

# ── _lq_disp_renderer_props() <id> -- "hwui_value renderengine_value" for a choice ──
#   debug.hwui.renderer         what apps draw with (skiagl | skiavk), read when an app starts
#   debug.renderengine.backend  what SurfaceFlinger composes with (gles | threaded | skiagl |
#                               skiaglthreaded | skiavk | skiavkthreaded), read when SurfaceFlinger starts
_lq_disp_renderer_props() {
    case "$1" in
        skiavk)         printf 'skiavk skiavk\n' ;;
        skiavkthreaded) printf 'skiavk skiavkthreaded\n' ;;
        skiagl)         printf 'skiagl skiagl\n' ;;
        skiaglthreaded) printf 'skiagl skiaglthreaded\n' ;;
        gles)           printf 'skiagl gles\n' ;;
        glesthreaded)   printf 'skiagl threaded\n' ;;
        *) return 1 ;;
    esac
}

# ── _lq_disp_renderer_get() -- default | skiavk | skiavkthreaded | skiagl | skiaglthreaded | gles | glesthreaded ──
_lq_disp_renderer_get() {
    local h b id pair
    h="$(getprop debug.hwui.renderer 2>/dev/null | tr -d '\r\n' | tr 'A-Z' 'a-z')"
    b="$(getprop debug.renderengine.backend 2>/dev/null | tr -d '\r\n' | tr 'A-Z' 'a-z')"
    if [ -z "$h" ] && [ -z "$b" ]; then printf 'default\n'; return 0; fi
    for id in skiavk skiavkthreaded skiagl skiaglthreaded gles glesthreaded; do
        pair="$(_lq_disp_renderer_props "$id")"
        [ "$pair" = "$h $b" ] && { printf '%s\n' "$id"; return 0; }
    done
    # only the app-side prop is set (by something else): report it if it is one we know
    case "$h:$b" in
        skiavk:|skiagl:) printf '%s\n' "$h" ;;
        *) printf 'custom\n' ;;
    esac
}

# ── _lq_disp_pipeline() -- the pipeline apps really draw with right now ──
_lq_disp_pipeline() {
    local p
    p="$(dumpsys gfxinfo com.android.systemui 2>/dev/null | grep -m1 -i 'Pipeline=')"
    case "$p" in
        *[Vv]ulkan*) printf 'skiavk\n' ;;
        *[Oo]pen[Gg][Ll]*) printf 'skiagl\n' ;;
        *) printf 'unknown\n' ;;
    esac
}

# ── _lq_disp_set_extras() <on|off> <gl|other> ──
# The tracing-off / capture-off props that belong with a renderer (list: renderer_extra_props.txt).
# "on" sets them (the gl-only ones are cleared when the renderer is not SkiaGL); "off" clears all.
_lq_disp_set_extras() {
    local mode="$1" family="$2" file scope key val
    file="${LQ_MODULE_DIR:-$MODDIR/modules}/renderer_extra_props.txt"
    [ -f "$file" ] || return 0
    while read -r scope key val; do
        case "$scope" in ''|\#*) continue ;; esac
        [ -n "$key" ] || continue
        if [ "$mode" = "on" ] && { [ "$scope" = "all" ] || [ "$family" = "gl" ]; }; then
            setprop "$key" "$val" >/dev/null 2>&1 || true
        else
            setprop "$key" "" >/dev/null 2>&1 || true
        fi
    done < "$file"
}

# ── _lq_disp_family() <id> -- gl for the SkiaGL choices, other for the rest ──
_lq_disp_family() {
    case "$1" in skiagl|skiaglthreaded) printf 'gl\n' ;; *) printf 'other\n' ;; esac
}

# ── _lq_disp_set_props() <hwui> <renderengine> -- empty value clears the prop ──
_lq_disp_set_props() {
    setprop debug.hwui.renderer "$1" >/dev/null 2>&1 || return 1
    setprop debug.renderengine.backend "$2" >/dev/null 2>&1 || return 1
    return 0
}

# ── _lq_disp_renderer_set() <default|skiavk|skiavkthreaded|skiagl|skiaglthreaded|gles|glesthreaded> ──
# Apps pick the new hwui renderer up the next time they start. SurfaceFlinger only reads its
# backend while it starts, so that half needs a reboot (post-fs-data.sh puts it back early at boot).
_lq_disp_renderer_set() {
    local v="$1" pair
    if [ "$v" = "default" ]; then
        _lq_write_state "$LQ_DISP_RENDERER_FILE" "default" >/dev/null 2>&1 || return 1
        _lq_disp_set_props "" "" || return 1
        _lq_disp_set_extras off other
        return 0
    fi
    pair="$(_lq_disp_renderer_props "$v")" || return 1
    _lq_write_state "$LQ_DISP_RENDERER_FILE" "$v" >/dev/null 2>&1 || return 1
    # shellcheck disable=SC2086
    _lq_disp_set_props $pair || return 1
    _lq_disp_set_extras on "$(_lq_disp_family "$v")"
    return 0
}

# ── _lq_disp_boot_apply() -- debug.* props are gone after a reboot, put the chosen renderer back ──
_lq_disp_boot_apply() {
    local v pair
    v="$(cat "$LQ_DISP_RENDERER_FILE" 2>/dev/null | tr -d '\r\n')"
    pair="$(_lq_disp_renderer_props "$v")" || return 0
    # shellcheck disable=SC2086
    _lq_disp_set_props $pair >/dev/null 2>&1 || true
    _lq_disp_set_extras on "$(_lq_disp_family "$v")"
}
