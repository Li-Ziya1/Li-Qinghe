#!/system/bin/sh

[ -z "$MODDIR" ] && MODDIR=${0%/*}
PATH="$MODDIR/system/bin:$MODDIR/system/xbin:/system/bin:/system/xbin:$PATH"
export PATH

: "${LQ_TMP_DIR:=/data/local/tmp/liqinghe}"
 : "${LQ_RUNTIME_PERF_KEYS_FILE:=$LQ_TMP_DIR/runtime_perf_keys.txt}"
: "${LQ_RUNTIME_PERF_BACKUP_FILE:=$LQ_TMP_DIR/runtime_perf_keys.backup}"
[ -d "$LQ_TMP_DIR" ] || mkdir -p "$LQ_TMP_DIR" >/dev/null 2>&1

# Single home for every System Tuning toggle's saved state (backed-up
# settings/props, per-group on/off flags, custom values). Everything under
# modules/system_tuning.sh used to be split across two folders
# (performance_extras/ and klixr_manual/) plus a loose file in LQ_TMP_DIR --
# it all lives here now. The one-time migration below moves any state left
# over from that older layout so upgrading doesn't silently drop a toggle's
# backup and leave it unable to restore.
: "${LQ_SYSTEM_TUNING_DIR:=$LQ_TMP_DIR/system_tuning}"
[ -d "$LQ_SYSTEM_TUNING_DIR" ] || mkdir -p "$LQ_SYSTEM_TUNING_DIR" >/dev/null 2>&1
# Old names some System Tuning code still uses -- always the same folder now.
# Defining them here too means callers that only source common.sh (e.g.
# service.sh's _lq_conflict_snapshot_refresh()) see the right path even before modules/system_tuning.sh
# has been sourced, instead of silently reading an unset/empty path.
: "${LQ_SYSTEM_TUNING_MANUAL_DIR:=$LQ_SYSTEM_TUNING_DIR}"
: "${LQ_SYSTEM_TUNING_DRIVER_DIR:=$LQ_SYSTEM_TUNING_DIR}"

: "${LQ_GAMELIST_FILE=$LQ_TMP_DIR/gamelist.txt}"
: "${LQ_USERPKG_FILE=$LQ_TMP_DIR/userpkg.txt}"
: "${LQ_WHITELIST_FILE=$LQ_TMP_DIR/whitelist.txt}"
: "${LQ_PRELIST_FILE=$LQ_TMP_DIR/prelist.txt}"

: "${LQ_GAMELIST_SOURCE=$MODDIR/gamelist.txt}"
: "${GAMELIST_LOCAL=$LQ_GAMELIST_FILE}"
# Output of the WebUI's "scan games" (Game tab; query-activities
# scan). Kept in a file separate from LQ_GAMELIST_FILE/LQ_GAMELIST_SOURCE on
# purpose -- the shipped gamelist.txt must stay untouched/pure. Consumers
# (WebUI, _lq_foreground_resolve, etc.) decide at read-time whether to prefer this file when it
# exists or fall back to the original gamelist.
: "${LQ_GAMELIST_DETECTED_FILE=$LQ_TMP_DIR/gamelist_detected.txt}"
: "${LAST_STATE=none}"
: "${GAME_CHECK_INTERVAL=4}"
: "${IDLE_CHECK_INTERVAL=4}"
: "${CONFIG_FILE=$LQ_TMP_DIR/lq.conf}"
: "${EXPECTED_FILE=$LQ_TMP_DIR/lqe.conf}"
: "${NOTIF_ID=p9Qk3Lt6xRn1iMw8h5Us2e7gd4vB0yif1j6Iq3zA}"
: "${CURRENT_GAME_APP=No active games}"
: "${CURRENT_MODE=powersave}"
: "${LQ_LIZIYA_PID_FILE=$LQ_TMP_DIR/liziya.pid}"
: "${CURRENT_MODE_FILE=$LQ_TMP_DIR/lq.mode}"
: "${TRANSITION_LOCK_FILE=$LQ_TMP_DIR/.lq_transition.lock}"
: "${TRANSITION_LOCK=0}"

: "${HWUI_GAME_CPU_PCT=50}"
: "${HWUI_IDLE_CPU_PCT=54}"

: "${JOB_SCHED_ACTIVE=72}"
: "${JOB_SCHED_BG_NORM=3}"
: "${JOB_SCHED_BG_MOD=6}"
: "${JOB_SCHED_BG_LOW=10}"
: "${JOB_SCHED_MIN_READY=4}"

: "${ENABLE_JOBSCHED=1}"
: "${ENABLE_SQLITE=1}"
: "${ENABLE_SWAP_THRESHOLD=1}"
: "${ENABLE_APP_STANDBY=1}"
: "${ENABLE_POWER_FIXED_PERF=1}"
: "${POWER_FIXED_PERF_SUPPORTED=0}"
: "${POWER_FIXED_PERF_STATE=0}"
: "${ENABLE_FILY=1}"
: "${ENABLE_FILY_USE_COMPACT=1}"
: "${ENABLE_TCTL=1}"
: "${TCTL_TARGET_TEMP=200}"
: "${TCTL_STATE_FILE=$LQ_TMP_DIR/.lq_tctl.state}"
: "${TCTL_LOG=$LQ_TMP_DIR/tctl.log}"
: "${TCTL_PROP_KEY=}"
: "${TCTL_BASELINE_VALUE=}"
: "${TCTL_ACTIVE_VALUE=}"
: "${FILY_INTERVAL=18}"
: "${FILY_SCREENOFF_INTERVAL=45}"
: "${FILY_FULL_SCAN_INTERVAL=120}"
: "${FILY_SPIKE_DELTA=6}"
: "${FILY_MEM_HIGH_PCT=82}"
: "${FILY_MEM_CRITICAL_PCT=89}"
: "${FILY_PSI_SOME_HIGH=2.3}"
: "${FILY_PSI_FULL_HIGH=0.45}"
: "${FILY_LOG=$LQ_TMP_DIR/fily.log}"
: "${FILY_PID_FILE=$LQ_TMP_DIR/.lq_fily.pid}"
: "${FILY_LAST_SCAN_FILE=$LQ_TMP_DIR/.lq_ram.scan}"
: "${FILY_ALLOW_PERIODIC_SCAN=1}"
: "${LQ_OTHER_DIR=$MODDIR/other}"
: "${LQ_PRELOAD_FILE=$LQ_TMP_DIR/preload.txt}"
: "${LQ_PRELOAD_STATE_FILE=$LQ_TMP_DIR/.lq_preload.done}"
: "${LQ_PRELIST_FILE=$LQ_TMP_DIR/prelist.txt}"
: "${LQ_WHITELIST_FILE=$LQ_TMP_DIR/whitelist.txt}"

[ -f "$CONFIG_FILE" ] && . "$CONFIG_FILE"
[ -f "$LQ_OTHER_DIR/pkgmgr.sh" ] && . "$LQ_OTHER_DIR/pkgmgr.sh"
[ -z "$LQ_TCTL_HELPER_NOLOAD" ] && [ -f "$LQ_OTHER_DIR/tctl.sh" ] && . "$LQ_OTHER_DIR/tctl.sh"
# Fily (adaptive RAM-pressure helper) is now the native fily_ctl binary,
# see system/bin/fily_ctl (arm64) / system/bin/fily_ctl32 (armeabi-v7a).
# No shell source needed; service.sh/tweaks.sh call the binary directly
# ("fily_ctl start|stop|restart|status|toggle") via _lq_fily_bin() below,
# which auto-picks the right arch for the device.
_lq_fily_bin() {
    if [ -x "$MODDIR/system/bin/fily_ctl" ] && [ -e /system/bin/linker64 ]; then
        printf '%s\n' "$MODDIR/system/bin/fily_ctl"
    elif [ -x "$MODDIR/system/bin/fily_ctl32" ]; then
        printf '%s\n' "$MODDIR/system/bin/fily_ctl32"
    elif [ -x "$MODDIR/system/bin/fily_ctl" ]; then
        # no linker64 detected but the 64-bit binary is there anyway;
        # let it try rather than fail outright
        printf '%s\n' "$MODDIR/system/bin/fily_ctl"
    else
        return 1
    fi
}

: "${LQ_MODULE_DIR=$MODDIR/modules}"
: "${LQ_IDLE_PROFILE_FILE=$LQ_TMP_DIR/idle_profile}"
: "${LQ_FILY_STATE_FILE=$LQ_TMP_DIR/fily_enabled}"
: "${LQ_SURFACE_FLINGER_PROFILE_FILE=$LQ_TMP_DIR/surface_flinger_profile}"
: "${LQ_TRACE_PROFILE_FILE=$LQ_TMP_DIR/trace_guard_profile}"
: "${LQ_RECOMMENDED_PROFILE_FILE=$LQ_SYSTEM_TUNING_DIR/recommended_profile}"
[ -f "$LQ_MODULE_DIR/state.sh" ] && . "$LQ_MODULE_DIR/state.sh"
[ -f "$LQ_MODULE_DIR/idle_profiles.sh" ] && . "$LQ_MODULE_DIR/idle_profiles.sh"
[ -f "$LQ_MODULE_DIR/surface_flinger.sh" ] && . "$LQ_MODULE_DIR/surface_flinger.sh"
[ -f "$LQ_MODULE_DIR/display_tuning.sh" ] && . "$LQ_MODULE_DIR/display_tuning.sh"
[ -f "$LQ_MODULE_DIR/trace_guard.sh" ] && . "$LQ_MODULE_DIR/trace_guard.sh"
_lq_init_tweak_state >/dev/null 2>&1 || true

# ── _resolve_ven_bin() ──
# ven is a plain foreground detector: it prints the top app's package name on
# stdout and knows nothing about the gamelist. _lq_foreground_resolve below does the game check.
# Preferred location is the module's own system/bin; the old
# /data/local/tmp/ven location still works as a fallback.
_resolve_ven_bin() {
    local bin
    for bin in "$MODDIR/system/bin/ven" /data/local/tmp/ven; do
        if [ -x "$bin" ]; then
            printf '%s\n' "$bin"
            return 0
        fi
    done
    return 1
}
# Resolved once when common.sh is sourced (paths do not change at runtime),
# so _lq_foreground_resolve does not fork a subshell per tick just to learn a constant.
_LQ_VEN_BIN="$(_resolve_ven_bin 2>/dev/null)" || _LQ_VEN_BIN=""

# ── _lq_sync_ven_bin() ──
# Fily (native) runs ven from $LQ_TMP_DIR/ven, so it never has to know where
# the module lives. Copy to a temp name and rename over the target: Fily can
# never execute a half-written ven, and a ven that is running at that moment
# (where writing in place can fail with "Text file busy") is swapped safely.
_lq_sync_ven_bin() {
    local src="$MODDIR/system/bin/ven" dst="$LQ_TMP_DIR/ven"
    [ -f "$src" ] || return 1
    [ -d "$LQ_TMP_DIR" ] || mkdir -p "$LQ_TMP_DIR" >/dev/null 2>&1 || return 1
    cp -f "$src" "$dst.tmp.$$" >/dev/null 2>&1 || { rm -f "$dst.tmp.$$"; return 1; }
    chmod 755 "$dst.tmp.$$" >/dev/null 2>&1 || { rm -f "$dst.tmp.$$"; return 1; }
    mv -f "$dst.tmp.$$" "$dst" >/dev/null 2>&1 || { rm -f "$dst.tmp.$$"; return 1; }
    return 0
}


# ── _power_help_has() ──
_power_help_has() {
    local needle="$1" help
    help="$(cmd power help 2>/dev/null)" || help=""
    [ -n "$help" ] || return 1
    printf '%s\n' "$help" | grep -Fq "$needle"
}

# ── _power_fixed_perf_detect() ──
_power_fixed_perf_detect() {
    if _power_help_has 'set-fixed-performance-mode-enabled' && _power_help_has 'fixed performance mode'; then
        POWER_FIXED_PERF_SUPPORTED=1
    else
        POWER_FIXED_PERF_SUPPORTED=0
    fi
    export POWER_FIXED_PERF_SUPPORTED
    [ "$POWER_FIXED_PERF_SUPPORTED" = "1" ]
}

# ── _power_fixed_perf_apply() ──
_power_fixed_perf_apply() {
    [ "${ENABLE_POWER_FIXED_PERF:-1}" = "1" ] || return 0
    [ "${POWER_FIXED_PERF_SUPPORTED:-0}" = "1" ] || _power_fixed_perf_detect >/dev/null 2>&1 || return 0
    cmd power set-fixed-performance-mode-enabled true >/dev/null 2>&1 && POWER_FIXED_PERF_STATE=1
    export POWER_FIXED_PERF_STATE
    return 0
}

# ── _power_fixed_perf_restore() ──
_power_fixed_perf_restore() {
    [ "${ENABLE_POWER_FIXED_PERF:-1}" = "1" ] || return 0
    [ "${POWER_FIXED_PERF_SUPPORTED:-0}" = "1" ] || return 0
    cmd power set-fixed-performance-mode-enabled false >/dev/null 2>&1 && POWER_FIXED_PERF_STATE=0
    export POWER_FIXED_PERF_STATE
    return 0
}

# ── _prop_exists() ──
_prop_exists() {
    local prop="$1" ctx
    ctx=$(getprop -Z "$prop" 2>/dev/null)
    [ -n "$ctx" ] && return 0
    [ -n "$(_prop_get "$prop")" ] && return 0
    return 1
}

# ── _prop_get() ──
_prop_get() {
    getprop "$1" 2>/dev/null
}

# ── _tctl_now_human() ──
_tctl_now_human() {
    date '+%F %T' 2>/dev/null || printf 'unknown\n'
}

# ── _tctl_fmt_val() ──
_tctl_fmt_val() {
    [ -n "$1" ] && printf '%s' "$1" || printf '<unset>'
}

# ── _tctl_log_line() ──
_tctl_log_line() {
    local event="${1:-tick}" key="${2:-}" target="${3:-}" baseline="${4:-}" verify="${5:-}" hint="${6:-}"
    local now line

    [ -n "$TCTL_LOG" ] || return 0
    now="$(_tctl_now_human)"
    [ -d "${TCTL_LOG%/*}" ] || mkdir -p "${TCTL_LOG%/*}" >/dev/null 2>&1

    line="[$now] $(printf '%-7s' "$event")"
    [ -n "$key" ] && line="$line | key=$(_tctl_fmt_val "$key")"
    [ -n "$target" ] && line="$line | target=$(_tctl_fmt_val "$target")"
    [ -n "$baseline" ] && line="$line | baseline=$(_tctl_fmt_val "$baseline")"
    [ -n "$verify" ] && line="$line | verify=$(_tctl_fmt_val "$verify")"
    [ -n "$hint" ] && line="$line | hint=$(_tctl_fmt_val "$hint")"

    printf '%s\n' "$line" >> "$TCTL_LOG" 2>/dev/null
}

# ── _lq_tctl_candidates() ──
# Vendor thermal-throttle properties Tctl knows how to drive.
_lq_tctl_candidates() {
    printf '%s\n' \
        debug.spect.asfi \
        persist.debug.spect.asfi \
        debug.spect.asfi.temp \
        persist.debug.spect.asfi.temp \
        debug.spect.fake_battery_temp \
        persist.debug.spect.fake_battery_temp \
        debug.spect.battery_temp \
        persist.spect.battery_temp \
        debug.spect.temp \
        persist.spect.temp \
        debug.sfrz.temp \
        persist.sfrz.temp \
        debug.spect.asfi.battery \
        persist.debug.spect.asfi.battery
}

# ── _lq_tctl_supported() ──
# True when one of those properties exists on this device. Read-only: unlike
# _tctl_detect_target it sets no TCTL_* state and writes nothing to the Tctl log.
_lq_tctl_supported() {
    local p
    [ "$ENABLE_TCTL" = "1" ] || return 1
    for p in $(_lq_tctl_candidates); do
        _prop_exists "$p" && return 0
    done
    return 1
}

# ── _tctl_detect_target() ──
_tctl_detect_target() {

    local p
    for p in $(_lq_tctl_candidates); do
        if _prop_exists "$p"; then
            TCTL_PROP_KEY="$p"
            TCTL_BASELINE_VALUE="$(_prop_get "$p")"
            TCTL_ACTIVE_VALUE="temp:${TCTL_TARGET_TEMP}"
            export TCTL_PROP_KEY TCTL_BASELINE_VALUE TCTL_ACTIVE_VALUE
            _tctl_log_line "detect" "$TCTL_PROP_KEY" "${TCTL_ACTIVE_VALUE}" "${TCTL_BASELINE_VALUE}" "$(_prop_get "$TCTL_PROP_KEY")" "target"
            return 0
        fi
    done

    TCTL_PROP_KEY=""
    TCTL_BASELINE_VALUE=""
    TCTL_ACTIVE_VALUE=""
    export TCTL_PROP_KEY TCTL_BASELINE_VALUE TCTL_ACTIVE_VALUE
    _tctl_log_line "detect" "" "" "" "" "unsupported"
    return 1
}

# ── _tctl_init() ──
_tctl_init() {
    [ "$ENABLE_TCTL" = "1" ] || return 1
    _tctl_detect_target
}

# ── _tctl_apply() ──
_tctl_apply() {
    local actual

    [ "$ENABLE_TCTL" = "1" ] || return 1
    [ "$(_lq_tctl_enabled 2>/dev/null)" = "1" ] || return 1
    [ -n "$TCTL_PROP_KEY" ] || _tctl_init >/dev/null 2>&1 || return 1
    [ -n "$TCTL_ACTIVE_VALUE" ] || TCTL_ACTIVE_VALUE="temp:${TCTL_TARGET_TEMP}"
    export TCTL_ACTIVE_VALUE

    if [ ! -f "$TCTL_STATE_FILE" ]; then
        [ -d "${TCTL_STATE_FILE%/*}" ] || mkdir -p "${TCTL_STATE_FILE%/*}" >/dev/null 2>&1
        {
            printf 'key=%s\n' "$TCTL_PROP_KEY"
            printf 'value=%s\n' "$TCTL_BASELINE_VALUE"
        } > "$TCTL_STATE_FILE" 2>/dev/null
    fi

    _tctl_log_line "apply" "$TCTL_PROP_KEY" "$TCTL_ACTIVE_VALUE" "$TCTL_BASELINE_VALUE" "" "try"
    setprop "$TCTL_PROP_KEY" "$TCTL_ACTIVE_VALUE" >/dev/null 2>&1
    actual="$(_prop_get "$TCTL_PROP_KEY")"
    if [ "$actual" = "$TCTL_ACTIVE_VALUE" ]; then
        _tctl_log_line "apply" "$TCTL_PROP_KEY" "$TCTL_ACTIVE_VALUE" "$TCTL_BASELINE_VALUE" "$actual" "ok"
    else
        _tctl_log_line "apply" "$TCTL_PROP_KEY" "$TCTL_ACTIVE_VALUE" "$TCTL_BASELINE_VALUE" "$actual" "fail"
        return 1
    fi
    return 0
}

# ── _tctl_restore() ──
_tctl_restore() {
    [ "$ENABLE_TCTL" = "1" ] || return 1

    local key value actual
    if [ -f "$TCTL_STATE_FILE" ]; then
        key=$(sed -n 's/^key=//p' "$TCTL_STATE_FILE" 2>/dev/null | head -n 1)
        value=$(sed -n 's/^value=//p' "$TCTL_STATE_FILE" 2>/dev/null | head -n 1)
    else
        key="$TCTL_PROP_KEY"
        value="$TCTL_BASELINE_VALUE"
    fi

    [ -n "$key" ] || return 0
    _tctl_log_line "restore" "$key" "$value" "$TCTL_BASELINE_VALUE" "" "try"
    setprop "$key" "$value" >/dev/null 2>&1
    actual="$(_prop_get "$key")"
    if [ "$actual" = "$value" ]; then
        _tctl_log_line "restore" "$key" "$value" "$TCTL_BASELINE_VALUE" "$actual" "ok"
    else
        _tctl_log_line "restore" "$key" "$TCTL_BASELINE_VALUE" "$value" "$actual" "fail"
        rm -f "$TCTL_STATE_FILE" >/dev/null 2>&1
        return 1
    fi
    rm -f "$TCTL_STATE_FILE" >/dev/null 2>&1
    return 0
}

# ── _set_current_mode() ──
_set_current_mode() {
    CURRENT_MODE="$1"
    printf '%s\n' "$CURRENT_MODE" > "$CURRENT_MODE_FILE" 2>/dev/null
}

# ── _transition_lock_on() ──
_transition_lock_on() {
    [ -d "${TRANSITION_LOCK_FILE%/*}" ] || mkdir -p "${TRANSITION_LOCK_FILE%/*}" >/dev/null 2>&1
    : > "$TRANSITION_LOCK_FILE" 2>/dev/null
}

# ── _transition_lock_off() ──
_transition_lock_off() {
    rm -f "$TRANSITION_LOCK_FILE" >/dev/null 2>&1
}

# ── _wait_pid_stable() ──
_wait_pid_stable() {
    local pkg="$1" cur prev="" stable=0 tries=0 max_tries=8

    [ -n "$pkg" ] || return 1

    while [ "$tries" -lt "$max_tries" ]; do
        cur="$(pidof "$pkg" 2>/dev/null)"
        if [ -n "$cur" ] && [ "$cur" = "$prev" ]; then
            stable=$((stable + 1))
            [ "$stable" -ge 2 ] && {
                printf '%s
' "$cur"
                return 0
            }
        else
            stable=0
        fi

        prev="$cur"
        tries=$((tries + 1))
        sleep 1
    done

    [ -n "$prev" ] || return 1
    printf '%s
' "$prev"
    return 0
}

# ── _lq_apply_taskprofile_pid() ──
_lq_apply_taskprofile_pid() {
    local pid="$1"
    shift || true

    [ -n "$pid" ] || return 1
    [ "$#" -gt 0 ] || return 0

    if command -v settaskprofile >/dev/null 2>&1; then
        settaskprofile "$pid" "$@" >/dev/null 2>&1 && return 0
    fi

    if [ -x "/system/bin/settaskprofile" ]; then
        /system/bin/settaskprofile "$pid" "$@" >/dev/null 2>&1 && return 0
    fi

    if [ -x "$MODDIR/system/bin/settaskprofile" ]; then
        "$MODDIR/system/bin/settaskprofile" "$pid" "$@" >/dev/null 2>&1 && return 0
    fi

    printf '%s\n' "Li Qinghe: settaskprofile unavailable, skip pid=$pid profiles=$*" >&2
    return 1
}

# ── _apply_current_game_profile() ──
_apply_current_game_profile() {
    local pids pid recheck=""

    [ -n "$CURRENT_GAME_APP" ] || return 1

    pids="$(_wait_pid_stable "$CURRENT_GAME_APP")" || return 1
    [ -n "$pids" ] || return 1

    for pid in $pids; do
        _lq_apply_taskprofile_pid "$pid" SCHED_SP_TOP_APP CPUSET_SP_TOP_APP SCHED_SP_FOREGROUND
    done

    sleep 1
    recheck="$(pidof "$CURRENT_GAME_APP" 2>/dev/null)"
    [ -n "$recheck" ] || return 0
    [ "$recheck" = "$pids" ] && return 0

    for pid in $recheck; do
        _lq_apply_taskprofile_pid "$pid" SCHED_SP_TOP_APP CPUSET_SP_TOP_APP SCHED_SP_FOREGROUND
    done
    return 0
}

# ── shared notification backend ─────────────────────────────────
LQ_NOTIFY_BACKEND="${LQ_NOTIFY_BACKEND:-$MODDIR/modules/notify.sh}"

# ── _lq_toast() ──
_lq_toast() {
    [ -x "$LQ_NOTIFY_BACKEND" ] || chmod 755 "$LQ_NOTIFY_BACKEND" >/dev/null 2>&1 || true
    sh "$LQ_NOTIFY_BACKEND" toast "$1" >/dev/null 2>&1 || true
}

# ── _lq_toast_plain() (plain toast, no Li Qinghe branding -- game/idle status pop-ups) ──
_lq_toast_plain() {
    [ -x "$LQ_NOTIFY_BACKEND" ] || chmod 755 "$LQ_NOTIFY_BACKEND" >/dev/null 2>&1 || true
    sh "$LQ_NOTIFY_BACKEND" toast_plain "$1" >/dev/null 2>&1 || true
}

# ── _lq_toast_game_enter() (game-entry toast: "<package> Optimized") ──
_lq_toast_game_enter() {
    _lq_toast_plain "$1 Optimized"
}

# ── _lq_toast_idle_enter() (idle-entry toast: "Back to idle") ──
_lq_toast_idle_enter() {
    _lq_toast_plain "Back to idle"
}

# ── _lq_notify() ──
_lq_notify() {
    [ -x "$LQ_NOTIFY_BACKEND" ] || chmod 755 "$LQ_NOTIFY_BACKEND" >/dev/null 2>&1 || true
    sh "$LQ_NOTIFY_BACKEND" notification "$1" >/dev/null 2>&1 || true
}

# ── _lq_wait_boot_completed() ──
_lq_wait_boot_completed() {
    until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
    sleep 5
}

# ── _ensure_gamelist() ──
_ensure_gamelist() {
    local src="$LQ_GAMELIST_SOURCE" dst="$LQ_GAMELIST_FILE" tmp src_size dst_size

    [ -s "$dst" ] && { chmod 666 "$dst" >/dev/null 2>&1; return 0; }
    [ -s "$src" ] || return 1

    [ -d "${dst%/*}" ] || mkdir -p "${dst%/*}" >/dev/null 2>&1 || true
    [ -d "${dst%/*}" ] || return 1

    src_size=$(wc -c < "$src" 2>/dev/null | tr -d '[:space:]')
    [ -n "$src_size" ] || return 1

    tmp="${dst}.new.$$"
    rm -f "$tmp" >/dev/null 2>&1

    if cp -f "$src" "$tmp" >/dev/null 2>&1; then
        :
    elif command -v toybox >/dev/null 2>&1 && toybox cp -f "$src" "$tmp" >/dev/null 2>&1; then
        :
    elif command -v busybox >/dev/null 2>&1 && busybox cp -f "$src" "$tmp" >/dev/null 2>&1; then
        :
    elif cat "$src" > "$tmp" 2>/dev/null; then
        :
    else
        rm -f "$tmp" >/dev/null 2>&1
        return 1
    fi

    [ -s "$tmp" ] || { rm -f "$tmp" >/dev/null 2>&1; return 1; }
    dst_size=$(wc -c < "$tmp" 2>/dev/null | tr -d '[:space:]')
    [ "$dst_size" = "$src_size" ] || { rm -f "$tmp" >/dev/null 2>&1; return 1; }

    chmod 666 "$tmp" >/dev/null 2>&1
    if mv -f "$tmp" "$dst" >/dev/null 2>&1; then
        :
    elif cp -f "$tmp" "$dst" >/dev/null 2>&1; then
        rm -f "$tmp" >/dev/null 2>&1
    elif cat "$tmp" > "$dst" 2>/dev/null; then
        rm -f "$tmp" >/dev/null 2>&1
    else
        rm -f "$tmp" >/dev/null 2>&1
        return 1
    fi

    chmod 666 "$dst" >/dev/null 2>&1
    [ -s "$dst" ] || return 1
    dst_size=$(wc -c < "$dst" 2>/dev/null | tr -d '[:space:]')
    [ "$dst_size" = "$src_size" ]
}

# ── _lq_init_package_lists() ──
_lq_init_package_lists() {
    _generate_user_pkg_inventory >/dev/null 2>&1 || true
    _ensure_gamelist >/dev/null 2>&1 || true
}



# Brand detection (xiaomi / samsung / other) lives with the System Tuning code
# so uninstall.sh can use it too.
[ -f "$MODDIR/modules/system_tuning/oem_family.sh" ] && . "$MODDIR/modules/system_tuning/oem_family.sh"

# ── _lq_collect_device_specs() ──
# Reads what the device actually is into LQ_SPEC_*: memory, swap, CPU cores and
# their real max frequencies, storage type, brand and model. procfs / sysfs /
# getprop only, so it is cheap enough to run on every tweaks.sh call. There are
# no hardware tiers: every tunable below is computed straight from these numbers.
_lq_collect_device_specs() {
    local i=0 f khz last=0 total=0 max=0 dev

    LQ_SPEC_RAM_MB="$(awk '/^MemTotal:/ {print int($2/1024)}' /proc/meminfo 2>/dev/null)"
    case "$LQ_SPEC_RAM_MB" in ''|*[!0-9]*|0) LQ_SPEC_RAM_MB=2048 ;; esac
    LQ_SPEC_SWAP_MB="$(awk '/^SwapTotal:/ {print int($2/1024)}' /proc/meminfo 2>/dev/null)"
    case "$LQ_SPEC_SWAP_MB" in ''|*[!0-9]*) LQ_SPEC_SWAP_MB=0 ;; esac

    # Per-core max frequency, in numeric core order. An offline core usually has
    # no cpufreq node; it belongs to the same cluster as the core before it, so
    # it takes that core's frequency instead of counting as zero.
    while [ -d "/sys/devices/system/cpu/cpu$i" ]; do
        f="/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq"
        khz=""
        [ -r "$f" ] && khz="$(cat "$f" 2>/dev/null)"
        case "$khz" in ''|*[!0-9]*|0) khz=$last ;; esac
        last=$khz
        total=$((total + khz))
        [ "$khz" -gt "$max" ] && max=$khz
        i=$((i + 1))
    done
    LQ_SPEC_CORES=$i
    [ "$LQ_SPEC_CORES" -gt 0 ] 2>/dev/null || LQ_SPEC_CORES=4
    if [ "$max" -le 0 ]; then
        max=1800000
        total=$((LQ_SPEC_CORES * max))
    fi
    LQ_SPEC_MAX_MHZ=$((max / 1000))
    LQ_SPEC_TOTAL_MHZ=$((total / 1000))

    LQ_SPEC_STORAGE=unknown
    dev="$(getprop ro.boot.bootdevice 2>/dev/null)$(getprop ro.boot.storage_type 2>/dev/null)"
    case "$dev" in
        *ufs*|*UFS*)                  LQ_SPEC_STORAGE=ufs ;;
        *sdhci*|*mmc*|*MMC*|*emmc*)   LQ_SPEC_STORAGE=emmc ;;
    esac
    if [ "$LQ_SPEC_STORAGE" = unknown ]; then
        if   [ -d /sys/block/nvme0n1 ]; then LQ_SPEC_STORAGE=nvme
        elif [ -d /sys/block/sda ];     then LQ_SPEC_STORAGE=ufs
        elif [ -d /sys/block/mmcblk0 ]; then LQ_SPEC_STORAGE=emmc
        fi
    fi

    LQ_SPEC_BRAND="$(getprop ro.product.brand 2>/dev/null | tr '[:upper:]' '[:lower:]' | tr -d '\r\n')"
    LQ_SPEC_MANUFACTURER="$(getprop ro.product.manufacturer 2>/dev/null | tr '[:upper:]' '[:lower:]' | tr -d '\r\n')"
    LQ_SPEC_MODEL="$(getprop ro.product.marketname 2>/dev/null | tr -d '\r\n')"
    [ -n "$LQ_SPEC_MODEL" ] || LQ_SPEC_MODEL="$(getprop ro.product.vendor.marketname 2>/dev/null | tr -d '\r\n')"
    [ -n "$LQ_SPEC_MODEL" ] || LQ_SPEC_MODEL="$(getprop ro.product.model 2>/dev/null | tr -d '\r\n')"
    LQ_SPEC_OEM_FAMILY="$(_lq_oem_family 2>/dev/null)"
    [ -n "$LQ_SPEC_OEM_FAMILY" ] || LQ_SPEC_OEM_FAMILY=other
}

# ── _lq_display_hz() ──
# Highest refresh rate the display offers (60 if it can't be read).
_lq_display_hz() {
    local hz
    hz="$(dumpsys display 2>/dev/null | awk -F'fps=' 'NF>1{v=$2+0;if(v>m)m=v}END{print int(m)}')"
    case "$hz" in ''|0|*[!0-9]*) hz=60 ;; esac
    printf '%s\n' "$hz"
}

# ── _lq_calc_values() [refresh_hz] ──
# Turns the LQ_SPEC_* numbers into a value for every tunable and prints them as
# NAME=value lines (numbers only, safe to eval). Everything is a smooth function
# of the measured specs, so two devices that differ only slightly get slightly
# different values instead of landing on the same fixed step:
#
#   mem   RAM position on a log scale, 0 at ~2 GB up to 1 at ~16 GB
#   cpu   aggregate core throughput (sum of every core's max GHz), 6 .. 20 GHz
#   st    fastest core's max GHz, 1.5 .. 3.4
#
#   HWUI target CPU time   50..58 %   from mem, cpu and st; idle is game + 4
#   Job scheduler          active jobs = 36 + 4 per core + 2 per GB of RAM, even,
#                          48..96; background counts and min-ready follow it
#   Multitasking           multiplier from RAM (log scale), +-0.1 from CPU, then
#                          snapped to the nearest of the five presets
#   SQLite WAL checkpoint  32 pages doubling per RAM octave (32..256), scaled by
#                          storage (eMMC x0.75, NVMe x1.15); journal limit is the
#                          WAL size plus 25 % headroom, in whole 4 KB pages
#   App standby            6 h doubling per RAM octave, scaled by CPU (6..48 h)
#   Low swap threshold     0.25 .. 1.00 by RAM, to the nearest 0.05
#   Fily need              0 .. 1 from (1 - mem), memory stall and free memory;
#                          0.45 or more means pressure management beats Multitasking
#   Long press             210 ms + two display frames, to the nearest 5 ms
_lq_calc_values() {
    awk -v ram="$LQ_SPEC_RAM_MB" -v cores="$LQ_SPEC_CORES" -v tot="$LQ_SPEC_TOTAL_MHZ" \
        -v mx="$LQ_SPEC_MAX_MHZ" -v stor="$LQ_SPEC_STORAGE" -v hz="${1:-0}" \
        -v psi="${LQ_SPEC_PSI_AVG300:-0}" -v avail="${LQ_SPEC_AVAIL_MB:-$LQ_SPEC_RAM_MB}" '
    function clamp(v,lo,hi){ return v<lo ? lo : (v>hi ? hi : v) }
    function rnd(v,s){ return int(v/s+0.5)*s }
    BEGIN{
        x=log(ram)/log(2)
        mem=clamp((x-10.73)/(13.92-10.73),0,1)
        cpu=clamp((tot/1000-6)/14,0,1)
        st=clamp((mx/1000-1.5)/1.9,0,1)

        game=50+int(8*(0.4*mem+0.3*cpu+0.3*st)+0.5)
        printf "HWUI_GAME_CPU_PCT=%d\n", game
        printf "HWUI_IDLE_CPU_PCT=%d\n", game+4

        act=clamp(rnd(36+4*cores+2*(ram/1024),2),48,96)
        nrm=clamp(rnd(act/16,1),3,8)
        printf "JOB_SCHED_ACTIVE=%d\n", act
        printf "JOB_SCHED_BG_NORM=%d\n", nrm
        printf "JOB_SCHED_BG_MOD=%d\n", rnd(nrm*1.8,1)
        printf "JOB_SCHED_BG_LOW=%d\n", rnd(nrm*3.2,1)
        printf "JOB_SCHED_MIN_READY=%d\n", clamp(rnd(cores/2,1),2,6)

        if (x<=12.87) m=0.5+(x-10.73)*0.304; else m=1.15+(x-12.87)*0.333
        m=clamp(m+(cpu-0.5)*0.2,0.5,1.5)
        printf "LQ_REC_MT_PRESET=%s\n", ((m<0.625) ? "lowest" : (m<0.875) ? "low" : (m<1.125) ? "medium" : (m<1.375) ? "high" : "highest")

        oct=exp(clamp((x-11.2)*1.1,0,3)*log(2))
        sf=1; if (stor=="emmc") sf=0.75; else if (stor=="nvme") sf=1.15
        wal=clamp(rnd(32*oct*sf,4),32,256)
        printf "LQ_REC_WAL=%d\n", wal
        printf "LQ_REC_JOURNAL=%d\n", int(wal*1.25+0.999)*4096

        h=clamp(rnd(6*oct*(0.85+0.3*cpu),1),6,48)
        printf "LQ_REC_STANDBY_MS=%.0f\n", h*3600000

        printf "LQ_REC_SWAP_THR=%.2f\n", clamp(rnd(0.25+0.75*clamp((x-11.2)/2.7,0,1),0.05),0.2,1)

        # How badly this device needs memory-pressure management (Fily) rather than a
        # bigger background-app allowance (Multitasking): mostly how little RAM it
        # has. How much memory stall (PSI, 5 min average) and how little free memory
        # it shows right now only nudges it (at most +0.20), so a one-off busy moment
        # can tip a borderline device but never an 8 GB-class one.
        press=clamp(psi/5,0,1)
        low=clamp((0.25-avail/ram)/0.25,0,1)
        printf "LQ_REC_FILY_NEED=%.2f\n", (1-mem)*0.75+press*0.15+low*0.05

        lp=250
        if (hz>0) lp=clamp(rnd(210+2*(1000/hz),5),150,600)
        printf "LQ_REC_LONGPRESS=%d\n", lp
    }'
}

# ── _detect_hwui_profile() ──
# Kept under its old name because service.sh / tweaks.sh call it. It no longer
# classifies the device into a tier: it reads the specs and sets the runtime
# values (HWUI target CPU time, JobScheduler counts) straight from them.
_detect_hwui_profile() {
    _lq_collect_device_specs
    eval "$(_lq_calc_values 0)"
}

# ── _lq_build_recommended_profile() ──
# Runs once at service startup (and on "Detect profile") and is the ONLY place
# device capability is turned into a recommendation: which System Tuning groups
# to enable and which value to use for each of their tunables. Every value comes
# from the device's measured specs (see _lq_calc_values); the brand only decides
# whether the vendor-specific OEM group applies. The result is written to
# $LQ_RECOMMENDED_PROFILE_FILE for the WebUI/backend to read verbatim.
_lq_build_recommended_profile() {
    local hz out tmp g gsafe rec_oem rec_swap rec_fily rec_tctl

    _lq_collect_device_specs
    hz="$(_lq_display_hz)"
    # Live memory state, only needed for the Fily decision
    LQ_SPEC_AVAIL_MB="$(awk '/^MemAvailable:/ {print int($2/1024)}' /proc/meminfo 2>/dev/null)"
    case "$LQ_SPEC_AVAIL_MB" in ''|*[!0-9]*) LQ_SPEC_AVAIL_MB=$LQ_SPEC_RAM_MB ;; esac
    LQ_SPEC_PSI=0; LQ_SPEC_PSI_AVG300=0
    if [ -r /proc/pressure/memory ]; then
        LQ_SPEC_PSI=1
        LQ_SPEC_PSI_AVG300="$(awk '/^some/ {for(i=1;i<=NF;i++) if($i ~ /^avg300=/){sub("avg300=","",$i); print $i}}' /proc/pressure/memory 2>/dev/null)"
        case "$LQ_SPEC_PSI_AVG300" in ''|*[!0-9.]*) LQ_SPEC_PSI_AVG300=0 ;; esac
    fi
    eval "$(_lq_calc_values "$hz")"

    # Helpers. Fily and Multitasking drive the same ActivityManager memory knobs and
    # exclude each other, so exactly one of them is recommended: Fily when this
    # device is memory-starved AND can run it (PSI readable, binary present),
    # otherwise Multitasking. Tctl is recommended wherever a vendor thermal property
    # it can drive exists; it only acts in game mode.
    rec_fily=0
    if [ "$LQ_SPEC_PSI" = 1 ] && _lq_fily_bin >/dev/null 2>&1 \
       && awk -v n="$LQ_REC_FILY_NEED" 'BEGIN{exit !(n+0>=0.45)}'; then
        rec_fily=1
    fi
    if _lq_tctl_supported; then rec_tctl=1; else rec_tctl=0; fi

    # OEM Tuning only does something on the families tuning_toggle_oem_tweaks
    # supports, so only recommend it there.
    case "$LQ_SPEC_OEM_FAMILY" in xiaomi|samsung) rec_oem=1 ;; *) rec_oem=0 ;; esac
    # The Low Swap threshold is meaningless on a device with no swap at all.
    if [ "$LQ_SPEC_SWAP_MB" -gt 0 ] 2>/dev/null; then rec_swap=1; else rec_swap=0; fi

    out="$LQ_RECOMMENDED_PROFILE_FILE"
    tmp="${out}.tmp.$$"
    {
        printf 'recommended_spec_brand=%s\n' "$LQ_SPEC_BRAND"
        printf 'recommended_spec_model=%s\n' "$LQ_SPEC_MODEL"
        printf 'recommended_spec_oem_family=%s\n' "$LQ_SPEC_OEM_FAMILY"
        printf 'recommended_spec_ram_mb=%s\n' "$LQ_SPEC_RAM_MB"
        printf 'recommended_spec_swap_mb=%s\n' "$LQ_SPEC_SWAP_MB"
        printf 'recommended_spec_cores=%s\n' "$LQ_SPEC_CORES"
        printf 'recommended_spec_max_mhz=%s\n' "$LQ_SPEC_MAX_MHZ"
        printf 'recommended_spec_storage=%s\n' "$LQ_SPEC_STORAGE"
        printf 'recommended_spec_refresh_hz=%s\n' "$hz"

        printf 'recommended_spec_psi=%s\n' "$LQ_SPEC_PSI"
        printf 'recommended_spec_fily_need=%s\n' "$LQ_REC_FILY_NEED"
        printf 'recommended_helper_fily=%s\n' "$rec_fily"
        printf 'recommended_helper_tctl=%s\n' "$rec_tctl"

        for g in job-scheduler sqlite-tuning \
                 app-standby persist-log-tags logging-diagnostics selected-diagnostics \
                 debug-props doze long-press-latency compile-keyboard; do
            gsafe="$(printf '%s' "$g" | tr '-' '_')"
            printf 'recommended_perf_%s=1\n' "$gsafe"
        done
        printf 'recommended_perf_multitasking=%s\n' "$((1 - rec_fily))"
        printf 'recommended_perf_low_swap=%s\n' "$rec_swap"
        printf 'recommended_perf_oem_tuning=%s\n' "$rec_oem"

        printf 'recommended_value_job_scheduler_max_job_count_active=%s\n' "$JOB_SCHED_ACTIVE"
        printf 'recommended_value_multitasking_preset=%s\n' "$LQ_REC_MT_PRESET"
        printf 'recommended_value_sqlite_tuning_wal_checkpoint=%s\n' "$LQ_REC_WAL"
        printf 'recommended_value_sqlite_tuning_journal_size=%s\n' "$LQ_REC_JOURNAL"
        printf 'recommended_value_app_standby_strong_usage_duration=%s\n' "$LQ_REC_STANDBY_MS"
        printf 'recommended_value_low_swap_threshold_percent=%s\n' "$LQ_REC_SWAP_THR"
        printf 'recommended_value_long_press_latency_timeout_ms=%s\n' "$LQ_REC_LONGPRESS"
    } > "$tmp" 2>/dev/null || { rm -f "$tmp" >/dev/null 2>&1; return 1; }

    chmod 666 "$tmp" >/dev/null 2>&1 || true
    mv -f "$tmp" "$out" 2>/dev/null || { rm -f "$tmp" >/dev/null 2>&1; return 1; }
    return 0
}

# ── _lq_recommended_get() ──
# Read-only lookup into the profile _lq_build_recommended_profile already
# wrote. Callers (WebUI backend included) must treat this as a plain read --
# never a trigger to detect or recalculate anything themselves.
_lq_recommended_get() {
    local key="$1"
    [ -n "$key" ] || return 1
    [ -f "$LQ_RECOMMENDED_PROFILE_FILE" ] || return 1
    sed -n "s/^${key}=//p" "$LQ_RECOMMENDED_PROFILE_FILE" 2>/dev/null | tail -n 1
}

# ── _lq_wait_recommended_value() ──
# Same as _lq_recommended_get, but if _lq_build_recommended_profile hasn't
# written $LQ_RECOMMENDED_PROFILE_FILE yet (or this particular key isn't in
# it), waits for it instead of the caller silently falling back to a
# hardcoded guess. service.sh always builds the recommended profile before
# anything that needs a default value, so this should normally return
# immediately on the first check; the bounded retry only covers a genuinely
# slow/cold start. Prints nothing and returns 1 if it truly never shows up
# within the wait window -- callers must treat that as a real failure, not
# silently substitute a made-up number.
_lq_wait_recommended_value() {
    local key="$1" tries=0 max_tries=25 v
    [ -n "$key" ] || return 1
    while [ "$tries" -lt "$max_tries" ]; do
        v="$(_lq_recommended_get "$key" 2>/dev/null)"
        if [ -n "$v" ]; then
            printf '%s\n' "$v"
            return 0
        fi
        tries=$((tries + 1))
        sleep 0.2 2>/dev/null || sleep 1
    done
    return 1
}

# ── boot baseline removed: heavy tweaks are manual in System Tuning ──

# ── runtime performance key helpers ──
_lq_runtime_perf_apply_keys() {
    [ -s "$LQ_RUNTIME_PERF_KEYS_FILE" ] || return 0
    local key ns value
    : > "$LQ_RUNTIME_PERF_BACKUP_FILE"
    while IFS='|' read -r ns key; do
        [ -n "$ns" ] && [ -n "$key" ] || continue
        value="$(settings get "$ns" "$key" 2>/dev/null | tr -d '\r')"
        printf '%s|%s|%s\n' "$ns" "$key" "$value" >> "$LQ_RUNTIME_PERF_BACKUP_FILE"
        settings put "$ns" "$key" 1 >/dev/null 2>&1 || true
    done < "$LQ_RUNTIME_PERF_KEYS_FILE"
}

_lq_runtime_perf_restore_keys() {
    [ -s "$LQ_RUNTIME_PERF_BACKUP_FILE" ] || return 0
    local ns key value
    while IFS='|' read -r ns key value; do
        [ -n "$ns" ] && [ -n "$key" ] || continue
        case "$value" in
            null|'') settings delete "$ns" "$key" >/dev/null 2>&1 || true ;;
            *) settings put "$ns" "$key" "$value" >/dev/null 2>&1 || true ;;
        esac
    done < "$LQ_RUNTIME_PERF_BACKUP_FILE"
    : > "$LQ_RUNTIME_PERF_BACKUP_FILE"
}

_lq_runtime_perf_detect_keys() {
    [ -d "$LQ_TMP_DIR" ] || mkdir -p "$LQ_TMP_DIR" >/dev/null 2>&1
    : > "$LQ_RUNTIME_PERF_KEYS_FILE"

    # Strict allowlist: only known performance/game/power switches are
    # eligible for automatic runtime mode. Do not scrape arbitrary keys
    # merely because their names contain perf/game/boost/turbo.
    local ns key value
    for ns in system global; do
        settings list "$ns" 2>/dev/null |
            awk -F= 'NF>=2 {print $1}' |
            while IFS= read -r key; do
                [ -n "$key" ] || continue
                case "$key" in
                    POWER_PERFORMANCE_MODE_OPEN|high_performance_mode_on|high_performance_mode|power_performance_mode|performance_mode|bench_mark_mode|benchmark_mode|tran_cpupower_mode|tran_perf_mode|tran_performance_mode|tran_game_mode|game_mode|game_mode_enable|gaming_mode|transsion_game_mode|transsion_game_acceleration|transsion_turbo_assistant)
                        ;;
                    *) continue ;;
                esac

                value="$(settings get "$ns" "$key" 2>/dev/null | tr -d '\r')"
                case "$value" in
                    0|1) printf '%s|%s\n' "$ns" "$key" >> "$LQ_RUNTIME_PERF_KEYS_FILE" ;;
                esac
            done
    done

    sort -u "$LQ_RUNTIME_PERF_KEYS_FILE" -o "$LQ_RUNTIME_PERF_KEYS_FILE" 2>/dev/null || true
    chmod 666 "$LQ_RUNTIME_PERF_KEYS_FILE" >/dev/null 2>&1 || true
}

# ── _lq_auto_game_apply() ── minimal automatic runtime game profile ──
_lq_auto_game_apply() {
    _lq_runtime_perf_apply_keys
    if [ "$(_lq_tctl_enabled 2>/dev/null)" = "1" ]; then
        _tctl_init >/dev/null 2>&1 || true
        _tctl_apply >/dev/null 2>&1 || true
    else
        rm -f "$TCTL_STATE_FILE" >/dev/null 2>&1 || true
    fi
    _apply_current_game_profile >/dev/null 2>&1 || true
    setprop debug.hwui.target_cpu_time_percent "${HWUI_GAME_CPU_PCT:-50}" >/dev/null 2>&1 || true
    _power_fixed_perf_apply >/dev/null 2>&1 || true
}

# ── _lq_auto_idle_restore() ── minimal automatic runtime idle restore ──
_lq_auto_idle_restore() {
    _lq_runtime_perf_restore_keys
    setprop debug.hwui.target_cpu_time_percent "${HWUI_IDLE_CPU_PCT:-54}" >/dev/null 2>&1 || true
    _power_fixed_perf_restore >/dev/null 2>&1 || true
    if [ "$(_lq_tctl_enabled 2>/dev/null)" = "1" ]; then
        _tctl_restore >/dev/null 2>&1 || true
    else
        rm -f "$TCTL_STATE_FILE" >/dev/null 2>&1 || true
    fi
}

# ── _lq_hwui_cpu_pct() ──
_lq_hwui_cpu_pct() {
    case $1 in
        debug.hwui.target_cpu_time_percent) [ "$2" = "game" ] && echo "${HWUI_GAME_CPU_PCT:-50}" || echo "${HWUI_IDLE_CPU_PCT:-54}" ;;
        *) echo "" ;;
    esac
}

# ── _lq_conflict_add_prop() ──
_lq_conflict_add_prop() {
    local key="$1" expected="$2" out="${3:-$EXPECTED_FILE}"
    [ -n "$key" ] || return 0
    [ -n "$expected" ] || return 0
    # persist.* props (persist.log.tag.*, persist.debug.*, ...) are never put
    # in the expected list: on some devices the system reverts them by itself,
    # which the watcher would report as a false conflict.
    case "$key" in persist.*) return 0 ;; esac
    # Used to grep the whole (growing) output file on every single call to
    # skip duplicates -- O(n) per insert, O(n^2) overall once a domain
    # contributes more than a handful of keys. persist.log.tag.* alone is
    # easily 200-500+ properties on a real device, so that grep-per-insert
    # was spawning hundreds of processes and re-scanning an ever-longer
    # file on every single Apply/Reset. Every insert is now an
    # unconditional append; _lq_build_expected_props does one linear dedup
    # pass over the whole file at the end instead (same end result: first
    # occurrence of a key wins).
    printf '%s=%s\n' "$key" "$expected" >> "$out"
}

# Reads a System Tuning value (same file tuning_set_value
# writes: value_<group>_<key>) without needing modules/system_tuning.sh.
# zi.sh, the process that switches game/idle and rebuilds this snapshot,
# only sources common.sh, so tuning_get_value does
# not exist there. Calling it came back empty, the code fell through to the
# RECOMMENDED value, and any custom SQLite value then no longer matched the
# snapshot -> false conflict (Sleep) the moment a game opened.
_lq_conflict_manual_value() {
    local safe file v
    safe="$(printf '%s' "$1" | tr '-' '_')"
    file="$LQ_SYSTEM_TUNING_MANUAL_DIR/value_${safe}_$2"
    [ -f "$file" ] || return 0
    v="$(cat "$file" 2>/dev/null | tr -d '\r\n ')"
    [ -n "$v" ] && printf '%s' "$v"
    return 0
}

# Build the complete set of properties that Li Qinghe can actively own.
# Older versions tracked only HWUI (+ optional Tctl), which meant another
# module could overwrite SurfaceFlinger, SQLite, debug/logging properties,
# etc. without ever being reported. This registry is property-only by design
# and only includes domains that Li Qinghe itself actually writes.
_lq_build_expected_props() {
    local mode="$1" line key value sf pct refresh frame_ns duration out tmp
    out="$EXPECTED_FILE"
    tmp="${out}.tmp.$$"
    : > "$tmp" || return 1

    # Static module properties from system.prop.
    if [ -f "$MODDIR/system.prop" ]; then
        while IFS= read -r line; do
            case "$line" in
                ''|\#*) continue ;;
            esac
            key="${line%%=*}"
            value="${line#*=}"
            case "$key" in
                ''|*[![:alnum:]_./-]*) continue ;;
            esac
            _lq_conflict_add_prop "$key" "$value" "$tmp"
        done < "$MODDIR/system.prop"
    fi

    # Runtime HWUI target differs between game/performance and idle.
    _lq_conflict_add_prop debug.hwui.target_cpu_time_percent "$(_lq_hwui_cpu_pct debug.hwui.target_cpu_time_percent "$mode")" "$tmp"

    # Tctl (thermal control) is intentionally NOT added to the conflict
    # watcher's expected-property registry: other tuning modules commonly
    # poke the same thermal-control knobs, and treating that as "conflict"
    # would false-positive against perfectly normal coexistence. Tctl is
    # applied best-effort in _lq_auto_game_apply()/_lq_auto_idle_restore() and any apply/restore failure is
    # already logged via _tctl_log_line, independent of the watcher.

    # SurfaceFlinger properties, only when the SF profile is active.
    sf="$(_lq_sf_detect 2>/dev/null)"
    case "$sf" in
        ''|0|off) ;;
        ''|*[!0-9]*) ;;
        *)
            refresh="$(_lq_sf_refresh 2>/dev/null)"
            case "$refresh" in ''|*[!0-9]*) refresh=60;; esac
            [ "$refresh" -ge 30 ] 2>/dev/null || refresh=60
            frame_ns=$((1000000000 / refresh))
            duration=$((frame_ns * sf / 100))
            _lq_conflict_add_prop debug.sf.early.app.duration "$duration" "$tmp"
            _lq_conflict_add_prop debug.sf.earlyGl.app.duration "$duration" "$tmp"
            _lq_conflict_add_prop debug.sf.late.app.duration "$duration" "$tmp"
            _lq_conflict_add_prop debug.sf.early.sf.duration "$duration" "$tmp"
            _lq_conflict_add_prop debug.sf.earlyGl.sf.duration "$duration" "$tmp"
            _lq_conflict_add_prop debug.sf.late.sf.duration "$duration" "$tmp"
            _lq_conflict_add_prop debug.sf.use_phase_offsets_as_durations 1 "$tmp"
            _lq_conflict_add_prop debug.sf.enable_gl_backpressure 1 "$tmp"
            _lq_conflict_add_prop debug.sf.latch_unsignaled 1 "$tmp"
            _lq_conflict_add_prop debug.sf.enable_hwc_vds 0 "$tmp"
            ;;
    esac

    # Manual SQLite tuning.
    if [ -f "$LQ_SYSTEM_TUNING_MANUAL_DIR/sqlite_tuning.state" ] && [ "$(cat "$LQ_SYSTEM_TUNING_MANUAL_DIR/sqlite_tuning.state" 2>/dev/null)" = "1" ]; then
        value="$(_lq_conflict_manual_value sqlite-tuning wal_checkpoint)"
        [ -n "$value" ] || value="$(_lq_wait_recommended_value recommended_value_sqlite_tuning_wal_checkpoint)"
        if [ -n "$value" ]; then
            _lq_conflict_add_prop debug.sqlite.wal.autocheckpoint "$value" "$tmp"
        fi
        value="$(_lq_conflict_manual_value sqlite-tuning journal_size)"
        [ -n "$value" ] || value="$(_lq_wait_recommended_value recommended_value_sqlite_tuning_journal_size)"
        if [ -n "$value" ]; then
            _lq_conflict_add_prop debug.sqlite.journalsizelimit "$value" "$tmp"
        fi
        _lq_conflict_add_prop debug.sqlite.journalmode PERSIST "$tmp"
    fi

    # Dynamically discovered debug props are all part of the active tuning
    # group, so every key discovered by that scanner is also conflict checked.
    if [ -f "$LQ_SYSTEM_TUNING_MANUAL_DIR/debug_props" ] && [ -f "$LQ_SYSTEM_TUNING_MANUAL_DIR/debug_props.state" ] && [ "$(cat "$LQ_SYSTEM_TUNING_MANUAL_DIR/debug_props.state" 2>/dev/null)" = "1" ]; then
        while read -r key value; do
            [ -n "$key" ] && _lq_conflict_add_prop "$key" "$value" "$tmp"
        done < "$LQ_SYSTEM_TUNING_MANUAL_DIR/debug_props"
    fi

    # Every persist.log.tag property Li Qinghe forced to S is tracked too.
    if [ -f "$LQ_SYSTEM_TUNING_MANUAL_DIR/persist_log_tags.list" ] && [ -f "$LQ_SYSTEM_TUNING_MANUAL_DIR/persist_log_tags.state" ] && [ "$(cat "$LQ_SYSTEM_TUNING_MANUAL_DIR/persist_log_tags.state" 2>/dev/null)" = "1" ]; then
        while IFS= read -r key; do
            [ -n "$key" ] && _lq_conflict_add_prop "$key" S "$tmp"
        done < "$LQ_SYSTEM_TUNING_MANUAL_DIR/persist_log_tags.list"
    fi

    # The renderer picked on the Tweaks page (debug.hwui.renderer + debug.renderengine.backend) is Li Qinghe's own write.
    if [ -f "$LQ_TMP_DIR/display_renderer" ]; then
        value="$(cat "$LQ_TMP_DIR/display_renderer" 2>/dev/null | tr -d '\r\n')"
        if pair="$(_lq_disp_renderer_props "$value" 2>/dev/null)"; then
            _lq_conflict_add_prop debug.hwui.renderer "${pair% *}" "$tmp"
            _lq_conflict_add_prop debug.renderengine.backend "${pair#* }" "$tmp"
        fi
    fi

    # One linear dedup pass over the whole file (first occurrence of each
    # key wins -- same result the old grep-per-insert produced, just O(n)
    # instead of O(n^2)) now that _lq_conflict_add_prop no longer checks
    # for duplicates itself.
    awk -F= '!seen[$1]++' "$tmp" > "${tmp}.dedup" 2>/dev/null && mv -f "${tmp}.dedup" "$tmp" 2>/dev/null
    rm -f "${tmp}.dedup" 2>/dev/null

    chmod 666 "$tmp" 2>/dev/null || true
    mv -f "$tmp" "$EXPECTED_FILE" 2>/dev/null || { rm -f "$tmp"; return 1; }
    return 0
}

# ── _lq_conflict_snapshot_refresh() -- rebuild the conflict watcher's expected-property snapshot for a mode ("game"/"idle") ──
_lq_conflict_snapshot_refresh() {
    _lq_build_expected_props "$1"
    [ "$1" = "idle" ] && rm -f "$LQ_RUNTIME_PERF_BACKUP_FILE" >/dev/null 2>&1 || true
}

# ── _enter_game_mode() ──
_enter_game_mode() {
    _transition_lock_on
    TRANSITION_LOCK=1
    _set_current_mode performance
    [ "$(cat "$LQ_IDLE_PROFILE_FILE" 2>/dev/null)" = "battery-saver" ] &&
        _lq_battery_saver_disable >/dev/null 2>&1 || true
    _lq_auto_game_apply
    _lq_conflict_snapshot_refresh "game"

    _lq_notify "$(printf '%s\n%s' \
        "All perf tweaks applied" \
        "enjoy your game")"
    _lq_toast_game_enter "$CURRENT_GAME_APP"
    TRANSITION_LOCK=0
    _transition_lock_off
}

# ── _enter_idle_mode() ──
_enter_idle_mode() {
    _transition_lock_on
    TRANSITION_LOCK=1
    _set_current_mode powersave
    _lq_auto_idle_restore
    if [ "$(cat "$LQ_IDLE_PROFILE_FILE" 2>/dev/null)" = "battery-saver" ]; then
        _lq_battery_saver_enable >/dev/null 2>&1 || true
    fi
    _lq_conflict_snapshot_refresh "idle"
    case "$(cat "$LQ_IDLE_PROFILE_FILE" 2>/dev/null)" in
        battery-saver) _LQ_IDLE_PROFILE_LABEL="Battery Saver" ;;
        *) _LQ_IDLE_PROFILE_LABEL="Normal" ;;
    esac
    _lq_notify "$(printf '%s\n%s' \
        "All perf tweaks reverted" \
        "Profile: $_LQ_IDLE_PROFILE_LABEL")"
    _lq_toast_idle_enter
    TRANSITION_LOCK=0
    _transition_lock_off
}

# ── gamelist cache ──
# The gamelist is held in one shell variable as "\npkg\npkg\n" so a tick can
# match it with a plain `case` (builtin, no fork, no grep). It is re-read only
# when the list path changes or the file is modified after the last load;
# a stamp file's mtime is the "last loaded" marker, compared with builtin -nt.
_LQ_NL='
'
_LQ_GL=""
_LQ_GL_PATH=""

_lq_gamelist_load() {
    local list="$1" line
    _LQ_GL="$_LQ_NL"
    if [ -r "$list" ]; then
        while IFS= read -r line || [ -n "$line" ]; do
            # Same rules zfg used: drop trailing CR/space/tab, skip blanks,
            # exact match otherwise (no comment syntax).
            line="${line%"${line##*[![:space:]]}"}"
            [ -n "$line" ] && _LQ_GL="$_LQ_GL$line$_LQ_NL"
        done < "$list"
    fi
    _LQ_GL_PATH="$list"
    : > "$LQ_TMP_DIR/.gamelist_loaded" 2>/dev/null
}

# ── _lq_foreground_resolve() ──
# Name kept so zi.sh does not change; the foreground app now comes from ven.
_lq_foreground_resolve() {
    local pkg list

    # Contract (unchanged for callers):
    #   return 0 -> LQ_FG_APP = top app package, LQ_FG_IS_GAME = 1 or 0
    #   return 1 -> foreground could not be resolved (LQ_FG_APP is empty)
    LQ_FG_APP=""
    LQ_FG_IS_GAME=0

    [ -n "$_LQ_VEN_BIN" ] || return 1

    # One command substitution per tick is the only fork left besides ven.
    pkg="$("$_LQ_VEN_BIN" 2>/dev/null)"

    # Only a bare package name is accepted. This also rejects any error text
    # ven might print, so it can never be mistaken for an app.
    case "$pkg" in
        ""|*[!A-Za-z0-9._]*) return 1 ;;
    esac

    # Same rule the WebUI and pkgmgr use (_lq_active_gamelist_file in
    # other/pkgmgr.sh): the list the game scan detected wins as soon as it has
    # content, otherwise the bundled gamelist. Inlined with builtin tests so
    # a tick still costs no extra process.
    if [ -s "$LQ_GAMELIST_DETECTED_FILE" ]; then
        list="$LQ_GAMELIST_DETECTED_FILE"
    else
        list="$GAMELIST_LOCAL"
        [ -s "$list" ] || list="$LQ_GAMELIST_FILE"
        [ -s "$list" ] || list="$LQ_GAMELIST_SOURCE"
    fi

    if [ "$list" != "$_LQ_GL_PATH" ] || [ ! "$LQ_TMP_DIR/.gamelist_loaded" -nt "$list" ]; then
        _lq_gamelist_load "$list"
    fi

    case "$_LQ_GL" in
        *"$_LQ_NL$pkg$_LQ_NL"*) LQ_FG_IS_GAME=1 ;;
    esac

    LQ_FG_APP="$pkg"
    return 0
}

# ── _lq_fix_perms() ──
# The state folder is created by root at boot/install, but the WebUI backend may
# run as shell (AxManager / Axora). Root-owned 0644 files and 0755 dirs then
# cannot be rewritten by that shell, so tweaks silently fail to save. Make the
# whole folder world-writable (only effective when called as root/owner).
_lq_fix_perms() {
    [ -d "$LQ_TMP_DIR" ] || return 0
    chmod 777 "$LQ_TMP_DIR" >/dev/null 2>&1 || true
    chmod -R a+rwX "$LQ_TMP_DIR" >/dev/null 2>&1 || {
        find "$LQ_TMP_DIR" -type d -exec chmod 777 {} + >/dev/null 2>&1
        find "$LQ_TMP_DIR" -type f -exec chmod 666 {} + >/dev/null 2>&1
    }
    # keep ven executable (Fily runs it from here)
    [ -f "$LQ_TMP_DIR/ven" ] && chmod 755 "$LQ_TMP_DIR/ven" >/dev/null 2>&1
    return 0
}
