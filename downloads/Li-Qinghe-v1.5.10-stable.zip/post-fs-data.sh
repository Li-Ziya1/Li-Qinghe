#!/system/bin/sh
# Runs before SurfaceFlinger starts: put the RenderEngine backend chosen on the Tweaks page
# (Renderer tile) back. debug.* props do not survive a reboot and SurfaceFlinger only reads
# debug.renderengine.backend while it starts, so service.sh would be too late for it.
D=/data/local/tmp/liqinghe
v="$(cat "$D/display_renderer" 2>/dev/null | tr -d '\r\n')"
case "$v" in
    skiavk)         h=skiavk; b=skiavk ;;
    skiavkthreaded) h=skiavk; b=skiavkthreaded ;;
    skiagl)         h=skiagl; b=skiagl ;;
    skiaglthreaded) h=skiagl; b=skiaglthreaded ;;
    gles)           h=skiagl; b=gles ;;
    glesthreaded)   h=skiagl; b=threaded ;;
    *) exit 0 ;;
esac
MODDIR=${0%/*}
if command -v resetprop >/dev/null 2>&1; then SP=resetprop; else SP=setprop; fi
$SP debug.hwui.renderer "$h" >/dev/null 2>&1
$SP debug.renderengine.backend "$b" >/dev/null 2>&1
# the extra props that go with a renderer (same list the Renderer tile uses)
case "$v" in skiagl|skiaglthreaded) fam=gl ;; *) fam=other ;; esac
while read -r scope key val; do
    case "$scope" in ''|\#*) continue ;; esac
    if [ "$scope" = "all" ] || [ "$fam" = "gl" ]; then $SP "$key" "$val" >/dev/null 2>&1; fi
done < "$MODDIR/modules/renderer_extra_props.txt" 2>/dev/null
exit 0
