#!/system/bin/sh

MODDIR=${0%/*}
umask 000
LQ_OTHER_DIR="$MODDIR/other"
LQ_TMP_DIR="${LQ_TMP_DIR:-/data/local/tmp/liqinghe}"
CONFIG_FILE="$LQ_TMP_DIR/lq.conf"
LQ_GAMELIST_FILE="$LQ_TMP_DIR/gamelist.txt"
LQ_WHITELIST_FILE="$LQ_TMP_DIR/whitelist.txt"
LQ_PRELIST_FILE="$LQ_TMP_DIR/prelist.txt"
LQ_PRELOAD_FILE="$LQ_TMP_DIR/preload.txt"
LQ_USERPKG_FILE="$LQ_TMP_DIR/userpkg.txt"
LQ_IDLE_PROFILE_FILE="$LQ_TMP_DIR/idle_profile"
LQ_SURFACE_FLINGER_PROFILE_FILE="$LQ_TMP_DIR/surface_flinger_profile"
LQ_TRACE_PROFILE_FILE="$LQ_TMP_DIR/trace_guard_profile"
LQ_FILY_STATE_FILE="$LQ_TMP_DIR/fily_enabled"
LQ_TCTL_STATE_FILE="$LQ_TMP_DIR/tctl_enabled"

mkdir -p "$LQ_OTHER_DIR" "$LQ_TMP_DIR" >/dev/null 2>&1
chmod 755 "$LQ_TMP_DIR" >/dev/null 2>&1

# Magisk's default post-install pass sets module files to 0644 unless told
# otherwise. Everything under system/bin is meant to be executed directly
# (ven, Liziya, fily_ctl, fily_ctl32, ywhy) -- without this they'd all be
# silently non-executable after a fresh install and _resolve_ven_bin/etc.
# would fail every time.
set_perm_recursive "$MODDIR/system/bin" 0 2000 0755 0755 >/dev/null 2>&1 || true

# Fily runs ven from $LQ_TMP_DIR/ven (service.sh refreshes this copy on every
# boot). Copy + rename so Fily never executes a half-written file and a copy
# that is running during a module update can still be replaced.
if [ -f "$MODDIR/system/bin/ven" ]; then
    cp -f "$MODDIR/system/bin/ven" "$LQ_TMP_DIR/ven.tmp" >/dev/null 2>&1 \
        && chmod 755 "$LQ_TMP_DIR/ven.tmp" >/dev/null 2>&1 \
        && mv -f "$LQ_TMP_DIR/ven.tmp" "$LQ_TMP_DIR/ven" >/dev/null 2>&1
    rm -f "$LQ_TMP_DIR/ven.tmp" >/dev/null 2>&1
fi

[ -f "$LQ_OTHER_DIR/pkgmgr.sh" ] && . "$LQ_OTHER_DIR/pkgmgr.sh"

# ── generate config jika belum ada ───────────────────────────
[ ! -f "$CONFIG_FILE" ] && {
cat <<EOF > "$CONFIG_FILE"
ENABLE_JOBSCHED=1
ENABLE_SQLITE=1
ENABLE_SWAP_THRESHOLD=1
ENABLE_APP_STANDBY=1
ENABLE_POWER_FIXED_PERF=1
ENABLE_FILY=1
ENABLE_FILY_USE_COMPACT=1
FILY_INTERVAL=18
FILY_SCREENOFF_INTERVAL=45
FILY_FULL_SCAN_INTERVAL=120
FILY_SPIKE_DELTA=6
FILY_MEM_HIGH_PCT=82
FILY_MEM_CRITICAL_PCT=89
FILY_PSI_SOME_HIGH=2.3
FILY_PSI_FULL_HIGH=0.45
ENABLE_TCTL=1
TCTL_TARGET_TEMP=210
EOF
chmod 666 "$CONFIG_FILE"
}

[ -f "$LQ_WHITELIST_FILE" ] || : > "$LQ_WHITELIST_FILE"
[ -f "$LQ_PRELIST_FILE" ] || : > "$LQ_PRELIST_FILE"
chmod 666 "$LQ_WHITELIST_FILE" "$LQ_PRELIST_FILE" >/dev/null 2>&1

[ -f "$LQ_PRELOAD_FILE" ] || : > "$LQ_PRELOAD_FILE"
chmod 666 "$LQ_PRELOAD_FILE" 2>/dev/null



# ── setup-only installer ───────────────────────────────────────
# Runtime tweaks are intentionally not applied here. They are exposed
# as manual System Tuning controls and automatic runtime primitives.
LQ_SYSTEM_TUNING_STATE="$LQ_TMP_DIR/system_tuning"
mkdir -p "$LQ_SYSTEM_TUNING_STATE" >/dev/null 2>&1
: > "$LQ_TMP_DIR/runtime_perf_keys.txt"
: > "$LQ_TMP_DIR/runtime_perf_keys.backup"
[ -f "$LQ_IDLE_PROFILE_FILE" ] || printf '%s\n' normal > "$LQ_TMP_DIR/idle_profile"
[ -f "$LQ_SURFACE_FLINGER_PROFILE_FILE" ] || printf '%s\n' 0 > "$LQ_TMP_DIR/surface_flinger_profile"
[ -f "$LQ_TRACE_PROFILE_FILE" ] || printf '%s\n' off > "$LQ_TMP_DIR/trace_guard_profile"
[ -f "$LQ_FILY_STATE_FILE" ] || printf '%s\n' 0 > "$LQ_TMP_DIR/fily_enabled"
[ -f "$LQ_TCTL_STATE_FILE" ] || printf '%s\n' 0 > "$LQ_TMP_DIR/tctl_enabled"
chmod 666 "$LQ_TMP_DIR/runtime_perf_keys.txt" "$LQ_TMP_DIR/runtime_perf_keys.backup" >/dev/null 2>&1
ui_print "Li Qinghe setup prepared."
ui_print "Manual tweaks will be applied from WebUI."

# Make the state folder writable for a shell-uid WebUI (AxManager / Axora).
chmod -R a+rwX "$LQ_TMP_DIR" >/dev/null 2>&1 || true
[ -f "$LQ_TMP_DIR/ven" ] && chmod 755 "$LQ_TMP_DIR/ven" >/dev/null 2>&1
