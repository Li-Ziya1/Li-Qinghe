#!/system/bin/sh
# userpkg_detect.sh -- isolated exec for the "refresh user-app inventory"
# step. Mirrors gamedetect.sh's isolation for the same reason (see that
# file's header): running a `cmd package ...` pipeline directly inline
# inside a script run by the Manager (or a function sourced into it) has been observed to
# fail outright on at least one device, while invoking the identical
# command from its own file via `sh` works reliably.
#
# Usage: sh userpkg_detect.sh
# Output: raw `package:`-prefixed package lines on stdout, one per line
# (exactly what `cmd package list packages` prints) -- the caller
# (pkgmgr.sh) strips the prefix and sanitizes.
# stderr: left as normal stderr, not redirected here -- the caller
# captures it and reports it directly if this produces no usable output.

cmd package list packages --user 0 -3
