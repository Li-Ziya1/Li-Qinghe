#!/system/bin/sh
# gamedetect.sh -- isolated exec for the "detect installed games" scan.
#
# One job (list game package names), two sources, picked by the first
# argument. Both live in this one file so the detection logic is not split
# across two scripts:
#
#   sh gamedetect.sh              same as "activities"
#   sh gamedetect.sh activities   PRIMARY source. Runs
#                                 `cmd package query-activities` and extracts
#                                 every package that owns a MAIN/LAUNCHER
#                                 activity.
#   sh gamedetect.sh dumpsys      FALLBACK source, used by the caller only
#                                 when the primary one never yields a usable
#                                 package. `dumpsys game` (Android 12+ Game
#                                 Manager service) reports the apps the
#                                 system already classifies as games. It is
#                                 less complete than scanning every launcher
#                                 activity, but as a fallback it only has to
#                                 give the user *something* instead of a hard
#                                 failure. It casts a wide net with
#                                 `grep -Eo` (any dotted, package-shaped
#                                 token, deduped) and relies on the caller to
#                                 re-sanitize, exactly like the primary
#                                 source: overshooting is fine, undershooting
#                                 because of an unexpected dump format is the
#                                 real risk.
#
# Kept in its own file instead of inlined in the caller: on some device/exec
# combos, running this exact `cmd package query-activities | awk` pipeline
# directly inside a script run by the Manager has been observed to fail outright every time,
# while invoking the identical pipeline from a separate script (this file,
# called via `sh`) works reliably. Root cause not fully confirmed --
# suspected to be related to how the Manager app execs such scripts
# (different stdin/job-control/subshell handling than a normal shell) -- but
# splitting it out sidesteps the issue rather than depending on it.
#
# Output:
#   Raw package names on stdout, one per line, BEFORE any sanitizing/dedup
#   by the caller (pkgmgr.sh scan-games does that pass). Nothing on stdout if the
#   source returned nothing.
# stderr:
#   Left as normal stderr, not redirected here -- the caller (pkgmgr.sh)
#   captures it directly and prints it as part of the failure reason if
#   this produces no usable output; no separate log file involved.
# Exit status:
#   0 for a known source (it is a plain pipeline; the caller decides
#   success/failure by checking whether any output was produced),
#   2 for an unknown source name.

case "${1:-activities}" in
    activities)
        cmd package query-activities -a android.intent.action.MAIN -c android.intent.category.LAUNCHER | awk -F= '/geNa/{p=$2}/ry=0/{print p}'
        ;;
    dumpsys)
        dumpsys game 2>/dev/null | grep -Eo '[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+' | sort -u
        ;;
    *)
        printf '%s\n' "gamedetect.sh: unknown source '$1' (use: activities | dumpsys)" >&2
        exit 2
        ;;
esac
