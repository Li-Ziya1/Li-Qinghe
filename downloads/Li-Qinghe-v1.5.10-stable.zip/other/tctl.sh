#!/system/bin/sh

[ -z "$MODDIR" ] && MODDIR=${0%/*}

if [ "${0##*/}" = "tctl.sh" ]; then
    LQ_TCTL_HELPER_NOLOAD=1
    [ -f "$MODDIR/common.sh" ] && . "$MODDIR/common.sh"
fi

# ── tctl() ──
tctl() {
    case "${1:-}" in
        reset)
            _tctl_restore >/dev/null 2>&1
            ;;
        temp|"")
            [ -n "$2" ] && TCTL_TARGET_TEMP="$2"
            _tctl_init >/dev/null 2>&1
            _tctl_apply >/dev/null 2>&1
            ;;
        status)
            _tctl_init >/dev/null 2>&1
            if [ -n "$TCTL_PROP_KEY" ]; then
                printf 'key=%s\n' "$TCTL_PROP_KEY"
                printf 'current=%s\n' "$(_prop_get "$TCTL_PROP_KEY")"
                [ -n "$TCTL_BASELINE_VALUE" ] && printf 'baseline=%s\n' "$(_tctl_fmt_val "$TCTL_BASELINE_VALUE")"
                printf 'target=%s\n' "$(_tctl_fmt_val "$TCTL_ACTIVE_VALUE")"
                printf 'log=%s\n' "${TCTL_LOG:-}"
            else
                printf 'unsupported\n'
            fi
            ;;
        log)
            _tctl_init >/dev/null 2>&1
            lines="${2:-40}"
            case "$lines" in
                ''|*[!0-9]*) lines=40 ;;
            esac
            [ -f "$TCTL_LOG" ] && tail -n "$lines" "$TCTL_LOG" 2>/dev/null || printf 'no log\n'
            ;;
        *)
            printf 'usage: tctl [temp [value]|reset|status|log [lines]]\n' >&2
            return 1
            ;;
    esac
}

if [ "${0##*/}" = "tctl.sh" ]; then
    tctl "$@"
    exit $?
fi
