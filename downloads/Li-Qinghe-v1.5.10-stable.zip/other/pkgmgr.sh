#!/system/bin/sh

: "${LQ_TMP_DIR:=/data/local/tmp/liqinghe}"
: "${LQ_USERPKG_FILE:=$LQ_TMP_DIR/userpkg.txt}"
: "${LQ_GAMELIST_FILE:=$LQ_TMP_DIR/gamelist.txt}"
: "${LQ_WHITELIST_FILE:=$LQ_TMP_DIR/whitelist.txt}"
: "${LQ_PRELIST_FILE:=$LQ_TMP_DIR/prelist.txt}"
: "${LQ_PRELOAD_FILE:=$LQ_TMP_DIR/preload.txt}"
# the WebUI game scan's detected list. When this has content, manual
# game add/remove from the WebUI targets it instead of LQ_GAMELIST_FILE --
# see _lq_active_gamelist_file() below.
: "${LQ_GAMELIST_DETECTED_FILE:=$LQ_TMP_DIR/gamelist_detected.txt}"

: "${LQ_MODULE_DIR:=${MODDIR:-${0%/*}/..}}"
: "${LQ_OTHER_DIR:=$LQ_MODULE_DIR/other}"
: "${LQ_PERSIST_GAMELIST_FILE:=$LQ_OTHER_DIR/gamelist.txt}"
: "${LQ_PERSIST_WHITELIST_FILE:=$LQ_OTHER_DIR/whitelist.txt}"
: "${LQ_PERSIST_PRELIST_FILE:=$LQ_OTHER_DIR/prelist.txt}"
: "${LQ_PERSIST_GAMELIST_DETECTED_FILE:=$LQ_OTHER_DIR/gamelist_detected.txt}"
# What the WebUI's game scan found, held here until the user decides: Replace writes it over $LQ_GAMELIST_DETECTED_FILE, Cancel
# throws it away. Nothing the scan finds touches any list before that.
: "${LQ_GAMESCAN_FILE:=$LQ_TMP_DIR/gamelist_scan.txt}"
# Packages the user typed in by hand on the User tab (apps the detector
# missed). Kept apart from userpkg.txt because that file is rebuilt from
# scratch on every refresh; the WebUI merges both when it shows the list.
: "${LQ_USERPKG_EXTRA_FILE:=$LQ_TMP_DIR/userpkg_extra.txt}"
: "${LQ_PERSIST_USERPKG_EXTRA_FILE:=$LQ_OTHER_DIR/userpkg_extra.txt}"

# Per-package graphics driver opt-in state. Only packages this module has
# actually flipped on get tracked here (one small list per driver id) --
# on uninstall we only need to remove exactly those packages from the
# device-wide Settings.Global lists, not touch anything already there
# from elsewhere.
: "${LQ_DRIVER_STATE_DIR:=$LQ_TMP_DIR/driver_pkgs}"


# ── Package name helpers ────────────────────────────────

# ── _lq_pkg_valid() ──
_lq_pkg_valid() {
    case "${1:-}" in
        *.*) ;;
        *) return 1 ;;
    esac
    # grep -Eq, not tr or a case-glob -- confirmed on a real device that
    # `tr -d 'A-Za-z0-9._-'` can silently mangle a perfectly clean package
    # name to nothing (some BusyBox/toybox tr builds mishandle A-Z-style
    # SET ranges), and a `*[!A-Za-z0-9._-]*` glob has the same risk if the
    # shell doesn't honor `!` negation. The same sanitizing rule is used
    # everywhere a package name is checked.
    printf '%s' "${1:-}" | grep -Eq '^[A-Za-z0-9._-]+$' || return 1
    return 0
}

# ── _lq_list_contains() ──
_lq_list_contains() {
    local file="$1" pkg="$2" line entry key
    [ -s "$file" ] || return 1
    while IFS= read -r line; do
        entry="${line%%#*}"
        entry=${entry#"${entry%%[![:space:]]*}"}
        entry=${entry%"${entry##*[![:space:]]}"}
        [ -n "$entry" ] || continue
        key="${entry%%=*}"
        key=${key#"${key%%[![:space:]]*}"}
        key=${key%"${key##*[![:space:]]}"}
        [ "$key" = "$pkg" ] && return 0
    done < "$file"
    return 1
}

# ── _lq_list_add() ──
_lq_list_add() {
    local file="$1" pkg="$2" dir
    _lq_pkg_valid "$pkg" || { printf '%s\n' 'invalid-package' >&2; return 2; }
    dir="${file%/*}"
    [ -d "$dir" ] || mkdir -p "$dir" >/dev/null 2>&1 || { printf '%s\n' "mkdir-failed:$dir" >&2; return 1; }
    if [ ! -f "$file" ]; then
        : > "$file" 2>/dev/null || { printf '%s\n' "create-failed:$file" >&2; return 1; }
    fi

    _lq_list_contains "$file" "$pkg" && return 0

    printf '%s\n' "$pkg" >> "$file" 2>/dev/null || {
        printf '%s\n' "append-failed:$file" >&2
        return 1
    }

    sort -u "$file" -o "$file" >/dev/null 2>&1 || true
    chmod 666 "$file" >/dev/null 2>&1 || true
    _lq_list_contains "$file" "$pkg" || {
        printf '%s\n' "verify-failed:$file" >&2
        return 1
    }
}

# ── _lq_list_remove() ──
_lq_list_remove() {
    local file="$1" pkg="$2" tmp line entry key
    _lq_pkg_valid "$pkg" || { printf '%s\n' 'invalid-package' >&2; return 2; }
    [ -f "$file" ] || return 0
    _lq_list_contains "$file" "$pkg" || return 0

    tmp="${file}.remove.$$"
    : > "$tmp" 2>/dev/null || { printf '%s\n' "create-failed:$tmp" >&2; return 1; }
    while IFS= read -r line; do
        entry="${line%%#*}"
        key="${entry%%=*}"
        key=${key#"${key%%[![:space:]]*}"}
        key=${key%"${key##*[![:space:]]}"}
        if [ "$key" != "$pkg" ]; then
            printf '%s\n' "$line" >> "$tmp" 2>/dev/null || { rm -f "$tmp"; printf '%s\n' "remove-write-failed:$file" >&2; return 1; }
        fi
    done < "$file"

    if ! mv -f "$tmp" "$file" 2>/dev/null; then
        if ! cp -f "$tmp" "$file" 2>/dev/null; then
            rm -f "$tmp" >/dev/null 2>&1
            printf '%s\n' "remove-write-failed:$file" >&2
            return 1
        fi
        rm -f "$tmp" >/dev/null 2>&1
    fi
    chmod 666 "$file" >/dev/null 2>&1 || true
    ! _lq_list_contains "$file" "$pkg"
}

# ── _lq_mirror_list() ──
_lq_mirror_list() {
    local src="$1" dst="$2" tmp
    [ -n "$src" ] && [ -n "$dst" ] || return 1
    [ -f "$src" ] || return 1
    [ -d "${dst%/*}" ] || mkdir -p "${dst%/*}" >/dev/null 2>&1 || return 1
    tmp="${dst}.new.$$"
    rm -f "$tmp" >/dev/null 2>&1
    cat "$src" > "$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
    chmod 666 "$tmp" >/dev/null 2>&1
    mv -f "$tmp" "$dst" 2>/dev/null || {
        cp -f "$tmp" "$dst" 2>/dev/null || { rm -f "$tmp"; return 1; }
        rm -f "$tmp" >/dev/null 2>&1
    }
    chmod 666 "$dst" >/dev/null 2>&1
    cmp -s "$src" "$dst" 2>/dev/null || return 1
    return 0
}

# ── _lq_seed_runtime_list() ──
_lq_seed_runtime_list() {
    local runtime="$1" persistent="$2"
    [ -f "$persistent" ] || return 0
    [ -s "$runtime" ] && return 0
    [ -s "$persistent" ] || return 0
    _lq_mirror_list "$persistent" "$runtime"
}

# ── _lq_whitelist_add() ──
_lq_whitelist_add() {
    _lq_list_add "$LQ_WHITELIST_FILE" "$1" || return $?
    _lq_mirror_list "$LQ_WHITELIST_FILE" "$LQ_PERSIST_WHITELIST_FILE" >/dev/null 2>&1 || true
    return 0
}
# ── _lq_whitelist_remove() ──
_lq_whitelist_remove() {
    _lq_list_remove "$LQ_WHITELIST_FILE" "$1" || return $?
    _lq_mirror_list "$LQ_WHITELIST_FILE" "$LQ_PERSIST_WHITELIST_FILE" >/dev/null 2>&1 || true
    return 0
}
# ── _lq_userextra_add() ──
_lq_userextra_add() {
    _lq_list_add "$LQ_USERPKG_EXTRA_FILE" "$1" || return $?
    _lq_mirror_list "$LQ_USERPKG_EXTRA_FILE" "$LQ_PERSIST_USERPKG_EXTRA_FILE" >/dev/null 2>&1 || true
    return 0
}
# ── _lq_userextra_remove() ──
_lq_userextra_remove() {
    _lq_list_remove "$LQ_USERPKG_EXTRA_FILE" "$1" || return $?
    if [ -s "$LQ_USERPKG_EXTRA_FILE" ]; then
        _lq_mirror_list "$LQ_USERPKG_EXTRA_FILE" "$LQ_PERSIST_USERPKG_EXTRA_FILE" >/dev/null 2>&1 || true
    else
        : > "$LQ_PERSIST_USERPKG_EXTRA_FILE" 2>/dev/null || true
    fi
    return 0
}
# ── _lq_preload_mode_valid() ──
_lq_preload_mode_valid() {
    case "${1:-}" in
        normal|extra) return 0 ;;
        *) return 1 ;;
    esac
}

# ── _lq_preload_mode_normalize() ──
_lq_preload_mode_normalize() {
    case "${1:-}" in
        normal) printf '%s\n' 'normal' ;;
        extra) printf '%s\n' 'extra' ;;
        *) return 1 ;;
    esac
}

# ── _lq_prelist_mode() ──
_lq_prelist_mode() {
    local pkg="$1" line entry key value normalized
    [ -f "$LQ_PRELIST_FILE" ] || return 1
    while IFS= read -r line; do
        entry="${line%%#*}"
        entry=${entry#"${entry%%[![:space:]]*}"}
        entry=${entry%"${entry##*[![:space:]]}"}
        [ -n "$entry" ] || continue
        key="${entry%%=*}"
        key=${key#"${key%%[![:space:]]*}"}
        key=${key%"${key##*[![:space:]]}"}
        [ "$key" = "$pkg" ] || continue
        if [ "$entry" = "$key" ]; then
            printf '%s\n' 'normal'
        else
            value="${entry#*=}"
            value=${value#"${value%%[![:space:]]*}"}
            value=${value%"${value##*[![:space:]]}"}
            normalized="$(_lq_preload_mode_normalize "$value" 2>/dev/null || true)"
            [ -n "$normalized" ] && printf '%s\n' "$normalized" || printf '%s\n' 'normal'
        fi
        return 0
    done < "$LQ_PRELIST_FILE"
    return 1
}


# ── _lq_prelist_add_pending() ──
_lq_prelist_add_pending() {
    local pkg="$1" tmp="${LQ_PRELIST_FILE}.pending.$$" line entry key
    _lq_pkg_valid "$pkg" || { printf '%s\n' 'invalid-package' >&2; return 2; }
    [ -d "${LQ_PRELIST_FILE%/*}" ] || mkdir -p "${LQ_PRELIST_FILE%/*}" >/dev/null 2>&1 || return 1
    : > "$tmp" 2>/dev/null || return 1
    if [ -f "$LQ_PRELIST_FILE" ]; then
        while IFS= read -r line; do
            entry="${line%%#*}"
            key="${entry%%=*}"
            key=${key#"${key%%[![:space:]]*}"}
            key=${key%"${key##*[![:space:]]}"}
            [ "$key" = "$pkg" ] && continue
            printf '%s\n' "$line" >> "$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
        done < "$LQ_PRELIST_FILE"
    fi
    printf '%s\n' "$pkg" >> "$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
    sort -u "$tmp" -o "$tmp" >/dev/null 2>&1 || true
    if ! mv -f "$tmp" "$LQ_PRELIST_FILE" 2>/dev/null; then
        cp -f "$tmp" "$LQ_PRELIST_FILE" 2>/dev/null || { rm -f "$tmp"; return 1; }
        rm -f "$tmp" >/dev/null 2>&1 || true
    fi
    chmod 666 "$LQ_PRELIST_FILE" >/dev/null 2>&1 || true
    _lq_list_contains "$LQ_PRELIST_FILE" "$pkg" || return 1
    _lq_mirror_list "$LQ_PRELIST_FILE" "$LQ_PERSIST_PRELIST_FILE" >/dev/null 2>&1 || true
    return 0
}


# ── _lq_prelist_entry() ──
_lq_prelist_entry() {
    local pkg="$1" line entry key
    [ -f "$LQ_PRELIST_FILE" ] || return 1
    while IFS= read -r line; do
        entry="${line%%#*}"
        entry=${entry#"${entry%%[![:space:]]*}"}
        entry=${entry%"${entry##*[![:space:]]}"}
        [ -n "$entry" ] || continue
        key="${entry%%=*}"
        key=${key#"${key%%[![:space:]]*}"}
        key=${key%"${key##*[![:space:]]}"}
        [ "$key" = "$pkg" ] || continue
        printf '%s\n' "$entry"
        return 0
    done < "$LQ_PRELIST_FILE"
    return 1
}

# ── _lq_prelist_add() ──
_lq_prelist_add() {
    local pkg="$1" mode="${2:-normal}" tmp="${LQ_PRELIST_FILE}.new.$$" line entry key normalized_mode
    _lq_pkg_valid "$pkg" || { printf '%s\n' 'invalid-package' >&2; return 2; }
    normalized_mode="$(_lq_preload_mode_normalize "$mode" 2>/dev/null)" || {
        printf '%s\n' 'invalid-preload-mode' >&2
        return 2
    }
    mode="$normalized_mode"
    [ -d "${LQ_PRELIST_FILE%/*}" ] || mkdir -p "${LQ_PRELIST_FILE%/*}" >/dev/null 2>&1 || { printf '%s\n' "mkdir-failed:${LQ_PRELIST_FILE%/*}" >&2; return 1; }
    : > "$tmp" 2>/dev/null || { printf '%s\n' "create-failed:$tmp" >&2; return 1; }
    if [ -f "$LQ_PRELIST_FILE" ]; then
        while IFS= read -r line; do
            entry="${line%%#*}"
            key="${entry%%=*}"
            key=${key#"${key%%[![:space:]]*}"}
            key=${key%"${key##*[![:space:]]}"}
            [ "$key" = "$pkg" ] && continue
            printf '%s\n' "$line" >> "$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
        done < "$LQ_PRELIST_FILE"
    fi
    printf '%s=%s\n' "$pkg" "$mode" >> "$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
    sort -u "$tmp" -o "$tmp" >/dev/null 2>&1 || true
    if ! mv -f "$tmp" "$LQ_PRELIST_FILE" 2>/dev/null; then
        if ! cp -f "$tmp" "$LQ_PRELIST_FILE" 2>/dev/null; then
            rm -f "$tmp" >/dev/null 2>&1
            printf '%s\n' "write-failed:$LQ_PRELIST_FILE" >&2
            return 1
        fi
        rm -f "$tmp" >/dev/null 2>&1
    fi
    chmod 666 "$LQ_PRELIST_FILE" >/dev/null 2>&1 || true
    _lq_list_contains "$LQ_PRELIST_FILE" "$pkg" || return 1
    [ "$(_lq_prelist_mode "$pkg" 2>/dev/null)" = "$mode" ] || return 1
    _lq_mirror_list "$LQ_PRELIST_FILE" "$LQ_PERSIST_PRELIST_FILE" >/dev/null 2>&1 || true
    return 0
}
# ── _lq_prelist_remove() ──
_lq_prelist_remove() {
    _lq_list_remove "$LQ_PRELIST_FILE" "$1" || return $?
    _lq_mirror_list "$LQ_PRELIST_FILE" "$LQ_PERSIST_PRELIST_FILE" >/dev/null 2>&1 || true
    return 0
}
# ── _lq_active_gamelist_file() ──
# Which file manual game add/remove (and "list game") should target:
# the game scan's detected list when it has content, otherwise the
# original/bawaan gamelist. Mirrors the same rule the WebUI uses to decide
# what to display, so the toggle state in the UI always matches whichever
# file just got written.
_lq_active_gamelist_file() {
    if [ -s "$LQ_GAMELIST_DETECTED_FILE" ]; then
        printf '%s\n' "$LQ_GAMELIST_DETECTED_FILE"
    else
        printf '%s\n' "$LQ_GAMELIST_FILE"
    fi
}

# ── _lq_game_add() ──
_lq_game_add() {
    LQ_GAME_TARGET_FILE="$(_lq_active_gamelist_file)"
    _lq_list_add "$LQ_GAME_TARGET_FILE" "$1" || return $?
    if [ "$LQ_GAME_TARGET_FILE" = "$LQ_GAMELIST_DETECTED_FILE" ]; then
        _lq_mirror_list "$LQ_GAMELIST_DETECTED_FILE" "$LQ_PERSIST_GAMELIST_DETECTED_FILE" >/dev/null 2>&1 || true
    else
        _lq_mirror_list "$LQ_GAMELIST_FILE" "$LQ_PERSIST_GAMELIST_FILE" >/dev/null 2>&1 || true
    fi
    return 0
}
# ── _lq_game_remove() ──
_lq_game_remove() {
    LQ_GAME_TARGET_FILE="$(_lq_active_gamelist_file)"
    _lq_list_remove "$LQ_GAME_TARGET_FILE" "$1" || return $?
    if [ "$LQ_GAME_TARGET_FILE" = "$LQ_GAMELIST_DETECTED_FILE" ]; then
        _lq_mirror_list "$LQ_GAMELIST_DETECTED_FILE" "$LQ_PERSIST_GAMELIST_DETECTED_FILE" >/dev/null 2>&1 || true
    else
        _lq_mirror_list "$LQ_GAMELIST_FILE" "$LQ_PERSIST_GAMELIST_FILE" >/dev/null 2>&1 || true
    fi
    return 0
}

# ── Per-package driver toggles (Game Driver / Updatable Driver / ANGLE) ──
# Gated to the Game tab's *detected* packages only in the WebUI (the
# bundled/bawaan gamelist doesn't expose this) -- see webroot/app.js. Uses
# Android's own per-app opt-in Settings.Global lists instead of the old
# all-apps switch, so only the games the user actually expanded are
# affected, never the whole device.

# ── _lq_csv_index() ──
# Prints the 1-based position of $2 inside comma-separated list $1.
_lq_csv_index() {
    local csv="$1" pkg="$2" i=0 tok
    [ -n "$csv" ] || return 1
    local oldifs="$IFS"
    IFS=','
    for tok in $csv; do
        i=$((i + 1))
        if [ "$tok" = "$pkg" ]; then IFS="$oldifs"; printf '%s\n' "$i"; return 0; fi
    done
    IFS="$oldifs"
    return 1
}
# ── _lq_csv_add() ──
_lq_csv_add() {
    local csv="$1" pkg="$2"
    if _lq_csv_index "$csv" "$pkg" >/dev/null 2>&1; then printf '%s\n' "$csv"; return 0; fi
    if [ -z "$csv" ]; then printf '%s\n' "$pkg"; else printf '%s,%s\n' "$csv" "$pkg"; fi
}
# ── _lq_csv_remove_at() ──
# Removes the token at 1-based index $2 from comma-separated list $1.
_lq_csv_remove_at() {
    local csv="$1" idx="$2" i=0 out='' tok
    local oldifs="$IFS"
    IFS=','
    for tok in $csv; do
        i=$((i + 1))
        [ "$i" = "$idx" ] && continue
        if [ -z "$out" ]; then out="$tok"; else out="$out,$tok"; fi
    done
    IFS="$oldifs"
    printf '%s\n' "$out"
}

# ── _lq_driver_track_file() ──
_lq_driver_track_file() {
    [ -d "$LQ_DRIVER_STATE_DIR" ] || mkdir -p "$LQ_DRIVER_STATE_DIR" >/dev/null 2>&1 || true
    printf '%s/%s.list\n' "$LQ_DRIVER_STATE_DIR" "$(printf '%s' "$1" | tr '-' '_')"
}

# Two mutually-exclusive per-package driver groups, matching the same
# Settings.Global keys/semantics as Specter's per-app driver override
# (webroot/spc.js: setDriver()/setAngleDriver()) so this behaves the same
# way on-device:
#   gfxdriver: default | game | dev | system
#     game   -> updatable_driver_production_opt_in_apps
#     dev    -> updatable_driver_prerelease_opt_in_apps
#     system -> updatable_driver_production_opt_out_apps
#     default -> package isn't in any of the three lists
#   angle: default | angle | native
#     backed by the positionally-paired angle_gl_driver_selection_pkgs /
#     angle_gl_driver_selection_values (same pairing approach as Specter's
#     getAngleConf()/writeAngleConf()).

# ── _lq_driver_group_valid() ──
_lq_driver_group_valid() {
    case "$1" in gfxdriver|angle) return 0 ;; *) return 1 ;; esac
}
# ── _lq_gfxdriver_choice_valid() ──
_lq_gfxdriver_choice_valid() {
    case "$1" in default|game|dev|system) return 0 ;; *) return 1 ;; esac
}
# ── _lq_angle_choice_valid() ──
_lq_angle_choice_valid() {
    case "$1" in default|angle|native) return 0 ;; *) return 1 ;; esac
}
# ── _lq_gfxdriver_key_for() ──
_lq_gfxdriver_key_for() {
    case "$1" in
        game) printf '%s\n' updatable_driver_production_opt_in_apps ;;
        dev) printf '%s\n' updatable_driver_prerelease_opt_in_apps ;;
        system) printf '%s\n' updatable_driver_production_opt_out_apps ;;
        *) return 1 ;;
    esac
}
# ── _lq_gfxdriver_get() ──
# default|game|dev|system -- whichever of the three opt-in/opt-out lists
# (if any) $1 currently appears in.
_lq_gfxdriver_get() {
    local pkg="$1" g key csv
    for g in game dev system; do
        key="$(_lq_gfxdriver_key_for "$g")"
        csv="$(settings get global "$key" 2>/dev/null | tr -d '\r')"; [ "$csv" = "null" ] && csv=""
        _lq_csv_index "$csv" "$pkg" >/dev/null 2>&1 && { printf '%s\n' "$g"; return 0; }
    done
    printf 'default\n'
}
# ── _lq_gfxdriver_set() ──
_lq_gfxdriver_set() {
    local pkg="$1" choice="$2" g key csv idx track
    _lq_pkg_valid "$pkg" || return 2
    _lq_gfxdriver_choice_valid "$choice" || return 2
    track="$(_lq_driver_track_file gfxdriver)"

    # Mutually exclusive -- pull pkg out of all three lists first, exactly
    # like Specter's setDriver() does, then (re)add to just the chosen one.
    for g in game dev system; do
        key="$(_lq_gfxdriver_key_for "$g")"
        csv="$(settings get global "$key" 2>/dev/null | tr -d '\r')"; [ "$csv" = "null" ] && csv=""
        idx="$(_lq_csv_index "$csv" "$pkg" 2>/dev/null)" || continue
        csv="$(_lq_csv_remove_at "$csv" "$idx")"
        settings put global "$key" "$csv" >/dev/null 2>&1 || return 1
    done

    if [ "$choice" = "default" ]; then
        _lq_list_remove "$track" "$pkg" >/dev/null 2>&1 || true
    else
        key="$(_lq_gfxdriver_key_for "$choice")" || return 2
        csv="$(settings get global "$key" 2>/dev/null | tr -d '\r')"; [ "$csv" = "null" ] && csv=""
        csv="$(_lq_csv_add "$csv" "$pkg")"
        settings put global "$key" "$csv" >/dev/null 2>&1 || return 1
        _lq_list_add "$track" "$pkg" >/dev/null 2>&1 || true
    fi

    [ "$(_lq_gfxdriver_get "$pkg" 2>/dev/null)" = "$choice" ] || return 1
    return 0
}
# ── _lq_angle_get() ──
# default|angle|native -- $1's paired entry in angle_gl_driver_selection_*,
# if it has one.
_lq_angle_get() {
    local pkg="$1" csv vals idx i=0 tok val='' oldifs
    csv="$(settings get global angle_gl_driver_selection_pkgs 2>/dev/null | tr -d '\r')"; [ "$csv" = "null" ] && csv=""
    idx="$(_lq_csv_index "$csv" "$pkg" 2>/dev/null)" || { printf 'default\n'; return 0; }
    vals="$(settings get global angle_gl_driver_selection_values 2>/dev/null | tr -d '\r')"; [ "$vals" = "null" ] && vals=""
    oldifs="$IFS"
    IFS=','
    for tok in $vals; do
        i=$((i + 1))
        [ "$i" = "$idx" ] && { val="$tok"; break; }
    done
    IFS="$oldifs"
    case "$val" in angle|native) printf '%s\n' "$val" ;; *) printf 'default\n' ;; esac
}
# ── _lq_angle_set() ──
_lq_angle_set() {
    local pkg="$1" choice="$2" csv vals idx track
    _lq_pkg_valid "$pkg" || return 2
    _lq_angle_choice_valid "$choice" || return 2
    track="$(_lq_driver_track_file angle)"

    csv="$(settings get global angle_gl_driver_selection_pkgs 2>/dev/null | tr -d '\r')"; [ "$csv" = "null" ] && csv=""
    vals="$(settings get global angle_gl_driver_selection_values 2>/dev/null | tr -d '\r')"; [ "$vals" = "null" ] && vals=""

    idx="$(_lq_csv_index "$csv" "$pkg" 2>/dev/null)" && {
        csv="$(_lq_csv_remove_at "$csv" "$idx")"
        vals="$(_lq_csv_remove_at "$vals" "$idx")"
    }
    if [ "$choice" != "default" ]; then
        csv="$(_lq_csv_add "$csv" "$pkg")"
        if [ -z "$vals" ]; then vals="$choice"; else vals="$vals,$choice"; fi
    fi

    settings put global angle_gl_driver_selection_pkgs "$csv" >/dev/null 2>&1 || return 1
    settings put global angle_gl_driver_selection_values "$vals" >/dev/null 2>&1 || return 1

    if [ "$choice" = "default" ]; then
        _lq_list_remove "$track" "$pkg" >/dev/null 2>&1 || true
    else
        _lq_list_add "$track" "$pkg" >/dev/null 2>&1 || true
    fi

    [ "$(_lq_angle_get "$pkg" 2>/dev/null)" = "$choice" ] || return 1
    return 0
}
# ── _lq_driver_cleanup_all() ──
# Uninstall-time cleanup: pulls every package this module ever set either
# group for (per $LQ_DRIVER_STATE_DIR's tracked lists) back to "default",
# then clears the tracked lists themselves.
_lq_driver_cleanup_all() {
    local track pkg
    track="$(_lq_driver_track_file gfxdriver)"
    if [ -f "$track" ]; then
        while IFS= read -r pkg; do
            [ -n "$pkg" ] || continue
            _lq_gfxdriver_set "$pkg" default >/dev/null 2>&1 || true
        done < "$track"
        rm -f "$track" >/dev/null 2>&1 || true
    fi
    track="$(_lq_driver_track_file angle)"
    if [ -f "$track" ]; then
        while IFS= read -r pkg; do
            [ -n "$pkg" ] || continue
            _lq_angle_set "$pkg" default >/dev/null 2>&1 || true
        done < "$track"
        rm -f "$track" >/dev/null 2>&1 || true
    fi
}

# ── _lq_pkgmgr_init() ──
_lq_pkgmgr_init() {
    [ -d "$LQ_TMP_DIR" ] || mkdir -p "$LQ_TMP_DIR" >/dev/null 2>&1 || return 1
    [ -f "$LQ_USERPKG_FILE" ] || : > "$LQ_USERPKG_FILE" 2>/dev/null || true
    _lq_seed_runtime_list "$LQ_GAMELIST_FILE" "$LQ_PERSIST_GAMELIST_FILE"
    _lq_seed_runtime_list "$LQ_PRELIST_FILE" "$LQ_PERSIST_PRELIST_FILE"
    _lq_seed_runtime_list "$LQ_WHITELIST_FILE" "$LQ_PERSIST_WHITELIST_FILE"
    _lq_seed_runtime_list "$LQ_USERPKG_EXTRA_FILE" "$LQ_PERSIST_USERPKG_EXTRA_FILE"
    [ -f "$LQ_USERPKG_EXTRA_FILE" ] || : > "$LQ_USERPKG_EXTRA_FILE" 2>/dev/null || true
    # Manual adds/removes made while the detected list was active persist
    # here too, so they survive a reboot the same way the other lists do.
    _lq_seed_runtime_list "$LQ_GAMELIST_DETECTED_FILE" "$LQ_PERSIST_GAMELIST_DETECTED_FILE"
    [ -f "$LQ_GAMELIST_FILE" ] || : > "$LQ_GAMELIST_FILE" 2>/dev/null || true
    [ -f "$LQ_PRELIST_FILE" ] || : > "$LQ_PRELIST_FILE" 2>/dev/null || true
    [ -f "$LQ_WHITELIST_FILE" ] || : > "$LQ_WHITELIST_FILE" 2>/dev/null || true
}

# ── _generate_user_pkg_inventory() ──
_generate_user_pkg_inventory() {
    local raw count=0 tmp attempt=0 src

    # The same isolated scan the game scan uses: `cmd package list packages` has been seen to fail outright when it
    # is run inline, and to work from its own file through `sh`, so it goes through other/userpkg_detect.sh, up to 3
    # tries one second apart. (`pm` is only a shell wrapper around `cmd package`, so it was never a different path.)
    # Why it failed goes to stderr as LQ_REASON:<text>, which the WebUI shows.
    src="$LQ_OTHER_DIR/userpkg_detect.sh"
    raw=""
    while [ "$attempt" -lt 3 ]; do
        attempt=$((attempt + 1))
        if [ -f "$src" ]; then
            raw=$(sh "$src" 2>/dev/null) || raw=""
        else
            raw=$(cmd package list packages --user 0 -3 2>/dev/null) || raw=""
        fi
        [ -n "$raw" ] && break
        [ "$attempt" -lt 3 ] && sleep 1
    done

    [ -n "$raw" ] || {
        printf 'LQ_REASON:%s\n' 'cmd package list packages returned no data after 3 attempts' >&2
        return 1
    }

    tmp="$LQ_USERPKG_FILE.new.$$"
    rm -f "$tmp" >/dev/null 2>&1

    # One pass over the whole list instead of a loop that forked a printf|grep pair for every package
    # (hundreds of forks, which is what made the User tab slow to open). Same rule as before: strip "package:" and
    # surrounding blanks (the [[:space:]] also covers \r), keep only names made of [A-Za-z0-9._-] that contain a dot.
    printf '%s\n' "$raw" \
        | sed -e 's/^[[:space:]]*package://' -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' \
        | grep -E '^[A-Za-z0-9_-]*([.][A-Za-z0-9._-]*)+$' \
        | sort -u > "$tmp" 2>/dev/null
    count=$(wc -l < "$tmp" 2>/dev/null)
    count=${count##* }
    case "$count" in ''|*[!0-9]*) count=0 ;; esac

    [ "$count" -gt 0 ] || {
        rm -f "$tmp" >/dev/null 2>&1
        printf 'LQ_REASON:%s\n' 'the package list came back but no name passed validation' >&2
        return 1
    }

    [ -s "$tmp" ] || {
        rm -f "$tmp" >/dev/null 2>&1
        return 1
    }

    chmod 666 "$tmp" >/dev/null 2>&1
    if mv -f "$tmp" "$LQ_USERPKG_FILE" 2>/dev/null; then
        :
    elif cp -f "$tmp" "$LQ_USERPKG_FILE" 2>/dev/null; then
        rm -f "$tmp" >/dev/null 2>&1
    elif cat "$tmp" > "$LQ_USERPKG_FILE" 2>/dev/null; then
        rm -f "$tmp" >/dev/null 2>&1
    else
        rm -f "$tmp" >/dev/null 2>&1
        return 1
    fi

    chmod 666 "$LQ_USERPKG_FILE" >/dev/null 2>&1
    [ -s "$LQ_USERPKG_FILE" ] || return 1

    printf '%s\n' "$count"
}




# ── _lq_preload_log_now() ──
_lq_preload_log_now() {
    local pkg="$1" status="$2" mode="$3" time_ms="$4" files="$5" total="$6" human
    [ -n "$pkg" ] || return 0
    human="$(date '+%F %T' 2>/dev/null || printf 'unknown')"
    case "$time_ms" in ''|*[!0-9]*) time_ms=0 ;; esac
    case "$files" in ''|*[!0-9]*) files=0 ;; esac
    case "$total" in '') total=0 ;; esac
    case "$status" in ok) ;; *) status=fail ;; esac
    case "$mode" in normal|extra) ;; *) mode=normal ;; esac
    [ -d "${LQ_PRELOAD_FILE%/*}" ] || mkdir -p "${LQ_PRELOAD_FILE%/*}" >/dev/null 2>&1
    printf '[%s] %s | time=%sms | stats=%s | mode=%s | files=%s | total=%s\n' \
        "$human" "$pkg" "$time_ms" "$status" "$mode" "$files" "$total" \
        >> "$LQ_PRELOAD_FILE" 2>/dev/null
    chmod 666 "$LQ_PRELOAD_FILE" >/dev/null 2>&1 || true
}

# ── _lq_ywhy_bin() ──
_lq_ywhy_bin() {
    local bin
    if [ -n "${LQ_MODULE_DIR:-}" ] && [ -x "$LQ_MODULE_DIR/system/bin/ywhy" ]; then
        printf '%s\n' "$LQ_MODULE_DIR/system/bin/ywhy"
        return 0
    fi
    if [ -n "${MODDIR:-}" ] && [ -x "$MODDIR/system/bin/ywhy" ]; then
        printf '%s\n' "$MODDIR/system/bin/ywhy"
        return 0
    fi
    bin="$(command -v ywhy 2>/dev/null || true)"
    [ -x "$bin" ] && printf '%s\n' "$bin" && return 0
    return 1
}

# ── _lq_preload_run_now() ──
_lq_preload_run_now() {
    local pkg="$1" mode="${2:-}" bin output rc time_ms files total
    _lq_pkg_valid "$pkg" || return 2
    mode="$(_lq_preload_mode_normalize "${mode:-$(_lq_prelist_mode "$pkg" 2>/dev/null || printf 'normal')}")" || mode='normal'

    bin="$(_lq_ywhy_bin 2>/dev/null)" || {
        _lq_preload_log_now "$pkg" fail "$mode" 0 0 0
        printf '%s\n' 'ywhy-not-found' >&2
        return 1
    }

    output="$("$bin" "$pkg=$mode" 2>&1)"
    rc=$?

    files="$(printf '%s\n' "$output" | sed -n 's/^\[YWHY\] Files queued: \([0-9][0-9]*\)$/\1/p' | tail -n 1)"
    time_ms="$(printf '%s\n' "$output" | sed -n 's/^\[YWHY\] done in \([0-9][0-9]*\) ms (.* MB)$/\1/p' | tail -n 1)"
    total="$(printf '%s\n' "$output" | sed -n 's/^\[YWHY\] done in [0-9][0-9]* ms (\([0-9][0-9.]*\) MB)$/\1/p' | tail -n 1)"

    case "$files" in ''|*[!0-9]*) files=0 ;; esac
    case "$time_ms" in ''|*[!0-9]*) time_ms=0 ;; esac
    [ -n "$total" ] || total=0

    if [ "$rc" -eq 0 ]; then
        _lq_preload_log_now "$pkg" ok "$mode" "$time_ms" "$files" "$total"
        return 0
    fi

    _lq_preload_log_now "$pkg" fail "$mode" "$time_ms" "$files" "$total"
    printf '%s\n' "$output" >&2
    return "$rc"
}

# ── _lq_preload_reset_now() ──
_lq_preload_reset_now() {
    local pkg="$1"
    _lq_pkg_valid "$pkg" || return 2
    return 0
}

# ── _lq_game_scan() ──
# The scan that used to run from the Action button, now asked for by the WebUI (Game tab). Runs other/gamedetect.sh the same way
# (query-activities up to 3 times, then the dumpsys fallback), keeps only plausible package names, and holds the result in
# $LQ_GAMESCAN_FILE. It prints the list between __LQ_LIST__ and __LQ_LIST_END__. NOTHING is written to a game list here.
# Why it failed goes to stderr as LQ_REASON:<text>, which the WebUI shows.
_lq_game_scan() {
    local detector raw tmp attempt=0 err count=0
    detector="$LQ_OTHER_DIR/gamedetect.sh"
    raw="$LQ_TMP_DIR/.lq_scan_raw.$$"
    tmp="$LQ_GAMESCAN_FILE.new.$$"
    rm -f "$raw" "$tmp" "$LQ_GAMESCAN_FILE" >/dev/null 2>&1

    if [ ! -f "$detector" ]; then
        printf 'LQ_REASON:%s\n' 'other/gamedetect.sh was not found inside the module' >&2
        return 1
    fi

    err=""
    while [ "$attempt" -lt 3 ]; do
        attempt=$((attempt + 1))
        err="$(sh "$detector" activities 2>&1 1>"$raw")"
        [ -s "$raw" ] && break
        [ "$attempt" -lt 3 ] && sleep 1
    done
    if [ ! -s "$raw" ]; then
        err="$(sh "$detector" dumpsys 2>&1 1>"$raw")"
    fi
    if [ ! -s "$raw" ]; then
        rm -f "$raw" >/dev/null 2>&1
        if [ -n "$err" ]; then
            printf 'LQ_REASON:%s\n' "the scan failed: $err" >&2
        else
            printf 'LQ_REASON:%s\n' 'the scan returned no data at all' >&2
        fi
        return 1
    fi

    tr -d '\r' < "$raw" \
        | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' \
        | grep -E '^[A-Za-z0-9_-]*([.][A-Za-z0-9._-]*)+$' \
        | sort -u > "$tmp" 2>/dev/null
    rm -f "$raw" >/dev/null 2>&1
    count=$(wc -l < "$tmp" 2>/dev/null)
    count=${count##* }
    case "$count" in ''|*[!0-9]*) count=0 ;; esac
    if [ "$count" -le 0 ]; then
        rm -f "$tmp" >/dev/null 2>&1
        printf 'LQ_REASON:%s\n' 'the scan returned data, but no package name passed validation' >&2
        return 1
    fi

    chmod 666 "$tmp" >/dev/null 2>&1
    mv -f "$tmp" "$LQ_GAMESCAN_FILE" 2>/dev/null || { cp -f "$tmp" "$LQ_GAMESCAN_FILE" 2>/dev/null || { rm -f "$tmp"; printf 'LQ_REASON:%s\n' 'could not keep the scan result' >&2; return 1; }; rm -f "$tmp" >/dev/null 2>&1; }
    chmod 666 "$LQ_GAMESCAN_FILE" >/dev/null 2>&1
    printf '%s\n' '__LQ_LIST__'
    cat "$LQ_GAMESCAN_FILE"
    printf '%s\n' '__LQ_LIST_END__'
    return 0
}

# ── _lq_game_commit() ──
# Replace: the held scan result becomes the detected game list (the file the Game tab prefers), and is mirrored to the persistent
# copy like every other edit of that list. The module's own gamelist.txt is never touched.
_lq_game_commit() {
    local tmp
    if [ ! -s "$LQ_GAMESCAN_FILE" ]; then
        printf 'LQ_REASON:%s\n' 'there is no scan result to write (scan again)' >&2
        return 1
    fi
    tmp="$LQ_GAMELIST_DETECTED_FILE.new.$$"
    rm -f "$tmp" >/dev/null 2>&1
    cat "$LQ_GAMESCAN_FILE" > "$tmp" 2>/dev/null || { rm -f "$tmp"; printf 'LQ_REASON:%s\n' 'could not write the temporary file' >&2; return 1; }
    chmod 666 "$tmp" >/dev/null 2>&1
    if ! mv -f "$tmp" "$LQ_GAMELIST_DETECTED_FILE" 2>/dev/null; then
        cp -f "$tmp" "$LQ_GAMELIST_DETECTED_FILE" 2>/dev/null || { rm -f "$tmp"; printf 'LQ_REASON:%s\n' "could not save to $LQ_GAMELIST_DETECTED_FILE" >&2; return 1; }
        rm -f "$tmp" >/dev/null 2>&1
    fi
    chmod 666 "$LQ_GAMELIST_DETECTED_FILE" >/dev/null 2>&1
    _lq_mirror_list "$LQ_GAMELIST_DETECTED_FILE" "$LQ_PERSIST_GAMELIST_DETECTED_FILE" >/dev/null 2>&1 || true
    rm -f "$LQ_GAMESCAN_FILE" >/dev/null 2>&1
    return 0
}

# ── _lq_game_discard() ──
# Cancel: the held scan result is thrown away, no list changes.
_lq_game_discard() {
    rm -f "$LQ_GAMESCAN_FILE" "$LQ_GAMESCAN_FILE".new.* >/dev/null 2>&1
    return 0
}

# ── Angle Texture ──
# ANGLE reads debug.angle.feature_overrides_enabled (a colon-separated list of feature overrides) when a process starts its GL
# context, so a change only reaches a game once that game is started again. The property itself is global, so the per-game part is done
# by a table: $LQ_ANGLETEX_CONF holds one line per game, `package|flags|mode` (mode = stop | apply | skip), and zi.sh -- which already follows
# the foreground app -- calls _lq_atx_enter (modules/angletex.sh) whenever a game comes to the front: if the property is not already
# that game's list it is set, and with mode=stop the game is force-stopped once. A game with no line gets the default (empty) list.
#   pixel  -> forceNearestFiltering
#   blur   -> disableAnisotropicFiltering
#   level  -> forceTextureLodOffset<1..4> (0 = not set)
# A feature that is off is simply left out of the list.
: "${LQ_ANGLETEX_CONF:=$LQ_TMP_DIR/angletex.conf}"
_lq_angletex_flags() {
    local out=""
    [ "$1" = "1" ] && out="forceNearestFiltering"
    [ "$2" = "1" ] && out="${out:+$out:}disableAnisotropicFiltering"
    case "$3" in
        1|2|3|4) out="${out:+$out:}forceTextureLodOffset$3" ;;
    esac
    printf '%s' "$out"
}
# ── _lq_angletex_conf_put() ── $1 package, $2 flags, $3 mode; keeps every other game's line, replaces this one's (skip = Manual, hands-off); drops it when it says "default, no stop"
_lq_angletex_conf_put() {
    local pkg="$1" flags="$2" mode="$3" tmp="$LQ_ANGLETEX_CONF.tmp" p f m
    {
        if [ -f "$LQ_ANGLETEX_CONF" ]; then
            while IFS='|' read -r p f m; do
                [ -n "$p" ] || continue
                [ "$p" = "$pkg" ] && continue
                printf '%s|%s|%s\n' "$p" "$f" "$m"
            done < "$LQ_ANGLETEX_CONF"
        fi
        # mode skip = Manual: a hands-off line, zi.sh never touches the property or the game for it (see modules/angletex.sh).
        # Anything else (Apply and Reset alike): the game's list, kept while it has flags or a force-stop is asked for.
        if [ "$mode" = "skip" ]; then
            printf '%s||skip\n' "$pkg"
        elif [ -n "$flags" ] || [ "$mode" = "stop" ]; then
            printf '%s|%s|%s\n' "$pkg" "$flags" "$mode"
        fi
    } > "$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
    if [ -s "$tmp" ]; then
        mv -f "$tmp" "$LQ_ANGLETEX_CONF" || { rm -f "$tmp"; return 1; }
        chmod 666 "$LQ_ANGLETEX_CONF" >/dev/null 2>&1 || true
    else
        rm -f "$tmp" "$LQ_ANGLETEX_CONF" >/dev/null 2>&1
    fi
    return 0
}
# ── _lq_angletex_set() ── $1 package, $2 pixel 0|1, $3 blur 0|1, $4 level 0..4, $5 force-stop 0|1, $6 manual 0|1
# manual=1 (the game is in Manual mode): one-time apply. The property is set now (and the game stopped with $5=1) but the game keeps its
# hands-off line, so zi.sh never repeats it.
# Saves the game's line, sets the property right away (a game started from now on already gets it) and, with $5=1, force-stops the game.
_lq_angletex_set() {
    local pkg="$1" flags mode=apply
    _lq_pkg_valid "$pkg" || return 2
    case "$2" in 0|1) ;; *) return 2 ;; esac
    case "$3" in 0|1) ;; *) return 2 ;; esac
    case "$4" in 0|1|2|3|4) ;; *) return 2 ;; esac
    case "${5:-0}" in 0|1) ;; *) return 2 ;; esac
    case "${6:-0}" in 0|1) ;; *) return 2 ;; esac
    [ "${5:-0}" = "1" ] && mode=stop
    flags="$(_lq_angletex_flags "$2" "$3" "$4")"
    if [ "${6:-0}" = "1" ]; then
        _lq_angletex_conf_put "$pkg" "" skip || return 1
    else
        _lq_angletex_conf_put "$pkg" "$flags" "$mode" || return 1
    fi
    setprop debug.angle.feature_overrides_enabled "$flags" >/dev/null 2>&1 || return 1
    [ "$(getprop debug.angle.feature_overrides_enabled 2>/dev/null | tr -d '\r')" = "$flags" ] || return 1
    if [ "$mode" = "stop" ]; then
        am force-stop "$pkg" >/dev/null 2>&1 || return 1
    fi
    return 0
}

# ── _lq_angletex_manual() ── $1 package: Manual mode. Only the hands-off line is written: no setprop, no force-stop, so whatever is set by hand stays.
# Going back to Auto is a normal set-angletex with the game's saved values.
_lq_angletex_manual() {
    _lq_pkg_valid "$1" || return 2
    _lq_angletex_conf_put "$1" "" skip || return 1
    return 0
}

# ── _lq_pkgmgr_usage() ──
_lq_pkgmgr_usage() {
    printf '%s\n' \
        'usage:' \
        '  pkgmgr.sh list <user|game|preload|whitelist>' \
        '  pkgmgr.sh add <game|preload|whitelist> <package>' \
        '  pkgmgr.sh remove <game|preload|whitelist> <package>' \
        '  pkgmgr.sh refresh-user' \
        '  pkgmgr.sh scan-games | commit-games | discard-games' \
        '  pkgmgr.sh preload <package> [normal|extra]' \
        '  pkgmgr.sh set-angletex-mode <package>   (Manual: the module leaves Angle Texture alone for this game)' \
        '  pkgmgr.sh set-preload-mode <package> <normal|extra>' \
        '  pkgmgr.sh get-driver <package>' \
        '  pkgmgr.sh set-driver <package> <game-driver|updatable-driver|angle> <0|1>' \
        '  pkgmgr.sh set-angletex <package> <pixel 0|1> <blur 0|1> <level 0-4> [force-stop 0|1]'
}

# ── _lq_pkgmgr_file_for() ──
_lq_pkgmgr_file_for() {
    case "${1:-}" in
        user)      printf '%s\n' "$LQ_USERPKG_FILE" ;; 
        userextra) printf '%s\n' "$LQ_USERPKG_EXTRA_FILE" ;; 
        game)      _lq_active_gamelist_file ;; 
        preload)   printf '%s\n' "$LQ_PRELIST_FILE" ;; 
        whitelist) printf '%s\n' "$LQ_WHITELIST_FILE" ;; 
        *) return 1 ;;
    esac
}

# ── _lq_pkgmgr_cli() ──
_lq_pkgmgr_cli() {
    local cmd="${1:-}" scope="${2:-}" pkg="${3:-}" extra="${4:-}" file rc old_mode line requested_mode verify_file
    _lq_pkgmgr_init || return 1

    case "$cmd" in
        list)
            file=$(_lq_pkgmgr_file_for "$scope") || return 2
            if [ "$scope" = "preload" ] && [ -f "$file" ]; then
                while IFS= read -r line; do
                    line="${line%%#*}"
                    line=${line#"${line%%[![:space:]]*}"}
                    line=${line%"${line##*[![:space:]]}"}
                    [ -n "$line" ] || continue
                    printf '%s\n' "${line%%=*}"
                done < "$file"
            else
                [ -f "$file" ] && cat "$file"
            fi
            ;;
        refresh-user)
            _generate_user_pkg_inventory
            ;;
        scan-games)
            _lq_game_scan
            ;;
        commit-games)
            _lq_game_commit
            ;;
        discard-games)
            _lq_game_discard
            ;;
        preload)
            [ -n "$scope" ] || return 2
            _lq_pkgmgr_file_for preload >/dev/null 2>&1 || return 2
            if _lq_list_contains "$LQ_PRELIST_FILE" "$scope"; then
                requested_mode="${pkg:-${extra:-}}"
                [ -n "$requested_mode" ] || requested_mode="$(_lq_prelist_mode "$scope" 2>/dev/null || printf 'normal')"
                requested_mode="$(_lq_preload_mode_normalize "$requested_mode" 2>/dev/null || true)"
                [ -n "$requested_mode" ] || {
                    printf '%s\n' 'invalid-preload-mode' >&2
                    return 2
                }
                _lq_preload_run_now "$scope" "$requested_mode"
            else
                printf '%s\n' 'not-in-prelist' >&2
                return 3
            fi
            ;;
        set-preload-mode)
            [ -n "$scope" ] || return 2
            _lq_preload_mode_valid "$pkg" || { printf '%s\n' 'invalid-preload-mode' >&2; return 2; }
            _lq_list_contains "$LQ_PRELIST_FILE" "$scope" || { printf '%s\n' 'not-in-prelist' >&2; return 3; }
            old_entry="$(_lq_prelist_entry "$scope" 2>/dev/null || printf '%s' "$scope")"
            _lq_prelist_add "$scope" "$pkg" || return $?
            if ! _lq_preload_run_now "$scope" "$pkg"; then
                if [ "$old_entry" = "$scope" ]; then
                    _lq_prelist_add_pending "$scope" >/dev/null 2>&1 || true
                else
                    old_mode="${old_entry#*=}"
                    _lq_prelist_add "$scope" "$old_mode" >/dev/null 2>&1 || true
                fi
                return 1
            fi
            ;;
        add|remove)
            [ -n "$pkg" ] || return 2
            case "$scope" in
                game)
                    if [ "$cmd" = add ]; then _lq_game_add "$pkg"; else _lq_game_remove "$pkg"; fi
                    ;;
                preload)
                    if [ "$cmd" = add ]; then
                        _lq_prelist_add_pending "$pkg" || return $?
                    else
                        if _lq_list_contains "$LQ_PRELIST_FILE" "$pkg"; then
                            old_entry="$(_lq_prelist_entry "$pkg" 2>/dev/null || printf '%s' "$pkg")"
                            _lq_prelist_remove "$pkg" || return $?
                            if [ "$old_entry" != "$pkg" ]; then
                                if ! _lq_preload_reset_now "$pkg"; then
                                    old_mode="${old_entry#*=}"
                                    _lq_prelist_add "$pkg" "$old_mode" >/dev/null 2>&1 || true
                                    return 1
                                fi
                            fi
                        fi
                    fi
                    ;;
                whitelist)
                    if [ "$cmd" = add ]; then _lq_whitelist_add "$pkg"; else _lq_whitelist_remove "$pkg"; fi
                    ;;
                userextra)
                    if [ "$cmd" = add ]; then _lq_userextra_add "$pkg"; else _lq_userextra_remove "$pkg"; fi
                    ;;
                *) return 2 ;;
            esac
            rc=$?
            case "$rc" in
                0) ;;
                *) return "$rc" ;;
            esac
            if [ "$scope" = "game" ] && [ -n "${LQ_GAME_TARGET_FILE:-}" ]; then
                # Verify against the exact file _lq_game_add/_lq_game_remove
                # just wrote, not a freshly recomputed "active" file -- an
                # add/remove can itself flip which file counts as active
                # (e.g. removing the last entry empties the detected file).
                verify_file="$LQ_GAME_TARGET_FILE"
            else
                verify_file="$(_lq_pkgmgr_file_for "$scope")" || return 2
            fi
            if [ "$cmd" = "add" ]; then
                _lq_list_contains "$verify_file" "$pkg" || return 1
            else
                ! _lq_list_contains "$verify_file" "$pkg" || return 1
            fi
            printf '%s\n' "$pkg"
            ;;
        get-driver)
            # Reuses the scope slot for the package name (list/get-value
            # style single-target commands take it as their 2nd arg).
            [ -n "$scope" ] || return 2
            _lq_pkg_valid "$scope" || return 2
            printf 'gfxdriver=%s\n' "$(_lq_gfxdriver_get "$scope")"
            printf 'angle=%s\n' "$(_lq_angle_get "$scope")"
            ;;
        set-driver)
            # scope=package, pkg=driver group (gfxdriver|angle), extra=choice
            # (matches how pkgBackendScript(pkg, 'set-driver', group, choice)
            # lays out args).
            [ -n "$scope" ] && [ -n "$pkg" ] || return 2
            _lq_driver_group_valid "$pkg" || return 2
            case "$pkg" in
                gfxdriver) _lq_gfxdriver_set "$scope" "$extra" || return $? ;;
                angle) _lq_angle_set "$scope" "$extra" || return $? ;;
            esac
            printf '%s\n' "$scope"
            ;;
        set-angletex)
            # args after the command: package pixel blur level [force-stop [manual]]
            _lq_angletex_set "$2" "$3" "$4" "$5" "$6" "$7" || return $?
            printf '%s\n' "$2"
            ;;
        set-angletex-mode)
            _lq_angletex_manual "$2" || return $?
            printf '%s\n' "$2"
            ;;
        *)
            _lq_pkgmgr_usage
            return 2
            ;;
    esac
}

case "${1:-}" in
    add|remove|preload|set-preload-mode|set-driver)
        if [ -f "${MODDIR:-/nonexistent}/other/runtime.sh" ]; then
            . "$MODDIR/other/runtime.sh"
            _lq_gate="$(_lq_lz_start)" || { printf '%s\n' "__LQ_ERR__ no-service-$_lq_gate"; exit 3; }
        fi
        ;;
esac

case "${1:-}" in
    list|add|remove|refresh-user|scan-games|commit-games|discard-games|preload|set-preload-mode|get-driver|set-driver|set-angletex|set-angletex-mode)
        _lq_pkgmgr_cli "$@"
        rc=$?
        if test "$rc" = "0"; then
            printf '%s\n' '__LQ_OK__'
        else
            printf '%s%s\n' '__LQ_ERR__' "$rc"
        fi
        exit "$rc"
        ;;
esac
