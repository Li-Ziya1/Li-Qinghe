#!/system/bin/sh
# Li Qinghe runtime bridge: one PID (Liziya) that everything else can lean on.
#
#   ensure-runtime   make sure Liziya is running (start it by hand when it isn't)
#                    and print its PID. __LQ_OK__ only when a PID exists.
#   runtime-status   print who/what/where (uid, pid, socket, module id, state dir)
#                    so a failure can be located from one block of text.
#
# Needs: MODDIR, LQ_TMP_DIR (defaults below). Light on purpose: no other module
# file has to be sourced for the common case.
: "${LQ_TMP_DIR:=/data/local/tmp/liqinghe}"
: "${EXPECTED_FILE:=$LQ_TMP_DIR/lqe.conf}"
: "${CURRENT_MODE_FILE:=$LQ_TMP_DIR/lq.mode}"
: "${TRANSITION_LOCK_FILE:=$LQ_TMP_DIR/.lq_transition.lock}"
: "${LQ_LIZIYA_PID_FILE:=$LQ_TMP_DIR/liziya.pid}"
: "${MODDIR:=$(cd "$(dirname "$0")/.." 2>/dev/null && pwd)}"

_lq_rt_log() {
    printf '%s uid=%s runtime: %s\n' "$(date +%m-%d_%H:%M:%S 2>/dev/null)" "$(id -u 2>/dev/null)" "$*" \
        >> "$LQ_TMP_DIR/debug.log" 2>/dev/null
}

# Prints the PID of the running watcher (or nothing). pidof first; the pid file is
# only trusted when /proc says that PID really is Liziya.
_lq_lz_pid() {
    local p="" f
    set -- $(pidof Liziya 2>/dev/null)
    p="$1"
    if [ -z "$p" ] && [ -r "$LQ_LIZIYA_PID_FILE" ]; then
        f="$(cat "$LQ_LIZIYA_PID_FILE" 2>/dev/null)"
        case "$f" in ''|*[!0-9]*) f="" ;; esac
        if [ -n "$f" ] && [ -r "/proc/$f/cmdline" ] \
           && tr '\0' ' ' < "/proc/$f/cmdline" 2>/dev/null | grep -q Liziya; then
            p="$f"
        fi
    fi
    printf '%s' "$p"
}

# Prints the PID on success (return 0) or a short reason (return 1).
_lq_lz_start() {
    local bin="$MODDIR/system/bin/Liziya" p i mode out e
    p="$(_lq_lz_pid)"
    if [ -n "$p" ]; then printf '%s' "$p"; return 0; fi

    [ -f "$bin" ] || { printf 'no-binary'; return 1; }
    [ -x "$bin" ] || chmod 755 "$bin" >/dev/null 2>&1
    [ -x "$bin" ] || { printf 'binary-not-executable'; return 1; }

    # Build the expected-property file first when it is missing (same call
    # service.sh makes). Liziya itself can start without it and waits for it.
    if [ ! -s "$EXPECTED_FILE" ] && command -v _lq_conflict_snapshot_refresh >/dev/null 2>&1; then
        mode=idle
        [ "$(cat "$CURRENT_MODE_FILE" 2>/dev/null)" = "performance" ] && mode=game
        _lq_conflict_snapshot_refresh "$mode" >/dev/null 2>&1 || true
    fi
    _lq_rt_log "pid missing, starting Liziya by hand"

    # New binary: it detaches itself and prints pid=<n> / error=<reason>.
    # (An old binary just exits 1 without printing either, so fall through.)
    out="$(if command -v timeout >/dev/null 2>&1; then timeout 8 "$bin" --start "$EXPECTED_FILE" "$TRANSITION_LOCK_FILE" "$MODDIR"; else "$bin" --start "$EXPECTED_FILE" "$TRANSITION_LOCK_FILE" "$MODDIR"; fi 2>/dev/null)"
    case "$out" in
        *pid=*|*error=*)
            p="$(printf '%s\n' "$out" | sed -n 's/^pid=//p' | head -n 1)"
            e="$(printf '%s\n' "$out" | sed -n 's/^error=//p' | head -n 1)"
            if [ -n "$p" ]; then
                printf '%s\n' "$p" > "$LQ_LIZIYA_PID_FILE" 2>/dev/null
                chmod 666 "$LQ_LIZIYA_PID_FILE" >/dev/null 2>&1
                _lq_rt_log "Liziya --start ok, pid=$p $(printf '%s' "$out" | tr '\n' ' ')"
                printf '%s' "$p"
                return 0
            fi
            _lq_rt_log "Liziya --start failed: $e"
            printf '%s' "${e:-start-failed}"
            return 1
            ;;
    esac

    if command -v setsid >/dev/null 2>&1; then
        setsid "$bin" "$EXPECTED_FILE" "$TRANSITION_LOCK_FILE" "$MODDIR" </dev/null >/dev/null 2>&1 &
    else
        nohup "$bin" "$EXPECTED_FILE" "$TRANSITION_LOCK_FILE" "$MODDIR" </dev/null >/dev/null 2>&1 &
    fi
    i=0
    while [ "$i" -lt 20 ]; do                    # up to ~5 s
        sleep 0.25 2>/dev/null || sleep 1
        p="$(_lq_lz_pid)"
        if [ -n "$p" ]; then
            printf '%s\n' "$p" > "$LQ_LIZIYA_PID_FILE" 2>/dev/null
            chmod 666 "$LQ_LIZIYA_PID_FILE" >/dev/null 2>&1
            _lq_rt_log "Liziya started, pid=$p"
            printf '%s' "$p"
            return 0
        fi
        i=$((i + 1))
    done
    _lq_rt_log "Liziya did not stay up (start-failed)"
    printf 'start-failed'
    return 1
}

_lq_lz_report() {
    local bin="$MODDIR/system/bin/Liziya" rc="nobin" mid=0 w=0
    if [ -x "$bin" ]; then
        if command -v timeout >/dev/null 2>&1; then timeout 3 "$bin" --alive >/dev/null 2>&1; rc=$?
        else "$bin" --alive >/dev/null 2>&1; rc=$?; fi
    fi
    grep -q '^id=LQlzy' "$MODDIR/module.prop" 2>/dev/null && mid=1
    [ -w "$LQ_TMP_DIR" ] && w=1
    printf 'runtime_uid=%s\n' "$(id -u 2>/dev/null)"
    printf 'liziya_pid=%s\n' "$(_lq_lz_pid)"
    printf 'liziya_alive_rc=%s\n' "$rc"            # 0 Alive, 2 Sleep, 1 socket unreachable
    printf 'module_id_ok=%s\n' "$mid"
    printf 'state_dir_writable=%s\n' "$w"
    printf 'expected_file=%s\n' "$([ -s "$EXPECTED_FILE" ] && echo yes || echo no)"
    printf 'selinux=%s\n' "$(getenforce 2>/dev/null)"
    if [ -z "$(_lq_lz_pid)" ] && [ -s "$LQ_TMP_DIR/liziya.err" ]; then
        printf 'liziya_last_error=%s\n' "$(head -n 1 "$LQ_TMP_DIR/liziya.err" 2>/dev/null)"
    fi
    printf 'liziya_native_start=%s\n' "$(grep -qa -- '--start' "$bin" 2>/dev/null && echo 1 || echo 0)"
}

_lq_runtime_cmd() {
    local r rc
    case "$1" in
        ensure-runtime)
            r="$(_lq_lz_start)"; rc=$?
            _lq_lz_report
            if [ "$rc" -eq 0 ]; then
                printf '__LQ_OK__\n'
            else
                printf '__LQ_ERR__ liziya-%s\n' "$r"
                _lq_rt_log "ensure-runtime failed: $r"
            fi
            ;;
        runtime-status)
            _lq_lz_report
            ;;
    esac
}
