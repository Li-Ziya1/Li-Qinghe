#!/system/bin/sh
MODDIR=${0%/*}
umask 000
. "$MODDIR/common.sh"
chmod 777 "$LQ_TMP_DIR" >/dev/null 2>&1 || true
_lq_fix_perms

# ── _lq_sync_pkgmgr_bridge() ──
_lq_sync_pkgmgr_bridge() {
    local bridge="$LQ_TMP_DIR/pkgmgr.sh"
    local target="$MODDIR/other/pkgmgr.sh"
    [ -f "$target" ] || return 1
    [ -d "$LQ_TMP_DIR" ] || mkdir -p "$LQ_TMP_DIR" >/dev/null 2>&1 || return 1
    {
        printf '%s\n' '#!/system/bin/sh'
        printf '%s\n' 'umask 000'
        printf 'MODDIR="%s"\n' "$MODDIR"
        printf '%s\n' 'export MODDIR'
        printf 'exec sh "%s" "$@"\n' "$target"
    } > "$bridge" 2>/dev/null || return 1
    chmod 755 "$bridge" >/dev/null 2>&1 || return 1
    return 0
}
_lq_sync_pkgmgr_bridge >/dev/null 2>&1
# ── _lq_sync_tweaks_bridge() ──
_lq_sync_tweaks_bridge() {
    local bridge="$LQ_TMP_DIR/tweaks.sh" target="$MODDIR/modules/tweaks.sh"
    [ -f "$target" ] || return 1
    [ -d "$LQ_TMP_DIR" ] || mkdir -p "$LQ_TMP_DIR" >/dev/null 2>&1 || return 1
    {
        printf '%s\n' '#!/system/bin/sh'
        printf '%s\n' 'umask 000'
        printf 'MODDIR="%s"\n' "$MODDIR"
        printf '%s\n' 'export MODDIR'
        printf 'exec sh "%s" "$@"\n' "$target"
    } > "$bridge" 2>/dev/null || return 1
    chmod 755 "$bridge" >/dev/null 2>&1 || return 1
}
_lq_sync_tweaks_bridge >/dev/null 2>&1
# Fily calls ven from here; refreshed every boot so a module update takes effect.
_lq_sync_ven_bin >/dev/null 2>&1

# Put this device's name into the module description ("Make your <device> feel better").
# Same naming as the WebUI (market name, else model, brand in front when it is missing).
# Only the description line is rewritten; id and author stay as they are.
_lq_set_description() {
    local prop="$MODDIR/module.prop" tmp="$LQ_TMP_DIR/module.prop.new"
    local brand model name first rest line
    [ -f "$prop" ] || return 1
    brand="$(getprop ro.product.brand 2>/dev/null | tr -d '\r\n')"
    [ -n "$brand" ] || brand="$(getprop ro.product.manufacturer 2>/dev/null | tr -d '\r\n')"
    model="$(getprop ro.product.marketname 2>/dev/null | tr -d '\r\n')"
    [ -n "$model" ] || model="$(getprop ro.product.vendor.marketname 2>/dev/null | tr -d '\r\n')"
    [ -n "$model" ] || model="$(getprop ro.product.model 2>/dev/null | tr -d '\r\n')"
    first="$(printf '%s' "$brand" | cut -c1 | tr 'a-z' 'A-Z')"
    rest="$(printf '%s' "$brand" | cut -c2- | tr 'A-Z' 'a-z')"
    brand="$first$rest"
    if [ -n "$model" ] && [ -n "$brand" ] && \
       [ "$(printf '%s' "$model" | tr 'A-Z' 'a-z' | cut -c1-${#brand})" != "$(printf '%s' "$brand" | tr 'A-Z' 'a-z')" ]; then
        name="$brand $model"
    else
        name="${model:-$brand}"
    fi
    # keep it plain so it is safe inside sed and module.prop
    name="$(printf '%s' "$name" | tr -cd 'A-Za-z0-9 ._+-')"
    [ -n "$name" ] || return 1
    line="description=Make your $name feel better"
    grep -qxF "$line" "$prop" 2>/dev/null && return 0
    mkdir -p "$LQ_TMP_DIR" >/dev/null 2>&1
    sed "s|^description=.*|$line|" "$prop" > "$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
    # write back only when the copy is complete and still the official id
    if [ -s "$tmp" ] && grep -q '^id=LQlzy' "$tmp" && grep -q '^author=' "$tmp" && grep -q '^description=' "$tmp"; then
        cat "$tmp" > "$prop" 2>/dev/null
    fi
    rm -f "$tmp"
    return 0
}
_lq_set_description >/dev/null 2>&1

rm -f "$LQ_PRELOAD_STATE_FILE" >/dev/null 2>&1

_lq_wait_boot_completed
_lq_init_package_lists >/dev/null 2>&1
rm -f "$TRANSITION_LOCK_FILE"
sleep 2

# AxManager loads system.prop through setprop and only accepts debug.*
# properties, so the two non-debug entries that used to live there
# (persist.* / security.*) are applied here once per boot instead. They are
# no longer in system.prop, so the conflict watcher's expected snapshot
# (built from that file) does not track them.
setprop persist.traced_perf.enable false >/dev/null 2>&1 || true
setprop security.perf_harden 0 >/dev/null 2>&1 || true

# Read the device specs once at service startup. They feed the HWUI target
# CPU-time values and the JobScheduler defaults (no hardware tiers involved).
_detect_hwui_profile
export HWUI_GAME_CPU_PCT HWUI_IDLE_CPU_PCT JOB_SCHED_ACTIVE JOB_SCHED_BG_NORM JOB_SCHED_BG_MOD JOB_SCHED_BG_LOW JOB_SCHED_MIN_READY
_lq_runtime_perf_detect_keys >/dev/null 2>&1 || true

# Turn those same specs (plus the brand) into a recommended System Tuning
# profile (which groups + which value for each) and persist it for the
# WebUI's One-Click Optimization toggle. This is the only detection/calc
# pass -- the WebUI only ever reads what gets written here.
_lq_build_recommended_profile >/dev/null 2>&1 || true

# Prepare persistent profile/state files without applying them.
[ -f "$LQ_IDLE_PROFILE_FILE" ] || _lq_write_state "$LQ_IDLE_PROFILE_FILE" normal
[ -f "$LQ_SURFACE_FLINGER_PROFILE_FILE" ] || _lq_write_state "$LQ_SURFACE_FLINGER_PROFILE_FILE" 0
[ -f "$LQ_TRACE_PROFILE_FILE" ] || _lq_write_state "$LQ_TRACE_PROFILE_FILE" off
[ -f "$LQ_FILY_STATE_FILE" ] || _lq_write_state "$LQ_FILY_STATE_FILE" 0
[ -f "$LQ_TCTL_STATE_FILE" ] || _lq_write_state "$LQ_TCTL_STATE_FILE" 0
case "$(_lq_tctl_enabled 2>/dev/null)" in 0|1) ;; *) _lq_write_state "$LQ_TCTL_STATE_FILE" 0 ;; esac

rm -f "$EXPECTED_FILE" "$LQ_RUNTIME_PERF_BACKUP_FILE" >/dev/null 2>&1 || true
# Stop a stale native instance without leaving a detector PID file behind.
for _LQ_PID in $(pidof Liziya 2>/dev/null); do
    kill -TERM "$_LQ_PID" >/dev/null 2>&1 || true
done
# Needed here (not sourced at the top of the script) to re-assert System
# Tuning / SurfaceFlinger group state before _lq_conflict_snapshot_refresh builds the conflict
# watcher's expected-property snapshot below. Sourcing system_tuning.sh
# triggers its own first-run value-seeding pass (tuning_seed_default_values),
# which falls back to hardcoded constants for any tunable whose
# recommended value isn't available yet -- so this must come AFTER
# _lq_build_recommended_profile above has already populated
# LQ_RECOMMENDED_PROFILE_FILE, or a tunable with no prior stored value
# gets permanently seeded with the wrong (fallback) number instead of this
# device's actual detected one.
. "$MODDIR/modules/system_tuning.sh"
. "$MODDIR/modules/surface_flinger.sh"
# Reflash/reboot keeps every System Tuning group's .state file (they live
# outside the module folder), but every property those groups set is a
# debug.* property, not persist.*, so it resets to unset on every boot.
# _lq_conflict_snapshot_refresh below builds the watcher's expected snapshot straight from those
# .state files -- if the real properties aren't re-applied first, Liziya's
# very first scan (moments after the "Ready" toast) sees a mismatch against
# a device that was never actually re-tuned yet, and raises a false-positive
# Sleep. Re-assert everything for real, under the transition lock so Liziya
# (started further below) never scans mid-restore.
_transition_lock_on

_lq_auto_idle_restore >/dev/null 2>&1 || true
for _LQ_G in $LQ_TUNING_GROUPS; do
    _LQ_GSAFE="$(tuning_group_slug "$_LQ_G")"
    if [ -f "$LQ_SYSTEM_TUNING_MANUAL_DIR/${_LQ_GSAFE}.state" ] && \
       [ "$(cat "$LQ_SYSTEM_TUNING_MANUAL_DIR/${_LQ_GSAFE}.state" 2>/dev/null)" = "1" ]; then
        tuning_set_group "$_LQ_G" 1 >/dev/null 2>&1 || true
    fi
done
unset _LQ_G _LQ_GSAFE
_lq_sf_refresh_invalidate
_lq_disp_rates_invalidate >/dev/null 2>&1 || true
_lq_disp_boot_apply >/dev/null 2>&1 || true
_lq_sf_apply "$(_lq_sf_detect 2>/dev/null)" >/dev/null 2>&1 || true

# Seed the expected-property snapshot before the native watcher starts.
# Profile transitions rebuild this file atomically through _lq_conflict_snapshot_refresh().
_lq_conflict_snapshot_refresh "idle" >/dev/null 2>&1 || true
_transition_lock_off
printf 'performance_keys=%s\n' "$(wc -l < "$LQ_RUNTIME_PERF_KEYS_FILE" 2>/dev/null)" > "$LQ_TMP_DIR/runtime_ready"

# Respect the persistent helper state. Fily is OFF unless its state file says 1.
# (native binary now owns start/stop/loop; it reads/writes the same
#  LQ_FILY_STATE_FILE and LQ_FILY_PID_FILE paths the old shell version used)
_FILY_BIN="$(_lq_fily_bin 2>/dev/null)"
if [ -n "$_FILY_BIN" ] && [ -x "$_FILY_BIN" ]; then
    if [ "$(_lq_fily_enabled 2>/dev/null)" = "1" ]; then
        "$_FILY_BIN" start >/dev/null 2>&1 || true
    else
        "$_FILY_BIN" stop >/dev/null 2>&1 || true
    fi
fi

# Pre-detect persist.log.tag properties every boot, before the "Ready"
# toast, so the WebUI "Silent Log Tags" toggle just reads this list and
# applies it -- instead of scanning every property on the device at the
# moment the toggle is clicked. Rebuilt fresh each boot (not just at
# install in customize.sh) so it self-heals if the cache file is ever lost
# on reboot, and always reflects whatever is currently on the device.
LQ_LOG_TAG_CATALOG="$LQ_SYSTEM_TUNING_DIR/persist_log_tags.catalog"
: > "$LQ_LOG_TAG_CATALOG"
getprop 2>/dev/null | sed -n 's/^\[\(persist\.log\.tag[^]]*\)\]:.*/\1/p' > "$LQ_LOG_TAG_CATALOG"
chmod 644 "$LQ_LOG_TAG_CATALOG" >/dev/null 2>&1

_lq_fix_perms
_lq_toast "Ready"
_lq_notify "$(printf '%s\n%s' \
    "All Runtime Ready" \
    "Open the WebUI to control other options")"

# Native conflict detector: sleeps on Android's property-area wait primitive
# while idle, and wakes only when a watched system property changes.
# Conflict is sticky and NEVER auto-recovers. Explicit recovery is:
#   Liziya --recovery
_CONFLICT_BIN="$MODDIR/system/bin/Liziya"
# Boot launch: the plain way first, exactly as before. If the watcher answers
# (a PID shows up) that is all; Liziya --start is not involved.
# Only when it does not come up is Liziya --start used as the switch: it starts
# the watcher detached and hands back the PID (or the reason it failed).
. "$MODDIR/other/runtime.sh"
if [ -x "$_CONFLICT_BIN" ]; then
    "$_CONFLICT_BIN" "$EXPECTED_FILE" "$TRANSITION_LOCK_FILE" "$MODDIR" >/dev/null 2>&1 &
    printf '%s\n' "$!" > "$LQ_LIZIYA_PID_FILE" 2>/dev/null
    chmod 666 "$LQ_LIZIYA_PID_FILE" >/dev/null 2>&1
    _lz_i=0
    _lz_pid=""
    while [ "$_lz_i" -lt 12 ]; do                 # about 3 s
        sleep 0.25 2>/dev/null || sleep 1
        _lz_pid="$(_lq_lz_pid)"
        [ -n "$_lz_pid" ] && break
        _lz_i=$((_lz_i + 1))
    done
    if [ -z "$_lz_pid" ]; then
        _lq_rt_log "boot: plain launch gave no PID, switching to Liziya --start"
        _lz_try=0
        while [ "$_lz_try" -lt 3 ]; do
            _lz_try=$((_lz_try + 1))
            _lz_out="$(_lq_lz_start)" && break
            sleep 2
        done
    fi
fi

# Show a single hidden-gem toast when the native detector raises a new conflict,
# and another single toast once it clears (recovered, either explicitly via
# Liziya --recovery or because the underlying conflict resolved itself).
# The toast state is reset after each transition, so a later conflict can
# show again without spamming on every poll.
_lq_conflict_notify_monitor() {
    local notified=0
    while :; do
        "$_CONFLICT_BIN" --alive 2>/dev/null
        if [ "$?" -eq 2 ]; then
            if [ "$notified" -eq 0 ]; then
                notified=1
                _lq_toast "Fell Asleep"
            fi
        else
            if [ "$notified" -eq 1 ]; then
                _lq_toast "Back to Alive"
            fi
            notified=0
        fi
        sleep 5
    done
}
_lq_conflict_notify_monitor >/dev/null 2>&1 &

exec sh "$MODDIR/zi.sh"

