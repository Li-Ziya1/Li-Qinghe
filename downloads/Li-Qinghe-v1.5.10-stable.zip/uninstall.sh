#!/system/bin/sh

MODDIR=${0%/*}
LQ_TMP_DIR="${LQ_TMP_DIR:-/data/local/tmp/liqinghe}"
CONFIG_FILE="$LQ_TMP_DIR/lq.conf"
NOTIF_ID="p9Qk3Lt6xRn1iMw8h5Us2e7gd4vB0yif1j6Iq3zA"

# Stop the native instance without relying on a persistent PID/flag file.
for _LQ_PID in $(pidof Liziya 2>/dev/null); do
    kill -TERM "$_LQ_PID" >/dev/null 2>&1 || true
done

# ── shared notification backend ─────────────────────────────────
NOTIFY_BACKEND="$MODDIR/modules/notify.sh"

# ── _lq_toast() ──
_lq_toast() { sh "$NOTIFY_BACKEND" toast "$1" >/dev/null 2>&1 || true; }

# ── _lq_notify() ──
_lq_notify() { sh "$NOTIFY_BACKEND" notification "$1" >/dev/null 2>&1 || true; }

# ── _lq_kill_service() ──
_lq_kill_service() {
    for p in $(pgrep -f "service.sh"); do
        kill "$p" 2>/dev/null
    done
}

# ── _RESTORE_WEBUI_PERSISTENT() ──
_RESTORE_WEBUI_PERSISTENT() {
    local base="$MODDIR/modules"
    [ -f "$base/state.sh" ] && . "$base/state.sh"
    [ -f "$base/idle_profiles.sh" ] && . "$base/idle_profiles.sh"
    [ -f "$base/system_tuning.sh" ] && . "$base/system_tuning.sh"
    [ -f "$base/surface_flinger.sh" ] && . "$base/surface_flinger.sh"
    [ -f "$base/display_tuning.sh" ] && . "$base/display_tuning.sh"
    [ -f "$base/trace_guard.sh" ] && . "$base/trace_guard.sh"
    [ -f "$MODDIR/other/pkgmgr.sh" ] && . "$MODDIR/other/pkgmgr.sh"

    case "$(_lq_idle_profile 2>/dev/null)" in
        battery-saver) _lq_battery_saver_disable >/dev/null 2>&1 || true ;;
    esac

    # Per-package Game Driver / Updatable Driver / ANGLE opt-ins only ever
    # touch the specific packages this module put there (tracked in
    # $LQ_DRIVER_STATE_DIR) -- pull just those back out instead of clearing
    # the whole device-wide setting, since other apps/tools may share it.
    _lq_driver_cleanup_all >/dev/null 2>&1 || true

    _lq_sf_restore_persistent >/dev/null 2>&1 || true
    _lq_disp_restore >/dev/null 2>&1 || true
    setprop debug.hwui.renderer "" >/dev/null 2>&1 || true
    setprop debug.renderengine.backend "" >/dev/null 2>&1 || true
    _lq_disp_set_extras off other >/dev/null 2>&1 || true
    _lq_trace_guard_off_all >/dev/null 2>&1 || true
    _lq_trace_guard_restore_originals >/dev/null 2>&1 || true

    settings delete global liqinghe_trace_guard_preset >/dev/null 2>&1 || true
    settings delete global liqinghe_trace_guard_active >/dev/null 2>&1 || true
    settings delete global liqinghe_surface_flinger_value >/dev/null 2>&1 || true
}

# ── _lq_restore_system_settings() ──
_lq_restore_system_settings() {
    {
        settings put global job_scheduler_constants ""
        settings delete global app_standby_constants
        settings delete global activity_manager_constants

        device_config delete activity_manager low_swap_threshold_percent

        am memory-factor reset
    } 2>/dev/null
}

# ── _lq_remove_runtime_files() ──
_lq_remove_runtime_files() {
    # only if Angle Texture was used (its table exists): hand the property back empty
    [ -s "$LQ_TMP_DIR/angletex.conf" ] && setprop debug.angle.feature_overrides_enabled "" >/dev/null 2>&1
    rm -rf "$LQ_TMP_DIR" >/dev/null 2>&1
    rm -f /data/local/tmp/ven >/dev/null 2>&1
}

# ── _lq_cancel_notifications() ──
_lq_cancel_notifications() {
    if command -v su >/dev/null 2>&1; then
        su -lp 2000 -c "cmd notification cancel $NOTIF_ID" 2>/dev/null
        su -lp 2000 -c "cmd notification cancel conflict_detected" 2>/dev/null
    else
        cmd notification cancel $NOTIF_ID 2>/dev/null
        cmd notification cancel conflict_detected 2>/dev/null
    fi
}

_lq_kill_service
_lq_restore_system_settings
_RESTORE_WEBUI_PERSISTENT

_KLIXR_STATE="$LQ_TMP_DIR/klixr"
# ── _restore_marked() ──
_restore_marked() {
    ns="$1"; key="$2"; marker="$3"
    [ -f "$_KLIXR_STATE/$marker" ] || return
    settings put "$ns" "$key" "$(cat "$_KLIXR_STATE/$marker")" >/dev/null 2>&1
}
_restore_marked system cloud_wireless_network_diagnostics_enabled cloud_wireless_network_diagnostics_enabled
_restore_marked system master_motion mastermotion
_restore_marked system motion_engine motionengine
_restore_marked system nearby_scanning_enabled nearbyscanning
_restore_marked global upload_apk_enable uploadapkfile
_restore_marked secure screensaver_enabled screensaveron
_restore_marked secure screensaver_activate_on_dock screensaveractiveondock

if [ -f "$_KLIXR_STATE/longpresstimeout" ]; then
    settings put secure long_press_timeout "$(cat "$_KLIXR_STATE/longpresstimeout")" >/dev/null 2>&1
fi

if [ -f "$_KLIXR_STATE/deviceidlewhitelist" ]; then
    while IFS= read -r pkg; do
        [ -n "$pkg" ] && dumpsys deviceidle sys-whitelist +"$pkg" >/dev/null 2>&1
    done < "$_KLIXR_STATE/deviceidlewhitelist"
fi

for a in activity_starts_logging_enabled enable_diskstats_logging foreground_service_starts_logging_enabled; do
    settings put global "$a" 1 >/dev/null 2>&1
done
settings delete global binder_calls_stats >/dev/null 2>&1

_lq_cancel_notifications
_lq_remove_runtime_files

_lq_toast "Uninstalled"
_lq_notify "$(printf '%s\n%s' \
    "Uninstalled Successfully" \
    "Reboot to confirm all tweaks have successfully reverted")"
