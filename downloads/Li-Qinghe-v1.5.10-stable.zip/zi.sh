#!/system/bin/sh
MODDIR=${0%/*}
. "$MODDIR/common.sh"
[ -f "$MODDIR/modules/angletex.sh" ] && . "$MODDIR/modules/angletex.sh"

# service.sh detects the HWUI profile once and exports its target values for
# the whole runtime session. Game/idle transitions reuse those values.
export HWUI_GAME_CPU_PCT HWUI_IDLE_CPU_PCT JOB_SCHED_ACTIVE JOB_SCHED_BG_NORM JOB_SCHED_BG_MOD JOB_SCHED_BG_LOW JOB_SCHED_MIN_READY

LAST_APP=""
EMPTY_STREAK=0
CURRENT_MODE="$(cat "$CURRENT_MODE_FILE" 2>/dev/null)"
[ -n "$CURRENT_MODE" ] || CURRENT_MODE="powersave"

_LQ_CONFLICT_BIN="$MODDIR/system/bin/Liziya"
while true; do
    # Liziya --alive is exit-code only: 0 = Alive, 2 = Sleep, 1 = watcher
    # unreachable (a missing/non-executable binary gives 126/127). Anything
    # but 0 means Sleep here, same as before, without a pipe, a grep or a
    # per-tick [ -x ] test.
    "$_LQ_CONFLICT_BIN" --alive 2>/dev/null
    if [ "$?" -ne 0 ]; then
        # Li Qinghe Sleep: suspend all game/idle profile application while
        # conflict or module-integrity state is active. Reset LAST_APP so the
        # normal loop re-evaluates the foreground app immediately on wake.
        LAST_APP=""
        sleep "$GAME_CHECK_INTERVAL"
        continue
    fi

    # _lq_foreground_resolve gets the top app from ven and decides game/non-game itself
    # (cached gamelist, no extra process) -- no separate lookup needed here.
    _lq_foreground_resolve
    if [ "$?" -ne 0 ] || [ -z "$LQ_FG_APP" ]; then
        # No trackable foreground app. This also fires transiently while a
        # game's own splash/loading screen is coming up, not just on the
        # home screen -- require a couple of consecutive empty reads before
        # treating it as "left to home", so a single blank read during game
        # launch doesn't bounce idle->game right back-to-back (which was
        # racing the conflict watcher's rescan into a false Sleep).
        EMPTY_STREAK=$((EMPTY_STREAK + 1))
        if [ "$EMPTY_STREAK" -ge 2 ] && [ -n "$LAST_APP" ] && [ "$CURRENT_MODE" != "powersave" ]; then
            LAST_STATE="idle"
            _enter_idle_mode
            LAST_APP=""
        fi
        sleep "$GAME_CHECK_INTERVAL"
        continue
    fi
    top_app="$LQ_FG_APP"
    EMPTY_STREAK=0

    if [ "$LAST_APP" != "$top_app" ]; then
        LAST_APP="$top_app"

        # Angle Texture: first thing when a game comes to the front, so the property is set before the game's GL starts
        if [ "$LQ_FG_IS_GAME" = "1" ] && command -v _lq_atx_enter >/dev/null 2>&1; then
            _lq_atx_enter "$top_app" >/dev/null 2>&1
        fi

        if [ "$LQ_FG_IS_GAME" = "1" ]; then
            CURRENT_GAME_APP="$top_app"
            LAST_STATE="game"

            if [ "$CURRENT_MODE" != "performance" ]; then
                _enter_game_mode
            else
                _apply_current_game_profile
            fi
        else
            LAST_STATE="idle"
            if [ "$CURRENT_MODE" != "powersave" ]; then
                _enter_idle_mode
            fi
        fi
    fi

    if [ "$CURRENT_MODE" = "performance" ]; then
        sleep "$GAME_CHECK_INTERVAL"
    else
        sleep "$IDLE_CHECK_INTERVAL"
    fi
done
