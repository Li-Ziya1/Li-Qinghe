/*
 * Li Qinghe • Void Engine
 * WebUI application logic
 *
 * Sections:
 *   Shell bridge / helpers
 *   Dashboard
 *   Navigation
 *   Package list
 *   Tweaks / Trace Guard
 *   Boot
 */

// ── Shell bridge ──────────────────────────────────────────────
// Every command goes through the host's callback form
// ksu.exec(cmd, options, callbackName), which runs the root shell on its own
// thread and reports back through a global callback. The plain one-argument
// ksu.exec(cmd) is synchronous: the WebView's UI thread sits and waits for the
// shell, so any slow command (apply tweaks, package scans, banner write) froze
// the whole UI. Here nothing ever waits on the UI thread.
//
// Safety rules:
//  - A command is NEVER run twice. A timeout only stops waiting for the
//    answer; it does not re-send the command down another path.
//  - Commands that may change something run one at a time, in the order they
//    were asked for (the blocking bridge used to guarantee that for free).
//    Plain reads run alongside them.
//  - A host that only has the one-argument form is detected on the first call
//    and used as before, so nothing breaks on older managers.
const LQ_HOST_NAMES = ['ksu', 'axeron', 'axora'];
const LQ_EXEC_TIMEOUT_MS = 180000;   // give up waiting after 3 min (never re-runs)
let lqExecSeq = 0;
let lqExecChain = Promise.resolve();
const lqHostNoCallback = new Set();  // host names that lack the callback form

function lqHosts() {
    const list = [];
    for (const n of LQ_HOST_NAMES) {
        let h;
        try { h = window[n]; } catch (_) { h = undefined; }
        if (h && typeof h.exec === 'function') list.push([n, h]);
    }
    return list;
}

function lqNormalize(r) {
    if (r == null) return null;
    if (typeof r === 'string') return r;
    if (typeof r === 'object' && 'stdout' in r) return String(r.stdout ?? '');
    return '';
}

// Runs one command on one host without blocking. Resolves to a string, or to
// null when this host can't take the command at all (nothing was run).
function lqCallHost(name, host, cmd, timeoutMs) {
    return new Promise(resolve => {
        const cb = `__lqx${++lqExecSeq}`;
        let done = false;
        let timer = 0;
        const cleanup = () => {
            clearTimeout(timer);
            try { delete window[cb]; } catch (_) { window[cb] = undefined; }
        };
        const settle = v => { if (done) return; done = true; cleanup(); resolve(v); };

        if (!lqHostNoCallback.has(name)) {
            window[cb] = (errno, stdout) => settle(typeof stdout === 'string' ? stdout : '');
            // stop waiting, but never resend: the command may well still be running
            timer = setTimeout(() => settle(''), timeoutMs);
            let ret;
            try {
                ret = host.exec(cmd, '{}', cb);
            } catch (_) {
                // threw before starting anything: this host has no callback form
                lqHostNoCallback.add(name);
                cleanup();
                done = true;
                resolve(lqCallHostSyncFallback(host, cmd));
                return;
            }
            if (ret && typeof ret.then === 'function') {
                // host answers with a promise: take that if the callback doesn't come first
                ret.then(v => { const s = lqNormalize(v); if (s !== null) settle(s); }, () => {});
            } else if (typeof ret === 'string' || (ret && typeof ret === 'object' && 'stdout' in ret)) {
                // host ignored the callback and already ran it synchronously
                lqHostNoCallback.add(name);
                settle(lqNormalize(ret));
            }
            // anything else (undefined, true, ...): the answer comes through the callback
            return;
        }
        done = true;
        resolve(lqCallHostSyncFallback(host, cmd));
    });
}

function lqCallHostSyncFallback(host, cmd) {
    try {
        const out = lqNormalize(host.exec(cmd));
        return out === null ? '' : out;
    } catch (_) {
        return null;
    }
}

// ── ksu.spawn: the one call that really runs in the background ───────────
// In a WebView every call into the host (ksu.exec / axeron.exec ...) is
// synchronous from the page's point of view: the JS thread waits until the Java
// method returns. KernelSU-style managers run an `exec` command to completion
// inside that method, so the page was frozen (cards, tabs, everything) for as
// long as a tweak took to apply, whichever way the result came back. `spawn`
// is different: it starts the command on its own thread, returns at once, and
// reports output and exit later through a callback object, so the UI stays free
// the whole time. Everything goes through it when the manager has it.
//   spawn(command, argsJson, optionsJson, callbackObjectName)
// The callback object gets stdout.emit('data', line), stderr.emit(...),
// emit('exit', code) and emit('error', err).
const lqSpawnState = new Map();   // host name -> 'ok' | 'bad' | Promise (probe running)

function lqHasSpawn() {
    return lqHosts().some(([n, h]) => typeof h.spawn === 'function' && lqSpawnState.get(n) !== 'bad');
}

// Resolves to the command's stdout (lines joined by \n), or null when spawn
// could not start it at all (so nothing ran and another path is safe to use).
function lqSpawnOnHost(name, host, cmd, timeoutMs) {
    return new Promise(resolve => {
        const cbName = `__lqs${++lqExecSeq}`;
        const out = [];
        let started = false, done = false, timer = 0;
        const finish = v => {
            if (done) return;
            done = true;
            clearTimeout(timer);
            // keep a harmless stub for a moment so late events don't hit a missing name
            window[cbName] = { stdout: { emit() {} }, stderr: { emit() {} }, emit() {} };
            setTimeout(() => { try { delete window[cbName]; } catch (_) {} }, 5000);
            resolve(v);
        };
        window[cbName] = {
            stdout: { emit(ev, data) { started = true; if (ev === 'data') out.push(String(data)); } },
            stderr: { emit() { started = true; } },
            emit(ev) {
                if (ev === 'exit') finish(out.join('\n'));
                else if (ev === 'error') finish(started ? out.join('\n') : null);
            }
        };
        timer = setTimeout(() => finish(out.join('\n')), timeoutMs);
        try {
            host.spawn(cmd, '[]', '{}', cbName);
        } catch (_) {
            finish(null);
        }
    });
}

// One quick harmless command decides whether this manager's spawn really
// reports back. If it never answers, spawn is not used and the old path stays.
function lqProbeSpawn(name, host) {
    let s = lqSpawnState.get(name);
    if (s) return typeof s === 'string' ? Promise.resolve(s) : s;
    s = lqSpawnOnHost(name, host, 'echo __LQ_SPAWN_OK__', 4000).then(out => {
        const ok = typeof out === 'string' && out.includes('__LQ_SPAWN_OK__');
        lqSpawnState.set(name, ok ? 'ok' : 'bad');
        return ok ? 'ok' : 'bad';
    });
    lqSpawnState.set(name, s);
    return s;
}

async function lqRunOnHosts(cmd, timeoutMs) {
    const wrapped = `(\n${cmd}\n) </dev/null`;   // nothing can sit waiting on stdin (only for this command)
    for (const [name, host] of lqHosts()) {
        if (typeof host.spawn === 'function' && lqSpawnState.get(name) !== 'bad') {
            if (await lqProbeSpawn(name, host) === 'ok') {
                const out = await lqSpawnOnHost(name, host, wrapped, timeoutMs);
                if (out !== null) return out;
            }
        }
        const out = await lqCallHost(name, host, wrapped, timeoutMs);
        if (out !== null) return out;
    }
    // last resort: a bare global exec() some hosts expose
    try {
        if (typeof window.exec === 'function' && window.exec !== exec) {
            const r = await window.exec(cmd);
            return r?.stdout ?? (typeof r === 'string' ? r : '');
        }
    } catch (_) {}
    return '';
}

// Simple reads (getprop / uname / cat) can't change anything, so they don't
// have to wait in line behind a running apply.
function lqIsPlainRead(cmd) {
    const s = String(cmd).replace(/2>\s*\/dev\/null/g, '').replace(/2>&1/g, '');
    return /^\s*(getprop|uname|cat)\b/.test(s) && !/[;&|`$(]|>|<</.test(s.replace(/\|\|/g, ''));
}

// how many change-commands are running or waiting right now
let lqExecPending = 0;
const LQ_QUEUE_RELEASE_MS = 45000;   // the next command goes after this, even if one is stuck

// ── Detached runs ─────────────────────────────────────────────
// Some managers keep the WebView busy for as long as a command is running,
// even through the callback form. A tweak apply can take seconds, so the whole
// UI (cards, nav) froze until it finished. So a change-command is not run
// "inside" the bridge call at all: the bridge only launches it in the
// background (that call returns right away, nothing is waiting on a pipe), and
// the result is then picked up with tiny quick reads between which the UI is
// completely free.
//   launch:  runs the command in a detached subshell, stdout -> <id>.out,
//            marker files <id>.start (began) and <id>.done (finished + exit code)
//   poll:    prints the output once <id>.done exists
// Same command, same stdout as before; it just never holds the bridge open.
const LQ_RUN_DIR = '/data/local/tmp/liqinghe/.run';
let lqRunSeq = 0;

function lqSq(s) { return "'" + String(s).replace(/'/g, "'\\''") + "'"; }

async function lqRunDetached(cmd, timeoutMs) {
    const id = Date.now().toString(36) + (++lqRunSeq).toString(36) + Math.random().toString(36).slice(2, 5);
    const base = `${LQ_RUN_DIR}/${id}`;
    const q = lqSq(base);
    const launch =
        `umask 000; mkdir -p ${lqSq(LQ_RUN_DIR)} 2>/dev/null; chmod 777 ${lqSq(LQ_RUN_DIR)} 2>/dev/null; ` +
        `( for fd in 3 4 5 6 7 8 9; do eval "exec $fd>&-" 2>/dev/null; done; : >${q}.start; ( \n${cmd}\n) >${q}.out 2>/dev/null </dev/null; echo $? >${q}.tmp; mv ${q}.tmp ${q}.done ) ` +
        `>/dev/null 2>&1 </dev/null &`;
    const poll =
        `b=${q}; if [ -f "$b.done" ]; then cat "$b.out" 2>/dev/null; echo; echo "__LQRUN_DONE__$(cat "$b.done")"; ` +
        `rm -f "$b.out" "$b.done" "$b.start"; elif [ -f "$b.start" ]; then echo __LQRUN_BUSY__; else echo __LQRUN_NOSTART__; fi`;

    const launched = await lqRunOnHosts(launch, 15000);
    const t0 = performance.now();
    let delay = 120, waitedStart = 0;
    for (;;) {
        await new Promise(r => setTimeout(r, delay));
        if (performance.now() - t0 > timeoutMs) return '';
        const res = String(await lqRunOnHosts(poll, 15000));
        const m = res.lastIndexOf('__LQRUN_DONE__');
        if (m >= 0) {
            let out = res.slice(0, m);
            if (out.endsWith('\n')) out = out.slice(0, -1);   // the echo added by the poll
            return out;
        }
        if (res.includes('__LQRUN_NOSTART__')) {
            // The launch never began (nothing ran), so running it the plain way
            // is safe and cannot double-apply anything.
            waitedStart += delay;
            if (waitedStart > 1500) return lqRunOnHosts(cmd, timeoutMs);
        }
        delay = Math.min(delay * 1.6, 700);
    }
}

// waits for the one-time spawn probe so the choice above is made on facts
async function lqSpawnReady() {
    for (const [name, host] of lqHosts()) {
        if (typeof host.spawn === 'function') await lqProbeSpawn(name, host);
    }
}

// ── Tweak controls stay locked until the backend has answered ──
// Nothing in them is a fact before check-state has been answered, only a default,
// so they stay dimmed and untouchable (see lqSetStateReady further down).
document.documentElement.classList.add('lq-sync-pending');

// The notice above the tweak controls, shown only while the status is not read yet.
function lqUpdateSyncNotice() {
    document.querySelectorAll('.lq-rt-notice').forEach(n => {
        n.textContent = lqTweakStateReady ? '' : 'Reading status from the service. Tweak controls unlock once the backend has answered...';
    });
}

function exec(cmd) {
    if (lqIsPlainRead(cmd)) return lqRunOnHosts(cmd, 15000);
    lqExecPending++;
    let release;
    const myTurn = new Promise(r => { release = r; });
    const prev = lqExecChain;
    lqExecChain = myTurn;                      // whoever comes next waits for my turn to end
    return prev.then(async () => {
        const timer = setTimeout(release, LQ_QUEUE_RELEASE_MS);
        try {
            // With spawn the manager already runs it in the background; the
            // detached launch + polling is only for managers without it.
            await lqSpawnReady();
            return lqHasSpawn() ? await lqRunOnHosts(cmd, LQ_EXEC_TIMEOUT_MS)
                                : await lqRunDetached(cmd, LQ_EXEC_TIMEOUT_MS);
        } finally {
            clearTimeout(timer);
            release();
            lqExecPending--;
        }
    });
}

// Kept for the polling code: same non-blocking path, plain reads only.
function execBg(cmd) {
    return lqRunOnHosts(cmd, 15000);
}

// ── Polling hygiene ───────────────────────────────────────────
// Polls wait for animations to finish, and the dashboard numbers are only
// refreshed while the dashboard is actually on screen. Whatever was last
// shown simply stays on screen in the meantime, nothing is cleared.
let lqMotionUntil = 0;
const lqDeferred = new Map();
const lqPolled = { cpu: false, temp: false, sys: false };

function lqMarkMotion(ms = 900) {
    lqMotionUntil = Math.max(lqMotionUntil, performance.now() + ms);
}

function lqInMotion() {
    if (performance.now() < lqMotionUntil) return true;
    if (typeof navBusy !== 'undefined' && navBusy) return true;
    const pill = document.getElementById('navPill');
    return !!(pill && (pill.classList.contains('holding') || pill.classList.contains('lens-hold')));
}

// Runs fn now, or just after the current motion ends. Never postpones for
// longer than ~2.5s, so a long press on the bar can't starve the numbers.
// Polling ticks never pile up: a tick is skipped while the previous one of the
// same kind is still waiting for its answer, and while a change (toggle apply)
// is running, so they don't compete with it for the root shell.
const lqPollBusy = new Set();
function lqRunPoll(key, fn) {
    if (lqPollBusy.has(key) || lqExecPending > 0) return;
    lqPollBusy.add(key);
    let r;
    try { r = fn(); } catch (e) { lqPollBusy.delete(key); throw e; }
    Promise.resolve(r).then(() => lqPollBusy.delete(key), () => lqPollBusy.delete(key));
    return r;
}

function lqWhenCalm(key, fn) {
    if (!lqInMotion()) return lqRunPoll(key, fn);
    if (lqDeferred.has(key)) return;
    const since = performance.now();
    const wait = () => {
        if (lqInMotion() && performance.now() - since < 2500) {
            lqDeferred.set(key, setTimeout(wait, 120));
            return;
        }
        lqDeferred.delete(key);
        lqRunPoll(key, fn);
    };
    lqDeferred.set(key, setTimeout(wait, 120));
}

// The live numbers (CPU / RAM / swap / storage / battery / temperature) belong to the
// System Monitor page now, so they are only polled while that page is open. On the
// Dashboard and every other page the ticks return at once and nothing is read.
function lqMonitorLive() {
    return !document.hidden && (typeof currentPage === 'undefined' || currentPage === 'monitor');
}
const lqDashboardLive = lqMonitorLive;   // the tick functions below still use the old name

// Refreshes the monitor numbers right now (page opened / app came back to the front).
function lqRefreshDashboard() {
    lqWhenCalm('cpu', tickCPU);
    lqWhenCalm('temp', tickTemp);
    lqWhenCalm('sys', tickSystemSlow);
}

function clip(t, max = 20) {
    if (!t) return '|';
    t = t.trim();
    return t.length > max ? t.slice(0, max) + '…' : t;
}

// ── CPU State ─────────────────────────────────────────────────
let maxCPU     = 0;
let minCPU     = 0;
let coreMaxes  = [];
let coresReady = false;
let coreCount  = 0;

function formatFreq(khz) {
    const v = Number(khz) || 0;
    if (v <= 0) return '|';
    if (v >= 1000000) return (v / 1000000).toFixed(2).replace(/\.00$/, '') + ' GHz';
    if (v >= 1000) return Math.round(v / 1000) + ' MHz';
    return v + ' kHz';
}

function initCores(n) {
    coreCount = n;
    set('graphCoreCount', String(n));

    coresReady = true;
}

// ── Dashboard tiles: Idle Profile + Environment ───────────────
// Idle Profile follows tweakState.idle_profile (loaded with the Tweaks state and
// repainted whenever it changes). Environment shows which manager is running the
// module and which privilege its shell has.
function lqDashProfilePaint() {
    // before the backend has answered, the profile is unknown: keep the placeholder
    if (!lqTweakStateReady) { set('dashIdleProfile', '|'); return; }
    const p = String(tweakState.idle_profile || 'normal');
    const name = p.split('-').filter(Boolean).map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    set('dashIdleProfile', name || 'Normal');
}

// ── Verification card (Home) + the developer lines (Settings) ────────────────────────
// Everything about who made the module comes from ONE place: `Liziya --identity` (the Liziya service reads module.prop as root and checks both
// the module id and the author). It prints identity=valid|invalid|unknown, reason=..., expected=..., id=..., expected_author=..., author=...
// and developer=<name>. Neither the html nor this file carries the id, the author tag or the developer name: they are shown from that output.
// Only a valid answer lights the card up; anything else (or no answer) leaves it dim with the reason.
const lqIdent = { state: '', reason: '', expected: '', id: '', expectedAuthor: '', author: '', developer: '' };
function lqIdentParse(raw) {
    const f = {};
    String(raw || '').split(/\r?\n/).forEach(l => { const i = l.indexOf('='); if (i > 0) f[l.slice(0, i).trim()] = l.slice(i + 1).trim(); });
    if (!/^(valid|invalid|unknown)$/.test(f.identity || '')) return null;
    return { state: f.identity, reason: f.reason || '', expected: f.expected || '', id: f.id || '', expectedAuthor: f.expected_author || '', author: f.author || '', developer: f.developer || '' };
}
// the developer name in Settings > About and the "by ..." line of the Home preview: both are filled from the service's answer
function lqIdentApply(o) {
    const dev = document.getElementById('lqAbDev');
    if (dev && o.developer) dev.textContent = o.developer;
    document.querySelectorAll('.sk-by').forEach(el => { el.textContent = o.expectedAuthor ? 'by ' + o.expectedAuthor : ''; });
}
function lqVerifyPaint(state, o) {
    const card = document.getElementById('lqVerify');
    if (!card) return;
    const ok = state === 'official';
    card.classList.toggle('is-official', ok);
    card.classList.toggle('is-checking', state === 'checking');
    const icon = document.getElementById('lqVerifyIcon');
    // one seal shape for every state, only what is cut out of it changes: check (official), cross (not official), exclamation (not verified), dots (checking)
    const SEAL = 'M23 12l-2.44-2.79.34-3.69-3.61-.82-1.89-3.2L12 2.96 8.6 1.5 6.71 4.69 3.1 5.5l.34 3.7L1 12l2.44 2.79-.34 3.7 3.61.82L8.6 22.5l3.4-1.47 3.4 1.46 1.89-3.19 3.61-.82-.34-3.69L23 12z';
    const GLYPH = {
        official: 'M10.09 16.72l-3.8-3.81 1.48-1.48 2.32 2.33 5.85-5.87 1.48 1.48-7.33 7.35z',
        other: 'M8.7 7.3 12 10.6l3.3-3.3 1.4 1.4L13.4 12l3.3 3.3-1.4 1.4L12 13.4l-3.3 3.3-1.4-1.4L10.6 12 7.3 8.7z',
        unread: 'M10.9 6.8h2.2v6.4h-2.2zM10.9 14.9h2.2v2.2h-2.2z',
        checking: 'M7.2 10.7a1.3 1.3 0 1 0 0 2.6 1.3 1.3 0 0 0 0-2.6zM12 10.7a1.3 1.3 0 1 0 0 2.6 1.3 1.3 0 0 0 0-2.6zM16.8 10.7a1.3 1.3 0 1 0 0 2.6 1.3 1.3 0 0 0 0-2.6z'
    };
    card.classList.toggle('is-other', state === 'other');
    card.classList.toggle('is-unread', state === 'unread');
    if (icon) icon.setAttribute('d', SEAL + GLYPH[GLYPH[state] ? state : 'checking']);
    const t = document.getElementById('lqVerifyTitle'), d = document.getElementById('lqVerifySub'), by = document.getElementById('lqVerifyBy');
    const x = o || lqIdent, q = v => String(v || '').slice(0, 40);
    let title = 'Verifying\u2026', sub = 'Checking the module', who = '';
    if (state === 'official') {
        title = 'Official made'; sub = 'Module ID and author match the official build.';
        who = x.developer ? 'Developer: ' + x.developer : '';
    } else if (state === 'other') {
        title = 'Not official made';
        if (x.reason === 'id-mismatch') sub = `Module ID \u201c${q(x.id)}\u201d is different from the official ${q(x.expected)}, so this is not the official build.`;
        else if (x.reason === 'author-mismatch') sub = x.author
            ? `Author \u201c${q(x.author)}\u201d is different from the official ${q(x.expectedAuthor)}, so this is not the official build.`
            : 'The author is missing from module.prop, so this is not the official build.';
        else sub = 'module.prop could not be read for the module ID and author, so this is not the official build.';
    } else if (state === 'unread') {
        title = 'Not verified'; sub = 'The Liziya service did not answer, so this can not be confirmed as the official build.';
    }
    if (t) t.textContent = title;
    if (d) d.textContent = sub;
    if (by) { by.textContent = who; by.hidden = !who; }      // the developer is named only on the official build
}
let lqVerifyRetry = 0, lqVerifyTries = 0;
async function lqVerifyLoad() {
    clearTimeout(lqVerifyRetry);
    lqVerifyPaint('checking');
    let raw = '';
    for (let t = 0; t < 3; t++) {
        try { raw = String(await execBg("if command -v Liziya >/dev/null 2>&1; then Liziya --identity 2>/dev/null; fi")); } catch (_) {}
        if (lqIdentParse(raw)) break;
        await new Promise(r => setTimeout(r, 500 + t * 500));
    }
    const o = lqIdentParse(raw);
    if (o) {
        Object.assign(lqIdent, o);
        lqIdentApply(o);
        lqVerifyPaint(o.state === 'valid' ? 'official' : o.state === 'invalid' ? 'other' : 'unread', o);
        if (o.state !== 'unknown') return;
    } else lqVerifyPaint('unread');
    // no answer (the bridge may not have been ready yet, or this Liziya build does not know --identity): try again in a while, a few times
    if (++lqVerifyTries < 6) lqVerifyRetry = setTimeout(lqVerifyLoad, 20000);
}

async function loadEnvironment() {
    // Axora (and AxManager) hand the WebUI a KernelSU-style `ksu` bridge, so the host
    // name alone can't tell them apart from real KernelSU. The real signals are the
    // shell's uid (KernelSU runs as root, Axora/AxManager as shell) and what is
    // actually running / installed.
    const hosts = lqHosts().map(([n]) => n);
    let uid = '', ps = '', pk = '';
    for (let t = 0; t < 6 && !uid; t++) {
        try { uid = String(await execBg('id -u 2>/dev/null')).trim().split(/\s+/).pop(); } catch (_) {}
        if (!uid) await new Promise(r => setTimeout(r, 400 + t * 400));
    }
    try { ps = String(await execBg("ps -A -o ARGS 2>/dev/null | grep -i -E 'axora|axeron|apatch|ksud' | grep -v grep")); } catch (_) {}
    try { pk = String(await execBg("pm list packages 2>/dev/null | grep -i -E 'axora|axeron|apatch'")); } catch (_) {}
    const has = (s, re) => re.test(s);
    let name = 'Unknown';
    if (hosts.includes('axora') || has(ps, /axora/i)) name = 'Axora';
    else if (has(ps, /axeron/i)) name = 'AxManager';
    else if (has(ps, /apatch/i)) name = 'APatch';
    else if (uid !== '0' && has(pk, /axora/i)) name = 'Axora';
    else if (uid !== '0' && has(pk, /axeron/i)) name = 'AxManager';
    else if (hosts.includes('axeron')) name = 'AxManager';
    else if (uid === '0') name = has(pk, /apatch/i) ? 'APatch' : 'KernelSU';
    else if (hosts.length) name = 'Shell manager';
    const priv = uid === '0' ? 'Root' : uid === '2000' ? 'Shell' : (uid ? 'UID ' + uid : '');
    set('dashEnvSub', priv ? name + ' · ' + priv : name);
}

// ── Device info ───────────────────────────────────────────────
async function loadDeviceInfo() {
    // The static props are read through execBg (the direct read path), not exec().
    // exec() puts a compound command (for-loop, ;, $()) in the change-queue behind
    // whatever boot work is still running, and a stalled run returned '' there, so
    // every tile fell back to N/A. Reads can't change anything, so they don't queue.
    // The display size needs `wm`, which boots a Java process, so that one is read a
    // little later and never holds the start up back.
    const PROPS = 'ro.product.manufacturer ro.product.brand ro.product.model ro.product.marketname ro.product.vendor.marketname ' +
        'ro.build.version.release ro.build.version.sdk ro.build.version.security_patch ro.build.display.id ro.product.cpu.abi ' +
        'ro.board.platform ro.soc.manufacturer ro.soc.model ro.build.fingerprint';
    const CMD = 'for k in ' + PROPS + '; do printf "%s=%s\\n" "$k" "$(getprop $k)"; done; ' +
        'printf "kernel=%s\\n" "$(uname -r)"; ' +
        'printf "selinux=%s\\n" "$(getenforce 2>/dev/null || cat /sys/fs/selinux/enforce 2>/dev/null)"';
    const parse = raw => {
        const o = {};
        String(raw || '').split(/\r?\n/).forEach(l => { const i = l.indexOf('='); if (i > 0) o[l.slice(0, i).trim()] = l.slice(i + 1).trim(); });
        return o;
    };
    // The bridge can still be warming up at boot, so an empty answer is retried a few
    // times before anything is shown as N/A.
    let m = {};
    for (let tries = 0; tries < 6; tries++) {
        try { m = parse(await execBg(CMD)); } catch (_) { m = {}; }
        if (m['ro.build.version.release'] || m['ro.product.model'] || m['ro.product.brand'] || m.kernel) break;
        await new Promise(r => setTimeout(r, 500 + tries * 400));
    }
    // fallback: if the loop still gave nothing, read the whole prop table once
    if (!m['ro.product.model'] && !m['ro.build.version.release']) {
        try {
            const dump = String(await execBg('getprop'));
            dump.split(/\r?\n/).forEach(l => { const x = l.match(/^\[([^\]]+)\]:\s*\[(.*)\]\s*$/); if (x) m[x[1]] = x[2]; });
            m.kernel = m.kernel || String(await execBg('uname -r')).trim();
        } catch (_) {}
    }
    // SELinux: tried one command at a time, because on some managers the bundled
    // getenforce is missing from PATH or the shell can't read selinuxfs. The first
    // one that answers wins; the boot props are the last resort.
    if (!/^(enforcing|permissive|disabled|[01])$/i.test(m.selinux || '')) {
        m.selinux = '';
        const tries = [
            'getenforce', '/system/bin/getenforce', 'toybox getenforce',
            'cat /sys/fs/selinux/enforce', 'cat /sys/fs/selinux/enforce',
            'getprop ro.boot.selinux', 'getprop ro.boot.selinux.mode'
        ];
        for (const c of tries) {
            try {
                const v = String(await execBg(c + ' 2>/dev/null')).trim().split(/\r?\n/).pop().trim();
                if (/^(enforcing|permissive|disabled|[01])$/i.test(v)) { m.selinux = v; break; }
            } catch (_) {}
        }
    }
    if (m.selinux === '1') m.selinux = 'Enforcing';
    else if (m.selinux === '0') m.selinux = 'Permissive';
    else if (m.selinux) m.selinux = m.selinux.charAt(0).toUpperCase() + m.selinux.slice(1).toLowerCase();
    const cap = s => String(s || '').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
    const na = v => (v && String(v).trim()) ? String(v).trim() : 'N/A';

    const brand = m['ro.product.brand'] || m['ro.product.manufacturer'] || '';
    const model = m['ro.product.marketname'] || m['ro.product.vendor.marketname'] || m['ro.product.model'] || '';
    const name = model && brand && model.toLowerCase().indexOf(brand.toLowerCase()) !== 0 ? cap(brand) + ' ' + model : model || cap(brand);
    set('deviceModel', na(name));
    set('devAndroid', m['ro.build.version.release'] ? m['ro.build.version.release'] + (m['ro.build.version.sdk'] ? ' (API ' + m['ro.build.version.sdk'] + ')' : '') : 'N/A');
    set('kernelInfo', na(m.kernel));
    set('devPatch', na(m['ro.build.version.security_patch']));
    const soc = m['ro.soc.model'] ? [m['ro.soc.manufacturer'], m['ro.soc.model']].filter(Boolean).join(' ') : m['ro.board.platform'];
    set('devChipset', na(soc));
    set('devMaker', na(cap(m['ro.product.manufacturer'])));
    set('devArch', na(m['ro.product.cpu.abi']));
    set('devSelinux', na(m.selinux));
    set('devBuild', na(m['ro.build.display.id']));
    set('devFingerprint', na(m['ro.build.fingerprint']));
    set('devDisplay', '|');

    setTimeout(async () => {
        try {
            const w = await execBg('wm size 2>/dev/null | tail -n 1; wm density 2>/dev/null | tail -n 1');
            const sz = String(w).match(/(\d+)\s*x\s*(\d+)/);
            const dn = String(w).match(/density:\s*(\d+)/i);
            set('devDisplay', sz ? sz[1] + ' × ' + sz[2] + (dn ? ' · ' + dn[1] + ' dpi' : '') : 'N/A');
        } catch (e) { set('devDisplay', 'N/A'); }
    }, 1800);
}

// Device Info: the chevron opens / closes the extra tiles.
function initDeviceToggle() {
    const btn = document.getElementById('devToggle');
    const more = document.getElementById('devMore');
    if (!btn || !more) return;
    btn.addEventListener('click', () => {
        const open = !more.classList.contains('open');
        more.classList.toggle('open', open);
        btn.classList.toggle('open', open);
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
}

// ── Live stats ────────────────────────────────────────────────
let busyCPU = false;
let busySYS = false;
let totalMem = 0, totalSwap = 0;

async function tickCPU() {
    if (busyCPU) return;
    if (lqPolled.cpu && !lqDashboardLive()) return;
    busyCPU = true;
    try {
        const [curRaw, maxRaw, minRaw] = await Promise.all([
            execBg('cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq 2>/dev/null'),
            coresReady ? '' : execBg('cat /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_max_freq 2>/dev/null'),
            coresReady ? '' : execBg('cat /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_min_freq 2>/dev/null'),
        ]);

        const curFreqs = curRaw.trim() ? curRaw.trim().split('\n').map(Number).filter(v => v > 0) : [];
        const hasCpu = curFreqs.length > 0;

        if (!hasCpu) {
            set('graphCurrent', '|');
            set('graphCoreCount', '|');
            set('cpuUsageTotal', '|%');
            return;
        }

        if (hasCpu && !coresReady) {
            coreMaxes = maxRaw.trim() ? maxRaw.trim().split('\n').map(Number).filter(v => v > 0) : [];
            const mins = minRaw.trim() ? minRaw.trim().split('\n').map(Number).filter(v => v > 0) : [];

            maxCPU = coreMaxes.length ? Math.max(...coreMaxes) : Math.max(...curFreqs);
            minCPU = mins.length ? Math.min(...mins) : Math.max(1, Math.round(maxCPU * 0.2));
            initCores(curFreqs.length);
        }

        const avgKHz = curFreqs.reduce((a, b) => a + b, 0) / curFreqs.length;
        set('graphCurrent', formatFreq(avgKHz));
        set('graphCoreCount', String(curFreqs.length || coreCount || '|'));

        let totalPct = 0;
        curFreqs.forEach((f, i) => {
            const m = coreMaxes[i] || maxCPU || 1;
            const pct = Math.max(0, Math.round(f / m * 100));
            totalPct += pct;
        });

        const avgPct = Math.round(totalPct / curFreqs.length);
        set('cpuUsageTotal', avgPct + '%');
        bar('cpuBar', avgPct, 100);
        lqPolled.cpu = true;
    } catch (e) { console.error(e); }
    finally { busyCPU = false; }
}

let busyTEMP = false;

async function tickTemp() {
    if (busyTEMP) return;
    if (lqPolled.temp && !lqDashboardLive()) return;
    busyTEMP = true;
    try {
        const tr = await execBg('cat /sys/class/power_supply/battery/temp 2>/dev/null');
        if (tr && !isNaN(parseInt(tr))) {
            let v = parseInt(tr);
            if (v > 10000) v /= 1000;
            else if (v > 100) v /= 10;
            set('liveTemp', v.toFixed(1) + '°C');
            set('liveTempSub', ' · ' + (v < 35 ? 'Cool' : v < 40 ? 'Normal' : v < 45 ? 'Warm' : 'Hot'));
            bar('tempBar', v, 60);
            lqPolled.temp = true;
        }
    } catch (e) { console.error(e); }
    finally { busyTEMP = false; }
}

async function tickSystemSlow() {
    if (busySYS) return;
    if (lqPolled.sys && !lqDashboardLive()) return;
    busySYS = true;
    try {
        const mem = await execBg("cat /proc/meminfo 2>/dev/null || free -k 2>/dev/null || toybox free -k 2>/dev/null");
        let mt = mem.match(/MemTotal:\s+(\d+)/);
        let ma = mem.match(/MemAvailable:\s+(\d+)/);
        let st = mem.match(/SwapTotal:\s+(\d+)/);
        let sf = mem.match(/SwapFree:\s+(\d+)/);

        if (!mt) {
            const fm = mem.match(/^Mem:\s+(\d+)\s+(\d+)\s+(\d+)/m);
            if (fm) {
                mt = [fm[0], 'MemTotal: ' + fm[1]];
                ma = [fm[0], 'MemAvailable: ' + (parseInt(fm[1]) - parseInt(fm[2]))];
            }
        }
        if (!st) {
            const fs = mem.match(/^Swap:\s+(\d+)\s+(\d+)/m);
            if (fs) {
                st = [fs[0], 'SwapTotal: ' + fs[1]];
                sf = [fs[0], 'SwapFree: ' + (parseInt(fs[1]) - parseInt(fs[2]))];
            }
        }

        if (mt) totalMem = parseInt(mt[1], 10) / 1024 / 1024;
        if (st) totalSwap = parseInt(st[1], 10) / 1024 / 1024;
        const usedMem = mt && ma ? totalMem - parseInt(ma[1], 10) / 1024 / 1024 : null;
        const usedSwap = st && sf ? totalSwap - parseInt(sf[1], 10) / 1024 / 1024 : null;
        if (usedMem != null && isFinite(usedMem) && totalMem > 0) {
            const usedMB = Math.round(usedMem * 1024), totalMB = Math.round(totalMem * 1024);
            set('liveRam', usedMB + ' MB used');
            set('liveRamSub', 'of ' + totalMB + ' MB total · ' + Math.max(0, totalMB - usedMB) + ' MB free');
            set('ramPct', Math.round(usedMem / totalMem * 100) + '%');
            bar('ramBar', usedMem, totalMem);
        }
        if (usedSwap != null && isFinite(usedSwap) && totalSwap > 0) {
            const usedMB = Math.round(usedSwap * 1024), totalMB = Math.round(totalSwap * 1024);
            set('liveSwap', usedMB + ' MB used');
            set('liveSwapSub', 'of ' + totalMB + ' MB total · ' + Math.max(0, totalMB - usedMB) + ' MB free');
            set('swapPct', Math.round(usedSwap / totalSwap * 100) + '%');
            bar('swapBar', usedSwap, totalSwap);
        } else if (st && totalSwap === 0) {
            set('liveSwap', 'No swap');
            set('liveSwapSub', 'Swap is not enabled on this device');
            set('swapPct', '');
            bar('swapBar', 0, 1);
        }

        const df = await execBg("df -k /data 2>/dev/null || df -k / 2>/dev/null || df -k /data/local/tmp 2>/dev/null || toybox df -k /data 2>/dev/null || toybox df -k / 2>/dev/null");
        const lines = df.trim().split(/\n/).filter(Boolean);
        const row = lines.length ? lines[lines.length - 1] : '';
        const dp = row.trim().split(/\s+/);
        if (dp.length >= 4) {
            const nums = dp.slice(1).map(Number);
            const t = nums.find(v => isFinite(v) && v > 0);
            const u = nums.find((v, i) => i > 0 && isFinite(v) && v >= 0);
            if (t > 0 && isFinite(u)) {
                const used = u / 1024 / 1024;
                const total = t / 1024 / 1024;
                set('liveStorage', used.toFixed(0) + ' GB used');
                set('liveStorageSub', 'of ' + total.toFixed(0) + ' GB total · ' + Math.max(0, total - used).toFixed(0) + ' GB free');
                set('storagePct', Math.round(used / total * 100) + '%');
                bar('storageBar', used, total);
            }
        }

        const bat = await execBg("cat /sys/class/power_supply/battery/capacity 2>/dev/null || cat /sys/class/power_supply/BAT0/capacity 2>/dev/null || dumpsys battery 2>/dev/null | grep -m1 -E 'level:|level='; echo '::state'; cat /sys/class/power_supply/battery/status 2>/dev/null || dumpsys battery 2>/dev/null | grep -m1 -E 'status:'");
        const batParts = bat.split('::state');
        const levelHit = batParts[0].match(/(?:level:|level=)\s*(\d+)/);
        const capHit = batParts[0].match(/^\s*(\d{1,3})\s*$/m);
        const bm = levelHit || capHit;
        if (bm) {
            const level = Math.max(0, Math.min(100, parseInt(bm[1], 10)));
            set('liveBattery', level + '%');
            bar('batteryBar', level, 100);
            // sysfs gives a word, dumpsys a number (2 charging, 3 discharging, 4 not charging, 5 full)
            const stText = String(batParts[1] || '').trim();
            const stNum = stText.match(/status:\s*(\d)/);
            const stWord = stNum ? ({2:'Charging',3:'Discharging',4:'Not charging',5:'Full'})[stNum[1]] : stText.split(/\r?\n/)[0];
            if (stWord) set('liveBatterySub', ' · ' + stWord);
        }

        lqPolled.sys = true;
    } catch (e) { console.error(e); }
    finally { busySYS = false; }
}

// ── Conflict check / protected WebUI sections ─────────────────
let lqConflictActive = false;
const LQ_CONFLICT_PAGES = new Set(['packages','tweaks']);

function setConflictLock(active) {
    lqConflictActive = !!active;

    ['packages','tweaks'].forEach(pageId => {
        const page = document.getElementById(`page-${pageId}`);
        if (!page) return;
        // While sleeping, just hide the page's content outright -- no lock
        // card, no message, nothing rendered at all.
        page.classList.toggle('lq-conflict-locked', lqConflictActive);
        const nav = document.querySelector(`#navPill .nav-item[data-nav="${pageId}"]`);
        if (nav) {
            nav.classList.toggle('conflict-disabled', lqConflictActive);
            nav.setAttribute('aria-disabled', lqConflictActive ? 'true' : 'false');
        }
    });
}

// ── Uptime pill ───────────────────────────────────────────────
// Device uptime like AZenith: "13h 3m 44s". Leading zero units are dropped and a
// day count is added once it passes 24h ("6d 16h 3m 44s").
function lqFormatUptime(sec) {
    sec = Math.max(0, Math.floor(sec));
    const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60), x = sec % 60;
    if (d > 0) return `${d}d ${h}h ${m}m ${x}s`;
    if (h > 0) return `${h}h ${m}m ${x}s`;
    if (m > 0) return `${m}m ${x}s`;
    return `${x}s`;
}
// The device is read now and then; in between the label is carried forward from
// the wall clock, so it costs nothing and still keeps counting after a sleep.
const lqUptime = { base: null, at: 0, busy: false };
function lqPaintUptime() {
    const el = document.getElementById('uptimeLabel');
    if (!el) return;
    el.textContent = (lqUptime.base == null ? '...' : lqFormatUptime(lqUptime.base + (Date.now() - lqUptime.at) / 1000));
}
async function lqUptimeRead() {
    if (lqUptime.busy) return;
    lqUptime.busy = true;
    try {
        const raw = await execBg('cat /proc/uptime 2>/dev/null');
        const v = parseFloat(String(raw || '').trim().split(/\s+/)[0]);
        if (isFinite(v) && v >= 0) { lqUptime.base = v; lqUptime.at = Date.now(); }
    } catch (_) {
    } finally {
        lqUptime.busy = false;
        lqPaintUptime();
    }
}

// True once the status pill has shown something the backend really said.
let lqStatusVerified = false;
// true / false from the `tamper=` line of `Liziya --status` (the Sleep comes from the id / author check); null while Liziya does not say (an older build)
let lqSleepTamper = null;

async function checkConflict() {
    if (document.hidden) return;
    const r = await execBg("if command -v Liziya >/dev/null 2>&1; then Liziya --status 2>/dev/null; else echo 'status=Unknown\\nlast_recovery=never'; fi");
    // An empty answer (bridge hiccup / timeout) is "no answer", not "Unknown":
    // keep whatever was last verified instead of overwriting it.
    if (!String(r || '').trim()) return false;
    const lines = String(r || '').trim().split(/\n+/);
    const statusLine = lines.find(line => line.startsWith('status=')) || 'status=Unknown';
    const lastLine = lines.find(line => line.startsWith('last_recovery=')) || 'last_recovery=never';
    const active = statusLine === 'status=Sleep';
    const isAlive = statusLine === 'status=Alive';
    const lastRecovery = lastLine.slice('last_recovery='.length);
    const tamperLine = lines.find(line => line.startsWith('tamper='));
    lqSleepTamper = tamperLine ? tamperLine === 'tamper=1' : null;
    const banner = document.getElementById('mainBanner');
    const lbl = document.getElementById('statusLabel');

    if (banner) banner.classList.toggle('sleeping', active);
    if (lbl) lbl.textContent = active ? 'Sleep' : (isAlive ? 'Alive' : 'Unknown');
    lqStatusVerified = true;
    const recoveryEl = document.getElementById('lastRecovery');
    if (recoveryEl) recoveryEl.textContent = lastRecovery === 'never' ? 'Never' : lastRecovery;

    setConflictLock(active);
    const lqValid = String(r || '').trim().length > 0;

    // If sleep kicks in while the user is still sitting on a protected page
    // (packages/tweaks), hide its content immediately and boot them straight
    // back to the dashboard -- no lock screen, no lingering content.
    if (active && LQ_CONFLICT_PAGES.has(currentPage) && !navBusy) {
        switchPage('dashboard', { conflictRedirect: true });
    }
    return lqValid;
}

// ── Status popup (Home banner chip) ───────────────────────────────────────────────────
// Tapping the Alive / Sleep chip says which one it is and what that means, and offers two buttons: Check status (what `Liziya --status` says,
// that is, why) and Recovery (`Liziya --recovery`). A sleep that comes from the anti-tamper check (identity=invalid: module.prop is not the
// official one) can not be recovered, so there the Recovery button is not offered at all. Liziya refuses --recovery unless a property conflict is
// active, so the button is only offered then; with an older Liziya that has no tamper= line, identity=invalid stands in for it.
let lqStatusPopBusy = false;
async function lqStatusPopup(srcEl) {
    const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const lbl = document.getElementById('statusLabel');
    const state = () => (lbl && lbl.textContent) || 'Unknown';
    const tamper = () => state() === 'Sleep' && (lqSleepTamper !== null ? lqSleepTamper : lqIdent.state === 'invalid');
    const why = () => lqIdent.reason === 'id-mismatch' ? 'the module ID was changed'
        : lqIdent.reason === 'author-mismatch' ? 'the author was changed' : 'module.prop could not be verified';
    let pop = lqGameScanPopup(srcEl), gone = false;
    let fin; const closed = new Promise(r => { fin = r; });
    const close = () => { gone = true; return pop.close().then(fin); };          // every way out goes through here, so the chip can be tapped again
    // Check status and Back do not grow or shrink this card: the old popup leaves and a NEW one pops in, already the right size
    const swap = () => { const old = pop; pop = lqGameScanPopup(srcEl, { swap: true }); pop.scrim(close); old.close({ swap: true }); };
    const wide = 'grid-template-columns:1fr;margin-top:18px';
    const main = () => {
        const st = state(), t = tamper();
        const text = st === 'Alive' ? 'Liziya is awake and watching the properties this module sets. Nothing else has changed them, so the tweaks work normally.'
            : t ? `The anti-tamper protection put the module to sleep because this is not the official build (${why()}). It can not be recovered from here.`
            : st === 'Sleep' ? 'Something else changed a property this module controls, so the module went to sleep instead of fighting it. Apps and Tweaks are locked until it is recovered.'
            : 'Liziya has not answered yet. Check status asks it again.';
        pop.show(`<div class="pkg-title">${esc(st)}</div><div class="pkg-sub">${esc(text)}</div><div class="lq-gs-note" hidden></div>`
            + (st !== 'Sleep' || t ? `<div class="lq-rec-modal-actions" style="${wide}"><button class="lq-rec-modal-btn is-apply" data-a="check" style="border-radius:var(--split-out)" type="button">Check status</button></div>`
                 : `<div class="lq-rec-modal-actions" style="margin-top:18px"><button class="lq-rec-modal-btn is-skip" data-a="check" type="button">Check status</button><button class="lq-rec-modal-btn is-apply" data-a="recover" type="button">Recovery</button></div>`));
        const note = pop.el.querySelector('.lq-gs-note');
        pop.el.querySelector('[data-a="check"]').addEventListener('click', details);
        const rec = pop.el.querySelector('[data-a="recover"]');
        if (rec) rec.addEventListener('click', async () => {
            const bs = pop.el.querySelectorAll('.lq-rec-modal-btn');
            bs.forEach(b => { b.disabled = true; });
            rec.textContent = 'Recovering…';
            let out = '';
            try { out = String(await exec("if command -v Liziya >/dev/null 2>&1; then Liziya --recovery 2>&1; else echo 'error=no-liziya'; fi") || ''); } catch (_) {}
            try { await checkConflict(); } catch (_) {}
            if (/success/.test(out) || state() === 'Alive') {
                await close();
                try { lqToastShow({ title: 'Recovery', text: 'Back to Alive', state: 'ok' }); } catch (_) {}
                return;
            }
            bs.forEach(b => { b.disabled = false; });
            rec.textContent = 'Recovery';
            note.hidden = false; note.className = 'lq-gs-note is-err';
            note.textContent = 'Recovery failed: the property is still different, or something keeps changing it. Check status shows which.';
        });
    };
    const details = async () => {
        // keep this popup as it is while Liziya answers (the buttons only show it is busy), so nothing resizes
        pop.el.querySelectorAll('.lq-rec-modal-btn').forEach(b => { b.disabled = true; });
        const chk = pop.el.querySelector('[data-a="check"]');
        if (chk) chk.textContent = 'Checking…';
        let raw = '';
        try { raw = String(await execBg("if command -v Liziya >/dev/null 2>&1; then Liziya --status 2>/dev/null; fi") || '').trim(); } catch (_) {}
        const rows = [];
        raw.split(/\r?\n/).forEach(l => {
            const i = l.indexOf('=');
            if (i < 1) return;
            const k = l.slice(0, i), v = l.slice(i + 1);
            if (/^conflict_\d+$/.test(k)) {
                const f = v.split('\t');
                const ex = (f.find(x => x.startsWith('expected=')) || '').slice(9), ac = (f.find(x => x.startsWith('actual=')) || '').slice(7);
                rows.push([f[0], `expected ${ex || '-'} · actual ${ac || '-'}`]);
            } else if (k !== 'tamper') rows.push([k, v]);
        });
        if (tamper()) rows.push(['anti-tamper', why()]);
        if (gone) return;
        const list = rows.length ? rows.map(r => `<div class="lq-rec-modal-row"><b>${esc(r[0])}</b><span>${esc(r[1])}</span></div>`).join('') : '<div class="lq-rec-modal-row"><b>No answer from Liziya</b></div>';
        swap();
        pop.show(`<div class="pkg-title">Status</div><div class="lq-rec-modal-list is-stacked">${list}</div><div class="lq-rec-modal-actions" style="${wide}"><button class="lq-rec-modal-btn is-apply" style="border-radius:var(--split-out)" type="button">Back</button></div>`);
        pop.el.querySelector('.is-apply').addEventListener('click', () => { swap(); main(); });
    };
    main();
    pop.scrim(close);
    await closed;
}
document.addEventListener('click', e => {
    if (!e.target.closest('#bannerStatus') || lqStatusPopBusy) return;
    lqStatusPopBusy = true;
    lqStatusPopup(e.target.closest('#bannerStatus')).catch(() => {}).finally(() => { lqStatusPopBusy = false; });
});

// ── Helpers ───────────────────────────────────────────────────
function set(id, val) {
    const el = document.getElementById(id);
    if (!el) return;
    const s = String(val);
    if (el.textContent !== s) el.textContent = s;
}
function bar(id, val, max) {
    const el = document.getElementById(id);
    if (!el || val==null || !max) return;
    const w = Math.min(100, Math.max(0, val/max*100)).toFixed(1)+'%';
    if (el.style.width !== w) el.style.width = w;
}

// ── Splash ────────────────────────────────────────────────────
// Boot work (device info, first stats, package scan, tweak state, ...) all
// runs while the splash is on screen. Anything registered here must finish
// before the splash is allowed to leave, so it never ends early.
const lqBootTasks = [];
let lqBootOpen = true;
// how much of the boot work has really finished: the splash fill follows this, not a timer
let lqBootTotal = 0, lqBootDoneN = 0;
function lqBootTrack(p) {
    if (lqBootOpen && p && typeof p.then === 'function') {
        lqBootTotal++;
        const fin = () => { lqBootDoneN++; };
        lqBootTasks.push(Promise.resolve(p).then(fin, fin));
    }
    return p;
}

// The home page is built while the liquid is still rising: it is switched on (and painted, tiles rastered, fonts laid out) right here, under the splash,
// instead of when the splash is ready to leave. Then, at the end, there is nothing left to build and nothing to wait for.
let lqPrebuilt = false;
function lqSplashPrebuild() {
    if (lqPrebuilt) return;
    const ar = document.getElementById('appRoot');
    if (!ar || !document.getElementById('splashScreen')) return;
    lqPrebuilt = true;
    ar.style.transition = 'none';
    try { lqSplashShowStill(); } catch (_) {}
    ar.classList.add('visible');
}

function runSplash(ms) {
    lqSplashFillStart();
    const wait = t => new Promise(r => setTimeout(r, t));
    const bootSettled = async () => {
        let seen = -1;
        while (seen !== lqBootTasks.length) {          // pick up tasks added late too
            seen = lqBootTasks.length;
            await Promise.all(lqBootTasks);
        }
    };

    function done() {
        lqResetDashboard();
        lqResetPkgRows();
        lqResetTweaks();
        lqResetSettings();

        const sp = document.getElementById('splashScreen');
        const ar = document.getElementById('appRoot');

        // The whole exit (the photo flying, the hole opening) is a busy stretch: the status polls (service check, CPU, ...) wait for it to end
        // instead of landing in the middle of it
        lqMarkMotion(700 + LQ_FLY_MS + LQ_SPLASH_OPEN_MS + 300);
        // The page is switched on now, while the splash still covers everything, and without the fade: the hole is what reveals it, so a fade only
        // added a full-screen opacity pass on top of the opening.
        ar.style.transition = 'none';
        lqSplashShowStill();           // the cards of the page that is open are simply there (no stagger): the hole only uncovers a finished page
        ar.classList.add('visible');

        const fx = document.getElementById('splashFx');
        (async () => {
            // The page was already painted under the splash (lqSplashPrebuild), so this is only a short check that the frames are steady
            // before the photo takes off.
            await lqSplashCalm(700, 5);
            const pos = lqSplashFly(sp);
            await wait(LQ_FLY_MS);
            // The photo flies (that runs on the compositor and stays smooth). Only then, once the frames are steady again, does the hole open.
            await lqSplashCalm();
            lqMarkMotion(LQ_SPLASH_OPEN_MS + 300);
            lqHeaderIntro(true);                                  // the header shows as the hole opens, once the photo has landed
            if (pos) lqSplashOpen(sp, pos.tx, pos.ty);

            setTimeout(()=>{ sp.remove(); if (fx) fx.remove(); }, LQ_SPLASH_OPEN_MS + 120);

            // The first realtime refresh and the dashboard stagger both land right here. Hold the pill back until the splash has finished
            // opening (its glass is the heaviest thing on the screen) and frames are steady again, so its spring entrance doesn't stutter
            // against that burst.
            setTimeout(lqRevealNavPill, LQ_SPLASH_OPEN_MS);
            setTimeout(lqNavShow, LQ_SPLASH_OPEN_MS + 3000);
        })();
    }

    // at least `ms` on screen, and not before the boot work is done (45s cap)
    Promise.race([Promise.all([wait(ms), bootSettled()]), wait(45000)])
        .then(lqSplashFillEnd)
        .then(() => { lqBootOpen = false; done(); });
}

// The splash: the profile photo fills in from the bottom like a liquid with a wave on top while the app boots (lqSplashFillStart, following the boot work that has
// really finished; lqSplashFillEnd, the rest of the way once everything is ready). Then the photo flies to its place in the top bar (lqSplashFly) and,
// once it has landed, the splash is masked away by a hole that grows from there (lqSplashOpen), so there is no fade.
const LQ_FLY_MS = 800;
const LQ_SPLASH_OPEN_MS = 1400;
// The fill level follows the boot work that has really finished (lqBootDoneN of lqBootTotal). The photo is filled up to LQ_FILL_RUN while the work
// runs, and lqSplashFillEnd takes the last stretch (clearing the wave crest) once everything is ready. The shown level only ever moves up and
// glides towards the real one, so a step that finishes in one go does not make it jump.
const LQ_FILL_RUN = .9, LQ_FILL_FULL = 1.1;
let lqSplashFillRaf = 0, lqSplashLvl = 0, lqSplashCvAnim = [];
// The two liquid covers (see .sp-cv in the CSS) are moved with WAAPI transforms, so the level keeps gliding on the compositor even while the main
// thread is busy booting. The main thread only says "go to this level" when a boot step finishes.
function lqSplashCvGo(level, ms, easing) {
    const win = document.getElementById('splashWin'), prof = document.querySelector('.splash-prof');
    if (!win || !prof) return null;
    const pw = prof.offsetWidth || 150, covers = win.querySelectorAll('.sp-cv'), offs = [0, -9];
    let main = null;
    covers.forEach((el, i) => {
        if (!el.animate) return;
        let from = NaN;
        try { from = new DOMMatrix(getComputedStyle(el).transform).m42; } catch (_) {}
        if (!isFinite(from)) from = pw + (offs[i] || 0);
        const to = (1 - level) * pw + (offs[i] || 0);
        const an = el.animate([{ transform: `translateY(${from}px)` }, { transform: `translateY(${to}px)` }], { duration: ms, easing, fill: 'forwards' });
        // The old animation is NOT cancelled before the new one exists: a cancelled animation drops the element straight back to its base
        // transform (level 0) until the new one has started on the compositor, and under main-thread load that showed as the liquid falling
        // to the bottom and climbing again. The new animation simply sits on top of the old one; the old one is removed once the new one runs.
        const old = lqSplashCvAnim[i];
        lqSplashCvAnim[i] = an;
        if (old) an.ready.then(() => { try { old.cancel(); } catch (_) {} }, () => {});
        if (i === 0) main = an;
    });
    return main;
}
// The liquid does not follow the boot work any more: it rises on its own, smoothly, to LQ_FILL_RUN (one compositor animation, so nothing the main
// thread does can make it stutter or fall back), waits there until the boot work is done, and lqSplashFillEnd takes the last stretch.
const LQ_FILL_RISE_MS = 2200;
function lqSplashFillStart() {
    if (lqSplashFillRaf) return;               // already running (it is started early, before the heavy boot work)
    if (!document.getElementById('splashWin')) return;
    lqSplashFillRaf = 1;
    lqSplashLvl = LQ_FILL_RUN;
    lqSplashCvGo(LQ_FILL_RUN, LQ_FILL_RISE_MS, 'cubic-bezier(.3,.45,.35,1)');
}
function lqSplashFillEnd() {
    const prof = document.querySelector('.splash-prof'), cv = document.querySelector('#splashWin .sp-cv');
    let cur = LQ_FILL_RUN;
    try { cur = Math.max(0, Math.min(LQ_FILL_FULL, 1 - new DOMMatrix(getComputedStyle(cv).transform).m42 / ((prof && prof.offsetWidth) || 150))); } catch (_) {}
    const ms = Math.round(260 + 440 * (LQ_FILL_FULL - cur) / LQ_FILL_FULL);     // the closer it already is, the shorter the last stretch
    const a = lqSplashCvGo(LQ_FILL_FULL, ms, 'ease-in-out');
    if (!a) return Promise.resolve();
    return Promise.race([a.finished, new Promise(r => setTimeout(r, ms + 200))]).catch(() => {}).then(() => new Promise(r => setTimeout(r, 220)));
}
function lqSplashFly(sp) {
    const prof = document.querySelector('.splash-prof'), card = document.querySelector('.splash-card'), note = document.getElementById('splashNote');
    const me = document.querySelector('.brand-avatar');
    const t = me ? me.getBoundingClientRect() : { left: 18, top: 70, width: 36, height: 36 };
    const tx = t.left + t.width / 2, ty = t.top + t.height / 2;
    if (!prof || !prof.animate) {
        sp.style.display = 'none';
        const fx = document.getElementById('splashFx'); if (fx) fx.style.display = 'none';
        return;
    }
    // the whole profile (photo, gap and card) flies together; the card stops turning on the way and ends in the angle the top bar's card has
    const r = prof.getBoundingClientRect();
    const win = document.getElementById('splashWin');
    if (win) win.classList.add('is-still');       // the waves are out of sight now (the photo is full): they stop animating
    prof.animate([{ transform: 'none' }, { transform: `translate(${tx - (r.left + r.width / 2)}px,${ty - (r.top + r.height / 2)}px) scale(${t.width / r.width})` }],
        { duration: LQ_FLY_MS, easing: 'cubic-bezier(.2,.85,.3,1)', fill: 'forwards' });
    if (card) {
        const m = new DOMMatrix(getComputedStyle(card).transform);
        const cur = (Math.atan2(m.b, m.a) * 180 / Math.PI + 360) % 360;
        const end = 22.5 + 45 * Math.ceil((cur + 90 - 22.5) / 45);       // the shape repeats every 45 degrees
        card.style.animation = 'none';
        card.animate([{ transform: `rotate(${cur}deg)` }, { transform: `rotate(${end}deg)` }], { duration: LQ_FLY_MS, easing: 'cubic-bezier(.3,.1,.3,1)', fill: 'forwards' });
    }
    if (note) note.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 220, fill: 'forwards' });
    return { tx, ty };        // the splash is cut open from there once the photo has arrived and the frames are steady (see runSplash)
}
// Resolves once `need` frames in a row came at the screen's own pace (no long frame), or after maxMs at the latest. The pace is measured, so a
// 30, 60 or 120 Hz screen is judged against itself.
function lqSplashCalm(maxMs = 1200, need = 6) {
    return new Promise(res => {
        const begin = performance.now();
        let last = begin, calm = 0, base = 1e9;
        const step = now => {
            const dt = now - last; last = now;
            base = Math.min(base, dt);
            calm = dt <= Math.max(22, base * 1.6) ? calm + 1 : 0;
            if (calm >= need || now - begin > maxMs) res(); else requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
    });
}
// Boot step: every font is loaded and parsed (the big SF Pro file, the Qurova one, a custom font if one is set) and the banner is decoded now, under
// the splash. Otherwise they come in while the hole is opening: the text is laid out again with the new font and the banner is decoded
// in the middle of the animation, which is what a cold start (not a refresh) used to show as lag.
async function lqWarmAssets() {
    const fonts = (document.fonts ? Array.from(document.fonts) : []).map(f => f.load().catch(() => {}));
    let ext = '', bust = '';
    try { ext = localStorage.getItem(UI_BANNER_EXT_KEY) || ''; bust = localStorage.getItem(UI_BANNER_BUST_KEY) || ''; } catch (_) {}
    const img = new Image();
    img.src = bannerImageUrl(ext, bust);
    const work = Promise.all([...fonts, img.decode().catch(() => {})]);
    await Promise.race([work, new Promise(r => setTimeout(r, 3000))]);       // never holds the splash for long
    return true;
}
// The first page does not play its stagger when the splash opens: dozens of cards starting their move and fade while the hole is opening was the
// heaviest thing on screen. They are shown as they are, once, behind the splash, so the hole uncovers a page that is already standing still.
// (Changing page later still plays the stagger as before.)
function lqSplashShowStill() {
    let nodes = [];
    if (currentPage === 'dashboard') {
        nodes = lqNodesDashboard();
        const banner = document.querySelector('#page-dashboard .banner-hero');
        if (banner) nodes.push(banner);
        lqLiteTokens.dash++;
    } else if (currentPage === 'tweaks') {
        nodes = lqNodesTweaks();
        lqLiteTokens.tweaks++;
    } else if (currentPage === 'settings') {
        nodes = lqNodesSettings();
        lqLiteTokens.settings++;
    }
    nodes.forEach(el => {
        el.classList.remove('lq-stagger-prep', 'lq-lite-card', 'lq-lite-tweak', 'lq-lite-settings');
        el.style.animation = '';
        el.style.animationDelay = '';
        el.style.willChange = '';
    });
}
function lqSplashOpen(sp, x, y) {
    const R = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y)) + 8;
    sp.style.setProperty('--lq-x', x + 'px');
    sp.style.setProperty('--lq-y', y + 'px');
    sp.style.setProperty('--lq-r', '0px');
    void sp.offsetWidth;
    sp.style.transition = `--lq-r ${LQ_SPLASH_OPEN_MS}ms cubic-bezier(.4,0,.2,1)`;
    sp.style.setProperty('--lq-r', R + 'px');
}

// Shows the bar. With liquid glass on, the glass filter is the expensive part, so it does not run while the
// bar springs in: the bar rises as a plain solid bar (class nav-entering) with its normal spring. When the
// spring is over it stands still and morphs into glass (lqNavMorph): the fill thins out, the blur and the
// saturation rise and the bend of the rim grows, one continuous change instead of a swap.
// lqNavGlassMaps waits while the bar is entering and then runs once.
let lqNavMapPending = null;
let lqNavMorphP = 1;           // 0..1, how much of the glass is on (1 = all)
function lqNavShow() {
    const pill = document.getElementById('navPill');
    if (!pill || pill.classList.contains('nav-in')) return;
    if (document.documentElement.classList.contains('lq-nav-glass')) {
        lqNavMorphSet(0);
        pill.classList.add('nav-entering');
        let t = 0;
        const end = e => {
            if (e && e.target !== pill) return;
            pill.removeEventListener('animationend', end);
            clearTimeout(t);
            pill.classList.remove('nav-entering');       // the filter starts now, at p = 0: it looks the same as the solid bar
            if (lqNavMapPending) { const a = lqNavMapPending; lqNavMapPending = null; lqNavGlassMaps(...a); }
            lqNavMorph(pill);
        };
        pill.addEventListener('animationend', end);
        t = setTimeout(end, 1100);
    }
    pill.classList.add('nav-in');
}

// Picking another nav style plays the whole first-appearance again (the rise of that style, and with glass on
// the solid bar that morphs into glass), so a style change looks exactly like the bar showing up the first time.
function lqNavReplay() {
    const pill = document.getElementById('navPill');
    if (!pill || !pill.classList.contains('nav-in') || lqNavAwayOn) return;      // (while the bar is away there is nothing to replay)
    cancelAnimationFrame(lqNavBumpRaf);
    pill.classList.add('no-anim');                      // the new layout is already in place: no slide of the tabs
    pill.classList.remove('nav-in', 'nav-entering');
    void pill.offsetWidth;                              // back to the hidden start pose right now
    lqNavShow();
    lqNavBumpRaf = requestAnimationFrame(() => pill.classList.remove('no-anim'));
}
let lqNavBumpRaf = 0;

function lqNavMorphSet(p) {
    lqNavMorphP = p;
    lqGxK(['lqf-bar', 'lqf-lens'], p);
    const pill = document.getElementById('navPill');
    if (pill) {
        if (p >= 1) pill.style.removeProperty('--lq-nav-p');
        else pill.style.setProperty('--lq-nav-p', p.toFixed(3));
    }
}
let lqNavMorphTok = 0;
function lqNavMorph(pill, dur = 950, settle = 110, steps = 16) {
    const tok = ++lqNavMorphTok;            // a new morph (or a new resize) cancels the one that is running
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) { lqNavMorphSet(1); return; }
    const DUR = dur, SETTLE = settle;       // SETTLE: the first frame with the filter on can hitch, nothing moves yet so it is not seen
    let t0 = 0;
    const step = now => {
        if (tok !== lqNavMorphTok) return;
        if (!t0) t0 = now;
        const x = Math.min(1, (now - t0) / DUR);
        // smoothstep (eases in and out), in 16 steps: every step redoes the glass filter, so 16 redraws instead of ~57
        // keeps the same look and is much lighter
        const p = Math.round(x * x * (3 - 2 * x) * steps) / steps;
        if (p !== lqNavMorphP) lqNavMorphSet(p);
        if (x < 1) requestAnimationFrame(step); else lqNavMorphSet(1);
    };
    setTimeout(() => { if (tok === lqNavMorphTok) requestAnimationFrame(step); }, SETTLE);
}

function lqRevealNavPill() {
    const pill = document.getElementById('navPill');
    if (!pill || pill.classList.contains('nav-in')) return;
    const begin = performance.now();
    let last = begin, calm = 0;
    const step = now => {
        const dt = now - last;
        last = now;
        calm = dt <= 22 ? calm + 1 : 0;
        if (calm >= 8 || now - begin > 1800) {
            lqMarkMotion(1000);
            lqNavShow();
            return;
        }
        requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
}



// ── Li-Yao-style stagger flow v3: PREPARE -> REVEAL -> CLEAN ──
const lqLiteTokens = { dash:0, drawer:0, pkg:0, tweaks:0, settings:0, monitor:0 };


function lqDashboardGroups(){
    const page=document.getElementById('page-dashboard');
    if(!page) return [];

    // Every card on the dashboard, top to bottom, each with its own slot: the banner is
    // animated separately, the tiles inside a side-by-side row (Idle Profile / Environment,
    // Battery / Temperature) count one by one. Nothing is looked up by a fixed class, so a
    // card that is added or moved later joins the order on its own.
    const cards=[...page.querySelectorAll(':scope > .card, :scope > .sys-duo > .card')];
    return cards.map(el=>({ nodes:[el] }));
}

function lqNodesDashboard(){
    return lqDashboardGroups().flatMap(group=>group.nodes);
}

function lqNodesPkg(){
    return [...document.querySelectorAll('#pkgList .pkg-item')];
}

function lqCancelAnimation(nodes, className, tokenKey){
    lqLiteTokens[tokenKey]++;
    nodes.forEach(el=>{
        el.classList.remove(className);
        el.style.animation='none';
        el.style.animationDelay='';
        el.style.willChange='';
    });
}

function lqPrepare(nodes){
    nodes.forEach((el,i)=>{
        el.classList.add('lq-stagger-prep');
        el.style.animation='none';
        el.style.animationDelay='';
        el.style.willChange='transform,opacity';
    });
}

function lqRevealAndAnimate(nodes, animationName, className, baseDelay, step, maxStep, tokenKey){
    if(!nodes.length) return;
    const token=++lqLiteTokens[tokenKey];

    void document.body.offsetHeight;

    nodes.forEach((el,index)=>{
        el.classList.remove('lq-stagger-prep');
        const delay=baseDelay + Math.min(index,maxStep)*step;
        el.style.animation=`${animationName} ${(animationName==='lqPkgEnterLite' ? '.72s' : '.82s')} cubic-bezier(.16,1,.3,1) ${delay}ms both`;
        el.classList.add(className);

        const finish=()=>{
            if(token!==lqLiteTokens[tokenKey]) return;
            el.classList.remove(className);
            el.style.animation='';
            el.style.animationDelay='';
            el.style.willChange='';
        };
        const onEnd=(evt)=>{
            if(token!==lqLiteTokens[tokenKey] || evt.animationName!==animationName) return;
            el.removeEventListener('animationend',onEnd);
            finish();
        };
        el.addEventListener('animationend',onEnd);
        window.setTimeout(finish,delay+1100);
    });
}

function lqNodesTweaks(){
    const page=document.getElementById('page-tweaks');
    if(!page) return [];
    return [
        ...page.querySelectorAll('.section-label, .lq-tweak-card, .lq-system-tuning-card, .lq-acc-card, .lq-rec-card, .lq-disp-card')
    ].filter(Boolean);
}

// System Monitor page: its header and every card (the Battery / Temperature tiles count one by one)
function lqNodesMonitor(){
    const page=document.getElementById('page-monitor');
    if(!page) return [];
    return [...page.querySelectorAll(':scope > .card, :scope > .sys-duo > .card')];
}
function lqResetMonitor(){
    const nodes=lqNodesMonitor();
    lqCancelAnimation(nodes,'lq-lite-monitor','monitor');
    nodes.forEach(el=>{
        el.style.animation='none'; el.style.animationDelay=''; el.style.willChange='';
        el.classList.remove('lq-lite-monitor'); el.classList.add('lq-stagger-prep');
    });
}
function lqReplayMonitor(){
    const nodes=lqNodesMonitor(); if(!nodes.length) return;
    const token=++lqLiteTokens.monitor;
    nodes.forEach(el=>{
        el.classList.remove('lq-lite-monitor'); el.style.animation='none'; el.style.animationDelay='';
        el.style.willChange='transform,opacity'; el.classList.add('lq-stagger-prep');
    });
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
        if(token!==lqLiteTokens.monitor) return; void document.body.offsetHeight;
        const step=Math.min(80, 520/Math.max(1,nodes.length-1));
        nodes.forEach((el,index)=>{
            const delay=36+index*step;
            el.classList.remove('lq-stagger-prep');
            el.style.animation=[
                `lqCardMoveLite .72s cubic-bezier(.16,1,.3,1) ${delay}ms both`,
                `lqOpacityIn .46s cubic-bezier(.16,1,.3,1) ${delay}ms both`
            ].join(',');
            el.classList.add('lq-lite-monitor');
            const finish=()=>{
                if(token!==lqLiteTokens.monitor) return;
                el.classList.remove('lq-lite-monitor'); el.style.animation=''; el.style.animationDelay=''; el.style.willChange='';
            };
            const onEnd=evt=>{ if(token!==lqLiteTokens.monitor||evt.animationName!=='lqCardMoveLite') return; el.removeEventListener('animationend',onEnd); finish(); };
            el.addEventListener('animationend',onEnd); window.setTimeout(finish,delay+1000);
        });
    }));
}

// Glass effect page: the mode chips, the preview card and the cards of the mode that is shown (the other mode's controls are hidden)
function lqNodesFrost(){
    const page=document.getElementById('page-frost');
    if(!page) return [];
    const wrap=document.getElementById(lqGlassFxMode==='liquid'?'glassModeLiquid':'glassModeFrost');
    const ctl=wrap && wrap.querySelector('.lq-glass-controls');
    return [
        page.querySelector('#glassModeChips'),
        page.querySelector('#frostCard'),
        ...(ctl ? [...ctl.children] : [])
    ].filter(Boolean);
}
function lqNodesSettings(which){
    if(which==='frost') return lqNodesFrost();
    if(which==='angletex') return lqNodesAngleTex();
    // both pages: Settings (the tab) and UI Settings (its sub page). Only the one that is open is ever on screen.
    const page=document.getElementById('page-uisettings'), hub=document.getElementById('page-settings');
    if(!page) return [];
    return [
        // About: the label, then its three cards, each in a slot of its own: Module (top left), the phone (right), Developer (bottom left)
        hub && hub.querySelector('#secSetAbout'),
        hub && hub.querySelector('#lqAbout > .lq-ab-id'),
        hub && hub.querySelector('#lqAbout > .lq-ab-phone'),
        hub && hub.querySelector('#lqAbout > .lq-ab-by'),
        hub && hub.querySelector('#secSetUi'),
        hub && hub.querySelector('#uiEntryCard'),
        hub && hub.querySelector('#secSetSys'),
        hub && hub.querySelector('#forceStopCard'),
        hub && hub.querySelector('#refreshUiCard'),
        page.querySelector('#skelCard'),
        page.querySelector('#secColor'),
        page.querySelector('#paletteCard'),
        page.querySelector('#customPaletteGroup'),
        page.querySelector('#secShape'),
        page.querySelector('#radiusCard'),
        page.querySelector('#secScale'),
        page.querySelector('#textScaleCard'),
        page.querySelector('#iconScaleCard'),
        page.querySelector('#fontCard'),
        page.querySelector('#secBanner'),
        page.querySelector('#bannerCard'),
        page.querySelector('#secNav'),
        page.querySelector('#navStyleCard'),
        page.querySelector('#navPosCard'),
        page.querySelector('#navSizeCard'),
        page.querySelector('#secExtras'),
        page.querySelector('#glassEntryCard'),
        page.querySelector('#frostEntryCard'),
        page.querySelector('#backupCard'),
        page.querySelector('#restoreCard')
    ].filter(Boolean);
}
function lqResetSettings(which){
    const nodes=lqNodesSettings(which);
    lqCancelAnimation(nodes,'lq-lite-settings','settings');
    nodes.forEach(el=>{
        el.style.animation='none'; el.style.animationDelay=''; el.style.willChange='';
        el.classList.remove('lq-lite-settings'); el.classList.add('lq-stagger-prep');
    });
}
function lqReplaySettings(which){
    const nodes=lqNodesSettings(which); if(!nodes.length)return;
    const token=++lqLiteTokens.settings;
    nodes.forEach(el=>{
        el.classList.remove('lq-lite-settings'); el.style.animation='none'; el.style.animationDelay='';
        el.style.willChange='transform,opacity'; el.classList.add('lq-stagger-prep');
    });
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
        if(token!==lqLiteTokens.settings)return; void document.body.offsetHeight;
        const vh=window.innerHeight||800; let slot=0;
        nodes.forEach((el)=>{
            // cards below the fold do not take a slot of their own: they join the last visible one
            const r=el.getBoundingClientRect(), vis=r.height>0 && r.top<vh;
            const index=vis ? slot++ : Math.max(0,slot-1);
            const delay=60+Math.min(index,9)*85; el.classList.remove('lq-stagger-prep');
            el.style.animation=`lqSettingsEnter .72s cubic-bezier(.16,1,.3,1) ${delay}ms both`;
            el.classList.add('lq-lite-settings');
            const finish=()=>{if(token!==lqLiteTokens.settings)return; el.classList.remove('lq-lite-settings'); el.style.animation=''; el.style.animationDelay=''; el.style.willChange='';};
            const onEnd=evt=>{if(token!==lqLiteTokens.settings||evt.animationName!=='lqSettingsEnter')return; el.removeEventListener('animationend',onEnd); finish();};
            el.addEventListener('animationend',onEnd); window.setTimeout(finish,delay+900);
        });
    }));
}
function lqResetTweaks(){
    const nodes=lqNodesTweaks();
    lqLiteTokens.tweaks++;
    lqCancelAnimation(nodes,'lq-lite-tweak','tweaks');
    nodes.forEach(el=>{
        el.style.animation='none';
        el.style.animationDelay='';
        el.style.willChange='';
        el.classList.remove('lq-lite-tweak');
        el.classList.add('lq-stagger-prep');
    });
}

function lqReplayTweaks(){
    const nodes=lqNodesTweaks();
    if(!nodes.length) return;

    const token=++lqLiteTokens.tweaks;

    nodes.forEach(el=>{
        el.classList.remove('lq-lite-tweak');
        el.style.animation='none';
        el.style.animationDelay='';
        el.style.willChange='transform,opacity';
        el.classList.add('lq-stagger-prep');
    });

    requestAnimationFrame(()=>{
        requestAnimationFrame(()=>{
            if(token!==lqLiteTokens.tweaks) return;
            void document.body.offsetHeight;

            // Urutan stagger dihitung hanya dari kartu yang benar-benar tampil
            // (kartu hidden tidak ikut makan slot), tanpa cap supaya tiap kartu
            // punya delay sendiri dan tidak muncul barengan.
            let order=0;
            // more nodes now (labels too): tighten the step so the whole page
            // still lands in about half a second, every node keeps its own slot
            const shown=nodes.filter(el=>el.getClientRects().length>0).length;
            const step=Math.min(72, 560/Math.max(1,shown-1));
            nodes.forEach((el)=>{
                const visible=el.getClientRects().length>0;
                const index=visible ? order++ : order;
                const delay=36 + index*step;
                el.classList.remove('lq-stagger-prep');
                el.style.animation=[
                    `lqCardMoveLite .72s cubic-bezier(.16,1,.3,1) ${delay}ms both`,
                    `lqOpacityIn .46s cubic-bezier(.16,1,.3,1) ${delay}ms both`
                ].join(',');
                el.classList.add('lq-lite-tweak');

                const finish=()=>{
                    if(token!==lqLiteTokens.tweaks) return;
                    el.classList.remove('lq-lite-tweak');
                    el.style.animation='';
                    el.style.animationDelay='';
                    el.style.willChange='';
                };
                const onEnd=(evt)=>{
                    if(token!==lqLiteTokens.tweaks || evt.animationName!=='lqCardMoveLite') return;
                    el.removeEventListener('animationend',onEnd);
                    finish();
                };
                el.addEventListener('animationend',onEnd);
                window.setTimeout(finish,delay+1000);
            });
        });
    });
}

function lqPrepareDashboard(){ lqPrepare(lqNodesDashboard()); }

function lqResetDashboard(){
    const nodes=lqNodesDashboard();
    lqLiteTokens.dash++;

    nodes.forEach(el=>{
        el.classList.remove(
            'lq-lite-card',
            'lq-stagger-prep',
            'lq-card-opacity-enter',
            'lq-section-label-enter'
        );
        el.style.animation='none';
        el.style.animationDelay='';
        el.style.willChange='';
    });

    const banner=document.querySelector('#page-dashboard .banner-hero');
    if(banner){
        banner.classList.remove('lq-lite-card');
        banner.style.animation='none';
        banner.style.animationDelay='';
        banner.style.willChange='transform,opacity';
        banner.classList.add('lq-stagger-prep');
    }

    lqPrepare(nodes);
}

function lqReplayDashboard(){
    const token=++lqLiteTokens.dash;
    const banner=document.querySelector('#page-dashboard .banner-hero');
    const groups=lqDashboardGroups();

    const contentNodes=groups.flatMap(group=>group.nodes);
    contentNodes.forEach(el=>{
        el.classList.remove('lq-stagger-prep','lq-lite-card');
        el.style.animation='none';
        el.style.animationDelay='';
        el.style.willChange='transform,opacity';
    });
    if(banner){
        banner.classList.remove('lq-stagger-prep','lq-lite-card');
        void banner.offsetWidth;
        const motionDelay=18;
        banner.style.animation=[
            `lqCardMoveLite .66s cubic-bezier(.16,1,.3,1) ${motionDelay}ms both`,
            `lqOpacityIn .42s cubic-bezier(.16,1,.3,1) ${motionDelay}ms both`
        ].join(',');
        banner.classList.add('lq-lite-card');
        banner.style.willChange='transform,opacity';

        const bannerEnd=(evt)=>{
            if(token!==lqLiteTokens.dash || evt.animationName!=='lqCardMoveLite') return;
            banner.removeEventListener('animationend',bannerEnd);
            banner.classList.remove('lq-lite-card');
            banner.style.animation='';
            banner.style.animationDelay='';
            banner.style.willChange='';
        };
        banner.addEventListener('animationend',bannerEnd);
        window.setTimeout(()=>{
            if(token!==lqLiteTokens.dash) return;
            banner.classList.remove('lq-lite-card');
            banner.style.animation='';
            banner.style.animationDelay='';
            banner.style.willChange='';
        }, 960);
    }

    // one slot per card; the step shrinks as cards are added so the page still lands in about a second
    const dashStep=Math.min(110, 760/Math.max(1,groups.length-1));
    groups.forEach((group, groupIndex)=>{
        group.nodes.forEach((el,nodeIndex)=>{
            const isLabel=el.classList.contains('section-label');
            const motionDelay=Math.round(70 + (groupIndex * dashStep) + (nodeIndex * 24));
            const opacityAnimation=isLabel
                ? 'lqSectionLabelOpacityIn .50s cubic-bezier(.16,1,.3,1)'
                : 'lqOpacityIn .50s cubic-bezier(.16,1,.3,1)';

            el.style.animation = [
                `lqCardMoveLite .90s cubic-bezier(.16,1,.3,1) ${motionDelay}ms both`,
                `${opacityAnimation} ${Math.max(0,motionDelay-10)}ms both`
            ].join(',');
            el.classList.add('lq-lite-card');

            const finish=()=>{
                if(token!==lqLiteTokens.dash) return;
                el.classList.remove('lq-lite-card');
                el.style.animation='';
                el.style.animationDelay='';
                el.style.willChange='';
            };

            const onEnd=(evt)=>{
                if(token!==lqLiteTokens.dash || evt.animationName!=='lqCardMoveLite') return;
                el.removeEventListener('animationend',onEnd);
                finish();
            };
            el.addEventListener('animationend',onEnd);
            window.setTimeout(finish, motionDelay + 1020);
        });
    });
}




function lqPreparePkgRows(){
    const nodes=lqNodesPkg();
    nodes.forEach(el=>el.classList.add('pkg-stagger-pending'));
    lqCancelAnimation(nodes,'lq-lite-pkg','pkg');
    nodes.forEach(el=>el.classList.add('pkg-stagger-pending'));
}
function lqResetPkgRows(){ lqPreparePkgRows(); }
function lqReplayPkgRows(){
    const nodes=lqNodesPkg();
    nodes.forEach(el=>el.classList.remove('pkg-stagger-pending'));
    // only the first rows are on screen; a few hundred CSS animations started at once for rows nobody sees made a long list stutter
    lqRevealAndAnimate(nodes.slice(0,24),'lqPkgEnterLite','lq-lite-pkg',70,54,18,'pkg');
}

function lqResetAllBeforeTransition(){
    // the page that is still on screen is NOT reset here (that made its cards vanish at once); it is reset after
    // it has left (see switchPage)
    if(currentPage!=='dashboard') lqResetDashboard();
    if(currentPage!=='packages') lqResetPkgSurface();
}

// ── page exit: the cards of the page that is leaving drift up and fade, top first, in a short stagger ──
// Only what is on screen takes part (what is below the fold has nothing to show), so the exit stays short.
const LQ_EXIT = { dur: 165, step: 15, maxN: 8, y: -10, ease: 'cubic-bezier(.4,0,1,1)' };
function lqExitNodes(page){
    let nodes;
    switch(page.id){
        case 'page-dashboard': nodes=[page.querySelector('.banner-hero'),...lqNodesDashboard()]; break;
        case 'page-packages':  nodes=[...lqNodesPkgSurface(),...lqNodesPkg()]; break;
        case 'page-tweaks':    nodes=lqNodesTweaks(); break;
        case 'page-monitor':   nodes=lqNodesMonitor(); break;
        case 'page-settings':
        case 'page-uisettings': nodes=lqNodesSettings(); break;
        case 'page-frost':     nodes=lqNodesFrost(); break;
        case 'page-angletex':  nodes=lqNodesAngleTex(); break;
        default:               nodes=[...page.children];
    }
    const vh=window.innerHeight||800;
    return [...new Set(nodes.filter(Boolean))].filter(el=>{
        const r=el.getBoundingClientRect();
        return r.height>0 && r.bottom>0 && r.top<vh;
    });
}
function lqPageExit(page){
    const none={ empty:true, done:Promise.resolve(), cancel(){} };
    if(lqReduced() || !page.animate) return none;
    const nodes=lqExitNodes(page);
    if(!nodes.length) return none;
    const anims=nodes.map((el,i)=>el.animate(
        [{opacity:1,translate:'0 0'},{opacity:0,translate:`0 ${LQ_EXIT.y}px`}],
        {duration:LQ_EXIT.dur,delay:Math.min(i,LQ_EXIT.maxN)*LQ_EXIT.step,easing:LQ_EXIT.ease,fill:'both'}
    ));
    // the panel itself fades over the last part, so anything that is not a card does not pop out at the end
    const total=LQ_EXIT.dur+Math.min(nodes.length-1,LQ_EXIT.maxN)*LQ_EXIT.step;
    anims.push(page.animate([{opacity:1},{opacity:0}],{duration:Math.round(total*0.55),delay:Math.round(total*0.45),easing:'linear',fill:'both'}));
    return {
        done:Promise.all(anims.map(a=>a.finished.catch(()=>{}))),
        cancel(){ anims.forEach(a=>{ try{ a.cancel(); }catch(_){} }); }
    };
}


function lqNodesPkgSurface(){
    const page=document.getElementById('page-packages');
    if(!page) return [];
    return [
        page.querySelector('.pkg-stack'),
        page.querySelector('.pkg-tabs'),
        page.querySelector('.pkg-sortbar'),
        page.querySelector('#pkgEmpty')
    ].filter(Boolean);
}

function lqResetPkgSurface(){
    lqLiteTokens.pkg++;
    lqNodesPkgSurface().forEach(el=>{
        el.classList.remove('lq-pkg-surface-anim','lq-pkg-surface-prep');
        el.style.animation='none';
        el.style.animationDelay='';
        el.style.willChange='';
        el.classList.add('lq-pkg-surface-prep');
    });
    lqResetPkgRows();
}

function lqReplayPkgSurface(){
    const nodes=lqNodesPkgSurface();
    if(!nodes.length) return;
    const token=++lqLiteTokens.pkg;
    nodes.forEach(el=>{
        el.classList.remove('lq-pkg-surface-prep','lq-pkg-surface-anim');
        el.style.animation='none';
        el.style.animationDelay='';
        el.style.willChange='transform,opacity';
    });
    void document.body.offsetHeight;

    nodes.forEach((el,index)=>{
        const delay=45 + index*62;
        el.style.animation=`lqPkgSurfaceEnter .72s cubic-bezier(.16,1,.3,1) ${delay}ms both`;
        el.classList.add('lq-pkg-surface-anim');

        const finish=()=>{
            if(token!==lqLiteTokens.pkg) return;
            el.classList.remove('lq-pkg-surface-anim');
            el.style.animation='';
            el.style.animationDelay='';
            el.style.willChange='';
        };
        const onEnd=(evt)=>{
            if(token!==lqLiteTokens.pkg || evt.animationName!=='lqPkgSurfaceEnter') return;
            el.removeEventListener('animationend',onEnd);
            finish();
        };
        el.addEventListener('animationend',onEnd);
        window.setTimeout(finish, delay+850);
    });
}

// ── Navigation ───────────────────────────────────────────────
const pageMeta = {
    dashboard: { title: 'Home', subtitle: 'Li Qinghe · Void Stable' },
    monitor:   { title: 'System Monitor', subtitle: 'Li Qinghe · Live Monitor' },
    frost:     { title: 'Glassmorphism', subtitle: 'Li Qinghe · Appearance' },
    packages:  { title: 'Apps', subtitle: 'Li Qinghe · Void Stable' },
    tweaks:    { title: 'Tweaks', subtitle: 'Li Qinghe · Idle & System Tweaks' },
    settings:  { title: 'Settings', subtitle: 'Li Qinghe · Settings' },
    uisettings:{ title: 'UI Settings', subtitle: 'Li Qinghe · Appearance' },
    angletex:  { title: 'Angle Texture', subtitle: 'Li Qinghe · Angle Texture' },
};

let currentPage = 'dashboard';
let navBusy = false;

// ── Bottom pill nav ──────────────────────────────────────────
// Inactive items show only their icon. The active item grows to fit its
// label, and its own background is the pill. Widths are measured in JS so the
// spring easing in CSS can overshoot on real pixel values.
// Pages that are opened from a card and have no tab of their own: the bar keeps
// showing the tab they belong to.
const LQ_SUBPAGE_PARENT = { monitor: 'dashboard', frost: 'settings', uisettings: 'settings', angletex: 'packages' };
let lqGlassPage = null;          // set by the Liquid Glass card: { open, close } for its preview
let lqGlassBackScroll = 0;       // where Settings was scrolled when the page was opened

function updateNavActive(page, animate = true) {
    const tab = LQ_SUBPAGE_PARENT[page] || page;
    document.querySelectorAll('#navPill .nav-item[data-nav]').forEach(btn => {
        const on = btn.dataset.nav === tab;
        const was = btn.classList.contains('active');
        btn.classList.toggle('active', on);
        if (on && !was && animate && document.documentElement.classList.contains('lq-nav-ios')) lqNavPop(btn);
        if (on) btn.setAttribute('aria-current', 'page');
        else btn.removeAttribute('aria-current');
    });
    lqNavPillLayout(animate);
    if (animate) lqMarkMotion(900);
}

// ── Top bar: follows the page ────────────────────────────────
// Tab pages show the photo and a title (Home keeps "Li Qinghe"). Sub pages swap the photo for a back button and the
// title for the name of the page, so they need no title card of their own. The title slides out and the new one slides in
// from the side the navigation goes (deeper = from the right, back = from the left).
const LQ_HDR = {
    dashboard:  { t: 'Li Qinghe',      depth: 0 },
    packages:   { t: 'Apps',           depth: 0 },
    tweaks:     { t: 'Tweaks',         depth: 0 },
    settings:   { t: 'Settings',       depth: 0 },
    monitor:    { t: 'System Monitor', depth: 1, back: 'dashboard' },
    uisettings: { t: 'UI Settings',    depth: 1, back: 'settings' },
    frost:      { t: 'Glassmorphism',  depth: 2, back: 'uisettings' },
    angletex:   { t: 'Angle Texture',   depth: 1, back: 'packages' }
};
const LQ_HDR_TABS = ['dashboard', 'packages', 'tweaks', 'settings'];
let lqHdrPage = null, lqHdrSeq = 0;

// ── The bar steps aside on the sub pages ─────────────────────────────────────────────────────────────────────────────
// System Monitor, UI Settings and Liquid Glass are reached from a card and left with the back button, so the bottom bar is not needed there
// (and its glass would only be one more thing to draw). When such a page opens, the bar waits until the page has settled (the stagger is
// over and the frames are steady), then slides down off the screen; going back to a tab brings it up with its normal entrance. Toasts do not
// change: they still come out of the bar's place, which is now just below the screen, so they rise from the bottom edge.
let lqNavAwayOn = false, lqNavAwayTok = 0;
function lqNavAwayApply(away) {
    const pill = document.getElementById('navPill');
    if (!pill || away === lqNavAwayOn) return;
    lqNavAwayOn = away;
    document.documentElement.classList.toggle('lq-nav-away', away);
    if (!away) { pill.classList.remove('nav-away', 'nav-away-done'); return; }
    if (!pill.classList.contains('nav-in')) { pill.classList.add('nav-away', 'nav-away-done'); return; }
    pill.classList.add('nav-away');
    let t = 0;
    const done = e => {
        if (e && (e.target !== pill || e.animationName !== 'navPillOut')) return;
        pill.removeEventListener('animationend', done);
        clearTimeout(t);
        if (lqNavAwayOn) pill.classList.add('nav-away-done');      // gone: nothing of it is drawn any more
    };
    pill.addEventListener('animationend', done);
    t = setTimeout(done, 900);
}
// away = true waits for a settled page first; false brings the bar back right away
function lqNavAwaySync(page) {
    const tok = ++lqNavAwayTok;
    const want = !!(LQ_HDR[page] && LQ_HDR[page].back);
    if (!want) { lqNavAwayApply(false); return; }
    lqNavSetCompact(false);      // the copy of the bar on the preview stage shares this flag: a bar left icon-only by a scroll would show no names there
    if (lqNavAwayOn) return;
    const begin = performance.now();
    let last = begin, calm = 0;
    const step = now => {
        if (tok !== lqNavAwayTok) return;                 // another page opened meanwhile
        const dt = now - last; last = now;
        calm = dt <= 22 ? calm + 1 : 0;
        const waited = now - begin;
        if ((waited > 900 && calm >= 10 && !navBusy) || waited > 3200) { lqNavAwayApply(true); return; }
        requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
}

function lqHeaderSet(page, animate = true) {
    const cfg = LQ_HDR[page];
    if (!cfg || page === lqHdrPage) return;
    const bar = document.getElementById('topBar');
    const title = document.getElementById('hdrTitle');
    if (!bar || !title) return;
    const prev = lqHdrPage;
    lqHdrPage = page;
    const sub = !!cfg.back;
    bar.classList.toggle('is-sub', sub);                       // photo <-> back button (CSS transition)
    bar.classList.toggle('has-search', page === 'packages');   // Apps: the search button shows up on the right
    try { lqPkgScanSync(); } catch (_) {}                      // and next to it, on the Game tab, the scan button
    const back = document.getElementById('hdrBack');
    if (back) { back.tabIndex = sub ? 0 : -1; back.setAttribute('aria-hidden', sub ? 'false' : 'true'); }
    const srch = document.getElementById('pkgSearchToggle');
    if (srch) srch.tabIndex = page === 'packages' ? 0 : -1;

    const seq = ++lqHdrSeq;
    title.getAnimations().forEach(a => a.cancel());
    if (!animate || prev === null || !title.animate || lqReduced()) { title.textContent = cfg.t; title.classList.toggle('lq-name', cfg.t === 'Li Qinghe'); return; }

    const from = LQ_HDR[prev];
    const dir = cfg.depth !== from.depth ? (cfg.depth > from.depth ? 1 : -1)
        : (LQ_HDR_TABS.indexOf(page) >= LQ_HDR_TABS.indexOf(prev) ? 1 : -1);
    const out = title.animate(
        [{ opacity: 1, transform: 'translateX(0)' }, { opacity: 0, transform: `translateX(${-dir * 16}px)` }],
        { duration: 130, easing: 'cubic-bezier(.4,0,1,1)', fill: 'forwards' });
    out.finished.then(() => {
        if (seq !== lqHdrSeq) return;
        title.textContent = cfg.t;
        title.classList.toggle('lq-name', cfg.t === 'Li Qinghe');
        out.cancel();
        title.animate(
            [{ opacity: 0, transform: `translateX(${dir * 24}px)` }, { opacity: 1, transform: 'translateX(0)' }],
            { duration: 380, easing: 'cubic-bezier(.16,1,.3,1)' });
    }).catch(() => {});
}

function lqHeaderBack() {
    const to = LQ_HDR[currentPage] && LQ_HDR[currentPage].back;
    if (to) switchPage(to);
}

// first appearance, right after the splash leaves: the photo pops in with a small overshoot, the title rises behind it
function lqHeaderIntro(landed) {
    const bar = document.getElementById('topBar');
    if (!bar) return;
    bar.classList.remove('hdr-prep');
    if (lqReduced()) return;
    bar.classList.add('hdr-in');
    if (landed) bar.classList.add('hdr-landed');          // the photo came flying from the splash, it does not pop in again
    setTimeout(() => bar.classList.remove('hdr-in', 'hdr-landed'), 1400);
}

function updatePageChrome(page) {
    const meta = pageMeta[page] || pageMeta.dashboard;
    set('pageSubtitle', meta.subtitle);
    lqHeaderSet(page);
    updateNavActive(page);
}

function waitForAnimation(el, fallbackMs) {
    return new Promise(resolve => {
        let done = false;
        const finish = () => {
            if (done) return;
            done = true;
            el.removeEventListener('animationend', finish);
            resolve();
        };
        el.addEventListener('animationend', finish, { once:true });
        setTimeout(finish, fallbackMs);
    });
}

async function switchPage(nextPage, options = {}) {
    if (navBusy || nextPage === currentPage) {
        return;
    }


    if (lqConflictActive && LQ_CONFLICT_PAGES.has(nextPage) && !options.conflictRedirect) {
        const nav = document.querySelector(`#navPill .nav-item[data-nav="${nextPage}"]`);
        nav?.classList.add('conflict-denied-flash');
        window.setTimeout(() => nav?.classList.remove('conflict-denied-flash'), 520);
        return;
    }

    const next = document.getElementById(`page-${nextPage}`);
    const current = document.getElementById(`page-${currentPage}`);
    if (!next || !current) return;

    navBusy = true;
    lqPkgBusyApply(nextPage);
    lqMarkMotion(900);
    lqHeaderSet(nextPage);                                    // the title changes together with the bar's lens
    updateNavActive(nextPage);
    if (!(LQ_HDR[nextPage] && LQ_HDR[nextPage].back)) lqNavAwaySync(nextPage);      // a tab page: the bar comes back with the page change
    lqResetAllBeforeTransition();

    await new Promise(resolve => setTimeout(resolve, 30));      // the bar's lens moves first

    current.classList.remove('is-entering');
    current.classList.add('is-visible');
    const exit = lqPageExit(current);
    if (exit.empty) {
        // nothing to animate (reduced motion, or an empty page): the old panel fade
        current.classList.add('is-leaving');
        await waitForAnimation(current, nextPage === 'packages' ? 150 : 280);
    } else {
        await exit.done;
    }

    current.classList.remove('is-leaving', 'is-visible');
    exit.cancel();
    if (currentPage === 'frost') lqGlassFxClose();      // the previews only exist while the page is open
    if (currentPage === 'dashboard') lqResetDashboard();    // ready for its next entrance
    if (currentPage === 'packages') lqResetPkgSurface();

    next.classList.remove('is-leaving', 'is-entering', 'is-visible');

    if (nextPage === 'dashboard') {
        lqResetDashboard();
        const dashboardBanner = next.querySelector('.banner-hero');
        dashboardBanner?.classList.add('lq-stagger-prep');
    }
    if (nextPage === 'packages') lqResetPkgSurface();
    if (nextPage === 'tweaks') lqResetTweaks();
    if (nextPage === 'settings' || nextPage === 'uisettings') lqResetSettings();
    if (nextPage === 'frost') {
        lqGlassFxShow(lqGlassFxMode || (lqGlassFxLiquidApplied() && !lqGlassFxFrostApplied() ? 'liquid' : 'frost'));      // the cards that will be shown are the ones that stagger in
        lqResetSettings('frost');
    }
    if (nextPage === 'angletex') lqResetSettings('angletex');
    if (nextPage === 'monitor') lqResetMonitor();

    void next.offsetWidth;
    next.classList.add('is-visible', 'is-entering');
    updatePageChrome(nextPage);
    {
        const host = document.getElementById('mainContent');
        if (host && nextPage === 'angletex') { lqAtxBackScroll = host.scrollTop; host.scrollTop = 0; }
        else if (host && currentPage === 'angletex' && nextPage === 'packages') host.scrollTop = lqAtxBackScroll;
        else if (host && (nextPage === 'glass' || nextPage === 'frost')) { lqGlassBackScroll = host.scrollTop; host.scrollTop = 0; }
        else if (host && (currentPage === 'glass' || currentPage === 'frost') && nextPage === 'uisettings') host.scrollTop = lqGlassBackScroll;
        else if (host && (nextPage === 'uisettings' || nextPage === 'settings')) host.scrollTop = 0;
    }

    // the cards start to stagger in right away (before, the page waited for its own fade-in over empty space)
    await new Promise(resolve => setTimeout(resolve, 24));
    if (nextPage === 'dashboard') {
        next.classList.remove('is-entering');
        next.classList.add('is-visible');
    } else {
        // the panel's own short fade-in finishes in the background
        window.setTimeout(() => {
            if (!next.classList.contains('is-entering')) return;
            next.classList.remove('is-entering');
            next.classList.add('is-visible');
        }, 190);
    }

    window.setTimeout(() => {
        if (currentPage !== nextPage) return;
        if (nextPage === 'dashboard') lqReplayDashboard();
        if (nextPage === 'packages') {
            lqReplayPkgSurface();
            if (document.querySelectorAll('#pkgList .pkg-item').length) {
                // lqReplayPkgSurface staggers hero/search/search-meta/tabs at
                // 45ms + index*62ms (tabs sits at index 3 -> 231ms). The list
                // rows are a separate stagger group with their own 70ms base
                // delay, so they need to be kicked off *after* the tabs have
                // started entering -- otherwise rows (which used to fire only
                // 42ms in) would visibly animate in before the tab nav does.
                // 223ms + the rows' own 70ms base lands the first row at
                // ~293ms, right after the tabs slot.
                window.setTimeout(() => {
                    if (currentPage === 'packages') lqReplayPkgRows();
                }, 223);
            }
        }
        if (nextPage === 'tweaks') lqReplayTweaks();
        if (nextPage === 'monitor') lqReplayMonitor();
        if (nextPage === 'angletex') {
            lqAtxShow();
            window.setTimeout(() => { if (currentPage === 'angletex') lqReplaySettings('angletex'); }, 48);
        }
        if (nextPage === 'frost') {
            lqGlassFxOpen();
            window.setTimeout(() => { if (currentPage === 'frost') lqReplaySettings('frost'); }, 48);
        }
        if (nextPage === 'settings' || nextPage === 'uisettings') {
            window.setTimeout(() => {
                if (currentPage === nextPage) lqReplaySettings();
            }, 48);
        }
    }, nextPage === 'dashboard' ? 34 : 8);

    currentPage = nextPage;
    document.getElementById('mainContent')?.classList.toggle('packages-view', nextPage === 'packages');
    navBusy = false;
    lqNavAwaySync(nextPage);                                  // a sub page: the bar slides down once it has settled
    // the live numbers are only read while the monitor page is open
    if (nextPage === 'monitor') window.setTimeout(lqRefreshDashboard, 450);
    if (nextPage === 'settings') window.setTimeout(lqAboutTick, 300);
}

// Press and hold the bar, then slide across it: each tab you touch becomes
// the selected one in the bar only. The page itself switches once on release.
function initNavHold() {
    const pill = document.getElementById('navPill');
    if (!pill) return;
    const HOLD_MS = 200;
    const DRAG_PX = 10;
    let st = null;
    let swallowClick = false;

    const tabAt = clientX => {
        const items = [...pill.querySelectorAll('.nav-item')];
        const rect = pill.getBoundingClientRect();
        const scale = rect.width / (pill.offsetWidth || rect.width) || 1;
        const finalW = parseFloat(pill.style.width) || pill.offsetWidth;
        // bar is centred, so its centre stays put while it scales and resizes
        const x = (clientX - (rect.left + rect.width / 2)) / scale + finalW / 2;
        let best = null, bestD = Infinity;
        items.forEach(btn => {
            const l = parseFloat(btn.style.left) || 0;
            const w = parseFloat(btn.style.width) || 0;
            const d = x < l ? l - x : x > l + w ? x - (l + w) : 0;
            if (d < bestD) { bestD = d; best = btn; }
        });
        return best ? best.dataset.nav : null;
    };

    const preview = tab => {
        if (!st || !tab || tab === st.sel) return;
        if (lqConflictActive && LQ_CONFLICT_PAGES.has(tab)) return;
        st.sel = tab;
        updateNavActive(tab);
    };

    const enter = () => {
        if (!st || st.holding) return;
        clearTimeout(st.timer);
        st.holding = true;
        lqMarkMotion(900);
        pill.classList.add('holding');
        try { pill.setPointerCapture(st.id); } catch (_) {}
        if (!lqReduced()) {
            // the pill follows the finger (lqPillDragBegin); the page changes when the finger lifts
            const idx = [...pill.querySelectorAll('.nav-item')].findIndex(b => b.dataset.nav === st.startTab);
            if (idx >= 0) { st.eng = true; lqPillDragBegin(pill, idx); return; }
        }
        preview(st.startTab);
    };

    const finish = (e, commit) => {
        if (!st || e.pointerId !== st.id) return;
        clearTimeout(st.timer);
        const s = st;
        st = null;
        if (!s.holding) return; // quick tap: the normal click handler does it
        try { pill.releasePointerCapture(s.id); } catch (_) {}
        pill.classList.remove('holding');
        lqMarkMotion(900);
        swallowClick = true;
        window.setTimeout(() => { swallowClick = false; }, 400);
        if (s.eng) {
            // where the pill is when the finger lifts decides the tab (a tab the page cannot open right now is skipped)
            const its = [...pill.querySelectorAll('.nav-item')];
            const cur = Math.max(0, its.findIndex(b => b.classList.contains('active')));
            let idx = commit ? lqPillDragEnd() : lqPillDragEnd(cur);
            let name = its[idx] ? its[idx].dataset.nav : null;
            if (name && lqConflictActive && LQ_CONFLICT_PAGES.has(name)) { idx = lqPillDragEnd(cur); name = its[idx] ? its[idx].dataset.nav : null; }
            s.sel = name || currentPage;
        }
        if (commit && s.sel !== currentPage && !navBusy) {
            switchPage(s.sel);
        } else if (s.sel !== currentPage) {
            updateNavActive(currentPage);
        }
    };

    pill.addEventListener('pointerdown', e => {
        if (document.documentElement.classList.contains('lq-nav-tabs')) return;   // tab styles have their own touch handling (initNavIos)
        if (st || (e.pointerType === 'mouse' && e.button !== 0)) return;
        const item = e.target.closest('.nav-item');
        if (!item) return;
        st = { id: e.pointerId, x0: e.clientX, y0: e.clientY, holding: false,
               startTab: item.dataset.nav, sel: currentPage, timer: 0 };
        st.timer = window.setTimeout(enter, HOLD_MS);
    });
    pill.addEventListener('pointermove', e => {
        if (!st || e.pointerId !== st.id) return;
        if (!st.holding) {
            if (Math.hypot(e.clientX - st.x0, e.clientY - st.y0) < DRAG_PX) return;
            enter();
        }
        if (st.eng) {
            const rect = pill.getBoundingClientRect();
            lqPillDragMove(e.clientX - st.x0, (rect.width / (pill.offsetWidth || rect.width)) || 1);
            return;
        }
        preview(tabAt(e.clientX));
    });
    pill.addEventListener('pointerup', e => finish(e, true));
    pill.addEventListener('pointercancel', e => finish(e, false));
    pill.addEventListener('contextmenu', e => e.preventDefault());
    pill.addEventListener('click', e => {
        if (swallowClick) { e.stopPropagation(); e.preventDefault(); }
    }, true);
}

function initNavigation() {
    document.querySelectorAll('#navPill .nav-item[data-nav]').forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.dataset.nav;
            if (lqConflictActive && LQ_CONFLICT_PAGES.has(target)) {
                switchPage(target);
                return;
            }
            switchPage(target);
        });
    });
    // the System Monitor page is opened from one Dashboard card and left with its back button
    document.getElementById('monitorEntry')?.addEventListener('click', () => switchPage('monitor'));
    document.getElementById('frostEntry')?.addEventListener('click', () => switchPage('frost'));
    document.getElementById('uiEntry')?.addEventListener('click', () => switchPage('uisettings'));
    document.getElementById('hdrBack')?.addEventListener('click', lqHeaderBack);   // one back button in the top bar for every sub page
    initNavHold();
    initNavIos();
    updatePageChrome(currentPage);
    updateNavActive(currentPage, false);
    document.getElementById('mainContent')?.classList.toggle('packages-view', currentPage === 'packages');
    window.addEventListener('resize', () => lqNavPillLayout(false));
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => lqNavPillLayout(false));
}



// ── UI Settings / Color Palette ──────────────────────────────
const UI_PALETTE_KEY = 'lq_ui_palette_v1';

const UI_PALETTES = {
    /* Li Qinghe uses one tonal family with three independently meaningful
       color inputs: the visible accent, card tint, and deep surface tint.
       Borders, glow, text hierarchy, and other derived colors stay automatic. */
    green:  { name: 'Material 3 Green',  hex: '#9ED8B5', card: '#5E9F78', surface: '#2F5B42' },
    teal:   { name: 'Material 3 Teal',   hex: '#8FD4CD', card: '#4D9D96', surface: '#255D58' },
    blue:   { name: 'Material 3 Blue',   hex: '#A8C7FA', card: '#5D8FD5', surface: '#2E4F82' },
    indigo: { name: 'Material 3 Indigo', hex: '#BEC7FF', card: '#6D79CF', surface: '#373F76' },
    purple: { name: 'Material 3 Purple', hex: '#D0BCFF', card: '#8D70CC', surface: '#4E3A78' },
    orange: { name: 'Material 3 Orange', hex: '#FFB77A', card: '#B96F38', surface: '#6A3F20' },
    rose:   { name: 'Material 3 Rose',   hex: '#FFB1C8', card: '#C56A85', surface: '#703B4D' },
    cyan:   { name: 'Material 3 Cyan',   hex: '#9FD8F0', card: '#5CA8C8', surface: '#2C5F78' },
    red:    { name: 'Material 3 Red',    hex: '#FFB4AB', card: '#C65B52', surface: '#6F3834' },
    amber:  { name: 'Material 3 Amber',  hex: '#FFDDB5', card: '#B97A36', surface: '#62451F' },
    monochrome: { name: 'Material 3 Mono', hex: '#FFFFFF', card: '#6A6A6A', surface: '#3A3A3A' },
};

function normalizeHex(hex) {
    return String(hex || '').trim().toUpperCase();
}

function isValidHex(hex) {
    return /^#[0-9A-F]{6}$/.test(normalizeHex(hex));
}

function hexToRgb(hex) {
    const value = normalizeHex(hex).slice(1);
    return {
        r: parseInt(value.slice(0, 2), 16),
        g: parseInt(value.slice(2, 4), 16),
        b: parseInt(value.slice(4, 6), 16),
    };
}

function mixHex(baseHex, tintHex, amount) {
    const base = hexToRgb(baseHex);
    const tint = hexToRgb(tintHex);
    const mix = channel => Math.round(channel[0] + (channel[1] - channel[0]) * amount);
    const r = mix([base.r, tint.r]);
    const g = mix([base.g, tint.g]);
    const b = mix([base.b, tint.b]);
    return '#' + [r, g, b].map(value => value.toString(16).padStart(2, '0')).join('').toUpperCase();
}

function applySurfacePalette(primaryHex, cardHex = primaryHex, surfaceHex = primaryHex, root = document.documentElement) {
    const bg = mixHex('#0D0B0C', surfaceHex, 0.12);
    const surfaceLow = mixHex('#141112', surfaceHex, 0.20);
    const surface = mixHex('#171315', surfaceHex, 0.28);
    const surfaceHigh = mixHex('#1D1619', surfaceHex, 0.34);
    const option = mixHex('#21181B', surfaceHex, 0.40);
    const optionHover = mixHex('#271B1F', surfaceHex, 0.46);
    const selected = mixHex('#24181D', cardHex, 0.25);
    const selectedStrong = mixHex('#24181D', cardHex, 0.34);
    const primaryContainer = mixHex('#20171B', cardHex, 0.30);
    const chrome = mixHex('#0B0A0B', surfaceHex, 0.10);
    const drawer = mixHex('#0C0A0B', surfaceHex, 0.14);

    root.style.setProperty('--bg', bg);
    root.style.setProperty('--bg-g', bg);
    root.style.setProperty('--s0', surfaceLow);
    root.style.setProperty('--s1', surface);
    root.style.setProperty('--m3-card-bg', surface);
    root.style.setProperty('--m3-card-hover', surfaceHigh);
    root.style.setProperty('--m3-option-bg', option);
    root.style.setProperty('--m3-option-hover', optionHover);
    root.style.setProperty('--m3-selected', selected);
    root.style.setProperty('--m3-selected-strong', selectedStrong);
    root.style.setProperty('--m3-primary-container', primaryContainer);
    root.style.setProperty('--chrome-bg', chrome);
    root.style.setProperty('--chrome-drawer', drawer);
}

function applyUIPalette(hex, cardHex = hex, surfaceHex = hex, root = document.documentElement) {
    const normalized = normalizeHex(hex);
    const card = normalizeHex(cardHex);
    const surface = normalizeHex(surfaceHex);
    if (!isValidHex(normalized) || !isValidHex(card) || !isValidHex(surface)) return false;

    const { r, g, b } = hexToRgb(normalized);
    applySurfacePalette(normalized, card, surface, root);
    root.style.setProperty('--ac', normalized);
    root.style.setProperty('--grn', normalized);
    root.style.setProperty('--ac-d', `rgba(${r},${g},${b},0.20)`);
    root.style.setProperty('--alive-bg', `rgba(${r},${g},${b},0.14)`);
    root.style.setProperty('--ac-g', `rgba(${r},${g},${b},0.38)`);
    root.style.setProperty('--bdr', `rgba(${r},${g},${b},0.22)`);
    root.style.setProperty('--bdr-h', `rgba(${r},${g},${b},0.52)`);
    const textPrimary = mixHex('#F3F0F2', normalized, 0.35);
    const textRgb = hexToRgb(textPrimary);
    root.style.setProperty('--hi', textPrimary);
    root.style.setProperty('--md', `rgba(${textRgb.r},${textRgb.g},${textRgb.b},0.64)`);
    root.style.setProperty('--lo', `rgba(${textRgb.r},${textRgb.g},${textRgb.b},0.36)`);
    root.style.setProperty('--ac2', mixHex(normalized, '#F3F0F2', 0.22));
    root.style.setProperty('--chrome-border', `rgba(${r},${g},${b},0.18)`);
    return true;
}

function saveUIPalette(state) {
    try { localStorage.setItem(UI_PALETTE_KEY, JSON.stringify(state)); } catch (_) {}
    lqMirrorUIPrefs();
}

function loadUIPalette() {
    try {
        const raw = localStorage.getItem(UI_PALETTE_KEY);
        if (!raw) return { type: 'preset', value: 'monochrome' };
        const state = JSON.parse(raw);
        if (state?.type === 'custom' && isValidHex(state.value) && isValidHex(state.card) && isValidHex(state.surface)) {
            return {
                type: 'custom',
                value: normalizeHex(state.value),
                card: normalizeHex(state.card),
                surface: normalizeHex(state.surface),
            };
        }
        if (state?.type === 'preset' && UI_PALETTES[state.value]) return { type: 'preset', value: state.value };
    } catch (_) {}
    return { type: 'preset', value: 'monochrome' };
}

function stateToSeedState(state) {
    if (state.type === 'custom') {
        const primary = normalizeHex(state.value);
        return {
            primary,
            card: normalizeHex(state.card || primary),
            surface: normalizeHex(state.surface || primary),
        };
    }
    const preset = UI_PALETTES[state.value] || UI_PALETTES.monochrome;
    return {
        primary: normalizeHex(preset.hex),
        card: normalizeHex(preset.card || preset.hex),
        surface: normalizeHex(preset.surface || preset.hex),
    };
}

function seedStateToPaletteState(seed) {
    return {
        type: 'custom',
        value: normalizeHex(seed.primary),
        card: normalizeHex(seed.card),
        surface: normalizeHex(seed.surface),
    };
}


function updateUIPaletteState(state, { persist = true } = {}) {
    const summary = document.getElementById('paletteSummaryText');
    if (state.type === 'custom') {
        const seed = stateToSeedState(state);
        // Re-apply the persisted custom palette whenever the UI initializes
        // (or this state is refreshed), so reloads keep the committed theme.
        applyUIPalette(seed.primary, seed.card, seed.surface);
        if (summary) summary.textContent = `Custom | ${seed.primary} | ${seed.card} | ${seed.surface}`;
    } else {
        const preset = UI_PALETTES[state.value] || UI_PALETTES.monochrome;
        applyUIPalette(preset.hex, preset.card, preset.surface);
        if (summary) summary.textContent = preset.name;
    }
    document.querySelectorAll('.lq-pal[data-palette]').forEach(btn => {
        btn.classList.toggle('active', state.type === 'preset' && btn.dataset.palette === state.value);
    });
    if (persist) saveUIPalette(state);
}

function setPaletteError(message) {
    const error = document.getElementById('customSeedHexError');
    if (error) error.textContent = message || '';
}

// Each settings card registers a hook here that re-reads its saved value and repaints
// itself, so a restore can put settings back live, exactly like a normal Apply.
const lqUiResync = {};

// Paints one saved setting straight onto the page. It only needs the saved value, not the
// settings card, so a restore still shows up even when a card did not finish its init.
// The card hook (lqUiResync) afterwards brings that card's sliders and labels in step.
async function lqUiApplyNow(key) {
    if (key === 'palette') {
        const st = loadUIPalette();
        updateUIPaletteState(st, { persist: false });
    } else if (key === 'radius') {
        applyUIRadius(loadUIRadius(), { persist: false });
    } else if (key === 'glass') {
        lqGlassCfg = lqGlassLoad();
        lqGlassNavCfg = lqGlassNavLoad();
        lqFrostCfg = lqFrostLoad();
        lqGlassApply();
    } else if (key === 'nav') {
        lqNavCfg = lqNavLoad();
        lqNavApply();
    } else if (key === 'scale') {
        applyUIScale(loadUIScale());
    } else if (key === 'font') {
        applyUIFont(loadUIFont());
    } else if (key === 'banner') {
        const ext = loadBannerExt(), bust = loadBannerBust();
        await preloadBannerImage(ext, bust);
        applyUIBannerVisual(ext, loadBannerPos(), bust);
    }
    try { await lqUiResync[key]?.(); } catch (e) { console.error('[resync]', key, e); }
}

// True when the page really shows the saved value (used to decide if a reload is needed).
function lqUiShows(key) {
    const root = document.documentElement, cs = getComputedStyle(root);
    if (key === 'palette') {
        const seed = stateToSeedState(loadUIPalette());
        return cs.getPropertyValue('--ac').trim().toLowerCase() === normalizeHex(seed.primary).toLowerCase();
    }
    if (key === 'radius') return parseFloat(cs.getPropertyValue('--r')) === loadUIRadius();
    return true;
}

function initUIPaletteSettings() {
    const summary = document.getElementById('paletteSummary');
    const paletteWrap = document.getElementById('paletteExpandWrap');
    const customCard = document.getElementById('customPaletteCard');
    const customWrap = document.getElementById('customPaletteExpandWrap');
    const hexInput = document.getElementById('customSeedHexInput');
    const rangeR = document.getElementById('customSeedR');
    const rangeG = document.getElementById('customSeedG');
    const rangeB = document.getElementById('customSeedB');
    const applyAll = document.getElementById('customPaletteApplyAll');
    const reset = document.getElementById('customPaletteReset');
    const copy = document.getElementById('customColorCopy');
    if (!summary || !paletteWrap || !customCard || !customWrap || !hexInput || !rangeR || !rangeG || !rangeB || !applyAll || !reset || !copy) return;

    let persistedState = loadUIPalette();
    let draft = stateToSeedState(persistedState);
    let activeRole = 'primary';
    const roleOrder = ['primary', 'card', 'surface'];
    const roleLabels = { primary: 'Primary Accent', card: 'Card Tint', surface: 'Surface Tint' };

    summary.addEventListener('click', () => {
        const open = summary.getAttribute('aria-expanded') === 'true';
        const next = !open;
        summary.setAttribute('aria-expanded', String(next));
        paletteWrap.classList.toggle('is-open', next);
    });

    customCard.addEventListener('click', () => {
        const open = customCard.getAttribute('aria-expanded') === 'true';
        const next = !open;
        customCard.setAttribute('aria-expanded', String(next));
        customWrap.classList.toggle('is-open', next);
    });

    document.querySelectorAll('.lq-pal[data-palette]').forEach(btn => {
        btn.addEventListener('click', () => {
            const key = btn.dataset.palette;
            if (!UI_PALETTES[key]) return;
            persistedState = { type: 'preset', value: key };
            draft = stateToSeedState(persistedState);
            updateUIPaletteState(persistedState);
            renderAll();
        });
    });

    function currentColor() { return draft[activeRole]; }

    function setRoleColor(hex) {
        draft[activeRole] = normalizeHex(hex);
        // Draft edits preview only inside the Custom Color editor.
        // The active app theme changes only when Apply Theme is pressed.
    }

    function rgbToHex(r, g, b) {
        return `#${[r, g, b].map(v => Number(v).toString(16).padStart(2, '0')).join('').toUpperCase()}`;
    }

    function rgbRangeStyle(input) {
        const value = Number(input.value) || 0;
        const pct = Math.max(0, Math.min(1, value / 255));
        input.style.setProperty('--lq-rgb-progress', String(pct));
        input.setAttribute('aria-label', `${(input.closest('.ui-custom-rgb-row')?.dataset.channel || 'r').toUpperCase()} channel`);
    }

    function renderSeedChips() {
        const ids = {
            primary: ['Primary', 'Primary'],
            card: ['Card', 'Card'],
            surface: ['Surface', 'Surface'],
        };
        roleOrder.forEach(role => {
            const [cap] = ids[role];
            const color = draft[role];
            const dot = document.getElementById(`seedDot${cap}`);
            const code = document.getElementById(`seedCode${cap}`);
            if (dot) dot.style.background = color;
            if (code) code.textContent = color;
        });
        document.querySelectorAll('.ui-custom-seed-chip[data-seed-role]').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.seedRole === activeRole);
        });
    }

    function renderEditor() {
        const color = currentColor();
        const rgb = hexToRgb(color);
        const preview = document.getElementById('customColorPreview');
        const hexValue = document.getElementById('customColorHexValue');
        const error = document.getElementById('customSeedHexError');
        const rValue = document.getElementById('customSeedRValue');
        const gValue = document.getElementById('customSeedGValue');
        const bValue = document.getElementById('customSeedBValue');
        const title = document.getElementById('customSeedEditor');
        if (title) title.setAttribute('aria-label', roleLabels[activeRole]);
        if (preview) preview.style.background = color;
        if (hexValue) hexValue.textContent = color;
        if (hexInput !== document.activeElement) hexInput.value = color;
        if (error) error.textContent = '';
        rangeR.value = rgb.r;
        rangeG.value = rgb.g;
        rangeB.value = rgb.b;
        if (rValue) rValue.textContent = rgb.r;
        if (gValue) gValue.textContent = rgb.g;
        if (bValue) bValue.textContent = rgb.b;
        rgbRangeStyle(rangeR); rgbRangeStyle(rangeG); rgbRangeStyle(rangeB);
        if (title) title.dataset.roleLabel = roleLabels[activeRole];
    }

    function renderPreviewStrip() {
        const ids = { primary: 'customPreviewPrimary', card: 'customPreviewCard', surface: 'customPreviewSurface' };
        roleOrder.forEach(role => {
            const node = document.getElementById(ids[role]);
            if (node) node.style.background = draft[role];
        });
    }

    // Apply/Reset only make sense once the draft actually differs from
    // what's currently applied, otherwise there's nothing to commit or
    // discard, so keep both disabled until something changes.
    function isDraftDirty() {
        const appliedSeed = stateToSeedState(persistedState);
        return roleOrder.some(role => draft[role] !== appliedSeed[role]);
    }

    function updateActionState() {
        const dirty = isDraftDirty();
        applyAll.disabled = !dirty;
        reset.disabled = !dirty;
    }

    function renderAll() {
        // an unapplied custom draft is shown on the live skeleton only; Apply makes it real
        const base = stateToSeedState(persistedState);
        lqSkelPalette(roleOrder.every(r => isValidHex(draft[r]) && normalizeHex(draft[r]) === normalizeHex(base[r])) ? null : draft);
        renderSeedChips();
        renderEditor();
        renderPreviewStrip();
        updateActionState();
    }

    document.querySelectorAll('.ui-custom-seed-chip[data-seed-role]').forEach(btn => {
        btn.addEventListener('click', () => {
            const role = btn.dataset.seedRole;
            if (!roleOrder.includes(role)) return;
            activeRole = role;
            renderAll();
        });
    });

    hexInput.addEventListener('input', () => {
        let value = normalizeHex(hexInput.value);
        if (value.length > 7) value = value.slice(0, 7);
        if (hexInput.value !== value) hexInput.value = value;
        if (!value) { setPaletteError(''); return; }
        if (!isValidHex(value)) { setPaletteError('Use exactly 6 hexadecimal digits.'); return; }
        setPaletteError('');
        setRoleColor(value);
        renderAll();
    });

    [rangeR, rangeG, rangeB].forEach(input => {
        input.addEventListener('input', () => {
            const rgb = hexToRgb(currentColor());
            const r = input === rangeR ? Number(input.value) : rgb.r;
            const g = input === rangeG ? Number(input.value) : rgb.g;
            const b = input === rangeB ? Number(input.value) : rgb.b;
            setRoleColor(rgbToHex(r, g, b));
            renderAll();
        });
    });

    copy.addEventListener('click', async () => {
        const value = currentColor();
        try {
            if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(value);
            else {
                const area = document.createElement('textarea');
                area.value = value; area.setAttribute('readonly', ''); area.style.position = 'fixed'; area.style.opacity = '0';
                document.body.appendChild(area); area.select(); document.execCommand('copy'); area.remove();
            }
            lqToastShow({ title: 'Theme colors', text: `Copied ${value}`, state: 'ok' });
        } catch (_) { lqToastShow({ title: 'Theme colors', text: 'Could not copy', state: 'err' }); }
    });

    function commitDraft() {
        if (!roleOrder.every(role => isValidHex(draft[role]))) {
            setPaletteError('One or more theme colors are invalid.');
            lqToastShow({ title: 'Theme colors', text: 'Some colors are invalid', state: 'err' });
            return;
        }
        const next = seedStateToPaletteState(draft);
        if (!applyUIPalette(next.value, next.card, next.surface)) {
            setPaletteError('Unable to apply the selected theme colors.');
            lqToastShow({ title: 'Theme colors', text: 'Failed to apply', state: 'err' });
            return;
        }
        persistedState = next;
        updateUIPaletteState(next);
        renderAll();
        lqToastShow({ title: 'Theme colors', text: 'Theme applied', state: 'ok' });
    }

    applyAll.addEventListener('click', commitDraft);
    reset.addEventListener('click', () => {
        persistedState = loadUIPalette();
        draft = stateToSeedState(persistedState);
        renderAll();
        lqToastShow({ title: 'Theme colors', text: 'Reset to saved colors', state: 'ok' });
    });

    updateUIPaletteState(persistedState, { persist: false });
    renderAll();
    // bring the selected swatch into view right away (no smooth scroll on first paint)
    const palRow = document.getElementById('palettePresetGrid');
    if (palRow && typeof ResizeObserver === 'function') {
        // the page is hidden while the app boots, so wait until the row really has a width
        const ro = new ResizeObserver(() => {
            const on = palRow.querySelector('.lq-pal.active');
            if (!palRow.clientWidth || !on) return;
            palRow.scrollLeft = Math.max(0, on.offsetLeft - (palRow.clientWidth - on.offsetWidth) / 2);
            ro.disconnect();
        });
        ro.observe(palRow);
    }
    lqUiResync.palette = () => {
        persistedState = loadUIPalette();
        draft = stateToSeedState(persistedState);
        updateUIPaletteState(persistedState, { persist: false });
        renderAll();
    };
}

// ── UI Settings / Corner Radius ──────────────────────────────
const UI_RADIUS_KEY = 'lq_ui_radius_v1';
const UI_RADIUS_DEFAULT = 28;
const UI_RADIUS_MIN = 0;
const UI_RADIUS_MAX = 32;

function normalizeRadius(value) {
    const parsed = Number(value);
    if (!Number.isFinite(parsed)) return UI_RADIUS_DEFAULT;
    return Math.min(UI_RADIUS_MAX, Math.max(UI_RADIUS_MIN, Math.round(parsed)));
}

function loadUIRadius() {
    try {
        const raw = localStorage.getItem(UI_RADIUS_KEY);
        if (raw === null) return UI_RADIUS_DEFAULT;
        return normalizeRadius(raw);
    } catch (_) {
        return UI_RADIUS_DEFAULT;
    }
}

function saveUIRadius(value) {
    try {
        localStorage.setItem(UI_RADIUS_KEY, String(normalizeRadius(value)));
    } catch (_) {}
    lqMirrorUIPrefs();
}

function applyUIRadius(value, { persist = true } = {}) {
    const radius = normalizeRadius(value);
    document.documentElement.style.setProperty('--r', `${radius}px`);
    if (typeof lqGlassOnRadius === 'function') lqGlassOnRadius();

    if (persist) saveUIRadius(radius);
    return radius;
}

function initUIRadiusSettings() {
    const summary = document.getElementById('radiusSummary');
    const expandWrap = document.getElementById('radiusExpandWrap');
    const slider = document.getElementById('radiusSlider');
    const summaryValue = document.getElementById('radiusSummaryValue');
    const summaryText = document.getElementById('radiusSummaryText');
    const applyButton = document.getElementById('radiusApply');
    const options = document.querySelectorAll('.ui-radius-option[data-radius]');

    if (!summary || !expandWrap || !slider || !summaryValue || !summaryText || !applyButton) return;

    let appliedRadius = loadUIRadius();
    let pendingRadius = applyUIRadius(appliedRadius, { persist: false });

    const updatePreview = radius => {
        pendingRadius = normalizeRadius(radius);
        slider.value = String(pendingRadius);
        slider.style.setProperty('--lq-progress', `${pendingRadius / UI_RADIUS_MAX}`);
        summaryValue.textContent = `${pendingRadius}px`;
        const cv = document.getElementById('radiusCustomValue'); if (cv) cv.textContent = `${pendingRadius}px`;
        summaryText.textContent = 'Sets the base corner radius. Smaller elements scale from it proportionally.';
        lqSkelRadius(pendingRadius);

        options.forEach(option => {
            option.classList.toggle('active', Number(option.dataset.radius) === pendingRadius);
        });

        // Nothing to commit until the draft actually differs from what's live.
        applyButton.disabled = pendingRadius === appliedRadius;
    };

    summary.addEventListener('click', () => {
        const open = summary.getAttribute('aria-expanded') === 'true';
        const next = !open;
        summary.setAttribute('aria-expanded', String(next));
        expandWrap.classList.toggle('is-open', next);
    });

    options.forEach(option => {
        option.addEventListener('click', () => {
            updatePreview(option.dataset.radius);
        });
    });

    slider.addEventListener('input', () => {
        updatePreview(slider.value);
    });

    applyButton.addEventListener('click', () => {
        const applied = applyUIRadius(pendingRadius);
        appliedRadius = applied;
        updatePreview(applied);
        lqToastShow({ title: 'Corner radius', text: 'Radius applied', state: 'ok' });
    });

    updatePreview(pendingRadius);
    lqUiResync.radius = () => {
        appliedRadius = loadUIRadius();
        applyUIRadius(appliedRadius, { persist: false });
        updatePreview(appliedRadius);
    };
}

// ── UI Settings / Text size, icon size and custom font ───────
// The stylesheet multiplies every text size by --lq-ts and every icon (and icon tile) size by --lq-is,
// so the two sliders only have to set those two numbers on <html>. The bottom bar keeps its own
// "Bar size" setting. A custom font is a file in webroot (custom-font.<ext>, written the same way as
// the banner photo); localStorage only remembers its extension, name and cache token.
const UI_SCALE_KEY = 'lq_ui_scale_v1';
const UI_FONT_KEY = 'lq_ui_font_v1';
const UI_SCALE_MIN = 80;
const UI_SCALE_MAX = 150;
const UI_SCALE_DEFAULT = 100;
const LQ_FONT_FORMATS = { ttf: 'truetype', otf: 'opentype', woff: 'woff', woff2: 'woff2' };
const LQ_FONT_MAX_BYTES = 8 * 1024 * 1024;
const LQ_FONT_FAMILIES = ['SF Pro Display', 'DM Sans'];   // the two names the stylesheet uses

function normalizeUIScale(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return UI_SCALE_DEFAULT;
    return Math.min(UI_SCALE_MAX, Math.max(UI_SCALE_MIN, Math.round(n)));
}
function loadUIScale() {
    try {
        const raw = JSON.parse(localStorage.getItem(UI_SCALE_KEY) || 'null');
        return { t: normalizeUIScale(raw?.t), i: normalizeUIScale(raw?.i) };
    } catch (_) {
        return { t: UI_SCALE_DEFAULT, i: UI_SCALE_DEFAULT };
    }
}
function saveUIScale(sc) {
    try { localStorage.setItem(UI_SCALE_KEY, JSON.stringify({ t: normalizeUIScale(sc.t), i: normalizeUIScale(sc.i) })); } catch (_) {}
    lqMirrorUIPrefs();
}
function applyUIScale(sc) {
    const t = normalizeUIScale(sc?.t), i = normalizeUIScale(sc?.i);
    const root = document.documentElement;
    root.style.setProperty('--lq-ts', String(t / 100));
    root.style.setProperty('--lq-is', String(i / 100));
    return { t, i };
}

function loadUIFont() {
    try {
        const raw = JSON.parse(localStorage.getItem(UI_FONT_KEY) || 'null');
        const ext = String(raw?.ext || '').toLowerCase();
        if (!LQ_FONT_FORMATS[ext]) return { ext: '', bust: '', name: '' };
        return { ext, bust: String(raw.bust || ''), name: String(raw.name || '').slice(0, 80) };
    } catch (_) {
        return { ext: '', bust: '', name: '' };
    }
}
function saveUIFont(f) {
    try {
        if (f && f.ext) localStorage.setItem(UI_FONT_KEY, JSON.stringify({ ext: f.ext, bust: f.bust || '', name: f.name || '' }));
        else localStorage.removeItem(UI_FONT_KEY);
    } catch (_) {}
    lqMirrorUIPrefs();
}
function applyUIFont(f) {
    let st = document.getElementById('lqCustomFontStyle');
    if (!f || !f.ext) {
        st?.remove();
    } else {
        if (!st) {
            st = document.createElement('style');
            st.id = 'lqCustomFontStyle';
            document.head.appendChild(st);       // after the stylesheet, so its faces win for the same family names
        }
        const url = `custom-font.${f.ext}${f.bust ? `?v=${encodeURIComponent(f.bust)}` : ''}`;
        st.textContent = LQ_FONT_FAMILIES.map(fam =>
            `@font-face{font-family:'${fam}';src:url('${url}') format('${LQ_FONT_FORMATS[f.ext]}');font-weight:100 900;font-style:normal;font-display:swap}`
        ).join('');
    }
    // text widths changed: let the bar measure its names again once the file is in
    try {
        document.fonts.load("16px 'SF Pro Display'").then(() => { try { lqNavPillLayout(false); } catch (_) {} }).catch(() => {});
    } catch (_) {}
}

function lqFontPath(ext) { return `${LQ_BANNER_WEBROOT_DIR}/custom-font.${ext}`; }
function lqBytesToBase64(bytes) {
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(bin);
}

// Same chunked upload as the banner photo, with a progress callback (fonts can be a few MB).
async function lqWriteFontFile(b64, ext, onProgress) {
    await exec(`mkdir -p ${shellQuote(LQ_BANNER_TMP_DIR)} 2>/dev/null; rm -f ${shellQuote(LQ_BANNER_TMP_FILE)} 2>/dev/null`);
    for (let i = 0; i < b64.length; i += LQ_BANNER_CHUNK_SIZE) {
        const chunk = b64.slice(i, i + LQ_BANNER_CHUNK_SIZE);
        const r = await exec(`printf '%s' ${shellQuote(chunk)} >> ${shellQuote(LQ_BANNER_TMP_FILE)} && echo __LQ_OK__`);
        if (!String(r || '').includes('__LQ_OK__')) {
            await exec(`rm -f ${shellQuote(LQ_BANNER_TMP_FILE)} 2>/dev/null`);
            return { ok: false, stage: 'upload' };
        }
        if (onProgress) onProgress(Math.min(1, (i + chunk.length) / b64.length));
    }
    const finalFile = lqFontPath(ext);
    const rmAll = Object.keys(LQ_FONT_FORMATS).map(e => `rm -f ${shellQuote(lqFontPath(e))}`).join(' ; ');
    const r = await exec(
        `${rmAll} ; base64 -d ${shellQuote(LQ_BANNER_TMP_FILE)} > ${shellQuote(finalFile)} 2>/dev/null ; ` +
        `rm -f ${shellQuote(LQ_BANNER_TMP_FILE)} ; [ -s ${shellQuote(finalFile)} ] && echo __LQ_OK__ || echo __LQ_ERR__`);
    return String(r || '').includes('__LQ_OK__') ? { ok: true } : { ok: false, stage: 'write' };
}
async function lqRemoveFontFiles() {
    await exec(Object.keys(LQ_FONT_FORMATS).map(e => `rm -f ${shellQuote(lqFontPath(e))}`).join(' ; '));
}

let lqNavRescaleRaf = 0;
function lqNavRescale() {
    if (lqNavRescaleRaf) return;
    lqNavRescaleRaf = requestAnimationFrame(() => {
        lqNavRescaleRaf = 0;
        try { if (lqNavInited) lqNavApply(); } catch (_) {}
    });
}

function initUIScaleSettings() {
    const $ = id => document.getElementById(id);
    let cur = applyUIScale(loadUIScale());

    // One card for the text size and one for the icon size, both work the same way: the slider and the presets
    // only change a draft that the sample in the card shows at its real size; Apply puts it on the whole app.
    // (Before, the whole UI resized under the finger while sliding, so the sample showed nothing useful.)
    let draft = { ...cur };
    const painters = [];
    const wire = (key, pref, sampleSel, varName) => {
        const slider = $(`${pref}Slider`), value = $(`${pref}Value`), applyBtn = $(`${pref}Apply`);
        const presets = [...document.querySelectorAll(`#${pref}Presets [data-scale]`)];
        const sample = document.querySelector(sampleSel);
        if (!slider || !value) return () => {};
        const paint = () => {
            const v = draft[key];
            slider.value = String(v);
            slider.style.setProperty('--lq-progress', String((v - UI_SCALE_MIN) / (UI_SCALE_MAX - UI_SCALE_MIN)));
            value.textContent = v === cur[key] ? `${v}%` : `${v}% (preview)`;
            presets.forEach(b => b.classList.toggle('is-active', Number(b.dataset.scale) === v));
            if (sample) sample.style.setProperty(varName, String(v / 100));      // the sample alone, not the app
            if (applyBtn) applyBtn.disabled = v === cur[key];
        };
        const set = v => { draft = { ...draft, [key]: normalizeUIScale(v) }; paint(); };
        slider.addEventListener('input', () => set(slider.value));
        presets.forEach(b => b.addEventListener('click', () => set(b.dataset.scale)));
        applyBtn?.addEventListener('click', () => {
            if (draft[key] === cur[key]) return;
            cur = applyUIScale({ ...cur, [key]: draft[key] });
            saveUIScale(cur);
            lqNavRescale();
            painters.forEach(fn => fn());
        });
        painters.push(paint);
        paint();
        return paint;
    };
    wire('t', 'textScale', '#textScaleSample', '--lq-ts');
    wire('i', 'iconScale', '.sc-sample-icons', '--lq-is');
    lqUiResync.scale = () => { cur = applyUIScale(loadUIScale()); draft = { ...cur }; painters.forEach(fn => fn()); lqNavRescale(); };

    // ── custom font ──
    const input = $('fontFileInput'), chooseBtn = $('fontChooseBtn'), resetBtn = $('fontResetBtn');
    const valueEl = $('fontValue'), errEl = $('fontError');
    if (!input || !chooseBtn || !resetBtn) return;
    let busy = false;
    const setErr = t => { if (errEl) errEl.textContent = t || ''; };
    const paintFont = () => {
        const f = loadUIFont();
        if (valueEl) valueEl.textContent = f.ext ? (f.name || `custom.${f.ext}`) : 'Default';
        resetBtn.disabled = !f.ext || busy;
        chooseBtn.disabled = busy;
        chooseBtn.textContent = f.ext ? 'Replace font' : 'Choose font';
    };
    lqUiResync.font = () => { applyUIFont(loadUIFont()); paintFont(); };
    paintFont();

    chooseBtn.addEventListener('click', () => { if (!busy) input.click(); });
    input.addEventListener('change', async () => {
        const file = input.files && input.files[0];
        input.value = '';
        if (!file || busy) return;
        const m = /\.([a-z0-9]+)$/i.exec(file.name || '');
        const ext = m ? m[1].toLowerCase() : '';
        if (!LQ_FONT_FORMATS[ext]) { setErr('Unsupported file. Use a TTF, OTF, WOFF or WOFF2 font.'); return; }
        if (file.size > LQ_FONT_MAX_BYTES) {
            setErr(`Font is ${(file.size / 1048576).toFixed(1)}MB, over the 8MB limit. Use a smaller or WOFF2 version.`);
            return;
        }
        setErr('');
        busy = true; paintFont();
        const toast = lqToastShow({ title: 'Font', text: 'Checking the file', state: 'pending' });
        try {
            const buf = await file.arrayBuffer();
            try { await new FontFace('LQ Probe', buf).load(); }
            catch (_) { setErr('That file is not a font this WebView can read.'); toast.update({ state: 'err', text: 'Not a valid font' }); busy = false; paintFont(); return; }
            toast.update({ text: 'Saving...' });       // one message for the whole upload, no percent spam
            const res = await lqWriteFontFile(lqBytesToBase64(new Uint8Array(buf)), ext);
            if (!res.ok) {
                setErr(res.stage === 'upload' ? 'Could not send the font to the device.' : 'Could not write the font file. Check root access.');
                toast.update({ state: 'err', text: 'Could not save the font' });
            } else {
                const f = { ext, bust: String(Date.now()), name: (file.name || '').replace(/\.[^.]+$/, '').slice(0, 80) };
                saveUIFont(f);
                applyUIFont(f);
                toast.update({ state: 'ok', text: 'Font applied' });
            }
        } catch (_) {
            setErr('Something went wrong while reading the font.');
            toast.update({ state: 'err', text: 'Font failed' });
        }
        busy = false; paintFont();
    });
    resetBtn.addEventListener('click', async () => {
        if (busy) return;
        busy = true; paintFont(); setErr('');
        await lqRemoveFontFiles();
        saveUIFont(null);
        applyUIFont(null);
        busy = false; paintFont();
        lqToastShow({ title: 'Font', text: 'Back to the default font', state: 'ok' });
    });
}

// Saved size and font go on before anything is drawn, so the page never flashes at the wrong size.
try { applyUIScale(loadUIScale()); applyUIFont(loadUIFont()); } catch (_) {}

// ── Liquid glass toast (experimental) ─────────────────────────
// Optional liquid glass for the toasts and the nav. What is behind the glass is really bent: a displacement map (drawn once per
// size and setting on a plain 2D canvas, see lqGxMapURL, no WebGL needed) feeds an SVG feDisplacementMap inside backdrop-filter,
// so the picture behind is pushed hardest at the edge and only a little inside. There is no rim light: the bend is the edge.
// Cost control: maps are only remade when the radius or a setting changes, and nothing is redrawn while the page scrolls.
// The bend has the same shape as the 1.5 beta 3.10 glass (a strong pull on the rim that dies out toward the middle, then a
// light blur of the map so the corners do not tear), but every part of it has its own slider.

const UI_GLASS_KEY = 'lq_ui_glass_v1';
const UI_GLASS_NAV_KEY = 'lq_ui_glass_nav_v1';      // the bottom nav's own Liquid Glass values (the toasts keep UI_GLASS_KEY)
// The merge gradient (the toast's colour where it joins the bar) has no settings any more: it is always on, with these values.
const LQ_GRAD_FIXED = { gradSolid: 60, gradSoft: 65, gradReach: 34 };
const LQ_GLASS_GRAD = ['gradSolid', 'gradSoft', 'gradReach'];
const LQ_GLASS_FIELDS = {
    //            min  max  step unit  dom id part
    distort: { min: 0,   max: 100, unit: '%',  id: 'Distort' },
    bezel:   { min: 4,   max: 30,  unit: 'px', id: 'Bezel' },
    curve:   { min: 0,   max: 100, unit: '%',  id: 'Curve' },      // inner curve: how much the inner pull is kept to the rim (low = even bend, high = flat glass that bends hard only at the edge)
    lipw:    { min: 2,   max: 30,  unit: 'px', id: 'LipW' },      // outer radius: how far from the edge the outer distortion reaches
    lip:     { min: 0,   max: 100, unit: '%',  id: 'Lip', fmt: v => v + '%' },   // outer distortion: how much more the picture bends on the way to the edge
    edge:    { min: 0,   max: 100, unit: '%',  id: 'Edge' },     // edge distortion: the super thin squeeze on the rim that draws the border
    split:   { min: 0,   max: 100, unit: '%',  id: 'Split' },
    blur:    { min: 0,   max: 30,  unit: 'px', id: 'Blur' },
    frost:   { min: 0,   max: 100, unit: '%',  id: 'Frost' },
    sat:     { min: 100, max: 250, unit: '%',  id: 'Sat' },
    gradSolid: { min: 0,  max: 100, unit: '%',  id: 'GradSolid' },   // merge gradient: how solid it is where card and bar meet
    gradSoft:  { min: 0,  max: 100, unit: '%',  id: 'GradSoft' },    // how smooth its fade is (0 = holds then drops, 100 = eases the whole way)
    gradReach: { min: 4,  max: 90,  unit: 'px', id: 'GradReach' }    // how far from the edge it reaches
};
const LQ_GLASS_KEYS = Object.keys(LQ_GLASS_FIELDS).filter(k => !LQ_GLASS_GRAD.includes(k));      // the ones with a slider
// The pull (px, toward the middle of the glass, so the rim shows what lies further in) at distance s from the edge is
//   INNER  base * u^k          u = 1 - s / (Inner radius), k from Inner curve (k = 1 + curve * LQ_GX_K_PER)
//   OUTER  base * L * v^6      v = 1 - s / (Outer radius), L from Outer distortion (0 .. LQ_GX_OUTER_MAX)
//   EDGE   edgePx * w^3        w = 1 - s / LQ_GX_EDGE_W, a hair thin band on the rim
// base = Inner distortion * LQ_GX_BASE px. INNER and OUTER are smoothed a little (LQ_GX_SIGMA) so the corners do not tear; EDGE is not.
const LQ_GX_RIMBLUR_AREA = 9000;         // only a piece this small (px2) gets the soft rim blur: on a big one it costs too much on every frame
const LQ_GX_BASE = 0.45;             // px of pull on the rim per % of Inner distortion
const LQ_GX_K_PER = 0.0371;          // Inner curve 62% gives k = 3.3, the shape of the 3.10 glass
const LQ_GX_OUTER_MAX = 2;           // Outer distortion 100% = the rim bends (1 + this) times as much as the inside
const LQ_GX_EDGE_PX = 6;             // px of pull of the hair thin band at Edge distortion 100%
const LQ_GX_EDGE_W = 3;              // width (px) of that band
const LQ_GX_SIGMA = 1.5;             // px: how much the map is smoothed
const LQ_GLASS_PRESETS = {
    reference: { lipw: 22, distort: 72, bezel: 22, curve: 62, lip: 45, edge: 20, split: 0,  blur: 3,  frost: 16, sat: 150, gradSolid: 60, gradSoft: 65, gradReach: 34 },
    clear:     { lipw: 16, distort: 56, bezel: 16, curve: 48, lip: 34, edge: 15, split: 0,  blur: 0,  frost: 6,  sat: 130, gradSolid: 60, gradSoft: 65, gradReach: 34 },
    frosted:   { lipw: 24, distort: 34, bezel: 24, curve: 30, lip: 23, edge: 12, split: 0,  blur: 14, frost: 46, sat: 180, gradSolid: 60, gradSoft: 65, gradReach: 34 },
    prism:     { lipw: 24, distort: 78, bezel: 24, curve: 66, lip: 53, edge: 25, split: 55, blur: 2,  frost: 12, sat: 160, gradSolid: 60, gradSoft: 65, gradReach: 34 }
};
const UI_GLASS_DEFAULT = { on: false, grad: true, ...LQ_GLASS_PRESETS.reference };
let lqGlassCfg = { ...UI_GLASS_DEFAULT };
let lqGlassNavCfg = { ...UI_GLASS_DEFAULT };      // values only; whether the nav is glass is lqNavCfg.glass
// Frosted Glass: the Surface on its own (blur, frost, colour and the merge gradient), no refraction, so any WebView with backdrop blur
// can show it. It has its own values and its own page; it and Liquid Glass turn each other off, so only one of them is ever applied.
const UI_FROST_KEY = 'lq_ui_frost_v1';
// The toasts and the bottom nav each have their own switch and their own blur, frost and saturation; the merge gradient belongs to the toast side
// (it is the toast's and the neck's colour).
const LQ_FROST_KEYS = ['blur', 'frost', 'sat'];      // the toast side
const LQ_FROST_NAV_KEYS = ['blur', 'frost', 'sat'];      // the nav side
const UI_FROST_DEFAULT = {
    toast: { on: false, grad: true, ...LQ_GRAD_FIXED, ...Object.fromEntries(LQ_FROST_KEYS.map(k => [k, LQ_GLASS_PRESETS.reference[k]])) },
    nav: { on: false, ...Object.fromEntries(LQ_FROST_NAV_KEYS.map(k => [k, LQ_GLASS_PRESETS.reference[k]])) }
};
let lqFrostCfg = JSON.parse(JSON.stringify(UI_FROST_DEFAULT));
// "Outer distortion" (lip) adds extra push on the outermost rim only, which is what draws the glass border: the push on the rim is
// (1 + e) times the inner push, e = 0..LQ_GX_OUTER_MAX. The map holds (inner + e * rim) / (1 + e) and the filter scale is the
// inner push times (1 + e), so the inside keeps its own strength whatever the multiple is (and the 8 bit map never clips).
function lqGlassLipE(cfg) { return Math.max(0, Math.min(100, Number(cfg && cfg.lip) || 0)) / 100 * LQ_GX_OUTER_MAX; }      // L: 0..2, how many times more the rim bends than the inside
let lqGlassSupported = null;
let lqGpOnRadius = null;     // set by the preview in the Liquid Glass card

function lqGlassNormalize(raw) {
    const o = raw && typeof raw === 'object' ? raw : {};
    const out = { on: o.on === true, grad: true, ...LQ_GRAD_FIXED };      // the merge gradient is fixed (whatever an older save holds)
    LQ_GLASS_KEYS.forEach(k => {
        const f = LQ_GLASS_FIELDS[k], n = Number(o[k]);
        out[k] = Number.isFinite(n) ? Math.min(f.max, Math.max(f.min, Math.round(n))) : UI_GLASS_DEFAULT[k];
    });
    if (!Number.isFinite(Number(o.lipw)) && Number.isFinite(Number(o.bezel))) out.lipw = Math.min(LQ_GLASS_FIELDS.lipw.max, Math.max(LQ_GLASS_FIELDS.lipw.min, Math.round(Number(o.bezel))));
    return out;
}

// The fill of the frosted glass for a Frost value: the same as it always was up to 90% (value * 0.009), and the last 10% carries on to a
// fully solid fill at 100%. It used to stop at 0.9, so the slider at 100% still let the picture through.
function lqFrostTint(f) {
    f = Math.max(0, Math.min(100, Number(f) || 0));
    return f <= 90 ? f * 0.009 : 0.81 + (f - 90) * 0.019;
}
function lqFrostNormalize(raw) {
    const o = raw && typeof raw === 'object' ? raw : {};
    // the first shape was one set of values for both: it becomes the toast side, and the nav side starts from the same blur, frost and saturation
    const flat = !o.toast && !o.nav;
    const side = (src, keys, def, withGrad) => {
        const r = src && typeof src === 'object' ? src : {};
        const out = { on: r.on === true };
        if (withGrad) Object.assign(out, { grad: true }, LQ_GRAD_FIXED);
        keys.forEach(k => {
            const f = LQ_GLASS_FIELDS[k], n = Number(r[k]);
            out[k] = Number.isFinite(n) ? Math.min(f.max, Math.max(f.min, Math.round(n))) : def[k];
        });
        return out;
    };
    return {
        toast: side(flat ? o : o.toast, LQ_FROST_KEYS, UI_FROST_DEFAULT.toast, true),
        nav: side(flat ? o : o.nav, LQ_FROST_NAV_KEYS, UI_FROST_DEFAULT.nav, false)
    };
}
function lqFrostLoad() {
    try {
        const raw = localStorage.getItem(UI_FROST_KEY);
        if (raw) return lqFrostNormalize(JSON.parse(raw));
        // first run after the split: the old "Use without glass" switch of Liquid Glass becomes Frosted Glass, with the values it was using
        const old = JSON.parse(localStorage.getItem(UI_GLASS_KEY) || 'null');
        if (old && old.surf === true && old.on !== true) return lqFrostNormalize({ ...old, on: true });
    } catch (_) {}
    return JSON.parse(JSON.stringify(UI_FROST_DEFAULT));
}
function lqFrostSave() {
    try { localStorage.setItem(UI_FROST_KEY, JSON.stringify(lqFrostCfg)); } catch (_) {}
    lqMirrorUIPrefs();
}

function lqGlassLoad() {
    try {
        const raw = localStorage.getItem(UI_GLASS_KEY);
        return raw ? lqGlassNormalize(JSON.parse(raw)) : { ...UI_GLASS_DEFAULT };
    } catch (_) {
        return { ...UI_GLASS_DEFAULT };
    }
}

function lqGlassNavLoad() {
    try {
        const raw = localStorage.getItem(UI_GLASS_NAV_KEY);
        if (raw) return lqGlassNormalize(JSON.parse(raw));
    } catch (_) {}
    return lqGlassLoad();      // first run after the split: the nav starts from the values it was sharing with the toasts
}

function lqGlassSave() {
    try { localStorage.setItem(UI_GLASS_KEY, JSON.stringify(lqGlassCfg)); } catch (_) {}
    try { localStorage.setItem(UI_GLASS_NAV_KEY, JSON.stringify(lqGlassNavCfg)); } catch (_) {}
    lqMirrorUIPrefs();
}

// ── Liquid glass: a displacement map that really bends what is behind ──────────────────────────────────────────────────
// The map of a w x h rounded box is drawn on a 2D canvas (lqGxMapURL): red = sideways push, green = up/down push (128 = no push),
// blue = how deep in the rim band (the soft rim blur is laid over it). An SVG filter (feImage + feDisplacementMap) inside
// backdrop-filter uses it, so the page behind the glass is bent for real. Needs a Chromium style WebView for the filter, nothing else.
const LQ_GX_VS = 'attribute vec2 aPos; void main() { gl_Position = vec4(aPos, 0.0, 1.0); }';
// the moving card's canvas shares these: the glass has no rim light, so lqRim is empty (the edge is the bend, see above)
const LQ_GX_RIM = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec4 uP;
uniform vec2 uQ;      // x: unused, y: 1 = glass / 0 = the plain faint rim of a solid card
vec4 lqRim(float depth, vec2 n) { return vec4(0.0); }
`;
function lqGxProgram(gl, vs, fs) {
    const mk = (type, src) => {
        const s = gl.createShader(type);
        gl.shaderSource(s, src);
        gl.compileShader(s);
        if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
        return s;
    };
    const prog = gl.createProgram();
    gl.attachShader(prog, mk(gl.VERTEX_SHADER, vs));
    gl.attachShader(prog, mk(gl.FRAGMENT_SHADER, fs));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
    return prog;
}
function lqGxQuad(gl, prog) {
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const ap = gl.getAttribLocation(prog, 'aPos');
    gl.enableVertexAttribArray(ap);
    gl.vertexAttribPointer(ap, 2, gl.FLOAT, false, 0, 0);
}
// draft: a slider is being dragged; the map has no heavy part any more, so this only tells the nav to remake it with the slider
const LQ_GX = { maps: new Map(), draft: false, draftT: 0 };
function lqGxDraft(done) {
    LQ_GX.draft = true;
    clearTimeout(LQ_GX.draftT);
    LQ_GX.draftT = setTimeout(() => { LQ_GX.draft = false; if (done) done(); }, 260);
}
// what the map and the filter need from the Liquid Glass settings; `sc` scales the edge width (a docked bar's Height setting).
function lqGxParams(cfg = lqGlassCfg, sc = 1) {
    const bezel = Math.max(2, cfg.bezel * sc), ow = Math.max(2, (Number.isFinite(cfg.lipw) ? cfg.lipw : cfg.bezel) * sc), str = Math.max(0, Math.min(1.2, cfg.distort / 100));
    const k = 1 + Math.max(0, Math.min(100, Number(cfg.curve) || 0)) * LQ_GX_K_PER;
    return {
        bezel, ow,
        curve: k,                                                                 // exponent of the inner pull
        k,
        lip: lqGlassLipE(cfg),                                                    // L, 0..LQ_GX_OUTER_MAX
        edge: Math.max(0, Math.min(100, Number(cfg.edge) || 0)) / 100,
        inner: 0,
        str,
        split: (cfg.split / 100) * 1.6
    };
}
// The displacement field of a w x h box with corner radius `rad`, as RGBA bytes. p: { bezel, ow, k, base, L, edgePx, off }.
// off (px) is the most a pixel can move, so every vector fits the 8 bit map; the filter scale is 2 * off.
function lqGxField(w, h, rad, p) {
    const N = w * h, hx = w / 2, hy = h / 2;
    const fx = new Float32Array(N), fy = new Float32Array(N), ex = new Float32Array(N), ey = new Float32Array(N), rw = new Uint8ClampedArray(N);
    const bz = p.bezel, ow = p.ow, k = p.k, base = p.base, L = p.L, ep = p.edgePx, off = p.off;
    const rwDen = 1.15 * bz;
    for (let py = 0; py < h; py++) {
        for (let px = 0; px < w; px++) {
            const cx = px + 0.5 - hx, cy = py + 0.5 - hy;
            const qx = Math.abs(cx) - (hx - rad), qy = Math.abs(cy) - (hy - rad);
            const ox = Math.max(qx, 0), oy = Math.max(qy, 0), out = Math.hypot(ox, oy);
            const s = Math.max(0, rad - out - Math.min(Math.max(qx, qy), 0));           // distance in from the edge
            let nx = 0, ny = 0;
            if (out > 0) { nx = (cx < 0 ? -ox : ox) / out; ny = (cy < 0 ? -oy : oy) / out; }
            else if (qx > qy) nx = cx < 0 ? -1 : 1;
            else ny = cy < 0 ? -1 : 1;
            const u = 1 - s / bz, v = 1 - s / ow, e = 1 - s / LQ_GX_EDGE_W;
            const m = (u > 0 ? base * Math.pow(u, k) : 0) + (v > 0 ? base * L * Math.pow(v, 6) : 0);
            const i = py * w + px;
            fx[i] = -nx * m / off; fy[i] = -ny * m / off;
            if (e > 0 && ep > 0) { const me = ep * e * e * e / off; ex[i] = -nx * me; ey[i] = -ny * me; }
            const r = 1 - s / rwDen;
            rw[i] = r > 0 ? 255 * Math.pow(r, 1.4) : 0;
        }
    }
    // a light gaussian over the inner and outer pull (not over the hair thin edge band) so the corners do not tear
    const KR = 4, ker = [];
    let ksum = 0;
    for (let i = -KR; i <= KR; i++) { const q = Math.exp(-(i * i) / (2 * LQ_GX_SIGMA * LQ_GX_SIGMA)); ker.push(q); ksum += q; }
    for (let i = 0; i < ker.length; i++) ker[i] /= ksum;
    const blur = src => {
        const tmp = new Float32Array(N), dst = new Float32Array(N);
        for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
            let a = 0;
            for (let q = -KR; q <= KR; q++) a += src[y * w + Math.min(w - 1, Math.max(0, x + q))] * ker[q + KR];
            tmp[y * w + x] = a;
        }
        for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
            let a = 0;
            for (let q = -KR; q <= KR; q++) a += tmp[Math.min(h - 1, Math.max(0, y + q)) * w + x] * ker[q + KR];
            dst[y * w + x] = a;
        }
        return dst;
    };
    const bx = blur(fx), by = blur(fy), data = new Uint8ClampedArray(N * 4);
    for (let i = 0; i < N; i++) {
        data[i * 4] = 128 + 127 * Math.max(-1, Math.min(1, bx[i] + ex[i]));
        data[i * 4 + 1] = 128 + 127 * Math.max(-1, Math.min(1, by[i] + ey[i]));
        data[i * 4 + 2] = rw[i];
        data[i * 4 + 3] = 255;
    }
    return data;
}
// The displacement map of a w x h box with corner radius `rad`, as a PNG data url (cached by size and shape).
function lqGxMapURL(w, h, rad, p) {
    w = Math.max(8, Math.round(w)); h = Math.max(8, Math.round(h));
    rad = Math.max(0, Math.min(rad, w / 2, h / 2));
    const key = [w, h, Math.round(rad * 10), p.bezel.toFixed(2), p.ow.toFixed(2), p.k.toFixed(3), p.base.toFixed(2), p.L.toFixed(3), p.edgePx.toFixed(2)].join('|');
    const hit = LQ_GX.maps.get(key);
    if (hit) { LQ_GX.maps.delete(key); LQ_GX.maps.set(key, hit); return hit; }
    try {
        const cv = document.createElement('canvas');
        cv.width = w; cv.height = h;
        const ctx = cv.getContext('2d');
        if (!ctx) return '';
        const img = ctx.createImageData(w, h);
        img.data.set(lqGxField(w, h, rad, p));
        ctx.putImageData(img, 0, 0);
        const url = cv.toDataURL('image/png');
        if (!url || url.length < 40) return '';
        LQ_GX.maps.set(key, url);
        while (LQ_GX.maps.size > 24) LQ_GX.maps.delete(LQ_GX.maps.keys().next().value);
        return url;
    } catch (_) { return ''; }
}

// ── the SVG filters that use the maps ──
// One filter per glass piece: lqf-toast (the real toasts), lqf-bar and lqf-lens (the nav), lqf-gt / lqf-gbar / lqf-glens (the same
// three on the Liquid Glass page stage, driven by the pending values) and one lqf-b<N> for each card while it moves. A filter is
// feImage (the map) -> feDisplacementMap; with Color split above 0 it is three displacement passes, one per colour channel,
// pushed a little differently, and added back together.
const LQ_SVGNS = 'http://www.w3.org/2000/svg';
const LQ_GXF = new Map();          // id -> { el, img, disp, sp, S, ca, o }
const LQ_GXK = new Map();          // id -> how much of the bend is on (0..1), kept so a filter made later starts at the right amount
const LQ_GX_IDS = ['lqf-toast', 'lqf-bar', 'lqf-lens', 'lqf-gt', 'lqf-gbar', 'lqf-glens'];
function lqSv(tag, attrs) {
    const e = document.createElementNS(LQ_SVGNS, tag);
    for (const k in attrs) e.setAttribute(k, attrs[k]);
    return e;
}
function lqGxDefs() {
    let s = document.getElementById('lqGxDefs');
    if (!s) {
        s = lqSv('svg', { id: 'lqGxDefs', width: '0', height: '0', 'aria-hidden': 'true' });
        s.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden;pointer-events:none';
        s.appendChild(lqSv('defs', {}));
        (document.body || document.documentElement).appendChild(s);
    }
    return s.firstChild;
}
function lqGxEnsure() {       // a plain pass-through filter for every id, so a css rule never points at nothing
    const defs = lqGxDefs();
    LQ_GX_IDS.forEach(id => {
        if (LQ_GXF.has(id)) return;
        const f = lqSv('filter', { id });
        f.appendChild(lqSv('feOffset', { dx: '0', dy: '0' }));
        defs.appendChild(f);
        LQ_GXF.set(id, { el: f, img: null, disp: [], sp: -1, S: 0, ca: 0, o: null });
    });
}
function lqGxScaleApply(id) {
    const r = LQ_GXF.get(id);
    if (!r || !r.disp.length) return;
    const k = LQ_GXK.has(id) ? LQ_GXK.get(id) : 1, s = r.S * k, f = v => Math.max(0, v).toFixed(2);
    if (!r.sp) r.disp[0].setAttribute('scale', f(s));
    else {
        r.disp[0].setAttribute('scale', f(s * (1 + r.ca)));
        r.disp[1].setAttribute('scale', f(s));
        r.disp[2].setAttribute('scale', f(s * (1 - r.ca)));
    }
}
// o: { url, w, h, off, split }. The map is placed at 0,0 and stretched to w x h unless the caller places it itself (lqGxPlace).
function lqGxFilter(id, o) {
    const defs = lqGxDefs();
    const sp = o.split > 0.02 ? 1 : 0;
    let r = LQ_GXF.get(id);
    const rbOn = !o.free && o.w * o.h <= LQ_GX_RIMBLUR_AREA;
    if (!r || r.sp !== sp || r.rbOn !== rbOn) {
        if (r) r.el.remove();
        const f = lqSv('filter', { id, x: '0', y: '0', width: '1', height: '1', filterUnits: 'objectBoundingBox', primitiveUnits: 'userSpaceOnUse', 'color-interpolation-filters': 'sRGB' });
        // outside the map (a moving body is bigger than its card) the push is none: a neutral grey under the map. Without it the
        // part of the body that is not the card (the neck) was pushed sideways by the empty map and looked like another material.
        const img = lqSv('feImage', { x: '0', y: '0', width: String(o.w), height: String(o.h), preserveAspectRatio: 'none', result: o.free ? 'mi' : 'm' });
        if (o.free) f.appendChild(lqSv('feFlood', { 'flood-color': 'rgb(128,128,0)', 'flood-opacity': '1', result: 'n' }));
        f.appendChild(img);
        if (o.free) f.appendChild(lqSv('feComposite', { in: 'mi', in2: 'n', operator: 'over', result: 'm' }));
        const disp = [];
        const mk = res => {
            const d = lqSv('feDisplacementMap', { in: 'SourceGraphic', in2: 'm', scale: '0', xChannelSelector: 'R', yChannelSelector: 'G' });
            if (res) d.setAttribute('result', res);
            disp.push(d); f.appendChild(d);
        };
        if (!sp) mk();
        else {
            const keep = { R: '1 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0', G: '0 0 0 0 0  0 1 0 0 0  0 0 0 0 0  0 0 0 1 0', B: '0 0 0 0 0  0 0 0 0 0  0 0 1 0 0  0 0 0 1 0' };
            ['R', 'G', 'B'].forEach(c => { mk('d' + c); f.appendChild(lqSv('feColorMatrix', { in: 'd' + c, type: 'matrix', values: keep[c], result: 'c' + c })); });
            f.appendChild(lqSv('feComposite', { in: 'cR', in2: 'cG', operator: 'arithmetic', k1: '0', k2: '1', k3: '1', k4: '0', result: 'cRG' }));
            f.appendChild(lqSv('feComposite', { in: 'cRG', in2: 'cB', operator: 'arithmetic', k1: '0', k2: '1', k3: '1', k4: '0', result: 'd' }));
        }
        if (!sp) disp[0].setAttribute('result', 'd');
        // Soft rim, the middle way: the rim of real glass is soft (smeared) while the middle stays sharp. A blurred copy of the bent picture is
        // laid over it, weighted by the map's blue channel (1 at the rim, 0 inside). Blurring a whole big piece costs about three quarters of the
        // filter on every frame, so only a small piece (the lens, about 5000 px2) gets it; a wide bar and the toasts keep a sharp, evenly
        // smeared rim, which is already soft because the picture there is stretched many times over.
        const rb = [];
        if (rbOn) {
            const e = lqSv('feGaussianBlur', { in: 'd', stdDeviation: '1', result: 'b' }); f.appendChild(e); rb.push(e);
            f.appendChild(lqSv('feColorMatrix', { in: 'm', type: 'matrix', values: '0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 1 0 0', result: 'w' }));
            f.appendChild(lqSv('feComposite', { in: 'b', in2: 'w', operator: 'in', result: 'bm' }));
            f.appendChild(lqSv('feComposite', { in: 'bm', in2: 'd', operator: 'over' }));
        }
        defs.appendChild(f);
        r = { el: f, img, disp, rb, rbOn, sp, S: 0, ca: 0, o: null, url: '' };
        LQ_GXF.set(id, r);
    }
    if (r.url !== o.url) { r.img.setAttribute('href', o.url); r.url = o.url; }
    if (!o.free) {
        r.img.setAttribute('width', String(o.w)); r.img.setAttribute('height', String(o.h));
    }
    r.S = 2 * Math.max(0, o.off);
    if (r.rb && r.rb[0]) r.rb[0].setAttribute('stdDeviation', Math.max(0.6, o.rim || 1).toFixed(2));
    r.ca = Math.min(0.3, 0.1 * (o.split || 0));
    r.o = o;
    lqGxScaleApply(id);
    return r;
}
// bakes the map for a w x h box and (re)builds the filter `id` with it
function lqGxBake(id, w, h, rad, p) {
    const m = 0.42 * Math.min(w, h);                                            // a small piece (the lens) gets narrower bands
    const bz = Math.max(2, Math.min(p.bezel, m)), ow = Math.max(2, Math.min(p.ow || p.bezel, m));
    const base = LQ_GX_BASE * 100 * Math.max(0, p.str || 0);                    // px of inner pull on the rim
    const L = Math.max(0, p.lip || 0), edgePx = LQ_GX_EDGE_PX * Math.max(0, Math.min(1, p.edge || 0));
    const off = Math.max(1e-3, base * (1 + L) + edgePx);                        // the most a pixel moves, in px
    const q = { ...p, bezel: bz, ow, k: p.k || p.curve || 3.3, base, L, edgePx, off };
    // while a slider is being dragged the map is made at half size (a quarter of the pixels to compute, encode and decode); the filter stretches
    // it over the same box, and the full size one is made once the finger stops
    const ds = (LQ_GX.draft && w * h > 6000) ? 0.5 : 1;
    const url = ds < 1 ? lqGxMapURL(w * ds, h * ds, rad * ds, { ...q, bezel: bz * ds, ow: ow * ds }) : lqGxMapURL(w, h, rad, q);
    if (!url) return false;
    lqGxFilter(id, { url, w: Math.round(w), h: Math.round(h), off, split: q.split, rim: Math.max(0.8, Math.min(1.8, bz * 0.07)), rad: Math.min(rad, w / 2, h / 2) });
    return true;
}
// how much of the bend is on, for the filters of the nav while the bar morphs from solid into glass
function lqGxK(ids, k) {
    ids.forEach(id => { LQ_GXK.set(id, k); lqGxScaleApply(id); });
}
// puts the map somewhere inside the box (a moving card's filter follows the card inside its sheet)
function lqGxPlace(id, x, y, w, h) {
    const r = LQ_GXF.get(id);
    if (!r || !r.img) return;
    const key = x.toFixed(1) + '|' + y.toFixed(1) + '|' + w.toFixed(1) + '|' + h.toFixed(1);
    if (r.pl === key) return;
    r.pl = key;
    r.img.setAttribute('x', x.toFixed(2)); r.img.setAttribute('y', y.toFixed(2));
    r.img.setAttribute('width', w.toFixed(2)); r.img.setAttribute('height', h.toFixed(2));
}
function lqGxDrop(id) {
    const r = LQ_GXF.get(id);
    if (r) { r.el.remove(); LQ_GXF.delete(id); }
    LQ_GXK.delete(id);
}

// Can this WebView draw the glass? It needs an SVG filter inside backdrop blur (any Chromium based WebView: Android System WebView,
// Chrome, Edge, Samsung Internet and the like), color-mix (the surface) and a 2D canvas to draw the map on. No WebGL. The check
// looks at what the browser really keeps of the value, not only at what parses. lqGlassWhy tells the person what is missing.
let lqGlassWhy = '';
function lqGlassProbe() {
    const no = why => { lqGlassWhy = why; return false; };
    try {
        if (!(window.CSS && CSS.supports)) return no('This WebView is too old');
        const ua = navigator.userAgent || '';
        if (/Firefox\/|FxiOS|Gecko\/\d+.*Firefox/.test(ua) || /\b(iPhone|iPad|iPod)\b/.test(ua)) return no('This WebView cannot bend what is behind the glass (it needs a Chromium WebView)');
        if (typeof SVGFEDisplacementMapElement !== 'function' || typeof SVGFEImageElement !== 'function') return no('No SVG displacement filter in this WebView');
        if (!CSS.supports('background', 'color-mix(in srgb, red 50%, transparent)')) return no('No color-mix in this WebView');
        const el = document.createElement('div');
        el.setAttribute('aria-hidden', 'true');
        el.style.cssText = 'position:fixed;left:-99px;top:-99px;width:8px;height:8px;pointer-events:none;'
            + '-webkit-backdrop-filter:blur(2px) url(#lqProbe) saturate(1.5);backdrop-filter:blur(2px) url(#lqProbe) saturate(1.5)';
        (document.body || document.documentElement).appendChild(el);
        const cs = getComputedStyle(el), v = cs.backdropFilter || cs.webkitBackdropFilter || '';
        el.remove();
        if (!/url\(/.test(v)) return no('No SVG filter inside backdrop blur in this WebView');
        // really draws a small map on a canvas and reads it back
        const url = lqGxMapURL(24, 24, 12, { bezel: 8, ow: 8, k: 3.3, base: 10, L: 1, edgePx: 2, off: 22 });
        if (!String(url).startsWith('data:image/png')) return no('No canvas in this WebView');
        lqGlassWhy = '';
        return true;
    } catch (_) {
        return no('This WebView cannot draw it');
    }
}
function lqGlassCanRender() {
    if (lqGlassSupported === null) lqGlassSupported = lqGlassProbe();
    return lqGlassSupported;
}
// The plain surface (blur + frost + colour, no glass edge) only needs backdrop blur.
function lqSurfCanRender() {
    try { return !!(window.CSS && CSS.supports && (CSS.supports('backdrop-filter', 'blur(2px)') || CSS.supports('-webkit-backdrop-filter', 'blur(2px)'))); } catch (_) { return false; }
}
// Frosted Glass on the toasts (and Liquid Glass is not: if both were ever saved on, Liquid Glass wins) / on the bottom nav
const lqFrostToastOn = () => !!lqFrostCfg.toast.on && !lqGlassCfg.on && lqSurfCanRender();
const lqFrostNavOn = () => !!lqFrostCfg.nav.on && !lqGlassNavLiquidFlag() && lqSurfCanRender();      // Liquid on the bar wins, whatever an old save holds
// the numbers the toast side of the surface (blur, frost, saturation, merge gradient) is drawn with
const lqSurfCfg = () => (lqFrostToastOn() ? lqFrostCfg.toast : lqGlassCfg);

// The glass of a toast (312 x 64, corner radius follows the UI radius). `host` is the page, or the stage in the card.
function lqGxToastRim(cfg = lqGlassCfg, host = document.documentElement) {
    const r = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--r'));
    const rad = Math.max(0, Math.min(Number.isFinite(r) ? r : 28, 26));
    lqGxBake(host === document.documentElement ? 'lqf-toast' : 'lqf-gt', 312, LQ_TOAST_H, rad, lqGxParams(cfg));
}

function lqGlassOnRadius() {
    if (document.documentElement.classList.contains('lq-glass-on')) lqGxToastRim();
    if (lqGpOnRadius) lqGpOnRadius();
}

// The merge gradient: the surface colour laid over the glass where the card and the bar meet, solid at the edge and fading out
// inward. The bar has it from its top edge down, the card from its bottom edge up (the way to the bar), and the neck is made of the
// same colour at the same solidity, so the three read as one liquid without switching the glass off. dir: 180deg or 0deg.
function lqGradStops(c) {
    const solid = Math.max(0, Math.min(1, c.gradSolid / 100)), soft = Math.max(0, Math.min(1, c.gradSoft / 100)), t0 = (1 - soft) * 0.85, st = [];
    for (let i = 0; i <= 6; i++) {
        const t = i / 6, w = t <= t0 ? 0 : (t - t0) / (1 - t0);
        st.push([t, solid * (1 - w * w * (3 - 2 * w))]);        // alpha at distance t * reach from the edge
    }
    return st;
}
const lqSurfGradColor = a => `color-mix(in srgb, var(--m3-card-bg, var(--s0)) ${(a * 100).toFixed(1)}%, transparent)`;
const lqGradColor = a => `color-mix(in srgb, var(--m3-card-bg, var(--s0)) ${(a * 100).toFixed(1)}%, transparent)`;
function lqGradCss(c, dir) {
    if (!c.grad || c.gradSolid < 1) return 'none';
    return `linear-gradient(${dir}, ${lqGradStops(c).map(([t, a]) => `${lqGradColor(a)} ${(c.gradReach * t).toFixed(1)}px`).join(', ')})`;
}
const lqGradOn = () => !!lqSurfCfg().grad && lqSurfCfg().gradSolid >= 1 && (document.documentElement.classList.contains('lq-glass-on') || document.documentElement.classList.contains('lq-surf-on'));
function lqGlassApply({ persist = false } = {}) {
    const root = document.documentElement;
    // a side is Liquid or Frosted, never both (an old save, or a restore, could hold both on)
    if (lqGlassCfg.on && lqFrostCfg.toast.on) lqFrostCfg.toast = { ...lqFrostCfg.toast, on: false };
    if (lqNavInited && lqGlassNavLiquidFlag() && lqFrostCfg.nav.on) lqFrostCfg.nav = { ...lqFrostCfg.nav, on: false };
    const c = lqGlassCfg;
    const want = c.on && lqGlassCanRender();
    if (want) lqGxEnsure();
    root.classList.toggle('lq-glass-on', want);
    root.classList.toggle('lq-surf-on', lqFrostToastOn());      // Frosted Glass on the toasts: blur, frost and colour, no glass edge
    const sc = lqSurfCfg();      // blur, frost, saturation and the merge gradient come from whichever of the two is applied
    root.style.setProperty('--lq-glass-blur', `${sc.blur}px`);
    root.style.setProperty('--lq-glass-bezel', `${c.bezel}px`);
    root.style.setProperty('--lq-glass-tint', String((lqFrostToastOn() ? lqFrostTint(sc.frost) : sc.frost * 0.009).toFixed(3)));
    root.style.setProperty('--lq-glass-sat', String((sc.sat / 100).toFixed(2)));
    root.classList.toggle('lq-grad', !!sc.grad && sc.gradSolid >= 1);
    root.style.setProperty('--lq-grad-up', lqGradCss(sc, '0deg'));
    // the bottom nav's own Liquid Glass values (the liquid nav rules read these, the toast's are only the fallback)
    const nl = lqGlassNavCfg;
    root.style.setProperty('--lq-lnav-blur', `${nl.blur}px`);
    root.style.setProperty('--lq-lnav-tint', String((nl.frost * 0.009).toFixed(3)));
    root.style.setProperty('--lq-lnav-sat', String((nl.sat / 100).toFixed(2)));
    // the bottom nav's own Frosted Glass values (the nav rules read these first and fall back to the toast's)
    if (lqFrostNavOn()) {
        const fn = lqFrostCfg.nav;
        root.style.setProperty('--lq-fnav-blur', `${fn.blur}px`);
        root.style.setProperty('--lq-fnav-tint', String(lqFrostTint(fn.frost).toFixed(3)));
        root.style.setProperty('--lq-fnav-sat', String((fn.sat / 100).toFixed(2)));
    } else ['--lq-fnav-blur', '--lq-fnav-tint', '--lq-fnav-sat'].forEach(v => root.style.removeProperty(v));
    if (want) { lqGxToastRim(); lqToastGlassWarmLater(); }
    if (persist) { lqGlassSave(); lqFrostSave(); }
    if (lqNavInited) lqNavApply();       // the iOS nav takes the same numbers
}

// The look is shown on a stage inside the card: the same toast element the app uses (same classes, so
// same size, blur, tint, rim), over the banner, with a copy of the bottom nav under it. Both are drawn at rest (no entrance, no stack);
// the copy of the bar changes tab with the same motion as the real bar. The glass on the stage is scoped to the stage and fed with the pending values.
const LQ_GP_SAMPLE = { title: 'Liquid glass', text: 'This is how a toast looks', state: 'ok' };
// One preview serves the Frosted and the Liquid card of the Glass effect page: which of the two it draws is decided by the config it is
// given (cfg.surf = frosted), so switching between them never rebuilds it and the stack, the bar and the stage keep their state.
function lqGlassPreviewCreate(stageId = 'frostStage', layerId = 'frostStageLayer') {
    const stage = document.getElementById(stageId), layer = document.getElementById(layerId);
    if (!stage || !layer) return null;
    let toast = null, lastCfg = null, lastWant = false, lastNavWant = false, lastNavSurf = false;
    let prevWant = null, prevNavWant = null, prevNavSurf = null, prevToastSurf = null;      // what the stage drew last, to tell when the look really changes
    // The stage is a tiny screen: the toast on top and, under it, the bottom nav in the style that is in use (Pill,
    // Capsule, Indicator bar or Material bar). With the nav switch on, a glass style is glass and follows the pending values.
    // The bar is a copy of the real one, so it has the shape of the style in use; these numbers follow its size (navMetrics).
    let TOAST_B = 84;
    let nav = null, navItems = [], navIdx = 0, navStageW = 0, navGeo = null, navGap = 12;
    let navMapKey = '';
    // the copy of the bar moves with the real bar's own engines (the sliding pill, the lens spring), each with a state of its own
    let navPS = null, navLens = null;

    // The copy of the bar sits at the bottom of the stage, under the toasts. Its size decides where the toasts rest.
    const navMetrics = () => {
        const d = LQ_NAV_STYLES[lqNavCfg.style] || LQ_NAV_STYLES.pill, g = lqNavGeom();
        navGap = d.dock ? 0 : 12;                                    // a docked bar sits flush with the bottom edge
        stage.classList.toggle('is-docked', !!d.dock);               // and flush with the sides (the stage's rounded corners cut it)
        const up = d.notch ? Math.round(52 * g.s * g.hk / 2) : 0;    // the Material bubble stands out above the bar
        const rest = parseFloat(getComputedStyle(layer).getPropertyValue('--toast-rest')) || 16;       // the same gap above the bar as the real toasts
        TOAST_B = Math.max(84, navGap + g.H + up + rest);
        stage.style.height = `${TOAST_B + 108}px`;
        layer.style.bottom = `${TOAST_B}px`;
    };

    // ── the nav copy (the same bar as the real one: same classes, same layout code, so it is always the style in use) ──
    // maps for the bar and the lens at the size of THIS style (the Capsule has both, the Material bar only the bubble)
    const navMaps = () => {
        const c = lastCfg && (lastCfg.navLq || lastCfg), geo = navGeo;
        if (!c || !nav || !geo || !geo.lw) return;
        const sc = lqNavGeom().s, p = lqGxParams(c, sc);
        const key = `${Math.round(geo.W)}x${geo.H}r${Math.round(geo.rad)}|${geo.lw}x${geo.lh}|${sc}|${c.bezel}|${c.curve}|${c.lip}|${c.edge}|${c.lipw}|${c.distort}|${c.split}|${LQ_GX.draft ? 1 : 0}`;
        if (key === navMapKey) return;
        lqGxEnsure();
        lqGxBake('lqf-gbar', Math.round(geo.W), geo.H, geo.rad, p);
        lqGxBake('lqf-glens', Math.round(geo.lw), Math.round(geo.lh), geo.lh / 2, p);
        navMapKey = key;
    };
    const navLensKind = geo => geo.d.ios ? 'ios' : (geo.notch ? 'notch' : 'material');
    const navLayout = () => {
        if (!nav || !navItems.length) return;
        navStageW = stage.clientWidth || 296;
        if (navPS.mode) lqPillFinish(navPS);          // a slide that is still running ends where it was going
        navGeo = lqNavCloneLayout(nav, navItems, navStageW, navIdx);
        navPS.p = navIdx; navPS.vw = navStageW;
        if (navGeo.d.tabs) {
            navLens.el = nav.querySelector('.nav-lens');
            lqNavLensConfig({ x: navGeo.minX + navIdx * navGeo.itemW, y: navGeo.ly, w: navGeo.lw, h: navGeo.lh, kind: navLensKind(navGeo), notch: navGeo.notch, snap: true }, navLens);
        }
    };
    // The surface on the bar follows the pending values, not the saved ones. Inline styles win over the html-level
    // rules, so this also undoes a saved surface when the switch in the card says off (and the other way round).
    const navLook = () => {
        if (!nav || !navGeo || !lastCfg) return;
        const d = navGeo.d;
        const surf = lastNavSurf;      // the bar's own mode (Frosted), not the toasts'
        const savedSurf = document.documentElement.classList.contains('lq-nav-surf');
        const blur = 'blur(var(--lq-fnav-blur, var(--lq-glass-blur, 4px))) saturate(var(--lq-fnav-sat, var(--lq-glass-sat, 1.5)))';
        if (d.notch) {      // Material bar: the switch is for the bubble only, the bar stays solid (and its pill gives up its own filter)
            const lens = nav.querySelector('.nav-lens');
            if (!lens) return;
            // value: undefined leaves the property alone, null removes the inline value, a string sets it
            const put = (el, k, v) => { if (v === undefined) return; if (v === null) el.style.removeProperty(k); else el.style.setProperty(k, v); };
            const set = (lbg, lsh, lbf, nbf, wc) => {
                put(lens, 'background', lbg); put(lens, 'box-shadow', lsh);
                put(lens, 'backdrop-filter', lbf); put(lens, '-webkit-backdrop-filter', lbf);
                put(nav, 'backdrop-filter', nbf); put(nav, '-webkit-backdrop-filter', nbf); put(nav, 'will-change', wc);
            };
            if (lastNavWant) set(null, null, null, null, null);      // glass on the bubble: the glass rules do it
            else if (surf) set('color-mix(in srgb, var(--ac-d) calc(var(--lq-fnav-tint, var(--lq-glass-tint, .14)) * 100%), transparent)', 'none', blur, 'none', 'transform');
            else if (savedSurf) set('var(--ac-d)', '0 6px 16px rgba(0,0,0,.28)', 'none', 'blur(14px) saturate(1.3)', 'transform, opacity');
            else set(null, null, null, null, null);
            return;
        }
        const bar = (d.glassBar && lastNavWant) ? null : nav;
        if (!bar) {
            // Liquid on the whole bar: the glass is its own layer inside the pill, and a backdrop filter left on the pill itself (from the Frosted
            // look) would make that layer see nothing to bend. So everything Frosted put on the pill goes.
            nav.style.removeProperty('background');
            nav.style.removeProperty('backdrop-filter'); nav.style.removeProperty('-webkit-backdrop-filter');
            return;
        }
        if (surf) {
            bar.style.background = 'color-mix(in srgb, var(--m3-card-bg, var(--s0)) calc(var(--lq-fnav-tint, var(--lq-glass-tint, .14)) * 100%), transparent)';
            bar.style.backdropFilter = blur; bar.style.webkitBackdropFilter = blur;
        } else if (savedSurf) {
            bar.style.background = 'var(--m3-card-bg, var(--s0))';
            bar.style.backdropFilter = 'none'; bar.style.webkitBackdropFilter = 'none';
        } else {
            bar.style.removeProperty('background');
            bar.style.removeProperty('backdrop-filter'); bar.style.removeProperty('-webkit-backdrop-filter');
        }
    };
    // a tap or a slide picks a tab with the real bar's own motion: the Pill slides on the bar's engine, the other styles carry the lens (or the
    // bubble, or the indicator) on the bar's spring, and the icon pops as it does on the bar
    const navSelect = i => {
        if (!nav || i === navIdx || !navItems[i] || !navGeo) return;
        navIdx = i;
        navItems.forEach((b, k) => b.classList.toggle('active', k === i));
        if (document.documentElement.classList.contains('lq-nav-ios')) lqNavPop(navItems[i]);
        const geo = navGeo;
        if (!geo.d.tabs) { lqNavLayoutPill(nav, navItems, true, navStageW, navPS); return; }
        lqNavLensConfig({ x: geo.minX + i * geo.itemW, y: geo.ly, w: geo.lw, h: geo.lh, kind: navLensKind(geo), notch: geo.notch, snap: false }, navLens);
    };
    const navBuild = () => {
        const real = document.getElementById('navPill');
        const src = real ? [...real.querySelectorAll('.nav-item')] : [];
        if (!src.length) return;
        nav = document.createElement('span');
        nav.className = 'nav-pill nav-in lq-gpn';       // (the stage's CSS keeps the bar from playing its entrance)
        nav.setAttribute('aria-hidden', 'true');
        nav.style.setProperty('--nav-gap', `${navGap}px`);
        navIdx = Math.max(0, src.findIndex(b => b.classList.contains('active')));
        navItems = src.map((b, i) => {
            const it = document.createElement('span');
            it.className = 'nav-item' + (i === navIdx ? ' active' : '');
            it.dataset.nav = b.dataset.nav;
            it.innerHTML = b.innerHTML;
            nav.appendChild(it);
            return it;
        });
        lqNavMakeLayers(nav);
        stage.appendChild(nav);
        navPS = lqPillStateNew(); navLens = lqNavLensNew();
        navLayout();
        lqGxK(['lqf-gbar', 'lqf-glens'], 1);
        const idxAt = e => {
            let best = 0, bd = Infinity;
            navItems.forEach((b, i) => {
                const r = b.getBoundingClientRect(), cx = r.left + r.width / 2, dd = Math.abs(e.clientX - cx);
                if (dd < bd) { bd = dd; best = i; }
            });
            return best;
        };
        let pressed = false;
        const lift = on => { if (navGeo && navGeo.d.tabs) lqNavLensPress(on, navLens); };
        nav.addEventListener('pointerdown', e => { pressed = true; try { nav.setPointerCapture(e.pointerId); } catch (_) {} lift(true); navSelect(idxAt(e)); });
        nav.addEventListener('pointermove', e => { if (pressed) navSelect(idxAt(e)); });
        const up = () => { if (!pressed) return; pressed = false; lift(false); };
        nav.addEventListener('pointerup', up);
        nav.addEventListener('pointercancel', up);
    };

    // ── the toast: one, at rest ──
    const build = () => {
        layer.textContent = '';
        const s = LQ_GP_SAMPLE;
        toast = document.createElement('div');
        toast.className = 'lq-toast';
        toast.dataset.state = s.state;
        toast.innerHTML = '<span class="lq-toast-icon"></span><span class="lq-toast-copy"><span class="lq-toast-title"></span><span class="lq-toast-text"></span></span><span class="lq-toast-more"></span><span class="lq-grad"></span><span class="lq-toast-rim"></span><span class="lq-toast-glow"><i class="lq-glow-ring"></i><i class="lq-glow-edge"></i></span>';
        toast.querySelector('.lq-toast-icon').innerHTML = LQ_TOAST_ICONS[s.state] || LQ_TOAST_ICONS.info;
        toast.querySelector('.lq-toast-title').textContent = s.title;
        toast.querySelector('.lq-toast-text').textContent = s.text;
        toast.style.setProperty('--ty', '0px');
        toast.style.setProperty('--tx', '0px');
        toast.style.setProperty('--s', '1');
        toast.style.setProperty('--o', '1');
        toast.style.setProperty('--dim', '0');
        layer.appendChild(toast);
    };

    // cfg (see lqGlassFxPreviewCfg): the toast values on top, toastMode / navMode ('liquid' | 'frost' | 'none') for what each side is drawn as,
    // navLq (the bar's Liquid values) and navFrost (the bar's Frosted values). The two sides are independent of each other.
    const apply = cfg => {
        lastCfg = cfg;
        const tm = cfg.toastMode, nm = cfg.navMode;
        lastWant = tm === 'liquid' && lqGlassCanRender();
        const toastSurf = tm === 'frost' && lqSurfCanRender();
        lastNavWant = nm === 'liquid' && !!LQ_NAV_STYLES[lqNavCfg.style]?.glass && lqGlassCanRender();     // what the real bar would be
        lastNavSurf = nm === 'frost' && lqSurfCanRender();
        const drawChanged = lastWant !== prevWant || lastNavWant !== prevNavWant || lastNavSurf !== prevNavSurf || toastSurf !== prevToastSurf;
        prevWant = lastWant; prevNavWant = lastNavWant; prevNavSurf = lastNavSurf; prevToastSurf = toastSurf;
        if (drawChanged && lqNavInited) {      // the bar's html classes follow the preview (see lqNavPreviewOverride)
            lqNavPreviewOverride = { glass: lastNavWant, surf: lastNavSurf };
            lqNavPreviewClasses();
        }
        stage.classList.toggle('is-glass', lastWant);
        stage.classList.toggle('is-nav-glass', lastNavWant);
        stage.classList.toggle('is-surf', toastSurf);
        stage.style.setProperty('--lq-glass-blur', `${cfg.blur}px`);
        stage.style.setProperty('--lq-glass-bezel', `${cfg.bezel}px`);
        stage.style.setProperty('--lq-glass-tint', String((toastSurf ? lqFrostTint(cfg.frost) : cfg.frost * 0.009).toFixed(3)));
        stage.style.setProperty('--lq-glass-sat', String((cfg.sat / 100).toFixed(2)));
        const nlq = cfg.navLq || cfg;      // the bar's own Liquid values
        stage.style.setProperty('--lq-lnav-blur', `${nlq.blur}px`);
        stage.style.setProperty('--lq-lnav-tint', String((nlq.frost * 0.009).toFixed(3)));
        stage.style.setProperty('--lq-lnav-sat', String((nlq.sat / 100).toFixed(2)));
        const fn = cfg.navFrost;      // the bar's own Frosted values
        if (fn) {
            stage.style.setProperty('--lq-fnav-blur', `${fn.blur}px`);
            stage.style.setProperty('--lq-fnav-tint', String(lqFrostTint(fn.frost).toFixed(3)));
            stage.style.setProperty('--lq-fnav-sat', String((fn.sat / 100).toFixed(2)));
        } else ['--lq-fnav-blur', '--lq-fnav-tint', '--lq-fnav-sat'].forEach(v => stage.style.removeProperty(v));
        stage.classList.toggle('is-grad', !!cfg.grad && cfg.gradSolid >= 1);
        stage.style.setProperty('--lq-grad-up', lqGradCss(cfg, '0deg'));
        if (nav) {
            if (stage.clientWidth && stage.clientWidth !== navStageW) navLayout();
            navLook();
        }
        if (drawChanged) { clearTimeout(mapT); mapT = 0; mapLast = performance.now(); mapsNow(); }      // a switch of look is drawn at once, not after the slider debounce
        else mapsSoon();
    };
    // Building a map (pixels + PNG) for the toast, the bar and the lens is the heavy part of dragging a slider.
    // The first call runs right away, the ones that follow while the finger is still moving are merged into one.
    let mapT = 0, mapLast = 0, openT = 0;
    // The sliders are under the stage: while it is scrolled out of sight nothing of it can be seen, so it does no work at all (no maps
    // are made and its glass filters are off); when it comes back into view the latest values are made once.
    let vis = true, mapDirty = false;
    if ('IntersectionObserver' in window) {
        new IntersectionObserver(es => {
            const v = es[es.length - 1].isIntersecting;
            if (v === vis) return;
            vis = v;
            stage.classList.toggle('is-paused', !v);
            if (v && mapDirty) { mapDirty = false; mapsNow(); }
        }, { rootMargin: '120px 0px' }).observe(stage);
    }
    document.addEventListener('visibilitychange', () => { stage.classList.toggle('is-paused', document.hidden || !vis); if (!document.hidden && vis && mapDirty) { mapDirty = false; mapsNow(); } }, { passive: true });
    // the toast's map is only made again when its values changed (the page opening again with the same look makes nothing)
    let toastKey = '';
    const toastMaps = () => {
        const c = lastCfg;
        if (!c) return;
        const key = `${c.bezel}|${c.curve}|${c.lip}|${c.edge}|${c.lipw}|${c.distort}|${c.split}|${LQ_GX.draft ? 1 : 0}|${getComputedStyle(document.documentElement).getPropertyValue('--r')}`;
        if (key === toastKey) return;
        lqGxToastRim(c, stage);
        toastKey = key;
    };
    const mapsNow = force => {
        if (!force && (document.hidden || !vis)) { mapDirty = true; return; }
        if (lastWant && lastCfg) toastMaps();
        if (nav && lastNavWant) navMaps();
    };
    const mapsSoon = () => {
        const now = performance.now();
        if (!mapT && now - mapLast > 200) { mapLast = now; mapsNow(); return; }
        clearTimeout(mapT);
        mapT = setTimeout(() => { mapT = 0; mapLast = performance.now(); mapsNow(); }, 200);
    };
    // The bar and the toast are built once, under the splash (lqGlassPreviewWarm), and stay built while the page is closed: a closed page is
    // display:none, so they are not drawn and cost nothing, and opening the page only shows what is already there. They are made again only when
    // what they are a copy of changed (the nav style / size, the text and icon scale, the corner radius).
    let builtSig = '';
    const sigNow = () => {
        const cs = getComputedStyle(document.documentElement);
        return JSON.stringify(lqNavCfg) + '|' + ['--lq-ts', '--lq-is', '--r-a', '--r'].map(k => cs.getPropertyValue(k)).join(',');
    };
    const destroy = () => {
        clearTimeout(mapT); mapT = 0; clearTimeout(openT);
        stage.classList.remove('is-opening');
        if (navPS && navPS.raf) cancelAnimationFrame(navPS.raf);
        if (navLens && navLens.raf) cancelAnimationFrame(navLens.raf);
        if (nav) nav.remove();
        nav = null; navItems = []; navGeo = null; navPS = null; navLens = null; navMapKey = ''; toastKey = '';
        layer.textContent = ''; toast = null;
    };
    const open = () => {
        if ((toast || nav) && builtSig !== sigNow()) destroy();
        if (toast || nav) {
            // already built: only follow the tab the real bar is on (no motion) and the stage's width. The look classes of the page flip back on in the
            // next frame (apply), and that must not be eased either.
            stage.classList.add('is-opening');
            clearTimeout(openT);
            openT = setTimeout(() => stage.classList.remove('is-opening'), 400);
            const real = document.querySelector('#navPill .nav-item.active');
            const i = real ? navItems.findIndex(b => b.dataset.nav === real.dataset.nav) : -1;
            if (i >= 0 && i !== navIdx) { navIdx = i; navItems.forEach((b, k) => b.classList.toggle('active', k === i)); navLayout(); }
            return;
        }
        // the bar and the toast are simply there: no easing into place while the stage is laid out (see .is-opening in the CSS)
        stage.classList.add('is-opening');
        navMetrics();
        navBuild();
        build();
        builtSig = sigNow();
        void stage.offsetWidth;
        clearTimeout(openT);
        openT = setTimeout(() => stage.classList.remove('is-opening'), 400);
    };
    // the page is left: the real bar goes back to its saved look, the stage keeps what it built
    const close = () => {
        prevWant = prevNavWant = prevNavSurf = prevToastSurf = null;
        if (lqNavPreviewOverride) { lqNavPreviewOverride = null; if (lqNavInited) lqNavApply(); }
        clearTimeout(mapT); mapT = 0;
    };
    // boot only: make the maps now even though the stage is not on screen
    const warmMaps = () => { clearTimeout(mapT); mapT = 0; mapDirty = false; mapsNow(true); };
    lqGpOnRadius = () => { toastKey = ''; if (lastWant && lastCfg) toastMaps(); };
    return { apply, open, close, warmMaps };
}

// Boot step: the Glass effect preview (the copy of the bar, the toast, their glass maps) is built while the splash is on screen, so opening the
// page only has to show it. The page is laid out for a moment (in flow, no height, hidden: .lq-prewarm) so the bar can be measured.
async function lqGlassPreviewWarm() {
    const frame = () => new Promise(r => requestAnimationFrame(() => r()));
    for (let i = 0; i < 30 && !lqNavInited; i++) await new Promise(r => setTimeout(r, 100));
    const panel = document.getElementById('page-frost'), pv = lqGlassPreviewShared();
    if (!lqNavInited || !panel || !pv) return false;
    lqGlassFxMode = lqGlassFxMode || (lqGlassFxLiquidApplied() && !lqGlassFxFrostApplied() ? 'liquid' : 'frost');      // the tab the page will open on
    panel.classList.add('lq-prewarm');
    try {
        await frame();
        pv.open();
        pv.apply(lqGlassFxPreviewCfg());
        pv.warmMaps();
        await frame();
    } finally {
        panel.classList.remove('lq-prewarm');
        pv.close();
    }
    return true;
}
let lqGlassPreviewOne = null;
const lqGlassPreviewShared = () => lqGlassPreviewOne || (lqGlassPreviewOne = lqGlassPreviewCreate());

function initUILiquidGlassSettings() {
    lqGlassCfg = lqGlassLoad();
    lqGlassNavCfg = lqGlassNavLoad();
    lqFrostCfg = lqFrostLoad();
    lqGlassApply();

    const $ = id => document.getElementById(id);
    const controls = $('glassControls');
    const summaryValue = $('glassSummaryValue');
    const applyBtn = $('glassApply');
    const resetBtn = $('glassReset'), offBtn = $('glassOff');
    const refractCard = $('glassRefractCard'), surfCard = $('glassSurfCard');
    const navGlassOn = () => !!lqNavCfg.glass && !!LQ_NAV_STYLES[lqNavCfg.style]?.glass;      // saved flag AND a style that can be glass
    if (!controls || !summaryValue) return;

    const sliders = {}, outs = {};
    for (const k of LQ_GLASS_KEYS) {
        sliders[k] = $(`glass${LQ_GLASS_FIELDS[k].id}Slider`);
        outs[k] = $(`glass${LQ_GLASS_FIELDS[k].id}Value`);
        if (!sliders[k] || !outs[k]) return;
    }
    const targetBtns = Array.from(controls.querySelectorAll('[data-glass-target]'));
    const preview = lqGlassPreviewShared();

    // Same as the Frosted card: the two chips only pick which side is edited (one at a time) and each side has its OWN values, so editing and
    // applying the toasts never touches the bottom nav and the other way round. Nothing reaches the app until Apply.
    let drafts = { toast: { ...lqGlassCfg }, nav: { ...lqGlassNavCfg } };
    let target = 'toast';      // 'toast' or 'nav'
    const saved = () => (target === 'toast' ? lqGlassCfg : lqGlassNavCfg);
    const sideMode = () => lqGlassSideMode(target);
    const usable = () => sideMode() !== 'frost';      // where Frosted is the one applied, the Liquid controls of that side are off until Apply switches it
    const valuesDiffer = () => LQ_GLASS_KEYS.some(k => drafts[target][k] !== saved()[k]);

    const paintValues = () => {
        const d = drafts[target];
        LQ_GLASS_KEYS.forEach(k => {
            const f = LQ_GLASS_FIELDS[k];
            sliders[k].style.setProperty('--lq-progress', String((d[k] - f.min) / (f.max - f.min)));
            outs[k].textContent = f.fmt ? f.fmt(d[k]) : `${d[k]}${f.unit}`;
        });
        syncBtns();
    };
    // Reset goes back to what is saved for the side being edited and is live only while its values differ. Apply is live then too, and also
    // while that side is not the one that is on (Frosted may be applied there: Apply is how Liquid is turned on for it).
    const syncBtns = () => {
        const d = valuesDiffer();
        if (resetBtn) resetBtn.disabled = !d || !usable();
        if (applyBtn) applyBtn.disabled = !(d || sideMode() !== 'liquid');
        if (offBtn) offBtn.disabled = sideMode() !== 'liquid';      // there is something to turn off only where Liquid is the one applied
    };
    const paint = () => {
        summaryValue.textContent = (lqGlassCfg.on || navGlassOn()) ? 'On' : 'Off';      // what is applied right now
        lqGlassFxSummary();
        targetBtns.forEach(b => {
            const on = b.dataset.glassTarget === target;
            b.classList.toggle('is-active', on);
            b.setAttribute('aria-selected', String(on));
        });
        const on = usable();
        refractCard?.classList.toggle('is-disabled', !on);
        surfCard?.classList.toggle('is-disabled', !on);
        LQ_GLASS_KEYS.forEach(k => {
            sliders[k].value = String(drafts[target][k]);
            sliders[k].disabled = !on;
        });
        paintValues();
    };
    // one preview refresh per frame at most while a slider moves. The preview always shows liquid on the toast AND the bar, each with its own
    // values being edited (like the Frosted card), whatever is applied.
    let raf = 0;
    const refresh = () => {
        if (!preview || raf) return;
        raf = requestAnimationFrame(() => { raf = 0; preview.apply(lqGlassFxPreviewCfg()); });
    };

    // the page opens and closes the preview (the toasts on the stage only exist while it is open)
    lqGlassPage = {
        open: () => { paint(); preview?.open(); refresh(); }, close: () => preview?.close(), show: () => { paint(); refresh(); },
        drafts: () => drafts, repaint: () => { paint(); }
    };

    targetBtns.forEach(b => b.addEventListener('click', () => {
        target = b.dataset.glassTarget === 'nav' ? 'nav' : 'toast';
        paint();
    }));

    LQ_GLASS_KEYS.forEach(k => {
        sliders[k].addEventListener('input', () => {
            drafts[target] = lqGlassNormalize({ ...drafts[target], [k]: sliders[k].value });
            paintValues();
            lqGxDraft(refresh);           // cheap maps while the finger moves, one full-size remake when it stops
            refresh();
        });
    });

    resetBtn?.addEventListener('click', () => {
        drafts[target] = { ...saved() };      // back to what was saved for this side, not to the defaults
        paint();
        refresh();
    });

    // Off: back to the plain solid look without any glass. The side that is picked goes back to its default values and Liquid is switched off for
    // it (Frosted is not turned on in its place).
    offBtn?.addEventListener('click', () => {
        if (sideMode() !== 'liquid') return;
        clearTimeout(LQ_GX.draftT); LQ_GX.draft = false;
        if (target === 'toast') {
            lqGlassCfg = lqGlassNormalize({ ...UI_GLASS_DEFAULT, on: false });
        } else {
            lqGlassNavCfg = lqGlassNormalize({ ...UI_GLASS_DEFAULT, on: false });
            lqNavCfg = lqNavNormalize({ ...lqNavCfg, glass: false });
        }
        lqGlassApply({ persist: true });
        if (target === 'nav') lqNavApply({ persist: true });
        drafts[target] = { ...saved() };
        lqUiResync.frost?.();
        lqGlassFxRepaintAll();
        refresh();
        lqToastShow({ title: 'Liquid glass', text: target === 'toast' ? 'Off for the toasts' : 'Off for the bottom nav', state: 'ok' });
    });

    applyBtn?.addEventListener('click', () => {
        if (!lqGlassCanRender()) {
            lqToastShow({ title: 'Liquid glass', text: lqGlassWhy || 'This WebView cannot draw it', state: 'err' });
            return;
        }
        if (target === 'nav' && !LQ_NAV_STYLES[lqNavCfg.style]?.glass) {
            lqToastShow({ title: 'Liquid glass', text: 'Pick Capsule or Material bar first', state: 'err' });
            return;
        }
        clearTimeout(LQ_GX.draftT); LQ_GX.draft = false;          // what the app's own toasts get is always the full-size map
        const before = JSON.stringify(lqFrostCfg);
        // only the picked side takes its values and is switched on; the other side keeps its values and its state
        if (target === 'toast') {
            lqGlassCfg = lqGlassNormalize({ ...drafts.toast, on: true });
            if (lqFrostCfg.toast.on) lqFrostCfg.toast = { ...lqFrostCfg.toast, on: false };      // Liquid and Frosted turn each other off, per side
        } else {
            lqGlassNavCfg = lqGlassNormalize({ ...drafts.nav, on: false });
            lqNavCfg = lqNavNormalize({ ...lqNavCfg, glass: true });
            if (lqFrostCfg.nav.on) lqFrostCfg.nav = { ...lqFrostCfg.nav, on: false };
        }
        lqGlassApply({ persist: true });
        if (target === 'nav') lqNavApply({ persist: true });
        if (JSON.stringify(lqFrostCfg) !== before) lqUiResync.frost?.();
        drafts[target] = { ...saved() };
        lqGlassFxRepaintAll();      // the Frosted card dims for this side now
        refresh();
        lqToastShow({ title: 'Liquid glass', text: target === 'toast' ? 'Applied to the toasts' : 'Applied to the bottom nav', state: 'ok' });
    });

    lqGlassNavSync = () => { paint(); refresh(); };
    paint();
    lqUiResync.glass = () => {
        lqGlassCfg = lqGlassLoad();
        lqGlassNavCfg = lqGlassNavLoad();
        lqFrostCfg = lqFrostLoad();
        lqGlassApply();
        drafts = { toast: { ...lqGlassCfg }, nav: { ...lqGlassNavCfg } };
        paint();
        refresh();
    };
}

// ── Frosted Glass card ───────────────────────────────────────────────────────────────────────────────────────────────
// A copy of the Liquid Glass card without the bend: blur, frost, colour and the merge gradient, with its own values. The preview is
// the same stage code (lqGlassPreviewCreate), told to draw the surface only. Applying it turns Liquid Glass (toasts and nav) off,
// and applying Liquid Glass turns this off.
// ── Glass effect page: Frosted and Liquid on one page ──────────────────────────────────────────────────────────────────
// The two cards keep their own values, their own Surface and their own preview; the chips on top pick which one is shown. Applying
// one turns the other off (see the Apply handlers), so only one of them is ever on for the toasts and for the nav.
let lqGlassFxMode = null;      // 'frost' | 'liquid'
// ONE preview serves both tabs, and it shows what is APPLIED on each side, not what the open tab is: switching tabs never changes it.
// A side that is on as Liquid is drawn as Liquid (with the Liquid card's values), one that is on as Frosted as Frosted, in either tab. Only a
// side that is off yet previews the tab that is open, so there is something to look at before the first Apply.
const lqGlassNavLiquidFlag = () => !!lqNavCfg.glass && !!LQ_NAV_STYLES[lqNavCfg.style]?.glass;
function lqGlassSideMode(side) {      // what is applied on 'toast' / 'nav': 'liquid' | 'frost' | 'none'
    if (side === 'toast') return lqGlassCfg.on ? 'liquid' : (lqFrostCfg.toast.on ? 'frost' : 'none');
    return lqGlassNavLiquidFlag() ? 'liquid' : (lqFrostCfg.nav.on ? 'frost' : 'none');
}
function lqGlassFxPreviewCfg() {
    const L = lqGlassPage && lqGlassPage.drafts && lqGlassPage.drafts(), F = lqFrostPage && lqFrostPage.drafts && lqFrostPage.drafts();
    const tab = lqGlassFxMode === 'liquid' ? 'liquid' : 'frost';
    const modeOf = side => { const m = lqGlassSideMode(side); return m === 'none' ? tab : m; };
    const tm = modeOf('toast'), nm = modeOf('nav');
    const lt = (L && L.toast) || lqGlassCfg, ln = (L && L.nav) || lqGlassNavCfg;
    const ft = (F && F.toast) || lqFrostCfg.toast, fn = (F && F.nav) || lqFrostCfg.nav;
    const top = tm === 'liquid' ? lt : { ...UI_GLASS_DEFAULT, ...ft };
    return { ...top, toastMode: tm, navMode: nm, navLq: ln, navFrost: { blur: fn.blur, frost: fn.frost, sat: fn.sat } };
}
function lqGlassFxRepaintAll() { lqGlassPage?.repaint?.(); lqFrostPage?.repaint?.(); }
const lqGlassFxLiquidApplied = () => !!lqGlassCfg.on || (!!lqNavCfg.glass && !!LQ_NAV_STYLES[lqNavCfg.style]?.glass);
const lqGlassFxFrostApplied = () => lqGlassSideMode('toast') === 'frost' || lqGlassSideMode('nav') === 'frost';
function lqGlassFxSummary() {
    const el = document.getElementById('glassFxSummary');
    if (!el) return;
    const parts = [];
    if (lqGlassFxLiquidApplied()) parts.push('Liquid');
    if (lqGlassFxFrostApplied()) parts.push('Frosted');
    el.textContent = parts.length ? parts.join(' + ') : 'Off';
}
function lqGlassFxShow(mode) {
    lqGlassFxMode = mode === 'liquid' ? 'liquid' : 'frost';
    const f = document.getElementById('glassModeFrost'), l = document.getElementById('glassModeLiquid');
    if (f) f.hidden = lqGlassFxMode !== 'frost';
    if (l) l.hidden = lqGlassFxMode !== 'liquid';
    document.querySelectorAll('#glassModeChips [data-glass-mode]').forEach(b => {
        const on = b.dataset.glassMode === lqGlassFxMode;
        b.classList.toggle('is-active', on);
        b.setAttribute('aria-selected', String(on));
    });
}
function lqGlassFxOpen() {
    lqGlassFxShow(lqGlassFxMode || (lqGlassFxLiquidApplied() && !lqGlassFxFrostApplied() ? 'liquid' : 'frost'));
    (lqGlassFxMode === 'liquid' ? lqGlassPage : lqFrostPage)?.open();      // the one preview is opened once; open() then draws this mode's values
}
function lqGlassFxClose() { (lqGlassPage || lqFrostPage)?.close(); }      // the same preview behind both
function initGlassEffectModes() {
    const chips = Array.from(document.querySelectorAll('#glassModeChips [data-glass-mode]'));
    chips.forEach(b => b.addEventListener('click', () => {
        const mode = b.dataset.glassMode === 'liquid' ? 'liquid' : 'frost';
        if (mode === lqGlassFxMode) return;
        lqGlassFxShow(mode);
        // the preview is not closed or rebuilt: it just draws the other mode's values, so a stack that is open stays open, the bar and the
        // sticky card stay where they are
        if (currentPage === 'frost') (mode === 'liquid' ? lqGlassPage : lqFrostPage)?.show();
    }));
    lqGlassFxSummary();
}
let lqFrostPage = null;      // { open, close } for its preview
function initUIFrostedGlassSettings() {
    lqFrostCfg = lqFrostLoad();
    const $ = id => document.getElementById(id);
    const controls = $('frostControls'), summaryValue = $('frostSummaryValue');
    const applyBtn = $('frostApply'), resetBtn = $('frostReset'), offBtn = $('frostOff');
    if (!controls) return;
    const sliders = {}, outs = {};
    for (const k of LQ_FROST_KEYS) {
        sliders[k] = $(`frost${LQ_GLASS_FIELDS[k].id}Slider`);
        outs[k] = $(`frost${LQ_GLASS_FIELDS[k].id}Value`);
        if (!sliders[k] || !outs[k]) return;
    }
    const targetBtns = Array.from(controls.querySelectorAll('[data-frost-target]'));
    const preview = lqGlassPreviewShared();
    const clone = o => JSON.parse(JSON.stringify(o));
    // No switches here: every control is live and the preview always shows the frosted glass on both the toast and the bar with the values being
    // edited. Apply puts the side that is picked under "Editing" into the app (and turns Liquid Glass off for it); the only way back is Liquid Glass.
    let draft = clone(lqFrostCfg);
    let target = 'toast';      // which side the cards edit and Apply applies: 'toast' or 'nav'
    const keysOf = () => (target === 'toast' ? LQ_FROST_KEYS : LQ_FROST_NAV_KEYS);

    // Reset goes back to what is saved for the side being edited. Reset is live only while its values differ from the saved ones; Apply also while
    // that side is not the one that is on (Liquid may be the one applied: Apply is how Frosted is turned on).
    const sideDiffers = () => keysOf().some(k => draft[target][k] !== lqFrostCfg[target][k]);
    const usable = () => lqGlassSideMode(target) !== 'liquid';      // where Liquid is the one applied, the Frosted controls of that side are off until Apply switches it
    const syncBtns = () => {
        const d = sideDiffers();
        if (resetBtn) resetBtn.disabled = !d || !usable();
        if (applyBtn) applyBtn.disabled = !(d || lqGlassSideMode(target) !== 'frost');
        if (offBtn) offBtn.disabled = lqGlassSideMode(target) !== 'frost';      // there is something to turn off only where Frosted is the one applied
    };
    const paintValues = () => {
        const side = draft[target];
        syncBtns();
        keysOf().forEach(k => {
            const f = LQ_GLASS_FIELDS[k];
            sliders[k].style.setProperty('--lq-progress', String((side[k] - f.min) / (f.max - f.min)));
            outs[k].textContent = f.fmt ? f.fmt(side[k]) : `${side[k]}${f.unit}`;
        });
    };
    const paint = () => {
        const side = draft[target];
        summaryValue.textContent = (lqGlassSideMode('toast') === 'frost' || lqGlassSideMode('nav') === 'frost') ? 'On' : 'Off';      // what is applied right now
        lqGlassFxSummary();
        const surfSub = $('frostSurfSub');      // the Surface text names the side that is picked, so the two cannot be mixed up
        if (surfSub) surfSub.textContent = target === 'toast'
            ? 'Blur, frost and colour of the frosted glass on the toasts. Apply, at the bottom, applies the toasts and turns Liquid glass off for them. Its own values, separate from the Liquid ones.'
            : 'Blur, frost and colour of the frosted glass on the bottom nav. Apply, at the bottom, applies the bottom nav and turns Liquid glass off for it. Its own values, separate from the Liquid ones.';
        targetBtns.forEach(b => { const on = b.dataset.frostTarget === target; b.classList.toggle('is-active', on); b.setAttribute('aria-selected', String(on)); });
        const on = usable();
        $('frostSurfCard')?.classList.toggle('is-disabled', !on);
        LQ_FROST_KEYS.forEach(k => {
            if (!keysOf().includes(k)) return;
            sliders[k].value = String(side[k]);
            sliders[k].disabled = !on;
        });
        paintValues();
    };
    let raf = 0;
    const refresh = () => {
        if (!preview || raf) return;
        raf = requestAnimationFrame(() => { raf = 0; preview.apply(lqGlassFxPreviewCfg()); });
    };
    lqFrostPage = {
        open: () => { paint(); preview?.open(); refresh(); }, close: () => preview?.close(), show: () => { paint(); refresh(); },
        drafts: () => draft, repaint: () => { paint(); }
    };

    // The card is a card like the others at rest and goes flush (full width, square top) once it is stuck to the top: a 1px marker sits where the
    // card naturally is, and when it has scrolled out above the top of the page the card is stuck. It widens once and stays flush for as long as it
    // is stuck, scrolling up included; it is a card like the others again only when the page has scrolled back to the card's own place.
    const card = $('frostCard'), sentinel = $('frostSentinel'), scroller = $('mainContent');
    if (card && sentinel && scroller) {
        const LEAD = 1;      // the same as the preview in UI Settings: stuck exactly when the card is pinned
        const check = () => {
            const d = sentinel.getBoundingClientRect().top - scroller.getBoundingClientRect().top;
            const was = card.classList.contains('is-stuck');
            const stuck = !!sentinel.offsetHeight && d < (was ? LEAD + 1 : LEAD);      // no offsetHeight: the page is not open; 1px of play against flicker on the line
            if (stuck !== was) card.classList.toggle('is-stuck', stuck);
        };
        scroller.addEventListener('scroll', check, { passive: true });
        window.addEventListener('resize', check, { passive: true });
    }

    targetBtns.forEach(b => b.addEventListener('click', () => { target = b.dataset.frostTarget === 'nav' ? 'nav' : 'toast'; paint(); }));
    LQ_FROST_KEYS.forEach(k => {
        sliders[k].addEventListener('input', () => {
            draft = lqFrostNormalize({ ...draft, [target]: { ...draft[target], [k]: Number(sliders[k].value) } });
            paintValues();
            refresh();
        });
    });
    resetBtn?.addEventListener('click', () => {      // the values of the side being edited go back to what is saved (nothing is applied by this)
        draft[target] = clone(lqFrostCfg[target]);
        paint();
        refresh();
    });
    // Off: the way back to the plain solid look without any glass. The side that is picked goes back to its default values and Frosted is switched off
    // for it (nothing else is turned on in its place).
    offBtn?.addEventListener('click', () => {
        if (lqGlassSideMode(target) !== 'frost') return;
        lqFrostCfg = lqFrostNormalize({ ...lqFrostCfg, [target]: { ...clone(UI_FROST_DEFAULT[target]), on: false } });
        lqGlassApply({ persist: true });
        draft = clone(lqFrostCfg);
        lqUiResync.glass?.();
        lqGlassFxRepaintAll();
        paint();
        refresh();
        lqToastShow({ title: 'Frosted glass', text: target === 'toast' ? 'Off for the toasts' : 'Off for the bottom nav', state: 'ok' });
    });
    applyBtn?.addEventListener('click', () => {
        if (!lqSurfCanRender()) {
            lqToastShow({ title: 'Frosted glass', text: 'This WebView has no backdrop blur', state: 'err' });
            return;
        }
        const norm = lqFrostNormalize(draft);
        lqFrostCfg = lqFrostNormalize({ ...lqFrostCfg, [target]: { ...norm[target], on: true } });      // only the side that is picked
        let navOff = false;
        // Liquid Glass and Frosted Glass turn each other off, toasts with toasts and nav with nav
        if (target === 'toast' && lqGlassCfg.on) lqGlassCfg = { ...lqGlassCfg, on: false };
        if (target === 'nav' && lqNavCfg.glass) { lqNavCfg = lqNavNormalize({ ...lqNavCfg, glass: false }); navOff = true; }
        lqGlassApply({ persist: true });
        if (navOff) lqNavApply({ persist: true });
        // the Liquid Glass card follows (its switches may just have been turned off); this card keeps what is being edited
        const keep = draft;
        lqUiResync.glass?.();
        draft = keep;
        lqGlassFxRepaintAll();      // the Liquid card dims for this side now
        refresh();
        lqToastShow({ title: 'Frosted glass', text: target === 'toast' ? 'Applied to the toasts' : 'Applied to the bottom nav', state: 'ok' });
    });

    lqUiResync.frost = () => {
        lqFrostCfg = lqFrostLoad();
        draft = clone(lqFrostCfg);
        paint();
        refresh();
    };
    paint();
}

// ── Bottom nav: style, position, size, liquid glass ──────────
// Four looks share one bar element:
//   pill      the original bar (only the active tab shows its name)
//   ios       floating capsule, icon over name, a "lens" under the active tab
//   iosbar    docked full-width bar; the selected tab opens up (icon + name side by side), the glass lens fits it
//   material  docked bar with a curved notch; the selected tab rises in a round bubble that sits in the notch
// The iOS motion: touching the bar lifts the lens (it grows with a springy
// wobble), it can be dragged along the bar and trails the finger on a spring
// (it stretches with speed and is rubber-banded past the ends), and on release
// it settles on the nearest tab while the picked icon pops. The page itself
// switches once, on release.
// Liquid glass on the nav is the same material as the toast and is driven by the
// same Liquid Glass card (distortion, edge width, blur, frost ...). It only changes
// the material of the bar and the lens: shapes and motion stay exactly the same.
const UI_NAV_KEY = 'lq_ui_nav_v1';
const UI_PKGSORT_KEY = 'lq_ui_pkgsort_v1';
const UI_ANGLETEX_KEY = 'lq_angletex_v1';
const LQ_NAV_STYLES = {
    pill:     { name: 'Pill',         base: 56, dock: false, ios: false, tabs: false, note: 'The default bar. Only the selected tab shows its name.' },
    ios:      { name: 'Capsule',      base: 58, dock: false, ios: true,  tabs: true,  glass: true, glassBar: true, note: 'A floating capsule with a spring lens. Hold and slide across it to pick a tab.' },
    iosbar:   { name: 'Indicator bar', base: 60, dock: true,  ios: true,  tabs: true,  bar: true, note: 'Docked to the bottom edge. Icon over name, and a slim indicator slides along the top edge to the selected tab.' },
    material: { name: 'Material bar', base: 64, dock: true,  ios: false, tabs: true,  notch: true,  glass: true, note: 'Docked bar with a notch: the selected tab rises out of it in a round bubble.' }
};
let lqNavInited = false;
let lqGlassNavSync = null;     // set by the Liquid Glass card: repaints its "Bottom nav" switch
const UI_NAV_DEFAULT = { style: 'pill', align: 'center', offset: 14, side: 12, scale: 100, wide: 100, labels: true, fade: true, glass: false, shrink: true };
let lqNavCfg = JSON.parse(JSON.stringify(UI_NAV_DEFAULT));
// While the Glass effect page is open the real bar is not on screen, but the copy of it on the preview stage is styled by the same html-level
// classes (lq-nav-glass, lq-nav-glass-bar, lq-nav-surf). Those must follow what the preview is showing (the pending values), not what is saved,
// or the bar keeps the saved look until Apply / reopening. The preview sets this; null = follow the saved choice.
let lqNavPreviewOverride = null;      // { glass, surf }
let lqNavCompact = false;      // the bar is icon only because the page is being scrolled down (see lqNavSetCompact)

function lqNavNormalize(raw) {
    const o = raw && typeof raw === 'object' ? raw : {}, D = UI_NAV_DEFAULT;
    const num = (v, lo, hi, d) => { const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, Math.round(n))) : d; };
    return {
        style: Object.prototype.hasOwnProperty.call(LQ_NAV_STYLES, o.style) ? o.style : D.style,
        align: ['left', 'center', 'right'].includes(o.align) ? o.align : D.align,
        offset: num(o.offset, 0, 64, D.offset),
        side: num(o.side, 0, 48, D.side),
        scale: num(o.scale, 70, 140, D.scale),      // Height
        wide: num(o.wide, 80, 130, D.wide),        // stretch sideways (floating bars only)
        labels: o.labels !== false,
        fade: o.fade !== false,
        shrink: o.shrink !== false,       // scrolling down turns the bar icon only, scrolling up brings the names back
        // true = the nav uses the Liquid Glass look (an older save kept it as {on:true,...})
        glass: o.glass === true || (!!o.glass && typeof o.glass === 'object' && o.glass.on === true)
    };
}
function lqNavLoad() {
    try {
        const raw = localStorage.getItem(UI_NAV_KEY);
        return raw ? lqNavNormalize(JSON.parse(raw)) : lqNavNormalize(null);
    } catch (_) { return lqNavNormalize(null); }
}
function lqNavSave() {
    try { localStorage.setItem(UI_NAV_KEY, JSON.stringify(lqNavCfg)); } catch (_) {}
    lqMirrorUIPrefs();
}

// The preview only needs the three html classes that style the copy of the bar on its stage; the real bar is not on screen on that page, so
// there is nothing to lay out or to bake a map for (lqNavApply does both).
function lqNavPreviewClasses() {
    const c = lqNavCfg, d = LQ_NAV_STYLES[c.style], root = document.documentElement, pvo = lqNavPreviewOverride;
    const glass = !!d.glass && (pvo ? pvo.glass : c.glass) && lqGlassCanRender();
    root.classList.toggle('lq-nav-glass', glass);
    root.classList.toggle('lq-nav-glass-bar', glass && !!d.glassBar);
    root.classList.toggle('lq-nav-surf', (pvo ? pvo.surf : lqFrostNavOn()) && !(glass && d.glassBar));
}
// Paints the saved choice onto the page: html classes + CSS variables, then lays the bar out again.
function lqNavApply({ persist = false, animate = false } = {}) {
    const c = lqNavCfg, d = LQ_NAV_STYLES[c.style], root = document.documentElement;
    const pvo = lqNavPreviewOverride;
    const glass = !!d.glass && (pvo ? pvo.glass : c.glass) && lqGlassCanRender();      // liquid glass: Capsule (bar and lens) and Material bar (the bubble only)
    root.classList.toggle('lq-nav-tabs', d.tabs);
    root.classList.toggle('lq-nav-ios', d.ios);
    root.classList.toggle('lq-nav-dock', d.dock);
    root.classList.toggle('lq-nav-notch', !!d.notch);
    root.classList.toggle('lq-nav-inline', !!d.inline);
    root.classList.toggle('lq-nav-bar', !!d.bar);
    if (glass) lqGxEnsure();
    root.classList.toggle('lq-nav-glass', glass);
    root.classList.toggle('lq-nav-glass-bar', glass && !!d.glassBar);       // the whole bar is glass only on the Capsule
        // the same surface on the bar of every style (also the pill), except where the whole bar is glass already
    root.classList.toggle('lq-nav-surf', (pvo ? pvo.surf : lqFrostNavOn()) && !(glass && d.glassBar));
    root.classList.toggle('lq-nav-nolabels', !c.labels);
    root.classList.toggle('lq-nav-shrinkable', !!c.shrink && !!c.labels && !d.notch);      // the bar's size transitions only exist while the feature is on
    root.classList.toggle('lq-nav-nofade', !c.fade || d.dock);       // the dark gradient behind the bar (never on a docked bar: it sits flush with the edge, nothing slides under it)

    const g = lqNavGeom();
    const sc = g.s;     // floating bars: 1 (Height changes only the bar). Docked bars: icons, names and gaps follow Height
    const H = lqNavGeom(false).H;       // the root always holds the full height (see lqNavCompactVars)
    const icon = d.tabs && !d.inline ? g.tabIcon : g.icon;
    const side = lqNavSide(d, c);
    const px = (k, v) => root.style.setProperty(k, `${v}px`);
    px('--nav-h', H);
    px('--nav-hf', lqNavGeom(false).H);           // the height with the names: the page's bottom space keeps this one, so it does not move while the bar shrinks
    px('--nav-gap', d.dock ? 0 : c.offset);
    px('--nav-side', side);
    px('--nav-icon', icon);
    root.style.setProperty('--nav-fs', `${g.fs.toFixed(2)}px`);
    px('--nav-iup', -Math.round(H / 2));            // notch style: how far the selected icon rises into its bubble
    px('--nav-lb', Math.round(6 * sc));
    // the Material bubble stands out above the bar: the toasts rest above the bubble, never behind it
    px('--nav-up', d.notch ? Math.round(Math.round(52 * sc * g.hk) / 2) + 6 : 0);
    px('--nav-ix', Math.round((H - 8 - icon) / 2));
    px('--nav-gp', Math.round(8 * sc));
    px('--nav-tg', Math.round(2 * sc));
    const floating = !d.dock;
    root.style.setProperty('--nav-ml', floating && c.align === 'left' ? `${side}px` : 'auto');
    root.style.setProperty('--nav-mr', floating && c.align === 'right' ? `${side}px` : 'auto');

    if (lqNavCompact && (!c.labels || !c.shrink || d.notch)) { lqNavCompact = false; root.classList.remove('lq-nav-compact'); }
    if (!animate) { lqNavMapKey = ''; lqNavLens.inited = false; }
    lqNavCompactVars();
    lqNavPillLayout(animate);
    if (persist) lqNavSave();
}
// ── layout ──
// Sizes follow the "Bar size" setting (lqNavGeom). At 100% they are the old fixed numbers.
// The text and icon sizes from "Size & font" are applied on top: the icons and names grow, and the bar
// gets just tall enough (hk) that they still fit.
function lqNavUiScale() {
    const st = document.documentElement.style;
    const f = n => { const v = parseFloat(st.getPropertyValue(n)); return Number.isFinite(v) && v > 0 ? v : 1; };
    return { ts: f('--lq-ts'), is: f('--lq-is') };
}
function lqNavGeom(compact = lqNavCompact) {
    const hs = lqNavCfg.scale / 100, u = lqNavUiScale();
    const d = LQ_NAV_STYLES[lqNavCfg.style] || LQ_NAV_STYLES.pill;
    const cmp = !!compact && !d.notch;      // scrolled down: the bar is only as big as its icons (names hidden)
    // Floating bars (Pill, Capsule): Height changes only the thickness of the bar, icons and names keep their
    // size (they follow "Text & icon size" only). Docked bars (Indicator bar, Material bar): Height scales the
    // icons, names and gaps together with the bar.
    const sc = d.dock ? hs : 1;
    const icon = Math.round(22 * sc * u.is);
    const tabIcon = Math.round(20 * sc * u.is);
    const fs = (d.tabs ? (d.ios ? 9.5 : 10.5) : 13) * sc * u.ts;
    const tg = Math.round(2 * sc);
    // air around icon + name inside the lens: 28 for the stacked tabs. Compact: only the icon, with air on every side
    // Compact is sized from the icon (not a fixed number), so a bigger icon gets a bigger bar and never ends up cramped
    const need = cmp ? (d.tabs ? Math.round(tabIcon * 2.45) : Math.round(icon * 2.1))
        : d.inline ? tabIcon + tg + fs * 1.3 + 16 * sc : d.tabs ? tabIcon + tg + fs * 1.3 + 28 * sc : icon + 16 * sc;
    let H, hk;
    if (d.dock) {
        hk = cmp ? need / (d.base * sc) : Math.max(1, need / (d.base * sc));
        H = Math.round(d.base * sc * hk);
    } else {
        const Hdef = cmp ? need : Math.max(d.base, need);         // the height at Height 100%
        const content = d.tabs ? (cmp ? tabIcon : tabIcon + tg + fs * 1.3) : icon;  // what has to fit inside, with 4px of air on each side at the very least
        H = Math.max(Math.ceil(content) + 8, Math.round(Hdef * hs));
        hk = H / d.base;
    }
    if (cmp) {
        // never as tall as the full bar (or taller): it only closes up by what the names took, and never below what the icon needs
        const content = d.tabs ? tabIcon : icon, full = lqNavGeom(false).H;
        H = Math.max(Math.ceil(content) + 8, Math.min(H, full - 8));
        hk = H / (d.dock ? d.base * sc : d.base);
    }
    // the Pill style: item height follows the bar, item WIDTH does not (that is the Width setting's job)
    const cw = cmp ? Math.max(icon + 16, H - 4) : Math.max(56, icon + 16) - 8;
    return {
        s: sc, h: H, H, collapsed: H - 8, cw, icon, hk, fs, ts: u.ts, is: u.is,
        iconX: Math.round((cw - icon) / 2),
        gap: Math.round(8 * sc), padR: Math.round(16 * sc),
        tabIcon, tg
    };
}

// Natural width of a tab name. Measured with a canvas so it also works while the element is hidden
// (the little preview phone sits on a page that is not always on screen).
let lqNavMeasureCtx = null;
function lqNavTextW(label) {
    if (!label) return 0;
    let w = Math.ceil(label.scrollWidth || 0);
    try {
        if (!lqNavMeasureCtx) lqNavMeasureCtx = document.createElement('canvas').getContext('2d');
        const cs = getComputedStyle(label);
        lqNavMeasureCtx.font = `${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
        w = Math.max(w, Math.ceil(lqNavMeasureCtx.measureText(label.textContent).width));
    } catch (_) {}
    return w;
}

// ── Shrink on scroll ────────────────────────────────────────────────────────────────────────────────────────────────
// Scrolling down turns the bar icon only, scrolling up brings the names back. Nothing flips at once: the names go out one tab after
// the other (left to right on the way out, right to left on the way back), the selected tab of the Pill closes up around its icon,
// and the whole bar answers with a soft press and release while a small wave runs over the icons. The bar's height never changes,
// so the toasts, the glass and the page's bottom space stay where they are.
function lqNavNamesOn() { return lqNavCfg.labels && !lqNavCompact; }
function lqNavCompactWave(dir, iconsOnly) {
    const pill = document.getElementById('navPill');
    if (!pill || !pill.animate || lqReduced() || !pill.classList.contains('nav-in')) return;
    const out = dir === 'down', items = [...pill.querySelectorAll('.nav-item')], n = items.length, kind = lqNavKind();
    try {
        if (iconsOnly) { /* the Pill: the bar itself moves with the sliding engine, only the icons get a small scale answer */ }
        else if (kind === 'float') {
            if (pill._shrinkAnim) pill._shrinkAnim.cancel();
            const ms = out ? 640 : 560;
            const a = pill._shrinkAnim = pill.animate(out ? lqNavLiquidFrames('out', 0.972, 0.92, ms, true) : lqNavLiquidFrames('in', 0.986, 0.95, ms, true), { duration: ms, composite: 'add' });
            a.onfinish = a.oncancel = () => { if (pill._shrinkAnim === a) pill._shrinkAnim = null; };
        } else lqNavFeelOn(pill, out ? 'out' : 'in', kind);      // a docked bar does not squash: its lens / indicator answers instead
        const e = 'cubic-bezier(.3,.6,.4,1)';
        items.forEach((b, i) => {
            const ic = b.querySelector('.lq-svg-icon');
            if (!ic || !ic.animate) return;
            ic.animate([
                { scale: '1', offset: 0, easing: e },
                { scale: iconsOnly ? (out ? '0.88' : '1.1') : (out ? '0.8' : '1.16'), offset: 0.38, easing: e },
                { scale: '1', offset: 1 }
            ], { duration: iconsOnly ? 460 : 520, delay: (out ? i : n - 1 - i) * (iconsOnly ? LQ_SHRINK_STAG : 52) });
        });
    } catch (_) {}
}
// While the bar is compact, its smaller height is set on the bar itself and on the toast layer (the only two that use it), never on the page's
// root: a custom property that changes on the root makes the browser recompute the style of every element of the page (the whole list of
// packages), a long frame exactly where the animation starts, which made the icons and the names stutter.
function lqNavCompactVars() {
    const pill = document.getElementById('navPill');
    if (!pill) return;
    const H = lqNavGeom().H;
    let layer = null;
    try { layer = lqToastLayer; } catch (_) {}        // not made yet (this can run while the page is still starting up)
    for (const el of [pill, layer]) {
        if (!el) continue;
        if (lqNavCompact) el.style.setProperty('--nav-h', `${H}px`); else el.style.removeProperty('--nav-h');
    }
}
function lqNavSetCompact(on) {
    const d0 = LQ_NAV_STYLES[lqNavCfg.style] || LQ_NAV_STYLES.pill;
    on = !!on && lqNavCfg.shrink && lqNavCfg.labels && !d0.notch;       // the Material bar never shrinks
    if (on === lqNavCompact) return;
    const pill = document.getElementById('navPill');
    if (!pill) return;
    lqNavCompact = on;
    const items = [...pill.querySelectorAll('.nav-item')];
    items.forEach((b, i) => { b.style.setProperty('--ci', i); b.style.setProperty('--cr', items.length - 1 - i); });
    // the Pill: the same sliding engine as a tab change does it (its class goes on when the names are gone, off as they start to come back)
    const viaPill = !d0.tabs && !lqReduced() && pill.classList.contains('nav-in') && pill.offsetWidth > 0 && LQ_PS.mode !== 'drag';
    if (!viaPill || !on) document.documentElement.classList.toggle('lq-nav-compact', on);
    lqNavCompactVars();
    if (viaPill && lqPillShrinkStart(on)) { lqNavPreviewLayout(); lqNavCompactWave(on ? 'down' : 'up', true); return; }
    document.documentElement.classList.toggle('lq-nav-compact', on);
    lqNavPillLayout(true);                       // the bar's height, its tabs and the lens follow the icons (CSS transitions do the gradual part)
    lqNavCompactWave(on ? 'down' : 'up');
}
const lqNavScr = { last: new WeakMap(), acc: 0, dir: 0, lock: 0, t: 0 };
function lqNavScrollWire() {
    const S = lqNavScr;
    // down far enough: icons only; up (or back at the top): names back. It answers at once, in both directions: nothing is paused or
    // held back, so it never feels late
    const decide = el => {
        const top = el.scrollTop;
        if (top <= 4) lqNavSetCompact(false);
        else if (S.dir > 0 && S.acc >= 26 && top > 56) lqNavSetCompact(true);
        else if (S.dir < 0 && S.acc >= 16) lqNavSetCompact(false);
    };
    document.addEventListener('scroll', e => {
        if (lqNavAwayOn || (LQ_HDR[currentPage] && LQ_HDR[currentPage].back) || !lqNavCfg.shrink || !lqNavCfg.labels || (LQ_NAV_STYLES[lqNavCfg.style] || {}).notch) return;
        let el = e.target;
        if (el === document) el = document.scrollingElement || document.documentElement;
        if (!(el instanceof Element)) return;
        if (el.closest('#navPill, .lq-sk-in') || (lqToastLayer && lqToastLayer.contains(el))) return;
        const top = el.scrollTop, prev = S.last.get(el);
        S.last.set(el, top);
        if (prev === undefined || top === prev) return;
        if (el.scrollHeight - el.clientHeight < 80) return;         // nothing worth scrolling here
        const dir = top > prev ? 1 : -1;
        if (dir !== S.dir) { S.dir = dir; S.acc = 0; }
        S.acc += Math.abs(top - prev);
        const wait = S.lock - performance.now();
        if (wait > 0) { clearTimeout(S.t); S.t = setTimeout(() => decide(el), wait + 30); return; }
        decide(el);
    }, { capture: true, passive: true });
    // touching the bar brings the names back (a tab is about to be picked)
    document.getElementById('navPill')?.addEventListener('pointerdown', () => lqNavSetCompact(false), { passive: true });
}
lqNavScrollWire();

function lqNavPillLayout(animate = true) {
    const pill = document.getElementById('navPill');
    if (!pill) return;
    const items = [...pill.querySelectorAll('.nav-item')];
    if (!items.length) return;
    const d = LQ_NAV_STYLES[lqNavCfg.style] || LQ_NAV_STYLES.pill;

    if (!animate) pill.classList.add('no-anim');
    if (d.inline) lqNavLayoutInline(pill, items, d, animate);
    else if (d.tabs) lqNavLayoutTabs(pill, items, d, animate);
    else lqNavLayoutPill(pill, items, animate);
    if (!animate) {
        void pill.offsetWidth;
        pill.classList.remove('no-anim');
    }
    lqNavPreviewLayout();
}

// Default style: inactive items show only their icon, the active one grows to fit its name.
//
// The pill is ONE highlight that slides from tab to tab (see "the sliding pill" below). While it travels, every tab is as wide as its share of the
// pill, and its name is simply uncovered or covered by that width: halfway between two tabs the first is half closed and the next half open.
// Taps play this as a short tween; a hold-and-slide makes the pill follow the finger.
function lqPillMetrics(pill, items, vwIn, ai) {
    const g = lqNavGeom();
    const showNames = lqNavNamesOn();
    const pad = 4, gap = 2;
    // natural (open) width of every item
    const full = items.map(btn => {
        const label = btn.querySelector('.nav-item-label');
        const labelW = label && showNames ? lqNavTextW(label) : 0;
        return showNames ? g.iconX + g.icon + g.gap + labelW + g.padR : g.cw;
    });
    const base = full.map((f, i) => i === ai ? f : g.cw);
    // Width setting: every item gets the same extra (or less) room, split evenly left and right of its content,
    // so the whole bar gets longer or shorter. A longer bar is held inside the screen.
    const vw = vwIn || document.documentElement.clientWidth || window.innerWidth || 360;
    const side = lqNavSide(LQ_NAV_STYLES.pill, lqNavCfg);
    const T0 = base.reduce((a, b) => a + b, 0) + gap * (items.length - 1) + 2 * pad;
    let ex = Math.round(g.cw * (lqNavCfg.wide / 100 - 1));
    if (ex > 0) ex = Math.min(ex, Math.max(0, Math.floor((vw - 2 * side - T0) / items.length)));
    return { g, full, base, ex, pad, gap, cw: g.cw, ix: g.iconX + ex / 2 };
}
// the plain layout: the active item open, the others icon only, moved by the CSS transitions (staggered, nearest first)
function lqPillApply(pill, items, M, animate, ai) {
    const delay = new Map();
    items
        .map((b, i) => ({ b, i, d: Math.abs(i - ai) }))
        .sort((a, b) => a.d - b.d || a.i - b.i)
        .forEach((o, rank) => delay.set(o.b, animate ? rank * 55 : 0));
    pill.style.setProperty('--nav-ix', `${M.ix.toFixed(1)}px`);   // same left room on every item, so the icon never jumps
    let x = M.pad;
    items.forEach((btn, i) => {
        const w = M.base[i] + M.ex;
        btn.style.setProperty('--d', delay.get(btn) + 'ms');
        btn.style.removeProperty('padding-left');
        btn.style.width = w + 'px';
        btn.style.left = x + 'px';
        x += w + M.gap;
    });
    pill.style.width = (x - M.gap + M.pad) + 'px';
}
function lqNavLayoutPill(pill, items, animate, vwIn, eng) {
    pill.style.removeProperty('--nav-fs');
    const ai = Math.max(0, items.findIndex(b => b.classList.contains('active')));
    const M = lqPillMetrics(pill, items, vwIn, ai);
    const S = eng || (!vwIn && pill.id === 'navPill' ? LQ_PS : null);           // (a copy of the bar in a preview slides only when it is given its own state)
    if (S) {
        if (S.mode) {
            // already sliding: new sizes, and aim at the tab that is active now
            S.G = M; S.items = items;
            if (S.mode === 'drag') return;
            if (!animate || lqReduced()) { lqPillFinish(S); return; }
            if (Math.abs(S.target - ai) > .001) lqPillTo(ai, undefined, S);
            return;
        }
        if (animate && S.p != null && Math.abs(S.p - ai) > .01 && !lqReduced() && pill.offsetWidth > 0) {
            lqPillBegin(pill, items, M, S.p, S);
            lqPillTo(ai, undefined, S);
            return;
        }
        S.p = ai;
    }
    lqPillApply(pill, items, M, animate, ai);
}

// ── the sliding pill ──
// p is where the pill is, in tabs (0 = first tab, 1.5 = halfway between the second and the third). Every tab is open by how close the pill is
// to it (1 at the tab, 0 one tab away), the highlight is the blend of the two tabs it sits between, and the names are covered by their tab's width.
const LQ_SHRINK_MS = 580, LQ_SHRINK_STAG = 28;      // slower than a tab change on purpose: the names must still be there while the card closes around them
const lqPillStateNew = () => ({ sh: null, p: null, target: 0, base: 0, mode: '', raf: 0, t0: 0, from: 0, dur: 520, last: 0, G: null, items: null, pill: null, hl: null, vw: 0 });
const LQ_PS = lqPillStateNew();
// Shrink on scroll (the Pill) rides on the same engine: sh.k is how far the names are open (1 = every name that belongs to the pill is out,
// 0 = icons only). The tabs' width, the pill's height and the names being covered / uncovered all follow k, with the very same curve a tab
// change uses, so the two read as one motion. sh.Gf / sh.Gc are the plain layouts with and without names.
function lqPillShG(sh, k) {
    const Gf = sh.Gf, Gc = sh.Gc, L = (a, b) => b + (a - b) * k;
    return { pad: Gf.pad, gap: Gf.gap, cw: L(Gf.cw, Gc.cw), ex: L(Gf.ex, Gc.ex), ix: L(Gf.ix, Gc.ix), full: Gf.full };
}
function lqPillPaint(p, S = LQ_PS) {
    const sh = S.sh, G0 = S.G, items = S.items, n = items ? items.length : 0;
    if (!(sh || G0) || !n) return;
    const G = sh ? lqPillShG(sh, sh.k) : G0;      // pad / gap do not change with k
    const pc = Math.max(-.3, Math.min(n - 1 + .3, p));
    let x = G.pad;
    const L = [], Wd = [];
    for (let i = 0; i < n; i++) {
        const w = Math.max(0, 1 - Math.abs(pc - i));
        // each tab follows its own k (a hair later than the one before it), so the bar closes up with a thin ripple; the bar's width is the
        // sum of the tabs, so nothing can stick out of the card
        const ki = sh ? sh.ks[i] : 1, kk = sh ? Math.min(1.06, Math.max(0, ki)) : 1;
        const Gi = sh ? lqPillShG(sh, ki) : G0;
        const wd = Gi.cw + Gi.ex + w * kk * (Gi.full[i] - Gi.cw);
        L[i] = x; Wd[i] = wd; x += wd + G.gap;
        const b = items[i];
        if (sh) b.style.setProperty('--nav-ix', `${Gi.ix.toFixed(1)}px`);
        b.style.left = L[i].toFixed(2) + 'px';
        b.style.width = wd.toFixed(2) + 'px';
        b.style.setProperty('--lw', w.toFixed(3));
        b.style.setProperty('--lk', Math.min(1, w * kk).toFixed(3));      // how much of the name is out (the colours keep following --lw)
    }
    if (sh) S.pill.style.setProperty('--lm', '1.05');
    if (sh) S.pill.style.setProperty('--nav-h', (sh.Hc + (sh.Hf - sh.Hc) * Math.min(1.06, Math.max(-.06, sh.k))).toFixed(2) + 'px');
    if (!sh) S.pill.style.setProperty('--nav-ix', `${G.ix.toFixed(1)}px`);
    S.pill.style.width = (x - G.gap + G.pad).toFixed(2) + 'px';
    if (n > 1 && S.hl) {
        const i0 = Math.max(0, Math.min(n - 2, Math.floor(pc))), t = pc - i0;
        const hx = L[i0] + t * (L[i0 + 1] - L[i0]), hw = Wd[i0] + t * (Wd[i0 + 1] - Wd[i0]);
        S.hl.style.transform = `translate3d(${hx.toFixed(2)}px,0,0)`;
        S.hl.style.width = hw.toFixed(2) + 'px';
    }
}
function lqPillBegin(pill, items, M, p, S = LQ_PS) {
    S.pill = pill; S.items = items; S.G = M; S.p = p;
    let hl = pill.querySelector(':scope > .nav-hl');
    if (!hl) { hl = document.createElement('span'); hl.className = 'nav-hl'; hl.setAttribute('aria-hidden', 'true'); pill.insertBefore(hl, pill.firstChild); }
    S.hl = hl;
    pill.classList.add('nav-slide');
    lqPillPaint(p, S);
}
function lqPillKick(S = LQ_PS) { if (!S.raf) { S.last = performance.now(); S.raf = requestAnimationFrame(t => lqPillStep(t, S)); } }
function lqPillTo(idx, dur, S = LQ_PS) {
    const dist = Math.abs(idx - S.p);
    S.mode = 'tween'; S.from = S.p; S.target = idx; S.t0 = performance.now();
    S.dur = dur || (440 + 90 * Math.min(3, dist));
    S.c1 = Math.min(1.1, 1.1 / Math.max(1, dist));       // a small overshoot, less for a long way
    lqPillKick(S);
}
function lqPillStep(now, S = LQ_PS) {
    S.raf = 0;
    if (!S.mode) return;
    let shDone = true;
    if (S.sh) {
        const h = S.sh, tn = now - h.t0, c1 = .6, c3 = c1 + 1;
        const ez = t => { t = Math.min(1, Math.max(0, t)); return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
        h.k = h.from + (h.to - h.from) * ez(tn / h.dur);
        for (let i = 0; i < h.ks.length; i++) h.ks[i] = h.fromK[i] + (h.to - h.fromK[i]) * ez((tn - h.dl[i]) / h.dur);
        if (tn >= h.dur + h.dmax) { h.k = h.to; h.ks.fill(h.to); } else shDone = false;
    }
    if (S.mode === 'tween' || S.mode === 'shrink') {
        let pDone = true;
        if (S.mode === 'tween') {
            const t = Math.min(1, (now - S.t0) / S.dur), c1 = S.c1, c3 = c1 + 1;
            const e = 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
            S.p = S.from + (S.target - S.from) * e;
            pDone = t >= 1;
            if (pDone) S.p = S.target;
        }
        if (pDone && shDone) { lqPillPaint(S.p, S); lqPillFinish(S); return; }
        if (pDone) S.mode = 'shrink';
    } else {
        const dt = Math.min(50, now - S.last); S.last = now;
        S.p += (S.target - S.p) * (1 - Math.exp(-dt / 70));     // follows the finger with a little lag
    }
    lqPillPaint(S.p, S);
    S.raf = requestAnimationFrame(t => lqPillStep(t, S));
}
// back to the plain layout (same numbers as the last frame, so nothing moves) and the plain highlight on the active tab
function lqPillFinish(S = LQ_PS) {
    const pill = S.pill;
    if (S.raf) cancelAnimationFrame(S.raf);
    S.raf = 0; S.mode = '';
    if (!pill) return;
    if (S.sh) {       // the shrink is over: the plain numbers of the state it ended in (same as the last frame)
        S.sh = null;
        pill.style.removeProperty('--lm');
        document.documentElement.classList.toggle('lq-nav-compact', lqNavCompact);
        lqNavCompactVars();
    }
    const items = [...pill.querySelectorAll('.nav-item')];
    const ai = Math.max(0, items.findIndex(b => b.classList.contains('active')));
    S.p = ai;
    pill.classList.add('nav-slide-end');
    pill.classList.remove('nav-slide');
    items.forEach(b => { b.style.removeProperty('--lw'); b.style.removeProperty('--lk'); b.style.removeProperty('--nav-ix'); });
    lqPillApply(pill, items, lqPillMetrics(pill, items, S.vw || 0, ai), false, ai);      // (S.vw: a copy of the bar on a stage is as wide as its stage)
    requestAnimationFrame(() => requestAnimationFrame(() => pill.classList.remove('nav-slide-end')));
}
// Shrink on scroll for the Pill: runs the names in or out with the same engine / curve as a tab change. false = not possible now (the plain way is used)
function lqPillShrinkStart(on) {
    const S = LQ_PS, pill = document.getElementById('navPill');
    if (!pill || S.mode === 'drag') return false;
    const to = on ? 0 : 1, now = performance.now();
    const delays = n => Array.from({ length: n }, (_, i) => (on ? i : n - 1 - i) * LQ_SHRINK_STAG);     // names go out left to right, come back right to left
    if (S.sh) {      // turned around while it was still moving: carry on from where it is
        const h = S.sh;
        h.from = h.k; h.fromK = h.ks.slice(); h.to = to; h.t0 = now; h.dur = LQ_SHRINK_MS;
        h.dl = delays(h.ks.length); h.dmax = (h.ks.length - 1) * LQ_SHRINK_STAG;
        if (!S.mode) S.mode = 'shrink';
        lqPillKick();
        return true;
    }
    const items = [...pill.querySelectorAll('.nav-item')];
    if (!items.length) return false;
    const ai = Math.max(0, items.findIndex(b => b.classList.contains('active')));
    const keep = lqNavCompact;
    lqNavCompact = false; const Gf = lqPillMetrics(pill, items, 0, ai), Hf = lqNavGeom().H;
    lqNavCompact = true;  const Gc = lqPillMetrics(pill, items, 0, ai), Hc = lqNavGeom().H;
    lqNavCompact = keep;
    const n = items.length, k0 = on ? 1 : 0;
    S.sh = { Gf, Gc, Hf, Hc, k: k0, from: k0, ks: new Array(n).fill(k0), fromK: new Array(n).fill(k0), to, t0: now, dur: LQ_SHRINK_MS, dl: delays(n), dmax: (n - 1) * LQ_SHRINK_STAG };
    if (S.mode) { S.G = on ? Gc : Gf; S.items = items; }
    else { lqPillBegin(pill, items, on ? Gc : Gf, ai); S.mode = 'shrink'; }
    lqPillKick();
    return true;
}
// hold and slide: the pill follows the finger (dx in screen px from where the finger went down, startIdx = the tab it went down on)
function lqPillDragBegin(pill, startIdx) {
    const S = LQ_PS;
    const items = [...pill.querySelectorAll('.nav-item')];
    const ai = Math.max(0, items.findIndex(b => b.classList.contains('active')));
    const M = lqPillMetrics(pill, items, 0, ai);
    if (!S.mode) lqPillBegin(pill, items, M, S.p != null ? S.p : ai); else { S.G = M; S.items = items; }
    S.mode = 'drag'; S.base = startIdx; S.target = startIdx;
    lqPillKick();
}
function lqPillDragMove(dx, scale) {
    const S = LQ_PS;
    if (S.mode !== 'drag' || !S.G) return;
    const step = Math.max(24, (S.G.cw + S.G.ex + S.G.gap) * (scale || 1));
    S.target = Math.max(0, Math.min(S.items.length - 1, S.base + dx / step));
}
// the finger is up: the pill settles on the nearest tab (or on `force`, an index). Returns the index.
function lqPillDragEnd(force) {
    const S = LQ_PS;
    if (S.mode !== 'drag') return -1;
    const idx = Number.isFinite(force) ? force : Math.max(0, Math.min(S.items.length - 1, Math.round(S.target)));
    lqPillTo(idx, 420);
    return idx;
}

// Geometry of the tab styles for a screen `vw` wide: bar, tabs and the lens behind the active tab.
// Width of the longest tab name at its normal (not shrunk) size, so the capsule can give it room.
// Side margin of the bar. A centred capsule with names may stretch closer to the screen edges (8) so the names
// get air inside the lens; the other bars keep the 12 they always had.
function lqNavSide(d, c) {
    if (d.dock) return 12;
    if (c.align !== 'center') return c.side;
    return d.tabs ? 8 : 12;
}
function lqNavWidestName(fsPx) {
    let w = 0;
    try {
        if (!lqNavMeasureCtx) lqNavMeasureCtx = document.createElement('canvas').getContext('2d');
        document.querySelectorAll('#navPill .nav-item-label').forEach(l => {
            const cs = getComputedStyle(l);
            lqNavMeasureCtx.font = `${cs.fontWeight} ${fsPx}px ${cs.fontFamily}`;
            w = Math.max(w, Math.ceil(lqNavMeasureCtx.measureText(l.textContent).width));
        });
    } catch (_) {}
    return w;
}
function lqNavTabGeom(d, n, vw, g) {
    const c = lqNavCfg, H = Math.round(d.base * g.s * g.hk);
    let W, itemW, x0;
    if (d.dock) { W = vw; itemW = W / n; x0 = 0; }
    else {
        const side = lqNavSide(d, c);
        // each tab (and so the lens on the active one) is as wide as its longest name needs plus air on both
        // sides, as far as the screen allows; before it stopped at 78 and the name touched the lens edge
        const room = Math.floor((vw - side * 2 - 8) / n);
        const air = lqNavNamesOn() ? Math.ceil(lqNavWidestName(g.fs)) + 2 * Math.round(18 * g.s) : 0;
        const baseW = lqNavCompact ? Math.round(g.tabIcon * 3.3) : Math.max(Math.round(78 * g.s * Math.max(1, g.ts)), air);
        // Width setting: stretches every tab (and so the lens and the bar). Never narrower than the names can still
        // be shrunk into, never wider than the screen allows.
        const minW = Math.max(40, lqNavNamesOn() ? Math.ceil(lqNavWidestName(g.fs * 0.68)) + 2 * Math.round(14 * g.s) : 40);
        itemW = Math.max(40, Math.min(room, Math.max(minW, Math.round(baseW * c.wide / 100))));
        W = itemW * n + 8; x0 = 4;
    }
    let lw, lh, ly, notch = null;
    if (d.notch) {
        // a round bubble centred on the top edge of the bar, with a notch around it cut out of the bar
        const D = Math.round(52 * g.s * g.hk);
        lw = D; lh = D; ly = -Math.round(D / 2);
        notch = { r: D / 2 + Math.round(6 * g.s), f: Math.round(8 * g.s) };
    } else if (d.bar) {
        // iOS tab bar: not a lens but a slim indicator that hangs from the top edge over the selected tab
        lw = Math.round(34 * g.s); lh = Math.max(3, Math.round(3 * g.s)); ly = 0;
    } else if (d.dock) { lw = Math.max(40, Math.round(itemW - 12)); lh = H - 8; ly = 4; }
    else { lw = itemW; lh = H - 8; ly = 4; }
    return { H, W, itemW, x0, lw, lh, ly, notch, minX: x0 + (itemW - lw) / 2 };
}

// Puts the tabs in place, with short names that are shrunk to fit, so a name is never cut.
function lqNavPlaceTabs(pill, items, geo) {
    items.forEach((btn, i) => {
        btn.style.left = (geo.x0 + i * geo.itemW) + 'px';
        btn.style.width = geo.itemW + 'px';
        btn.style.removeProperty('padding-left');
        btn.style.removeProperty('--d');
    });
    pill.style.removeProperty('--nav-fs');
    pill.style.removeProperty('--nav-ix');
    if (lqNavNamesOn()) {
        const base = parseFloat(getComputedStyle(pill).getPropertyValue('--nav-fs')) || 10.5;
        const avail = geo.itemW - 2 * Math.round(14 * (LQ_NAV_STYLES[lqNavCfg.style].dock ? lqNavCfg.scale / 100 : 1));     // at least ~14px of air on each side of a name
        let worst = 1;
        items.forEach(b => {
            const l = b.querySelector('.nav-item-label');
            const w = l ? lqNavTextW(l) : 0;
            if (w > avail) worst = Math.min(worst, avail / w);
        });
        if (worst < 1) pill.style.setProperty('--nav-fs', (base * Math.max(worst, 0.68)).toFixed(2) + 'px');
    }
}

// ── iOS tab bar: the selected tab opens up (icon + name side by side), the others stay icon only ──
// The lens fits the open tab. Tabs and lens move with the same CSS curve and time, so they stay together.
function lqNavInlineGeom(items, ai, vw, g) {
    const n = items.length, H = Math.round(LQ_NAV_STYLES.iosbar.base * g.s);
    const icon = g.icon, pad = Math.round(8 * g.s), padX = Math.round(14 * g.s), gap = g.gap;
    const label = items[ai] && items[ai].querySelector('.nav-item-label');
    const labelW = lqNavNamesOn() && label ? lqNavTextW(label) : 0;
    let aw = padX * 2 + icon + (labelW ? gap + labelW : 0);
    const avail = vw - pad * 2, minIn = icon + 8;
    aw = Math.min(aw, avail - (n - 1) * minIn);
    const iw = n > 1 ? (avail - aw) / (n - 1) : 0;
    let x = pad;
    const tabs = items.map((_, i) => {
        const w = i === ai ? aw : iw, t = { x, w, pl: i === ai ? padX : Math.max(0, (w - icon) / 2) };
        x += w;
        return t;
    });
    return { H, tabs, lw: aw, lh: H - 8, ly: 4, lx: tabs[ai] ? tabs[ai].x : pad };
}
function lqNavInlineApply(items, geo) {
    items.forEach((btn, i) => {
        const t = geo.tabs[i];
        btn.style.left = `${t.x.toFixed(2)}px`;
        btn.style.width = `${t.w.toFixed(2)}px`;
        btn.style.paddingLeft = `${t.pl.toFixed(2)}px`;
        btn.style.removeProperty('--d');
    });
}
function lqNavLayoutInline(pill, items, d, animate) {
    const g = lqNavGeom();
    const vw = document.documentElement.clientWidth || window.innerWidth || 360;
    const ai = Math.max(0, items.findIndex(b => b.classList.contains('active')));
    const geo = lqNavInlineGeom(items, ai, vw, g);
    pill.style.width = '';
    pill.style.removeProperty('--nav-fs');
    pill.style.removeProperty('--nav-ix');
    lqNavInlineApply(items, geo);
    lqNavLensEnsure(pill);
    lqNavLensConfig({ x: geo.lx, y: geo.ly, w: geo.lw, h: geo.lh, kind: 'inline', notch: null, snap: !animate });
    if (document.documentElement.classList.contains('lq-nav-glass')) {
        lqNavGlassMaps(Math.round(vw), geo.H, 0, geo.lw, geo.lh, g.s);
    }
}

// ── Material bar: the bar's top edge has a smooth round notch under the bubble ──
// The notch is a circle on the top edge with a filleted rim on both sides, written as a clip path for the
// bar's own layer (the bubble sits above the bar, so the bar and not the whole nav is clipped).
function lqNavNotchPath(cx, r, f) {
    const s = Math.sqrt(r * r + 2 * r * f), k = r / (r + f);
    const t = v => v.toFixed(2);
    return `path('M -80 0 H ${t(cx - s)} A ${f} ${f} 0 0 1 ${t(cx - k * s)} ${t(k * f)} A ${r} ${r} 0 0 0 ${t(cx + k * s)} ${t(k * f)} A ${f} ${f} 0 0 1 ${t(cx + s)} 0 H 2400 V 2400 H -80 Z')`;
}

// iOS and Material styles: equal tabs, icon over name, one moving lens behind the active tab.
function lqNavLayoutTabs(pill, items, d, animate) {
    const g = lqNavGeom(), n = items.length;
    const vw = document.documentElement.clientWidth || window.innerWidth || 360;
    const geo = lqNavTabGeom(d, n, vw, g);
    pill.style.width = d.dock ? '' : geo.W + 'px';
    lqNavPlaceTabs(pill, items, geo);

    const ai = Math.max(0, items.findIndex(b => b.classList.contains('active')));
    lqNavLensEnsure(pill);
    Object.assign(lqNavLens, { minX: geo.minX, maxX: geo.minX + (n - 1) * geo.itemW, itemW: geo.itemW, x0: geo.x0, n });
    lqNavLensConfig({ x: geo.minX + ai * geo.itemW, y: geo.ly, w: geo.lw, h: geo.lh, kind: d.ios ? 'ios' : (geo.notch ? 'notch' : 'material'), notch: geo.notch, snap: !animate });

    if (document.documentElement.classList.contains('lq-nav-glass')) {
        lqNavGlassMaps(Math.round(geo.W), geo.H, d.dock ? 0 : geo.H / 2, geo.lw, geo.lh, g.s);
    }
}

// ── the little phone on top of UI Settings: a copy of the real bar, same classes, same numbers ──
function lqNavPreviewEl() {
    const host = document.querySelector('.lq-sk-in');
    const real = document.getElementById('navPill');
    if (!host || !real) return null;
    let pv = host.querySelector('.sk-navclone');
    if (pv) return pv;
    pv = document.createElement('span');
    pv.className = 'nav-pill nav-in sk-navclone';
    pv.setAttribute('aria-hidden', 'true');
    [...real.querySelectorAll('.nav-item')].forEach((btn, i) => {
        const it = document.createElement('span');
        it.className = 'nav-item' + (i === 0 ? ' active' : '');    // the preview shows the dashboard
        it.dataset.nav = btn.dataset.nav;
        it.innerHTML = btn.innerHTML;
        pv.appendChild(it);
    });
    lqNavMakeLayers(pv);
    host.appendChild(pv);
    return pv;
}
// Lays out a copy of the bar (same classes as the real one) for a given width and active tab, with the same
// functions the real bar uses. Returns what the glass maps and the toasts need to know about its size.
function lqNavCloneLayout(pv, items, vw, ai) {
    const d = LQ_NAV_STYLES[lqNavCfg.style] || LQ_NAV_STYLES.pill, g = lqNavGeom();
    items.forEach((b, i) => b.classList.toggle('active', i === ai));
    if (!d.tabs) {
        lqNavLayoutPill(pv, items, false, vw);
        return { d, H: g.H, W: 0, lw: 0, lh: 0, rad: 0 };
    }
    const geo = lqNavTabGeom(d, items.length, vw, g);
    pv.style.width = d.dock ? '' : geo.W + 'px';
    lqNavPlaceTabs(pv, items, geo);
    const x = geo.minX + ai * geo.itemW;
    const lens = pv.querySelector('.nav-lens');
    if (lens) {
        lens.style.width = geo.lw + 'px';
        lens.style.height = geo.lh + 'px';
        lens.style.transform = `translate3d(${x}px,${geo.ly}px,0)`;
    }
    const bg = pv.querySelector('.nav-glassbg');
    if (bg) bg.style.clipPath = geo.notch ? lqNavNotchPath(x + geo.lw / 2, geo.notch.r, geo.notch.f) : '';
    return { d, ...geo, rad: d.dock ? 0 : geo.H / 2 };
}
function lqNavPreviewLayout() {
    const pv = lqNavPreviewEl();
    if (!pv) return;
    const items = [...pv.querySelectorAll('.nav-item')];
    const d = LQ_NAV_STYLES[lqNavCfg.style] || LQ_NAV_STYLES.pill;
    if (!d.tabs) { lqNavLayoutPill(pv, items, false, 360); return; }       // the little phone is 360 wide
    const g = lqNavGeom();
    if (d.inline) {
        const ig = lqNavInlineGeom(items, 0, 360, g);
        pv.style.width = '';
        lqNavInlineApply(items, ig);
        const lensI = pv.querySelector('.nav-lens');
        if (lensI) {
            lensI.style.width = ig.lw + 'px';
            lensI.style.height = ig.lh + 'px';
            lensI.style.transform = `translate3d(${ig.lx}px,${ig.ly}px,0)`;
        }
        return;
    }
    const geo = lqNavTabGeom(d, items.length, 360, g);       // the little phone is 360 wide
    pv.style.width = d.dock ? '' : geo.W + 'px';
    lqNavPlaceTabs(pv, items, geo);
    const lens = pv.querySelector('.nav-lens');
    if (lens) {
        lens.style.width = geo.lw + 'px';
        lens.style.height = geo.lh + 'px';
        lens.style.transform = `translate3d(${geo.minX}px,${geo.ly}px,0)`;
    }
    const bg = pv.querySelector('.nav-glassbg');
    if (bg) bg.style.clipPath = geo.notch ? lqNavNotchPath(geo.minX + geo.lw / 2, geo.notch.r, geo.notch.f) : '';
}

// ── the lens: a spring-driven element behind the active tab ──
const lqNavLensNew = () => ({ el: null, x: 0, v: 0, tx: 0, y: 0, w: 0, h: 0, sc: 1, sv: 0, tsc: 1, drag: false, raf: 0, t0: 0,
                    inited: false, kind: 'ios', minX: 0, maxX: 0, itemW: 0, x0: 0, n: 1, notch: null, bg: null });
const lqNavLens = lqNavLensNew();

// glass layer + lens, put first so the tabs sit above them
function lqNavMakeLayers(pill) {
    const bg = document.createElement('span');
    bg.className = 'nav-glassbg';
    bg.setAttribute('aria-hidden', 'true');
    const lens = document.createElement('span');
    lens.className = 'nav-lens';
    lens.setAttribute('aria-hidden', 'true');
    pill.insertBefore(lens, pill.firstChild);
    pill.insertBefore(bg, pill.firstChild);
    return lens;
}
function lqNavLensEnsure(pill) {
    const L = lqNavLens;
    if (L.el && L.el.parentNode === pill) return;
    L.el = lqNavMakeLayers(pill);
    L.inited = false;
}

function lqNavLensPaint(L = lqNavLens) {
    if (!L.el) return;
    // it stretches along the way it moves, like jelly, and gives the width back in height
    const k = L.kind === 'ios' ? Math.min(Math.abs(L.v) / 2000, 0.2) : 0;
    L.el.style.transform = `translate3d(${L.x.toFixed(2)}px,${L.y}px,0) scale(${(L.sc * (1 + k)).toFixed(4)},${(L.sc * (1 - k * 0.6)).toFixed(4)})`;
    // the notch follows the bubble on every frame of its spring
    if (L.kind === 'notch' && L.bg && L.notch) L.bg.style.clipPath = lqNavNotchPath(L.x + L.w / 2, L.notch.r, L.notch.f);
}

function lqNavLensConfig({ x, y, w, h, kind, snap, notch = null }, L = lqNavLens) {
    if (!L.el) return;
    L.kind = kind;
    L.notch = notch;
    if (kind === 'notch') L.bg = L.el.parentNode && L.el.parentNode.querySelector('.nav-glassbg');
    else { if (L.bg) L.bg.style.clipPath = ''; L.bg = null; }
    if (L.w !== w || L.h !== h) {
        L.w = w; L.h = h;
        L.el.style.width = `${w}px`;
        L.el.style.height = `${h}px`;
    }
    L.y = y;
    if (!L.drag) L.tx = x;
    // inline: the lens moves by the same CSS transition as the tabs (no spring), so they never drift apart
    if (snap || !L.inited || lqReduced() || kind === 'inline') {
        L.x = L.tx; L.v = 0;
        L.sc = L.tsc; L.sv = 0;
        L.inited = true;
        lqNavLensPaint(L);
    } else {
        lqNavLensRun(L);
    }
}

function lqNavLensRun(L = lqNavLens) {
    if (!L.el || L.raf) return;
    if (lqReduced()) { L.x = L.tx; L.v = 0; L.sc = L.tsc; L.sv = 0; lqNavLensPaint(L); return; }
    L.t0 = performance.now();
    const tick = now => {
        const dt = Math.min((now - L.t0) / 1000, 0.05);
        L.t0 = now;
        // iOS: lively, a little overshoot. Material: close to critically damped.
        const P = L.kind === 'ios' ? { k: 190, c: 19.5 } : L.kind === 'notch' ? { k: 150, c: 16 } : { k: 520, c: 46 };
        const S = { k: 520, c: 21 };
        const steps = Math.max(1, Math.ceil(dt / 0.004)), h = dt / steps;
        for (let i = 0; i < steps; i++) {
            L.v += (-P.k * (L.x - L.tx) - P.c * L.v) * h;
            L.x += L.v * h;
            L.sv += (-S.k * (L.sc - L.tsc) - S.c * L.sv) * h;
            L.sc += L.sv * h;
        }
        const settled = Math.abs(L.x - L.tx) < 0.04 && Math.abs(L.v) < 0.4 && Math.abs(L.sc - L.tsc) < 0.0008 && Math.abs(L.sv) < 0.02;
        if (settled) { L.x = L.tx; L.v = 0; L.sc = L.tsc; L.sv = 0; L.raf = 0; lqNavLensPaint(L); return; }
        lqNavLensPaint(L);
        L.raf = requestAnimationFrame(tick);
    };
    L.raf = requestAnimationFrame(tick);
}

function lqNavLensPress(on, L = lqNavLens) {
    if (!L.el) return;
    const lift = on && L.kind === 'ios';
    L.tsc = lift ? 1.18 : (on && L.kind === 'notch' ? 1.08 : 1);      // the Material bubble swells a little while held
    L.el.classList.toggle('is-press', lift);
    (L.el.parentNode || document.getElementById('navPill'))?.classList.toggle('lens-hold', lift);
    lqMarkMotion(900);
    lqNavLensRun(L);
}

function lqNavPop(btn) {
    btn.classList.remove('nav-pop');
    void btn.offsetWidth;
    btn.classList.add('nav-pop');
    window.setTimeout(() => btn.classList.remove('nav-pop'), 700);
}

// Touch handling for the tab styles with a lens (Capsule, Indicator bar, Material bar). The bar answers right away
// on touch (no long press needed): hold and slide to carry the lens or the bubble across, release to open the tab.
function initNavIos() {
    const pill = document.getElementById('navPill');
    if (!pill) return;
    const L = lqNavLens;
    let st = null, swallow = false, swallowT = 0;
    const isIos = () => document.documentElement.classList.contains('lq-nav-tabs') && !document.documentElement.classList.contains('lq-nav-inline');
    const items = () => [...pill.querySelectorAll('.nav-item')];
    const allowed = tab => !(lqConflictActive && LQ_CONFLICT_PAGES.has(tab));
    const select = tab => {
        if (!st || !tab || tab === st.sel || !allowed(tab)) return;
        st.sel = tab;
        updateNavActive(tab);
    };
    const localX = cx => cx - pill.getBoundingClientRect().left;
    const tabAt = lx => items()[Math.max(0, Math.min(L.n - 1, Math.floor((lx - L.x0) / L.itemW)))]?.dataset.nav;
    const rubber = d => 26 * (1 - Math.exp(-d / 26));

    const finish = (e, commit) => {
        if (!st || e.pointerId !== st.id) return;
        const s = st;
        st = null;
        L.drag = false;
        try { pill.releasePointerCapture(s.id); } catch (_) {}
        lqNavLensPress(false);
        swallow = true;
        clearTimeout(swallowT);
        swallowT = window.setTimeout(() => { swallow = false; }, 400);
        if (commit && s.sel !== currentPage && !navBusy) switchPage(s.sel);
        else updateNavActive(currentPage);
    };

    pill.addEventListener('pointerdown', e => {
        if (!isIos() || st || (e.pointerType === 'mouse' && e.button !== 0)) return;
        const item = e.target.closest('.nav-item');
        if (!item) return;
        const cur = items().find(b => b.classList.contains('active'));
        st = { id: e.pointerId, x0: e.clientX, moved: false, sel: cur ? cur.dataset.nav : currentPage };
        try { pill.setPointerCapture(e.pointerId); } catch (_) {}
        lqNavLensPress(true);
        select(item.dataset.nav);
    });
    pill.addEventListener('pointermove', e => {
        if (!st || e.pointerId !== st.id) return;
        if (!st.moved) {
            if (Math.abs(e.clientX - st.x0) < 6) return;
            st.moved = true;
            L.drag = true;
        }
        const lx = localX(e.clientX);
        let want = lx - L.w / 2;
        if (want < L.minX) want = L.minX - rubber(L.minX - want);
        else if (want > L.maxX) want = L.maxX + rubber(want - L.maxX);
        L.tx = want;                 // the lens trails the finger on its spring
        lqNavLensRun();
        select(tabAt(lx));
    });
    pill.addEventListener('pointerup', e => finish(e, true));
    pill.addEventListener('pointercancel', e => finish(e, false));
    pill.addEventListener('contextmenu', e => { if (isIos()) e.preventDefault(); });
    pill.addEventListener('click', e => {
        if (swallow) { e.stopPropagation(); e.preventDefault(); }
    }, true);
}

// ── glass maps for the bar and the lens (same idea as the toast map, sized per element) ──
let lqNavMapKey = '';
// The edge of the bar and of the lens: WebGL pictures sized to each of them (edge width, curve, lip and strength come from
// the Liquid Glass card, so the nav and the toasts have the same edge).
function lqNavGlassMaps(W, H, rad, lw, lh, sc) {
    const gc = lqGlassNavCfg;      // the bar and the lens have their own values, not the toasts'
    const key = `${W}x${H}r${Math.round(rad)}|${lw}x${lh}|${sc}|${gc.bezel}|${gc.curve}|${gc.lip}|${gc.edge}|${gc.lipw}|${gc.distort}|${gc.split}|${LQ_GX.draft ? 1 : 0}`;
    if (key === lqNavMapKey) return;
    const np = document.getElementById('navPill');
    if (np && (np.classList.contains('nav-entering') || np.classList.contains('nav-resizing'))) { lqNavMapPending = [W, H, rad, lw, lh, sc]; return; }
    const p = lqGxParams(gc, sc);
    lqGxEnsure();
    lqGxBake('lqf-bar', W, H, rad, p);
    lqGxBake('lqf-lens', Math.round(lw), Math.round(lh), lh / 2, p);
    lqNavMapKey = key;
}

// ── settings cards (style, position, size). Liquid Glass lives in its own card under Extras. ──
function initNavSettings() {
    lqNavCfg = lqNavLoad();
    lqNavInited = true;
    lqNavApply();

    const $ = id => document.getElementById(id);
    const styleBtns = [...document.querySelectorAll('#navStyleGrid [data-nav-style]')];
    const alignBtns = [...document.querySelectorAll('#navAlignGrid [data-nav-align]')];
    if (!styleBtns.length || !alignBtns.length) return;
    const labelsToggle = $('navLabelsToggle');
    const shrinkToggle = $('navShrinkToggle');
    const fadeToggle = $('navFadeToggle');
    const sl = id => ({ input: $(`${id}Slider`), out: $(`${id}Value`) });
    const S = { offset: sl('navOffset'), side: sl('navSide'), scale: sl('navScale'), wide: sl('navWide') };

    const setRange = (r, v, lo, hi, unit) => {
        if (!r.input || !r.out) return;
        r.input.value = String(v);
        r.input.style.setProperty('--lq-progress', String((v - lo) / (hi - lo)));
        r.out.textContent = `${v}${unit}`;
    };

    const paint = () => {
        const c = lqNavCfg, d = LQ_NAV_STYLES[c.style];
        styleBtns.forEach(b => b.classList.toggle('is-active', b.dataset.navStyle === c.style));
        alignBtns.forEach(b => b.classList.toggle('is-active', b.dataset.navAlign === c.align));
        const sv = $('navStyleValue'); if (sv) sv.textContent = d.name;
        const note = $('navStyleNote'); if (note) note.textContent = d.note;

        // docked bars are tied to the screen edge: position does not apply
        const locked = d.dock;
        $('navAlignGrid')?.classList.toggle('is-disabled', locked);
        $('navPosControls')?.classList.toggle('is-disabled', locked);
        const pn = $('navPosNote'); if (pn) pn.hidden = !locked;
        if (S.side.input) S.side.input.disabled = locked || c.align === 'center';
        // a centred bar has no side distance: dim just this slider (docked styles already dim the whole group)
        const sideOff = !locked && c.align === 'center';
        $('navSideLabelRow')?.classList.toggle('is-off', sideOff);
        $('navSideSliderRow')?.classList.toggle('is-off', sideOff);
        if (S.offset.input) S.offset.input.disabled = locked;
        alignBtns.forEach(b => { b.disabled = locked; });

        setRange(S.offset, c.offset, 0, 64, 'px');
        setRange(S.side, c.side, 0, 48, 'px');
        setRange(S.scale, c.scale, 70, 140, '%');
        // width only exists on the floating bars: a docked bar spans the whole screen
        setRange(S.wide, c.wide, 80, 130, '%');
        if (locked && S.wide.out) S.wide.out.textContent = 'Full';
        if (S.wide.input) S.wide.input.disabled = locked;
        $('navWideLabelRow')?.classList.toggle('is-disabled', locked);
        $('navWideSliderRow')?.classList.toggle('is-disabled', locked);
        const wn = $('navWideNote'); if (wn) wn.hidden = !locked;
        if (labelsToggle) {      // the Material bar has its own way of showing the name (only the selected tab), so the switch is locked there
            labelsToggle.classList.toggle('on', c.labels); labelsToggle.setAttribute('aria-pressed', String(c.labels));
            labelsToggle.disabled = !!d.notch;
            $('navLabelsRow')?.classList.toggle('is-disabled', !!d.notch);
        }
        if (shrinkToggle) {      // only means something while the bar shows names
            const off = !c.labels || !!d.notch, so = c.shrink && !off;      // !!: classList.toggle(x, undefined) flips the class instead of setting it
            shrinkToggle.classList.toggle('on', so); shrinkToggle.setAttribute('aria-pressed', String(so)); shrinkToggle.disabled = off;
            $('navShrinkRow')?.classList.toggle('is-disabled', off);
        }
        // docked bars (Indicator bar, Material bar) never draw the gradient, so the switch is shown off and locked;
        // the saved choice itself is kept and comes back on the floating bars
        const fadeOn = c.fade && !d.dock;
        if (fadeToggle) {
            fadeToggle.classList.toggle('on', fadeOn);
            fadeToggle.setAttribute('aria-pressed', String(fadeOn));
            fadeToggle.disabled = d.dock;
        }
        $('navFadeRow')?.classList.toggle('is-disabled', d.dock);
        const fn = $('navFadeNote');
        if (fn) {
            if (!fn.dataset.txt) fn.dataset.txt = fn.textContent;
            fn.textContent = d.dock ? 'Not used on a docked bar, it sits flush with the screen edge.' : fn.dataset.txt;
        }
        lqGlassNavSync?.();
    };
    const commit = next => {
        lqNavCfg = lqNavNormalize(next);
        lqNavApply({ persist: true });
        paint();
    };
    const cur = () => JSON.parse(JSON.stringify(lqNavCfg));

    styleBtns.forEach(b => b.addEventListener('click', () => {
        const n = cur();
        if (n.style === b.dataset.navStyle) return;
        n.style = b.dataset.navStyle;
        commit(n);
        lqNavReplay();
    }));
    alignBtns.forEach(b => b.addEventListener('click', () => { const n = cur(); n.align = b.dataset.navAlign; commit(n); }));
    [['offset', S.offset], ['side', S.side], ['scale', S.scale], ['wide', S.wide]].forEach(([k, r]) => {
        r.input?.addEventListener('input', () => { const n = cur(); n[k] = r.input.value; commit(n); });
    });
    labelsToggle?.addEventListener('click', () => { if (LQ_NAV_STYLES[lqNavCfg.style].notch) return; const n = cur(); n.labels = !n.labels; commit(n); });
    shrinkToggle?.addEventListener('click', () => { if (!lqNavCfg.labels || LQ_NAV_STYLES[lqNavCfg.style].notch) return; const n = cur(); n.shrink = !n.shrink; commit(n); });
    fadeToggle?.addEventListener('click', () => { if (LQ_NAV_STYLES[lqNavCfg.style].dock) return; const n = cur(); n.fade = !n.fade; commit(n); });

    paint();
    lqUiResync.nav = () => { lqNavCfg = lqNavLoad(); lqNavApply(); paint(); lqUiResync.glass?.(); };
}

// ── UI prefs backup (automatic) ──────────────────────────────
// localStorage belongs to the WebUI host, and a fresh flash (or the host cleaning up) can wipe it, which silently put every UI setting
// back to its default. The module keeps its own state in /data/local/tmp/liqinghe (customize.sh leaves that folder alone on updates), so
// every save is mirrored to ONE file in the backup-ui folder there, and whatever localStorage is missing is put back from it on boot.
// The file is a normal Li Qinghe UI backup (the same format the Restore card reads), plus a `prefs` part with the exact stored values.
//
// What used to go wrong (all fixed here):
//   - the old file was written with the JSON text inside the command, and the root bridge drops every double quote from a command, so on
//     those hosts the file was never valid JSON and could never be read back. It is sent as base64 now (same way as every other file).
//   - it was written in place, so a WebUI closed in the middle of the write left a half file. It is written next to it and renamed now.
//   - it was replaced by whatever localStorage held at that moment: after a failed or skipped restore, the first setting that changed
//     overwrote the whole file with that one setting. Nothing is written until the saved copy has been read (or is known not to exist),
//     and a copy that cannot be read is moved aside as .bad, never overwritten.
//   - the restore only ran when localStorage was completely empty, and gave up after three quick tries when the root bridge was not
//     ready yet. It now fills in every key that is missing and keeps trying in the background.
const LQ_UI_PREFS_LEGACY_FILE = '/data/local/tmp/liqinghe/ui_prefs.json';      // where the first version wrote it
const LQ_UI_PREF_KEYS = [UI_PALETTE_KEY, UI_RADIUS_KEY, UI_GLASS_KEY, UI_GLASS_NAV_KEY, UI_FROST_KEY, UI_NAV_KEY, UI_SCALE_KEY, UI_FONT_KEY, UI_PKGSORT_KEY, UI_ANGLETEX_KEY];
let lqPrefsMirrorTimer = 0;
let lqPrefsGate = false;      // true once the saved copy has been read (or there is none): before that nothing is written over it
let lqPrefsDirty = false;      // something changed while the gate was shut
let lqBkLockChain = Promise.resolve();

function lqCollectUIPrefs() {
    const out = {};
    LQ_UI_PREF_KEYS.forEach(key => {
        try {
            const v = localStorage.getItem(key);
            if (v !== null) out[key] = v;
        } catch (_) {}
    });
    return out;
}

// What goes into the file: the items the Restore card knows (only what is not on its default, no font file and no banner photo, those stay
// in the module folder) and `prefs`, the exact stored values, which is what the boot-time restore uses.
function lqAutoBackupDoc(prefs) {
    const snap = lqBkSnapshot(), items = {};
    LQ_BK_KEYS.forEach(k => {
        if (snap[k].isDefault || k === 'font') return;
        items[k] = k === 'banner' ? { pos: snap.banner.value.pos } : snap[k].value;
    });
    return { format: LQ_BK_FORMAT, version: LQ_BK_VERSION, module: 'LQlzy', created: new Date().toISOString(), items, prefs };
}

async function lqWriteUIPrefsNow() {
    clearTimeout(lqPrefsMirrorTimer);
    lqPrefsMirrorTimer = 0;
    if (!lqPrefsGate) { lqPrefsDirty = true; return false; }
    const prefs = lqCollectUIPrefs();
    if (!Object.keys(prefs).length) return false;      // never replace the saved copy with nothing
    lqPrefsDirty = false;
    // no raw whitespace anywhere in the file (the Restore card reads it back without any): a space inside a string is written as \u0020
    const text = lqBkAscii(JSON.stringify(lqAutoBackupDoc(prefs))).replace(/ /g, '\\u0020');
    const ok = await lqBkWriteAtomic(LQ_BK_AUTO_FILE, text);
    if (!ok) { lqPrefsDirty = true; return false; }
    exec(`rm -f ${shellQuote(LQ_UI_PREFS_LEGACY_FILE)} ${shellQuote(LQ_BK_OLD_FILE)} 2>/dev/null`);      // the older places are not needed any more
    return true;
}

function lqMirrorUIPrefs() {
    clearTimeout(lqPrefsMirrorTimer);
    lqPrefsMirrorTimer = setTimeout(lqWriteUIPrefsNow, 250);
}
// closing the WebUI right after a change: do not wait for the delay
function lqFlushUIPrefs() { if (lqPrefsMirrorTimer || lqPrefsDirty) lqWriteUIPrefsNow(); }
window.addEventListener('pagehide', lqFlushUIPrefs);
document.addEventListener('visibilitychange', () => { if (document.hidden) lqFlushUIPrefs(); });

// Reads the saved copy. state: 'ok' (prefs is the stored values), 'none' (there is no file, a definite answer from the shell),
// 'bad' (there is a file but it cannot be read as a backup), 'unknown' (the root bridge did not answer).
async function lqReadSavedPrefs() {
    const ask = async file => {
        const F = shellQuote(file);
        const r = String(await exec(`[ -s ${F} ] && echo __LQ_Y__ || echo __LQ_N__`) || '');
        if (r.includes('__LQ_N__')) return { state: 'none' };
        if (!r.includes('__LQ_Y__')) return { state: 'unknown' };
        // The bridge hands a command's output back in pieces and joins them with a newline, and the file is one long line: from about 4 KB on
        // a newline lands inside the text, which JSON.parse refuses (a raw newline is not allowed inside a string). The file itself was fine
        // (that is how a good file of 5 KB got moved aside as .bad and the UI fell back to its defaults). The file never holds whitespace of its
        // own (see lqWriteUIPrefsNow), so it is read the way the Restore card reads it, piece by piece with every whitespace dropped, and if that
        // cannot be used a plain read is tried as it is and then with the whitespace dropped.
        const parse = txt => {
            try {
                txt = String(txt || '').trim();
                const i0 = txt.indexOf('{'), i1 = txt.lastIndexOf('}');      // anything the bridge adds around the JSON is not part of the file
                return JSON.parse(i0 >= 0 && i1 > i0 ? txt.slice(i0, i1 + 1) : txt);
            } catch (_) { return null; }
        };
        let doc = null;
        try { doc = parse(await lqBkReadFile(file)); } catch (_) {}
        if (!doc) {
            let txt = '';
            try { txt = String(await exec(`cat ${F} 2>/dev/null`) || ''); } catch (_) {}
            doc = parse(txt) || parse(txt.replace(/\s+/g, ''));
        }
        const prefs = doc && typeof doc === 'object' ? (doc.format === LQ_BK_FORMAT ? doc.prefs : doc) : null;      // the first version's file was the bare key map
        if (prefs && typeof prefs === 'object' && !Array.isArray(prefs)) return { state: 'ok', prefs };
        return { state: 'bad' };
    };
    const cur = await ask(LQ_BK_AUTO_FILE);
    if (cur.state !== 'none') return cur;
    const old = await ask(LQ_BK_OLD_FILE);      // the previous place (module folder), only for the first run after the update
    if (old.state !== 'none') return old;
    return ask(LQ_UI_PREFS_LEGACY_FILE);
}

// Puts back every key localStorage is missing. Returns 'restored', 'nothing' (the gate is open, nothing to put back) or 'wait'
// (the saved copy could not be read yet: the gate stays shut, so nothing can overwrite it).
async function lqRestoreUIPrefs(giveUpOnBad = false) {
    let res = { state: 'unknown' };
    for (let attempt = 0; attempt < 5; attempt++) {
        if (attempt) await new Promise(r => setTimeout(r, attempt * 900));      // the root bridge can need a moment right after the page opens
        res = await lqReadSavedPrefs();
        if (res.state === 'ok' || res.state === 'none') break;
    }
    if (res.state === 'unknown') return 'wait';
    // a file that is there but did not read as a backup is most often a bridge that answered badly (cut or empty output), not a broken file:
    // the gate stays shut and it is read again a few times first, so the good copy is never moved aside or written over because of one bad read
    if (res.state === 'bad' && !giveUpOnBad) return 'wait';
    if (res.state === 'bad') {
        // keep what is there for a look, and go on without it: a file that cannot be read is no use, and the next save replaces it
        await exec(`cp -f ${shellQuote(LQ_BK_AUTO_FILE)} ${shellQuote(LQ_BK_AUTO_FILE + '.bad')} 2>/dev/null`);
        res = { state: 'none' };
    }
    let restored = false;
    if (res.state === 'ok') {
        LQ_UI_PREF_KEYS.forEach(key => {
            if (typeof res.prefs[key] !== 'string') return;
            try {
                if (localStorage.getItem(key) === null) { localStorage.setItem(key, res.prefs[key]); restored = true; }
            } catch (_) {}
        });
    }
    lqPrefsGate = true;
    lqMirrorUIPrefs();      // from here on the file follows localStorage (this also moves the first version's file over)
    return restored ? 'restored' : 'nothing';
}
// every card repaints from what is stored, the same way a normal Apply does
async function lqRepaintUIPrefs() {
    for (const k of ['palette', 'radius', 'glass', 'nav', 'scale', 'font', 'banner']) {
        try { await lqUiApplyNow(k); } catch (_) {}
    }
    try { loadPkgSort(); syncPkgSortUI(); syncPkgEditClass(); redrawPkgList(0); } catch (_) {}      // the Apps list: sort mode and the custom order
}
// the saved copy could not be read at boot: ask again every few seconds for a while, and repaint if it turns out there was something
function lqRestoreRetry(n = 0) {
    if (lqPrefsGate || n >= 20) return;
    setTimeout(async () => {
        if (lqPrefsGate) return;
        const r = await lqRestoreUIPrefs(n >= 2);
        if (r === 'restored') lqRepaintUIPrefs();
        else if (r === 'wait') lqRestoreRetry(n + 1);
    }, 4000);
}

// One failing init must never stop the others from running, otherwise the
// saved radius/palette would silently not get applied.
// Every init step is listed on the splash with its own state (running / done / failed),
// so what the app is doing while it boots is visible instead of hidden behind one bar.
const LQ_BOOT_LABELS = {
    radius: 'Corner radius', sizeFont: 'Size & font', glass: 'Liquid glass', frost: 'Frosted glass', palette: 'Color palette',
    navigation: 'Navigation', packages: 'Apps', tweaks: 'Tweaks page',
    banner: 'Banner', backup: 'Backup settings', dashboard: 'Home',
    deviceInfo: 'Device info', deviceToggle: 'Device card', environment: 'Environment',
    cpu: 'CPU stats', temp: 'Temperature', system: 'Memory & storage', uptime: 'Uptime',
    conflict: 'Service status', tweakState: 'Tweak status', restorePrefs: 'Saved preferences', toastWarm: 'Toasts', aboutPhone: 'About phone', glassPreview: 'Glass preview', atxPreview: 'Angle Texture preview', assets: 'Fonts & images'
};
// The one line under the splash bar always names what is happening right now.
const lqBootRun = new Map();   // running steps, in the order they started
let lqBootFlash = 0;
function lqBootText(t) {
    const n = document.getElementById('splashNote');
    if (!n || n.textContent === t) return;
    n.textContent = t;
    n.classList.remove('swap'); void n.offsetWidth; n.classList.add('swap');
}
function lqBootStep(key, state, detail) {
    const label = LQ_BOOT_LABELS[key];
    if (!label) return;
    if (state === 'run') lqBootRun.set(key, detail ? `${label} (${detail})` : label);
    else lqBootRun.delete(key);
    if (state === 'warn' || state === 'err') {
        // a problem stays readable for a moment before the next step takes the line
        lqBootText(`${label}: ${detail || (state === 'err' ? 'failed' : 'no answer')}`);
        lqBootFlash = performance.now() + 900;
        setTimeout(lqBootPaint, 950);
        return;
    }
    lqBootPaint();
}
function lqBootPaint() {
    if (performance.now() < lqBootFlash) return;
    const last = [...lqBootRun.values()].pop();
    lqBootText(last ? `Loading ${last}...` : '');
}

function lqSafeInit(name, fn) {
    lqBootStep(name, 'run');
    try {
        const r = fn();
        if (r && typeof r.then === 'function') {
            r.then(v => lqBootStep(name, v === false ? 'warn' : 'ok', v === false ? 'no answer' : null),
                   e => { console.error('[init]', name, e); lqBootStep(name, 'err', 'failed'); });
            lqBootTrack(r);
        } else {
            lqBootStep(name, 'ok');
        }
    } catch (e) {
        console.error('[init]', name, e);
        lqBootStep(name, 'err', 'failed');
    }
}

// ── UI Settings / Custom Banner ──────────────────────────────
// The photo itself is written to disk as webroot/custom.<ext> (via the
// root shell bridge) instead of living in localStorage, localStorage
// only remembers which extension is active plus the crop position, so
// it stays tiny and the banner survives a WebUI reopen by just pointing
// at the file that's already sitting in webroot.
const LQ_MODULE_DIR = '/data/user_de/0/com.android.shell/axeron/plugins/LQlzy';
const LQ_BANNER_WEBROOT_DIR = `${LQ_MODULE_DIR}/webroot`;
const LQ_BANNER_TMP_DIR = '/data/local/tmp/liqinghe';
const LQ_BANNER_TMP_FILE = `${LQ_BANNER_TMP_DIR}/banner_upload.b64`;
// 180000 used to be here, but that's actually OVER Linux's per-argument
// exec limit (MAX_ARG_STRLEN = 131072 bytes/128KB): any chunk at full size
// blew past it and made the whole exec() call fail before writing anything,
// which is why uploads only "worked" for photos small enough to fit in one
// undersized chunk (e.g. already-compressed images) and failed for
// everything else. 90000 leaves comfortable headroom for the surrounding
// `printf '%s' ... >>` shell wrapper on top of the raw chunk bytes.
const LQ_BANNER_CHUNK_SIZE = 90000; // base64 chars per exec call
const LQ_BANNER_MIME_EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/webp': 'webp' };
const LQ_BANNER_ALLOWED_EXT = ['png', 'jpg', 'webp'];
const LQ_BANNER_MAX_SIZE_BYTES = 5 * 1024 * 1024; // 5MB cap on the picked file itself

const UI_BANNER_EXT_KEY = 'lq_ui_banner_ext_v1';
const UI_BANNER_POS_KEY = 'lq_ui_banner_pos_v1';
const UI_BANNER_BUST_KEY = 'lq_ui_banner_bust_v1';
// the custom banner (which photo, where it is cropped) is part of the saved look too: without these three a wiped localStorage brought back the
// default banner although the photo itself was still in the webroot folder
LQ_UI_PREF_KEYS.push(UI_BANNER_EXT_KEY, UI_BANNER_POS_KEY, UI_BANNER_BUST_KEY);
const UI_BANNER_POS_DEFAULT = 50;

function bannerFilePath(ext) {
    return `${LQ_BANNER_WEBROOT_DIR}/custom.${ext}`;
}

// Trusts the browser-reported MIME type first (accurate for photos coming
// out of the Android media picker); falls back to the file name's suffix
// for the rare picker/source that hands back a generic/empty type.
function resolveBannerExt(file) {
    const byMime = LQ_BANNER_MIME_EXT[String(file?.type || '').toLowerCase()];
    if (byMime) return byMime;
    const match = /\.([a-z0-9]+)$/i.exec(file?.name || '');
    let ext = match ? match[1].toLowerCase() : '';
    if (ext === 'jpeg') ext = 'jpg';
    return LQ_BANNER_ALLOWED_EXT.includes(ext) ? ext : '';
}

function normalizeBannerPos(value) {
    const parsed = Number(value);
    if (!Number.isFinite(parsed)) return UI_BANNER_POS_DEFAULT;
    return Math.min(100, Math.max(0, Math.round(parsed)));
}

function loadBannerExt() {
    try {
        const raw = localStorage.getItem(UI_BANNER_EXT_KEY) || '';
        return LQ_BANNER_ALLOWED_EXT.includes(raw) ? raw : '';
    } catch (_) {
        return '';
    }
}

function saveBannerExt(ext) {
    try {
        if (ext) localStorage.setItem(UI_BANNER_EXT_KEY, ext);
        else localStorage.removeItem(UI_BANNER_EXT_KEY);
    } catch (_) {}
    lqMirrorUIPrefs();
}

function loadBannerPos() {
    try {
        const raw = localStorage.getItem(UI_BANNER_POS_KEY);
        if (!raw) return { x: UI_BANNER_POS_DEFAULT, y: UI_BANNER_POS_DEFAULT };
        const [x, y] = String(raw).split(',');
        return { x: normalizeBannerPos(x), y: normalizeBannerPos(y) };
    } catch (_) {
        return { x: UI_BANNER_POS_DEFAULT, y: UI_BANNER_POS_DEFAULT };
    }
}

function saveBannerPos(pos) {
    try {
        localStorage.setItem(UI_BANNER_POS_KEY, `${normalizeBannerPos(pos?.x)},${normalizeBannerPos(pos?.y)}`);
    } catch (_) {}
    lqMirrorUIPrefs();
}

// The cache-bust token is persisted and only rolled when the file's bytes
// actually change (a fresh Apply). Reusing the same token across renders,
// instead of a new Date.now() every time, means the browser treats
// unrelated re-paints (position tweak, page reopen) as the exact same
// resource it already has decoded, instead of re-fetching it from scratch.
function loadBannerBust() {
    try {
        return localStorage.getItem(UI_BANNER_BUST_KEY) || '';
    } catch (_) {
        return '';
    }
}

function saveBannerBust(bust) {
    try {
        if (bust) localStorage.setItem(UI_BANNER_BUST_KEY, bust);
        else localStorage.removeItem(UI_BANNER_BUST_KEY);
    } catch (_) {}
    lqMirrorUIPrefs();
}

function bannerImageUrl(ext, bust) {
    return ext ? `custom.${ext}${bust ? `?v=${bust}` : ''}` : 'banner.jpg';
}

function bannerCssUrl(ext, bust) {
    return `url('${bannerImageUrl(ext, bust)}')`;
}

// Fetches/decodes the image ahead of time so the CSS swap right after is
// an instant paint from cache instead of a blank flash while it loads.
function preloadBannerImage(ext, bust) {
    return new Promise(resolve => {
        const img = new Image();
        img.onload = () => resolve(true);
        img.onerror = () => resolve(false);
        img.src = bannerImageUrl(ext, bust);
    });
}

function applyUIBannerVisual(ext, pos, bust) {
    const safePos = { x: normalizeBannerPos(pos?.x), y: normalizeBannerPos(pos?.y) };
    document.documentElement.style.setProperty('--banner-url', bannerCssUrl(ext, bust));
    document.documentElement.style.setProperty('--banner-pos-x', `${safePos.x}%`);
    document.documentElement.style.setProperty('--banner-pos-y', `${safePos.y}%`);
    return safePos;
}

// Streams the photo into webroot in base64 chunks (a single shell command
// carrying a whole photo's worth of base64 can blow past the exec bridge's
// argument-length limit), decodes it server-side, and clears out every
// other custom.* extension first so only one custom banner ever exists.
// Same upload writeBannerFile used to do, but instead of a plain true/false this
// also reports *which* stage failed, so the Apply button can tell the
// person whether the photo never made it to the device (upload) or made
// it there but couldn't be written as the final file (likely a root/
// storage problem on the device itself).
async function writeBannerFileVerbose(dataUrl, ext) {
    const commaIdx = String(dataUrl || '').indexOf(',');
    const base64Data = commaIdx >= 0 ? dataUrl.slice(commaIdx + 1) : '';
    if (!base64Data) return { ok: false, stage: 'upload' };

    await exec(`mkdir -p ${shellQuote(LQ_BANNER_TMP_DIR)} 2>/dev/null; rm -f ${shellQuote(LQ_BANNER_TMP_FILE)} 2>/dev/null`);

    for (let i = 0; i < base64Data.length; i += LQ_BANNER_CHUNK_SIZE) {
        const chunk = base64Data.slice(i, i + LQ_BANNER_CHUNK_SIZE);
        const r = await exec(`printf '%s' ${shellQuote(chunk)} >> ${shellQuote(LQ_BANNER_TMP_FILE)} && echo __LQ_OK__`);
        if (!String(r || '').includes('__LQ_OK__')) {
            await exec(`rm -f ${shellQuote(LQ_BANNER_TMP_FILE)} 2>/dev/null`);
            return { ok: false, stage: 'upload' };
        }
    }

    const finalFile = bannerFilePath(ext);
    const rmOthers = LQ_BANNER_ALLOWED_EXT.map(e => `rm -f ${shellQuote(bannerFilePath(e))}`).join(' ; ');
    const finalizeCmd =
        `${rmOthers} ; ` +
        `base64 -d ${shellQuote(LQ_BANNER_TMP_FILE)} > ${shellQuote(finalFile)} 2>/dev/null ; ` +
        `rm -f ${shellQuote(LQ_BANNER_TMP_FILE)} ; ` +
        `[ -s ${shellQuote(finalFile)} ] && echo __LQ_OK__ || echo __LQ_ERR__`;

    const result = await exec(finalizeCmd);
    const ok = String(result || '').includes('__LQ_OK__');
    return ok ? { ok: true, stage: null } : { ok: false, stage: 'write' };
}

async function removeBannerFiles() {
    const rmAll = LQ_BANNER_ALLOWED_EXT.map(e => `rm -f ${shellQuote(bannerFilePath(e))}`).join(' ; ');
    await exec(rmAll);
}

async function bannerFileExists(ext) {
    if (!ext) return false;
    const r = await exec(`[ -s ${shellQuote(bannerFilePath(ext))} ] && echo __LQ_OK__ || echo __LQ_ERR__`);
    return String(r || '').includes('__LQ_OK__');
}

// ── Banner frame editor ──────────────────────────────────────
// Everything is measured in "banner-width units" (banner width = 1,
// banner height = 1/aspect). Editor state is { k, th, cx, cy }:
//   k      = scale, units per source pixel
//   th     = rotation in radians (clockwise)
//   cx, cy = photo centre relative to the banner centre
// The clamp below guarantees the (rotated) photo always covers the whole
// banner rectangle, so no empty corner can ever show up.
const BANNER_EDIT_HEIGHT_PX = 168;  // keep in sync with .banner-hero height
const BANNER_OUT_WIDTH = 1200;      // baked banner width in px
const BANNER_OUT_QUALITY = 0.92;
const BANNER_ZOOM_MAX = 6;          // x the minimum "cover" scale
const BANNER_SLACK_MIN = 0.0015;    // in banner-width units
const BANNER_COVER_EPS = 1.0008;    // tiny safety margin vs. rounding gaps

function bannerExtents(g, th) {
    const c = Math.abs(Math.cos(th)), s = Math.abs(Math.sin(th));
    const W = 1, H = 1 / g.aspect;
    return { ax: (W / 2) * c + (H / 2) * s, ay: (W / 2) * s + (H / 2) * c };
}

// Smallest scale at which the photo, rotated by th, still covers the banner.
function bannerKMin(g, th) {
    const e = bannerExtents(g, th);
    return Math.max(e.ax / (g.iw / 2), e.ay / (g.ih / 2)) * BANNER_COVER_EPS;
}

// How far the photo centre may move (in the photo's own rotated axes).
function bannerSlack(g, th, k) {
    const e = bannerExtents(g, th);
    let ex = Math.max(0, (g.iw * k) / 2 - e.ax);
    let ey = Math.max(0, (g.ih * k) / 2 - e.ay);
    // Slack this small (<~0.5px) is just the anti-gap margin, not real room to move.
    // Treat it as "fits exactly" so that axis locks to centre and its slider stays put.
    if (ex < BANNER_SLACK_MIN) ex = 0;
    if (ey < BANNER_SLACK_MIN) ey = 0;
    return { ex, ey };
}

function bannerWrapAngle(a) {
    const TAU = Math.PI * 2;
    a = ((a % TAU) + TAU) % TAU;
    return a > Math.PI ? a - TAU : a;
}

function bannerClampState(g, st) {
    const kMin = bannerKMin(g, st.th);
    const kMax = Math.max(kMin, bannerKMin(g, 0) * BANNER_ZOOM_MAX);
    const nk = Math.min(Math.max(st.k, kMin), kMax);
    if (nk !== st.k) {
        const r = nk / st.k;
        st.cx *= r;
        st.cy *= r;
        st.k = nk;
    }
    const c = Math.cos(st.th), s = Math.sin(st.th);
    const { ex, ey } = bannerSlack(g, st.th, st.k);
    let dx = c * st.cx + s * st.cy;
    let dy = -s * st.cx + c * st.cy;
    dx = Math.min(ex, Math.max(-ex, dx));
    dy = Math.min(ey, Math.max(-ey, dy));
    st.cx = c * dx - s * dy;
    st.cy = s * dx + c * dy;
    return st;
}

function getBannerAspect(fallbackEl) {
    const hero = document.getElementById('mainBanner');
    if (hero && hero.offsetWidth > 20 && hero.offsetHeight > 20) return hero.offsetWidth / hero.offsetHeight;
    const scroller = fallbackEl && fallbackEl.closest ? fallbackEl.closest('.main-content') : null;
    let w = scroller ? scroller.clientWidth - 26 : 0;
    if (!(w > 100)) w = (document.documentElement.clientWidth || 360) - 26;
    return w / BANNER_EDIT_HEIGHT_PX;
}

function loadBannerSourceImage(url) {
    return new Promise((resolve, reject) => {
        const im = new Image();
        im.onload = () => resolve(im);
        im.onerror = () => reject(new Error('image load failed'));
        im.src = url;
    });
}

function initUIBannerSettings() {
    const summary = document.getElementById('bannerSummary');
    const expandWrap = document.getElementById('bannerExpandWrap');
    const fileInput = document.getElementById('bannerFileInput');
    const chooseBtn = document.getElementById('bannerChooseBtn');
    const formatError = document.getElementById('bannerFormatError');
    // the framing is drawn straight into the live preview's banner
    const preview = document.getElementById('skelBanner');
    const previewCard = preview;
    const canvas = document.getElementById('bannerPreviewCanvas');
    const zoomSlider = document.getElementById('bannerZoomSlider');
    const rotSlider = document.getElementById('bannerRotSlider');
    const posXSlider = document.getElementById('bannerPosXSlider');
    const posYSlider = document.getElementById('bannerPosYSlider');
    const zoomValue = document.getElementById('bannerZoomValue');
    const rotValue = document.getElementById('bannerRotValue');
    const posXValue = document.getElementById('bannerPosXValue');
    const posYValue = document.getElementById('bannerPosYValue');
    const rotate90Btn = document.getElementById('bannerRotate90');
    const frameResetBtn = document.getElementById('bannerFrameReset');
    const resetBtn = document.getElementById('bannerReset');
    const applyBtn = document.getElementById('bannerApply');

    if (!summary || !expandWrap || !fileInput || !chooseBtn || !preview || !previewCard || !canvas ||
        !zoomSlider || !rotSlider || !posXSlider || !posYSlider || !zoomValue || !rotValue ||
        !posXValue || !posYValue || !rotate90Btn || !frameResetBtn || !resetBtn || !applyBtn) return;

    let pendingExt = loadBannerExt();
    let pendingBust = loadBannerBust();
    const legacyPos = loadBannerPos(); // photos applied by older versions were framed with CSS positions
    applyUIBannerVisual(pendingExt, legacyPos, pendingBust);

    let appliedExt = pendingExt;
    let src = null;              // decoded photo currently being edited
    const g = { iw: 1, ih: 1, aspect: BANNER_OUT_WIDTH / (BANNER_OUT_WIDTH / 2.2) };
    const st = { k: 1, th: 0, cx: 0, cy: 0 };
    let newFile = false;         // a freshly picked photo that hasn't been applied yet
    let baseline = null;         // framing that is currently live (initial load or last Apply)
    let sized = false;
    let rafId = 0;

    const setFormatError = msg => { if (formatError) formatError.textContent = msg || ''; };
    const snapshotBaseline = () => { baseline = { k: st.k, th: st.th, cx: st.cx, cy: st.cy }; };
    // Apply is only useful while the framing actually differs from what's live.
    const isDirty = () => {
        if (newFile) return true;
        if (!baseline) return false;
        return Math.abs(st.k - baseline.k) / baseline.k > 0.002 ||
            Math.abs(bannerWrapAngle(st.th - baseline.th)) > 0.0005 ||
            Math.abs(st.cx - baseline.cx) > 0.0005 ||
            Math.abs(st.cy - baseline.cy) > 0.0005;
    };
    const updateActionState = () => {
        applyBtn.disabled = !isDirty();
        resetBtn.disabled = !appliedExt;
    };

    // ── drawing (same routine for the live preview and the final bake) ──
    function renderTo(ctx, w, h, quality) {
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        if (!src) { ctx.clearRect(0, 0, w, h); return; }
        ctx.fillStyle = '#000';
        ctx.fillRect(0, 0, w, h);
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = quality;
        ctx.save();
        ctx.translate(w / 2 + st.cx * w, h / 2 + st.cy * w);
        ctx.rotate(st.th);
        ctx.scale(st.k * w, st.k * w);
        ctx.drawImage(src, -g.iw / 2, -g.ih / 2, g.iw, g.ih);
        ctx.restore();
    }

    function draw() {
        rafId = 0;
        if (!sized) return;
        renderTo(canvas.getContext('2d'), canvas.width, canvas.height, 'medium');
    }
    const scheduleDraw = () => { if (!rafId) rafId = requestAnimationFrame(draw); };

    function layout() {
        const cssW = preview.clientWidth;
        if (!(cssW > 0)) { sized = false; return; }
        const aspect = getBannerAspect(previewCard);
        if (Math.abs(aspect - g.aspect) > 1e-4) {
            g.aspect = aspect;
            if (src) {
                const wasDirty = isDirty();
                bannerClampState(g, st);
                if (!wasDirty) snapshotBaseline();
            }
        }
        previewCard.style.height = `${Math.round((cssW / g.aspect) * 100) / 100}px`;
        const dpr = Math.min(window.devicePixelRatio || 1, 2);   // preview only, the baked banner is rendered separately
        const w = Math.round(cssW * dpr);
        const h = Math.round(w / g.aspect);
        if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
        sized = true;
        syncControls();
        scheduleDraw();
    }

    function setSlider(el, val, min, max) {
        el.value = String(val);
        el.style.setProperty('--lq-progress', String(Math.min(1, Math.max(0, (val - min) / (max - min)))));
    }

    function syncControls() {
        const k0 = bannerKMin(g, 0);
        // 0% = photo just fills the banner, 100% = max zoom
        const zoomPct = Math.min(100, Math.max(0, Math.round(((st.k / k0 - 1) / (BANNER_ZOOM_MAX - 1)) * 100)));
        setSlider(zoomSlider, zoomPct, 0, 100);
        zoomValue.textContent = `${zoomPct}%`;

        const deg = Math.min(360, Math.max(0, Math.round((st.th * 180) / Math.PI)));
        setSlider(rotSlider, deg, 0, 360);
        rotValue.textContent = `${deg}\u00B0`;

        const { ex, ey } = bannerSlack(g, st.th, st.k);
        const c = Math.abs(Math.cos(st.th)), s = Math.abs(Math.sin(st.th));
        const bx = c * ex + s * ey, by = s * ex + c * ey;
        const px = bx > 1e-6 ? Math.round((1 - st.cx / bx) * 50) : 50;
        const py = by > 1e-6 ? Math.round((1 - st.cy / by) * 50) : 50;
        const cpx = Math.min(100, Math.max(0, px)), cpy = Math.min(100, Math.max(0, py));
        setSlider(posXSlider, cpx, 0, 100);
        setSlider(posYSlider, cpy, 0, 100);
        posXValue.textContent = `${cpx}%`;
        posYValue.textContent = `${cpy}%`;
    }

    function changed() {
        if (!src) return;
        bannerClampState(g, st);
        updateActionState();
        syncControls();
        scheduleDraw();
    }

    // Fit-to-banner starting frame; pos = legacy 0..100 position values.
    function resetFrameState(pos) {
        st.th = 0;
        st.k = bannerKMin(g, 0);
        const { ex, ey } = bannerSlack(g, 0, st.k);
        st.cx = ex * (1 - 2 * ((pos?.x ?? 50) / 100));
        st.cy = ey * (1 - 2 * ((pos?.y ?? 50) / 100));
        bannerClampState(g, st);
    }

    function setSource(img, pos) {
        src = img;
        g.iw = img.naturalWidth || img.width || 1;
        g.ih = img.naturalHeight || img.height || 1;
        g.aspect = getBannerAspect(previewCard);
        resetFrameState(pos);
        newFile = false;
        layout();
        snapshotBaseline();
        syncControls();
        scheduleDraw();
    }

    // Moves/zooms/rotates so the photo point under (m) follows to (m2).
    // Coordinates are banner-centred units.
    function transformAbout(m, ratio, dth, m2) {
        const c0 = Math.cos(st.th), s0 = Math.sin(st.th);
        const rx = c0 * (m.x - st.cx) + s0 * (m.y - st.cy);
        const ry = -s0 * (m.x - st.cx) + c0 * (m.y - st.cy);
        // Keep the angle inside the slider's own 0..360 range instead of wrapping,
        // so the slider and its label never flip sides while gesturing on the preview.
        const nth = Math.min(Math.PI * 2, Math.max(0, st.th + dth));
        const c1 = Math.cos(nth), s1 = Math.sin(nth);
        st.cx = m2.x - ratio * (c1 * rx - s1 * ry);
        st.cy = m2.y - ratio * (s1 * rx + c1 * ry);
        st.k *= ratio;
        st.th = nth;
        changed();
    }

    const origin = { x: 0, y: 0 };

    // ── UI wiring ──
    summary.addEventListener('click', () => {
        const open = summary.getAttribute('aria-expanded') === 'true';
        const next = !open;
        summary.setAttribute('aria-expanded', String(next));
        expandWrap.classList.toggle('is-open', next);
        requestAnimationFrame(layout);
    });

    chooseBtn.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', () => {
        const file = fileInput.files && fileInput.files[0];
        fileInput.value = '';
        if (!file) return;

        if (!String(file.type || '').startsWith('image/')) {
            setFormatError("That doesn't look like a photo. Please choose an image.");
            return;
        }
        if (!resolveBannerExt(file)) {
            setFormatError('Unsupported photo format. Use PNG, JPG, or WEBP.');
            return;
        }
        if (file.size > LQ_BANNER_MAX_SIZE_BYTES) {
            const mb = (file.size / (1024 * 1024)).toFixed(1);
            setFormatError(`Photo is ${mb}MB, which is over the 5MB limit. Please compress it (WEBP works best) and try again.`);
            return;
        }
        setFormatError('');

        const reader = new FileReader();
        reader.onload = async () => {
            try {
                const im = await loadBannerSourceImage(String(reader.result || ''));
                setSource(im, { x: 50, y: 50 });
                newFile = true;
                updateActionState();
            } catch (_) {
                setFormatError('Could not read that photo. Please try another one.');
            }
        };
        reader.onerror = () => setFormatError('Could not read that photo. Please try another one.');
        reader.readAsDataURL(file);
    });

    zoomSlider.addEventListener('input', () => {
        if (!src) return;
        const nk = Math.max(bannerKMin(g, 0) * (1 + (Number(zoomSlider.value) / 100) * (BANNER_ZOOM_MAX - 1)), bannerKMin(g, st.th));
        const r = nk / st.k;
        st.cx *= r;
        st.cy *= r;
        st.k = nk;
        changed();
    });

    rotSlider.addEventListener('input', () => {
        if (!src) return;
        const nth = (Number(rotSlider.value) * Math.PI) / 180;
        transformAbout(origin, 1, nth - st.th, origin);
    });

    const onPosSlider = () => {
        if (!src) return;
        const { ex, ey } = bannerSlack(g, st.th, st.k);
        const c = Math.abs(Math.cos(st.th)), s = Math.abs(Math.sin(st.th));
        st.cx = (c * ex + s * ey) * (1 - 2 * (Number(posXSlider.value) / 100));
        st.cy = (s * ex + c * ey) * (1 - 2 * (Number(posYSlider.value) / 100));
        changed();
    };
    posXSlider.addEventListener('input', onPosSlider);
    posYSlider.addEventListener('input', onPosSlider);

    rotate90Btn.addEventListener('click', () => {
        if (!src) return;
        transformAbout(origin, 1, ((st.th + Math.PI / 2) % (Math.PI * 2)) - st.th, origin);
    });

    frameResetBtn.addEventListener('click', () => {
        if (!src) return;
        resetFrameState({ x: 50, y: 50 });
        changed();
    });

    if (typeof ResizeObserver === 'function') new ResizeObserver(() => layout()).observe(preview);
    window.addEventListener('resize', layout);

    let applyBusy = false;
    let resetBusy = false;

    resetBtn.addEventListener('click', async () => {
        if (resetBusy) return;
        resetBusy = true;
        const bannerToast = lqToastShow({ title: 'Banner', text: lqExecPending > 0 ? 'Queued…' : 'Resetting…', state: 'pending' });
        await removeBannerFiles();
        await preloadBannerImage('', '');
        pendingExt = '';
        pendingBust = '';
        setFormatError('');
        saveBannerExt('');
        saveBannerBust('');
        saveBannerPos({ x: UI_BANNER_POS_DEFAULT, y: UI_BANNER_POS_DEFAULT });
        applyUIBannerVisual('', { x: UI_BANNER_POS_DEFAULT, y: UI_BANNER_POS_DEFAULT }, '');
        appliedExt = '';
        try {
            setSource(await loadBannerSourceImage(bannerImageUrl('', '')), { x: 50, y: 50 });
        } catch (_) { src = null; scheduleDraw(); }
        newFile = false;
        updateActionState();
        bannerToast.update({ state: 'ok', text: 'Reset to default banner' });
        resetBusy = false;
    });

    // Apply bakes exactly what the preview shows into a banner-shaped JPEG,
    // so the dashboard just displays a plain, already-framed picture.
    applyBtn.addEventListener('click', async () => {
        if (applyBusy || !src) return;
        applyBusy = true;
        setFormatError('');
        const bannerToast = lqToastShow({ title: 'Banner', text: lqExecPending > 0 ? 'Queued…' : 'Applying…', state: 'pending' });

        let dataUrl = '';
        try {
            bannerClampState(g, st);
            const outW = BANNER_OUT_WIDTH;
            const outH = Math.max(1, Math.round(outW / g.aspect));
            const oc = document.createElement('canvas');
            oc.width = outW;
            oc.height = outH;
            renderTo(oc.getContext('2d'), outW, outH, 'high');
            dataUrl = oc.toDataURL('image/jpeg', BANNER_OUT_QUALITY);
            if (dataUrl.length < 1000) throw new Error('empty export');
        } catch (_) {
            setFormatError('Could not process this photo. Please choose it again.');
            bannerToast.update({ state: 'err', text: 'Could not process the photo' });
            applyBusy = false;
            return;
        }

        const result = await writeBannerFileVerbose(dataUrl, 'jpg');
        if (!result.ok) {
            setFormatError(result.stage === 'upload'
                ? 'Upload interrupted before the photo reached the module. Please try again.'
                : 'Photo uploaded, but the module could not write it to disk (check root access or free storage). Please try again.');
            bannerToast.update({ state: 'err', text: result.stage === 'upload' ? 'Upload interrupted' : 'Could not write the banner' });
            applyBusy = false;
            return;
        }

        const bust = String(Date.now());
        await preloadBannerImage('jpg', bust);
        pendingExt = 'jpg';
        pendingBust = bust;
        saveBannerExt('jpg');
        saveBannerBust(bust);
        // Framing is baked into the file now, so the CSS position goes back to neutral.
        const neutral = { x: UI_BANNER_POS_DEFAULT, y: UI_BANNER_POS_DEFAULT };
        saveBannerPos(neutral);
        applyUIBannerVisual('jpg', neutral, bust);
        appliedExt = 'jpg';
        newFile = false;
        snapshotBaseline();
        updateActionState();
        bannerToast.update({ state: 'ok', text: 'Banner applied' });
        applyBusy = false;
    });

    updateActionState();
    layout();

    // Restore hook: pick up the saved banner and show it, like a finished Apply.
    lqUiResync.banner = async () => {
        pendingExt = loadBannerExt();
        pendingBust = loadBannerBust();
        const pos = loadBannerPos();
        await preloadBannerImage(pendingExt, pendingBust);
        applyUIBannerVisual(pendingExt, pos, pendingBust);
        appliedExt = pendingExt;
        setFormatError('');
        try {
            setSource(await loadBannerSourceImage(bannerImageUrl(pendingExt, pendingBust)), pendingExt ? pos : { x: 50, y: 50 });
        } catch (_) { src = null; scheduleDraw(); }
        newFile = false;
        updateActionState();
    };

    // Load whatever banner is live right now as the editing starting point.
    (async () => {
        let exists = true;
        if (pendingExt) exists = await bannerFileExists(pendingExt);
        if (pendingExt && !exists) {
            // Module folder was reinstalled/reset: quietly fall back to the default banner.
            pendingExt = '';
            pendingBust = '';
            appliedExt = '';
            saveBannerExt('');
            saveBannerBust('');
            applyUIBannerVisual('', legacyPos, '');
            updateActionState();
        }
        try {
            setSource(await loadBannerSourceImage(bannerImageUrl(pendingExt, pendingBust)), pendingExt ? legacyPos : { x: 50, y: 50 });
        } catch (_) { /* preview keeps the CSS fallback background */ }
    })();
}

// ── UI Settings / Backup & Restore ───────────────────────────
// Backup: the person picks which parts of the UI settings go into ONE json file
// in Download. A part that is still on its default is left out (nothing to
// save), so a backup only ever carries what was actually changed.
// Restore: the chosen file is checked first (format, version, every value), then
// a popup lists what is inside, with Skip / Restore. The file is kept inside the
// module's own folder as the single "staged" backup, so it can be reviewed and
// applied later without picking it again. Only one staged file exists: picking
// another one replaces it. Parts the file does not contain are left untouched.
const LQ_BK_FORMAT = 'liqinghe-ui-backup';
const LQ_BK_VERSION = 1;
const LQ_BK_DL_DIR = '/sdcard/Download';
const LQ_BK_UI_DIR = `${LQ_BK_DL_DIR}/LiQingheBackupUI`;      // the backup folder: in Download, so a reboot or a reflash does not remove it
const LQ_BK_OLD_FILE = `${LQ_BANNER_TMP_DIR}/backup-ui/ui_backup.json`;      // where the automatic backup was kept before (read once, then removed)
const LQ_BK_AUTO_FILE = `${LQ_BK_UI_DIR}/ui_backup.json`;      // the automatic backup: the one file in the backup folder (also the manual backup, there is nothing else to copy)
const LQ_BK_STAGED_FILE = `${LQ_BANNER_TMP_DIR}/ui_backup_staged.json`;
const LQ_BK_WRITE_TMP = `${LQ_BANNER_TMP_DIR}/ui_backup_write.tmp`;
const LQ_BK_META_KEY = 'lq_ui_backup_stage_v1';
const LQ_BK_MAX_FILE = 16 * 1024 * 1024;       // a custom font (up to 8MB, as base64) can be inside
const LQ_BK_READ_CHUNK = 60000;
const LQ_BK_LABELS = { palette: 'Color palette', radius: 'Corner radius', scale: 'Text & icon size', font: 'Custom font', banner: 'Banner', glass: 'Liquid glass', nav: 'Bottom navigation' };
const LQ_BK_KEYS = Object.keys(LQ_BK_LABELS);
let lqBkBusy = false;

function lqBkAscii(text) {
    return String(text).replace(/[\u007f-\uffff]/g, c => '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0'));
}

function lqBkShortName(name) {
    const s = String(name || '');
    return s.length > 28 ? `${s.slice(0, 14)}…${s.slice(-11)}` : s;
}

function lqBkDescribe(key, v, extra = {}) {
    if (key === 'palette') return v.type === 'preset' ? (UI_PALETTES[v.value]?.name || v.value) : `Custom ${v.value}`;
    if (key === 'radius') return `${v}px`;
    if (key === 'scale') return `Text ${v.t}%, icons ${v.i}%`;
    if (key === 'font') return v ? `${v.name || `custom.${v.ext}`}${extra.kb ? `, ${extra.kb} KB` : ''}` : '';
    if (key === 'glass') return `${v.on ? 'On' : 'Off'}, distortion ${v.distort}%`;
    if (key === 'nav') return `${LQ_NAV_STYLES[v.style].name}${LQ_NAV_STYLES[v.style].glass && v.glass ? ', liquid glass' : ''}`;
    if (key === 'banner') {
        const moved = !!v.pos && (v.pos.x !== UI_BANNER_POS_DEFAULT || v.pos.y !== UI_BANNER_POS_DEFAULT);
        if (v.photo && moved) return 'Photo + position';
        if (v.photo) return extra.kb ? `Photo, ${extra.kb} KB` : 'Photo';
        return moved ? `Position ${v.pos.x}% / ${v.pos.y}%` : 'Default';
    }
    return '';
}

// What is on this device right now, and whether it is still the default.
function lqBkSnapshot() {
    const out = {};
    const ps = loadUIPalette();
    const seed = stateToSeedState(ps), def = stateToSeedState({ type: 'preset', value: 'monochrome' });
    out.palette = { value: ps, isDefault: seed.primary === def.primary && seed.card === def.card && seed.surface === def.surface };

    const r = loadUIRadius();
    out.radius = { value: r, isDefault: r === UI_RADIUS_DEFAULT };

    const sc = loadUIScale();
    out.scale = { value: { t: sc.t, i: sc.i }, isDefault: sc.t === UI_SCALE_DEFAULT && sc.i === UI_SCALE_DEFAULT };

    const fo = loadUIFont();
    out.font = { value: fo.ext ? { ext: fo.ext, name: fo.name } : null, isDefault: !fo.ext };

    const ext = loadBannerExt(), pos = loadBannerPos();
    out.banner = {
        value: { pos, photo: ext ? { ext } : null },
        isDefault: !ext && pos.x === UI_BANNER_POS_DEFAULT && pos.y === UI_BANNER_POS_DEFAULT
    };

    const g = lqGlassNormalize(lqGlassCfg);
    const gn = lqGlassNormalize(lqGlassNavCfg);
    out.glass = { value: { ...g, navVals: gn }, isDefault: !g.on && LQ_GLASS_KEYS.every(k => g[k] === UI_GLASS_DEFAULT[k] && gn[k] === UI_GLASS_DEFAULT[k]) };

    const nv = lqNavNormalize(lqNavCfg);
    out.nav = { value: nv, isDefault: JSON.stringify(nv) === JSON.stringify(UI_NAV_DEFAULT) };

    LQ_BK_KEYS.forEach(k => { out[k].detail = lqBkDescribe(k, out[k].value); });
    return out;
}

// ── file helpers (everything goes through the root shell bridge) ──
// Text goes to a temp file in the module folder in chunks (same trick as the
// banner upload), then gets placed at its final path.
async function lqBkStageTmp(text) {
    // The root bridge drops every double quote from a command, so raw JSON text
    // arrives without its quotes. Base64 has no special characters, so the text
    // is sent as base64 and decoded on the device (text is ASCII only, see lqBkAscii).
    const b64 = btoa(text), tmpB64 = `${LQ_BK_WRITE_TMP}.b64`;
    await exec(`mkdir -p ${shellQuote(LQ_BANNER_TMP_DIR)} 2>/dev/null; rm -f ${shellQuote(LQ_BK_WRITE_TMP)} ${shellQuote(tmpB64)} 2>/dev/null`);
    for (let i = 0; i < b64.length; i += LQ_BANNER_CHUNK_SIZE) {
        const r = await exec(`printf '%s' ${shellQuote(b64.slice(i, i + LQ_BANNER_CHUNK_SIZE))} >> ${shellQuote(tmpB64)} && echo __LQ_OK__`);
        if (!String(r || '').includes('__LQ_OK__')) { await exec(`rm -f ${shellQuote(tmpB64)} 2>/dev/null`); return false; }
    }
    const d = String(await exec(`base64 -d ${shellQuote(tmpB64)} > ${shellQuote(LQ_BK_WRITE_TMP)} 2>/dev/null ; rm -f ${shellQuote(tmpB64)} 2>/dev/null ; [ -s ${shellQuote(LQ_BK_WRITE_TMP)} ] && echo __LQ_OK__ || echo __LQ_ERR__`) || '');
    return d.includes('__LQ_OK__');
}

// Puts the temp file at `path` with cat (cp can fail on the shared-storage
// mount) and checks the byte count. Returns { ok, err } with the shell's own
// error text when it fails, so the reason can be shown.
// Only plain commands here (no $(...), no { }): the module's other exec calls
// never use them, and some managers rewrite `$` before the shell sees it.
async function lqBkPlaceTmp(path, size) {
    const dir = path.slice(0, path.lastIndexOf('/'));
    const P = shellQuote(path);
    const r = String(await exec(
        `( mkdir -p ${shellQuote(dir)} ; cat ${shellQuote(LQ_BK_WRITE_TMP)} > ${P} ) 2>&1 ; ` +
        `[ -s ${P} ] && echo __LQ_OK__ || echo __LQ_ERR__`) || '');
    if (!r.includes('__LQ_OK__')) {
        const err = r.replace('__LQ_ERR__', '').replace(/\s+/g, ' ').trim();
        return { ok: false, err: err || 'no answer from the shell' };
    }
    const n = parseInt(String(await exec(`wc -c < ${P} 2>/dev/null`) || '').trim(), 10);
    return n === size ? { ok: true, err: '' } : { ok: false, err: `size mismatch (${Number.isFinite(n) ? n : '?'} of ${size})` };
}

// Everything that goes through the one shared temp file takes turns (the automatic backup and the kept restore file must not mix).
function lqBkLock(fn) {
    const run = lqBkLockChain.then(fn, fn);
    lqBkLockChain = run.then(() => {}, () => {});
    return run;
}

// One exact path (used for the kept restore file in the module folder).
function lqBkWriteFile(path, text) {
    return lqBkLock(async () => {
        if (!(await lqBkStageTmp(text))) return false;
        const res = await lqBkPlaceTmp(path, text.length);
        await exec(`rm -f ${shellQuote(LQ_BK_WRITE_TMP)} 2>/dev/null`);
        return res.ok;
    });
}

// Written next to the real path and then renamed over it, so the file is always either the old one or the new one, never half of one.
function lqBkWriteAtomic(path, text) {
    return lqBkLock(async () => {
        const part = `${path}.new`, P = shellQuote(path), N = shellQuote(part);
        if (!(await lqBkStageTmp(text))) return false;
        const res = await lqBkPlaceTmp(part, text.length);
        await exec(`rm -f ${shellQuote(LQ_BK_WRITE_TMP)} 2>/dev/null`);
        if (!res.ok) { await exec(`rm -f ${N} 2>/dev/null`); return false; }
        const r = String(await exec(`mv -f ${N} ${P} 2>&1 && echo __LQ_OK__`) || '');
        return r.includes('__LQ_OK__');
    });
}

async function lqBkReadFile(path) {
    const size = parseInt(String(await exec(`wc -c < ${shellQuote(path)} 2>/dev/null`) || '').trim(), 10);
    if (!Number.isFinite(size) || size <= 0 || size > LQ_BK_MAX_FILE) return null;
    let out = '';
    for (let i = 0; i * LQ_BK_READ_CHUNK < size; i++) {
        // the staged file never contains whitespace, so anything the bridge adds between pieces is dropped
        out += String(await exec(`dd if=${shellQuote(path)} bs=${LQ_BK_READ_CHUNK} skip=${i} count=1 2>/dev/null`) || '').replace(/\s+/g, '');
    }
    return out.length === size ? out : null;
}

// ── check a backup file ──
function lqBkImageMatches(ext, b64) {
    let sig = '';
    try { sig = atob(b64.slice(0, 24)); } catch (_) { return false; }
    if (ext === 'jpg') return sig.startsWith('\xFF\xD8\xFF');
    if (ext === 'png') return sig.startsWith('\x89PNG');
    if (ext === 'webp') return sig.startsWith('RIFF') && sig.slice(8, 12) === 'WEBP';
    return false;
}

// the first bytes of a font file must match its extension
function lqBkFontMatches(ext, b64) {
    let sig = '';
    try { sig = atob(b64.slice(0, 8)); } catch (_) { return false; }
    if (ext === 'ttf') return sig.startsWith('\x00\x01\x00\x00') || sig.startsWith('true');
    if (ext === 'otf') return sig.startsWith('OTTO') || sig.startsWith('\x00\x01\x00\x00');
    if (ext === 'woff') return sig.startsWith('wOFF');
    if (ext === 'woff2') return sig.startsWith('wOF2');
    return false;
}

function lqBkCheckItem(key, raw) {
    if (key === 'palette') {
        if (raw?.type === 'preset' && UI_PALETTES[raw.value]) return { value: { type: 'preset', value: raw.value } };
        if (raw?.type === 'custom' && isValidHex(raw.value) && isValidHex(raw.card) && isValidHex(raw.surface)) {
            return { value: { type: 'custom', value: normalizeHex(raw.value), card: normalizeHex(raw.card), surface: normalizeHex(raw.surface) } };
        }
        return null;
    }
    if (key === 'radius') {
        const n = Number(raw);
        return typeof raw === 'number' && Number.isFinite(n) ? { value: normalizeRadius(n) } : null;
    }
    if (key === 'glass') {
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
        const v = lqGlassNormalize(raw);
        if (raw.navVals && typeof raw.navVals === 'object') v.navVals = lqGlassNormalize(raw.navVals);      // older backups have no nav values
        return { value: v };
    }
    if (key === 'nav') {
        return raw && typeof raw === 'object' && !Array.isArray(raw) ? { value: lqNavNormalize(raw) } : null;
    }
    if (key === 'scale') {
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
        const t = Number(raw.t), i = Number(raw.i);
        if (!Number.isFinite(t) || !Number.isFinite(i)) return null;
        return { value: { t: normalizeUIScale(t), i: normalizeUIScale(i) } };
    }
    if (key === 'font') {
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
        const ext = String(raw.ext || '').toLowerCase(), data = raw.data;
        if (!LQ_FONT_FORMATS[ext] || typeof data !== 'string' || !data) return null;
        if (data.length > Math.ceil(LQ_FONT_MAX_BYTES * 4 / 3) + 8) return null;
        if (!/^[A-Za-z0-9+/]+={0,2}$/.test(data) || !lqBkFontMatches(ext, data)) return null;
        const name = String(raw.name || '').replace(/[^\x20-\x7e]/g, '').slice(0, 80);
        return { value: { ext, name, data }, kb: Math.max(1, Math.round(data.length * 3 / 4 / 1024)) };
    }
    if (key === 'banner') {
        if (!raw || typeof raw !== 'object') return null;
        const v = { pos: null, photo: null };
        let kb = 0;
        if (raw.pos) {
            const x = Number(raw.pos.x), y = Number(raw.pos.y);
            if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
            v.pos = { x: normalizeBannerPos(x), y: normalizeBannerPos(y) };
        }
        if (raw.photo) {
            const ext = String(raw.photo.ext || ''), data = raw.photo.data;
            if (!LQ_BANNER_ALLOWED_EXT.includes(ext) || typeof data !== 'string' || !data) return null;
            if (data.length > Math.ceil(LQ_BANNER_MAX_SIZE_BYTES * 4 / 3) + 8) return null;
            if (!/^[A-Za-z0-9+/]+={0,2}$/.test(data) || !lqBkImageMatches(ext, data)) return null;
            v.photo = { ext, data };
            kb = Math.max(1, Math.round(data.length * 3 / 4 / 1024));
        }
        if (!v.pos && !v.photo) return null;
        return { value: v, kb };
    }
    return null;
}

// Returns { ok, error, doc, items:[{key,label,detail,valid,value}], validCount }
function lqBkParse(text) {
    const fail = error => ({ ok: false, error });
    if (typeof text !== 'string' || !text.trim()) return fail('The file is empty');
    if (text.length > LQ_BK_MAX_FILE) return fail('The file is too large');
    let doc;
    try { doc = JSON.parse(text); } catch (_) { return fail('This is not a backup file'); }
    if (!doc || typeof doc !== 'object' || doc.format !== LQ_BK_FORMAT) return fail('Not a Li Qinghe UI backup');
    if (!Number.isInteger(doc.version) || doc.version < 1) return fail('Backup version is missing');
    if (doc.version > LQ_BK_VERSION) return fail('Made by a newer version');
    if (!doc.items || typeof doc.items !== 'object' || Array.isArray(doc.items)) return fail('The backup has no items');
    const items = [];
    LQ_BK_KEYS.forEach(key => {
        if (!(key in doc.items)) return;
        const chk = lqBkCheckItem(key, doc.items[key]);
        items.push(chk
            ? { key, label: LQ_BK_LABELS[key], valid: true, value: chk.value, detail: lqBkDescribe(key, chk.value, { kb: chk.kb }) }
            : { key, label: LQ_BK_LABELS[key], valid: false, value: null, detail: 'Damaged, skipped' });
    });
    const validCount = items.filter(i => i.valid).length;
    if (!validCount) return fail(items.length ? 'Nothing in this file can be restored' : 'The backup has no items');
    const created = typeof doc.created === 'string' ? doc.created.slice(0, 40) : '';
    return { ok: true, doc, items, validCount, created };
}

// ── staged file bookkeeping (small meta in localStorage, the file on disk) ──
// What actually gets kept on disk: only the verified items, normalised and
// compact (no whitespace at all), never the raw file the person picked.
function lqBkCleanText(parsed) {
    const items = {};
    parsed.items.forEach(i => { if (i.valid) items[i.key] = i.value; });
    const created = /^[0-9TZ:.+-]{0,40}$/.test(parsed.created) ? parsed.created : '';
    return lqBkAscii(JSON.stringify({ format: LQ_BK_FORMAT, version: LQ_BK_VERSION, module: 'LQlzy', created, items }));
}

function lqBkLoadMeta() {
    try {
        const m = JSON.parse(localStorage.getItem(LQ_BK_META_KEY) || 'null');
        return m && typeof m === 'object' && Array.isArray(m.items) ? m : null;
    } catch (_) { return null; }
}
function lqBkSaveMeta(meta) {
    try {
        if (meta) localStorage.setItem(LQ_BK_META_KEY, JSON.stringify(meta));
        else localStorage.removeItem(LQ_BK_META_KEY);
    } catch (_) {}
}
function lqBkMetaFrom(parsed, name, size) {
    return { name: String(name || 'Backup file').slice(0, 120), size, created: parsed.created,
             items: parsed.items.map(i => ({ key: i.key, label: i.label, detail: i.detail, valid: i.valid })) };
}
function lqBkDateText(iso) {
    const d = new Date(iso);
    if (!iso || Number.isNaN(d.getTime())) return 'Unknown';
    try { return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) + ', ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' }); }
    catch (_) { return iso.slice(0, 10); }
}
function lqBkSizeText(bytes) {
    return bytes >= 1048576 ? `${(bytes / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

// Apply / skip popup, same look as the recommended profile one.
function lqBkPopup({ title, sub, lines, applyText = 'Restore' }) {
    return new Promise(res => {
        const el = document.createElement('div');
        el.className = 'lq-rec-modal';
        el.innerHTML = '<div class="lq-rec-modal-scrim"></div><div class="lq-rec-modal-card" role="dialog" aria-modal="true">'
            + '<div class="pkg-title"></div><div class="pkg-sub"></div>'
            + '<div class="lq-rec-modal-list is-stacked"></div>'
            + '<div class="lq-rec-modal-actions"><button class="lq-rec-modal-btn is-skip" type="button">Skip</button><button class="lq-rec-modal-btn is-apply" type="button"></button></div></div>';
        el.querySelector('.pkg-title').textContent = title;
        el.querySelector('.pkg-sub').textContent = sub;
        el.querySelector('.is-apply').textContent = applyText;
        const list = el.querySelector('.lq-rec-modal-list');
        lines.forEach(([k, v]) => {
            const row = document.createElement('div'); row.className = 'lq-rec-modal-row';
            const a = document.createElement('span'), b = document.createElement('b');
            a.textContent = k; b.textContent = v; row.appendChild(a); row.appendChild(b); list.appendChild(row);
        });
        let done = false;
        const close = v => {
            if (done) return; done = true;
            el.classList.add('is-out');
            setTimeout(() => { el.remove(); res(v); }, 220);
        };
        el.querySelector('.is-apply').addEventListener('click', () => close('apply'));
        el.querySelector('.is-skip').addEventListener('click', () => close('skip'));
        el.querySelector('.lq-rec-modal-scrim').addEventListener('click', () => close('skip'));
        document.body.appendChild(el);
        const card = el.querySelector('.lq-rec-modal-card');
        card.addEventListener('animationend', () => { card.style.willChange = 'auto'; }, { once: true });
    });
}

// ── Live skeleton preview (UI Settings) ──────────────────────
// Small by default, tap to enlarge. The look comes entirely from the same CSS variables the
// dashboard uses, so there is nothing to repaint from here: JS only picks the scale.
const LQ_SKEL_W = 360, LQ_SKEL_H = 667, LQ_SKEL_SMALL = 0.32;
// scale of the enlarged preview: as wide as the card allows, but never more than about half the screen
function lqSkelScale() {
    const card = document.getElementById('skelCard');
    const avail = (card && card.clientWidth ? card.clientWidth : window.innerWidth - 26) - 28;
    const byHeight = (window.innerHeight * 0.66) / LQ_SKEL_H;
    return Math.max(LQ_SKEL_SMALL, Math.min(1, avail / LQ_SKEL_W, byHeight));
}
// Pending radius shown before Apply: scoped to the preview, the real UI is untouched.
function lqSkelRadius(px) {
    const f = document.getElementById('skelFrame');
    if (!f) return;
    const names = ['--r', '--r-a', '--r-b', '--r-c', '--r-d'], k = [1, 1, .78, .66, .5];
    names.forEach((n, i) => {
        if (px == null) f.style.removeProperty(n);
        else f.style.setProperty(n, (px * k[i]) + 'px');
    });
}
// Unapplied palette draft, scoped to the preview (null puts the applied palette back).
let lqSkelPalVars = [];
function lqSkelPalette(seed) {
    const f = document.getElementById('skelFrame');
    if (!f) return;
    lqSkelPalVars.forEach(n => f.style.removeProperty(n));
    lqSkelPalVars = [];
    if (!seed) return;
    const before = new Set(Array.from(f.style));
    if (!applyUIPalette(seed.primary, seed.card, seed.surface, f)) return;
    lqSkelPalVars = Array.from(f.style).filter(n => !before.has(n));
}

function initUISkeleton() {
    const f = document.getElementById('skelFrame'), card = document.getElementById('skelCard');
    if (!f || !card) return;
    // All motion is CSS (transform + clip-path on one state class), so tapping again, even mid way,
    // simply reverses it. JS only flips the state, sizes the open preview and plays the tap glow.
    let promoteT = 0, sb = lqSkelScale();
    const follow = document.getElementById('skelFollow');
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const size = () => { sb = lqSkelScale(); card.style.setProperty('--Sb', String(sb)); };
    // The card is a card like the others at rest and goes flush (full width, square top) only once it is stuck to the top: a 1px marker
    // sits where the card naturally is, and when it has scrolled out above the top of the page the card is stuck.
    const sentinel = document.getElementById('skelSentinel'), scroller = document.getElementById('mainContent');
    if (sentinel && scroller) {
        // Read on every scroll event (not from an observer, whose answer arrives a frame or two late).
        // Purely positional, the same as the Frosted Glass page: the card widens ONCE when it leaves its own place (the marker above it has
        // scrolled to the top of the page) and goes back to a card like the others ONCE when the page is back at that place. Nothing depends on
        // the scroll direction, so scrolling up or down while it is pinned never changes it. LEAD: it changes a few px before the card pins.
        const LEAD = 1;      // the card is pinned exactly when its marker has reached the top of the page; the marker is always at least 4px below it at rest
        let restickT = 0;
        const check = () => {
            // no offsetHeight: the page is not open
            const d = sentinel.getBoundingClientRect().top - scroller.getBoundingClientRect().top;
            // 1px of play so a finger resting right on the line never makes it flicker
            const was = card.classList.contains('is-stuck');
            const stuck = !!sentinel.offsetHeight && d < (was ? LEAD + 1 : LEAD);
            if (stuck === was) return;
            card.classList.add('is-restick');
            clearTimeout(restickT);
            restickT = setTimeout(() => card.classList.remove('is-restick'), 640);
            card.classList.toggle('is-stuck', stuck);
        };
        scroller.addEventListener('scroll', check, { passive: true });
        window.addEventListener('resize', check, { passive: true });
    }
    const offsetNow = () => {
        if (!follow) return 0;
        const t = getComputedStyle(follow).transform;
        return t && t !== 'none' ? new DOMMatrix(t).m42 : 0;
    };
    const set = open => {
        // the content under the card makes room in one layout step (CSS margin); to keep that from
        // looking like a jump, it is first put back where it was visually and then eased with a
        // single transform (the same easing and length as the card), so nothing lays out per frame
        const v = offsetNow(), extra = LQ_SKEL_H * (sb - LQ_SKEL_SMALL);
        card.classList.toggle('is-big', open);
        f.setAttribute('aria-expanded', String(open));
        f.setAttribute('aria-label', open ? 'Preview of Home, tap to shrink' : 'Preview of Home, tap to enlarge');
        // promote the layers only while they move, then let them re-raster sharp
        f.classList.add('is-anim');
        clearTimeout(promoteT);
        promoteT = setTimeout(() => {
            f.classList.remove('is-anim');
            if (follow) { follow.classList.remove('is-anim'); follow.style.transition = ''; follow.style.transform = ''; }
        }, 600);
        if (!follow || reduce) return;
        follow.classList.add('is-anim');
        follow.style.transition = 'none';
        follow.style.transform = `translateY(${v + (open ? -extra : extra)}px)`;
        void follow.offsetHeight;
        follow.style.transition = 'transform .48s cubic-bezier(.24,1.28,.32,1)';   // same curve as --sk-ease
        follow.style.transform = 'translateY(0px)';
    };
    const flash = () => {
        f.classList.remove('is-flash');
        void f.offsetWidth;
        f.classList.add('is-flash');
    };
    f.addEventListener('animationend', e => { if (e.animationName === 'lqSkFlash') f.classList.remove('is-flash'); });
    f.addEventListener('click', () => { flash(); set(!card.classList.contains('is-big')); });
    // Palette, Radius and Banner are always open: their headings stay as labels and never toggle.
    // Custom Color, Liquid Glass, Backup and Restore are secondary and still fold.
    document.querySelectorAll('#page-uisettings .ui-settings-summary.is-static').forEach(b => {
        b.tabIndex = -1;
        b.setAttribute('aria-disabled', 'true');
        b.addEventListener('click', e => e.stopImmediatePropagation(), true);
    });
    let t = 0;
    window.addEventListener('resize', () => { clearTimeout(t); t = setTimeout(size, 150); });
    size();
}

function initUIBackupSettings() {
    const $ = id => document.getElementById(id);
    const summary = $('backupSummary'), expandWrap = $('backupExpandWrap');
    const restoreSummary = $('restoreSummary'), restoreWrap = $('restoreExpandWrap'), summaryValue = $('restoreSummaryValue');
    const rowsEl = $('bkRows'), hint = $('bkHint');
    const stageEl = $('bkStage'), stageName = $('bkStageName'), stageMeta = $('bkStageMeta');
    const reviewBtn = $('bkReview'), removeBtn = $('bkRemove'), chooseBtn = $('bkChoose'), fileInput = $('bkFile');
    if (!summary || !expandWrap || !restoreSummary || !restoreWrap || !rowsEl || !stageEl || !reviewBtn || !removeBtn || !chooseBtn || !fileInput) return;

    // restored on the previous page load? tell the person once, after the splash
    try {
        const n = Number(sessionStorage.getItem('lq_bk_restored') || 0);
        sessionStorage.removeItem('lq_bk_restored');
        if (n > 0) setTimeout(() => lqToastShow({ title: 'Restore', text: `${n} setting${n > 1 ? 's' : ''} restored`, state: 'ok' }), 5600);
    } catch (_) {}

    // ---- backup side ----
    // The UI settings are backed up automatically: one file in the LiQingheBackupUI folder (inside Download), kept up to date on every change
    // (lqWriteUIPrefsNow). This card only tells where that file is: there is nothing to copy.
    const readInfo = async () => {
        try {
            const txt = String(await exec(`cat ${shellQuote(LQ_BK_AUTO_FILE)} 2>/dev/null`) || '').trim();
            let doc; try { doc = JSON.parse(txt); } catch (_) { doc = JSON.parse(txt.replace(/\s+/g, '')); }      // the bridge can break a long line with a newline (the file holds no whitespace of its own)
            if (doc && doc.format === LQ_BK_FORMAT && doc.items && typeof doc.items === 'object') return { items: Object.keys(doc.items).length, created: doc.created };
        } catch (_) {}
        return null;
    };
    const paintRows = async () => {
        const autoInfo = await readInfo();
        rowsEl.textContent = '';
        const row = document.createElement('div');
        row.className = 'lq-tweak-subrow lq-bk-row lq-glass-switch-row';
        const copy = document.createElement('div');
        const t = document.createElement('div'); t.className = 'pkg-title lq-tweak-subtitle'; t.textContent = 'Automatic backup';
        const d = document.createElement('div'); d.className = 'pkg-sub';
        d.textContent = autoInfo
            ? `${autoInfo.items} setting${autoInfo.items === 1 ? '' : 's'}, ${lqBkDateText(autoInfo.created)}`
            : 'Nothing to back up yet, everything is still on its default';
        copy.append(t, d);
        row.append(copy);
        rowsEl.appendChild(row);
        if (hint) hint.textContent = `File: ${LQ_BK_AUTO_FILE.slice(LQ_BK_AUTO_FILE.lastIndexOf('/') + 1)}\nFolder: ${LQ_BK_UI_DIR}`;
    };

    // ---- restore side ----
    const paintStage = () => {
        const m = lqBkLoadMeta();
        stageEl.hidden = !m;
        if (summaryValue) { summaryValue.hidden = !m; summaryValue.textContent = m ? '1 file' : ''; }
        chooseBtn.textContent = m ? 'Replace backup file' : 'Choose backup file';
        if (!m) return;
        const n = m.items.filter(i => i.valid).length;
        stageName.textContent = lqBkShortName(m.name);
        stageMeta.textContent = `${n} setting${n === 1 ? '' : 's'}, ${lqBkSizeText(m.size)}, ${lqBkDateText(m.created)}`;
    };

    const popupLines = m => [
        ['File', lqBkShortName(m.name)],
        ['Created', lqBkDateText(m.created)],
        ...m.items.map(i => [i.label, i.detail])
    ];

    // Put the settings back. Writes the saved keys, mirrors them to the module
    // folder, then reloads once so every card starts from the restored values.
    const restoreFrom = async (text) => {
        if (lqBkBusy) return;
        lqBkBusy = true;
        const toast = lqToastShow({ title: 'Restore', text: 'Reading the file', state: 'pending' });
        try {
            if (text == null) text = await lqBkReadFile(LQ_BK_STAGED_FILE);
            const parsed = text == null ? null : lqBkParse(text);
            if (!parsed || !parsed.ok) {
                toast.update({ state: 'err', text: parsed?.error || 'The saved file is gone' });
                if (!parsed) { lqBkSaveMeta(null); paintStage(); }
                lqBkBusy = false; return;
            }
            toast.update({ text: 'Restoring' });
            let count = 0;
            const failed = [];
            for (const it of parsed.items) {
                if (!it.valid) continue;
                if (it.key === 'palette') { saveUIPalette(it.value); count++; }
                else if (it.key === 'radius') { saveUIRadius(it.value); count++; }
                else if (it.key === 'scale') { saveUIScale(it.value); count++; }
                else if (it.key === 'font') {
                    const w = await lqWriteFontFile(it.value.data, it.value.ext);
                    if (!w.ok) { failed.push('font'); continue; }
                    saveUIFont({ ext: it.value.ext, bust: String(Date.now()), name: it.value.name });
                    count++;
                }
                else if (it.key === 'glass') {
                    const { navVals, ...gv } = it.value;
                    try {
                        localStorage.setItem(UI_GLASS_KEY, JSON.stringify(gv));
                        if (navVals) localStorage.setItem(UI_GLASS_NAV_KEY, JSON.stringify(navVals)); else localStorage.removeItem(UI_GLASS_NAV_KEY);
                    } catch (_) {}
                    count++;
                }
                else if (it.key === 'nav') { try { localStorage.setItem(UI_NAV_KEY, JSON.stringify(it.value)); } catch (_) {} count++; }
                else if (it.key === 'banner') {
                    const v = it.value;
                    if (v.photo) {
                        const mime = v.photo.ext === 'jpg' ? 'jpeg' : v.photo.ext;
                        const w = await writeBannerFileVerbose(`data:image/${mime};base64,${v.photo.data}`, v.photo.ext);
                        if (!w.ok) { failed.push('banner'); continue; }
                        saveBannerExt(v.photo.ext);
                        saveBannerBust(String(Date.now()));
                        saveBannerPos(v.pos || { x: UI_BANNER_POS_DEFAULT, y: UI_BANNER_POS_DEFAULT });
                    } else if (v.pos) {
                        saveBannerPos(v.pos);
                    }
                    count++;
                }
            }
            if (!count) { toast.update({ state: 'err', text: 'Could not restore' }); lqBkBusy = false; return; }
            await lqWriteUIPrefsNow();
            // repaint every restored card live, the same way a normal Apply does
            let stuck = false;
            for (const it of parsed.items) {
                if (!it.valid || failed.includes(it.key)) continue;
                try { await lqUiApplyNow(it.key); } catch (e) { console.error('[restore]', it.key, e); }
                if (!lqUiShows(it.key)) stuck = true;
            }
            try { paintRows(); } catch (_) {}
            if (stuck) {
                // safety net: the page did not take a value, so start fresh from what is saved
                try { sessionStorage.setItem('lq_bk_restored', String(count)); } catch (_) {}
                toast.update({ state: 'ok', text: 'Restored, reloading' });
                setTimeout(() => location.reload(), 900);
                return;
            }
            toast.update({ state: failed.length ? 'err' : 'ok', text: failed.length ? `Restored, ${failed.join(' and ')} failed` : `Restored ${count} setting${count > 1 ? 's' : ''}` });
        } catch (_) {
            toast.update({ state: 'err', text: 'Restore failed' });
        }
        lqBkBusy = false;
    };

    const review = async (freshText) => {
        const m = lqBkLoadMeta();
        if (!m) return;
        const choice = await lqBkPopup({
            title: 'Backup file ready',
            sub: 'Restore these UI settings now? Anything not listed stays as it is.',
            lines: popupLines(m)
        });
        if (choice === 'apply') await restoreFrom(freshText);
    };

    chooseBtn.addEventListener('click', () => { if (!lqBkBusy) fileInput.click(); });
    fileInput.addEventListener('change', async () => {
        const file = fileInput.files && fileInput.files[0];
        fileInput.value = '';
        if (!file || lqBkBusy) return;
        if (file.size > LQ_BK_MAX_FILE) { lqToastShow({ title: 'Restore', text: 'The file is too large', state: 'err' }); return; }
        lqBkBusy = true;
        const toast = lqToastShow({ title: 'Restore', text: 'Checking the file', state: 'pending' });
        let text = '';
        try { text = typeof file.text === 'function' ? await file.text() : await new Response(file).text(); } catch (_) { text = ''; }
        const parsed = lqBkParse(text);
        if (!parsed.ok) { toast.update({ state: 'err', text: parsed.error }); lqBkBusy = false; return; }
        const clean = lqBkCleanText(parsed);
        const stored = await lqBkWriteFile(LQ_BK_STAGED_FILE, clean);
        if (!stored) { toast.update({ state: 'err', text: 'Could not keep the file' }); lqBkBusy = false; return; }
        lqBkSaveMeta(lqBkMetaFrom(parsed, file.name, clean.length));
        paintStage();
        toast.update({ state: 'ok', text: 'File checked and kept' });
        lqBkBusy = false;
        // apply always reads the kept copy, so what you reviewed is exactly what gets restored
        await review(null);
    });

    reviewBtn.addEventListener('click', () => { if (!lqBkBusy) review(null); });
    removeBtn.addEventListener('click', async () => {
        if (lqBkBusy) return;
        await exec(`rm -f ${shellQuote(LQ_BK_STAGED_FILE)} 2>/dev/null`);
        lqBkSaveMeta(null);
        paintStage();
        lqToastShow({ title: 'Restore', text: 'Backup file removed', state: 'ok' });
    });

    summary.addEventListener('click', () => {
        const next = summary.getAttribute('aria-expanded') !== 'true';
        summary.setAttribute('aria-expanded', String(next));
        expandWrap.classList.toggle('is-open', next);
        if (next) paintRows();
    });

    restoreSummary.addEventListener('click', () => {
        const next = restoreSummary.getAttribute('aria-expanded') !== 'true';
        restoreSummary.setAttribute('aria-expanded', String(next));
        restoreWrap.classList.toggle('is-open', next);
    });

    paintRows();
    paintStage();

    // a staged file can outlive the stored meta (cleared WebUI storage): rebuild it from the file
    (async () => {
        if (lqBkLoadMeta()) return;
        const has = String(await exec(`[ -s ${shellQuote(LQ_BK_STAGED_FILE)} ] && echo __LQ_OK__ || echo __LQ_ERR__`) || '');
        if (!has.includes('__LQ_OK__')) return;
        const text = await lqBkReadFile(LQ_BK_STAGED_FILE);
        const parsed = text == null ? null : lqBkParse(text);
        if (parsed && parsed.ok) { lqBkSaveMeta(lqBkMetaFrom(parsed, 'Saved backup file', text.length)); paintStage(); }
    })();
}

// ── Tweaks page ─────────────────────────────
const tweakState={idle_profile:'normal',surface_flinger:'0',display_refresh:'0',display_adaptive:'0',display_renderer:'',display_rates:'',trace_guard_count:'0',trace_guard_preset:'default',perf_one_click_optimization:'0',helper_fily:'0',helper_tctl:'0',perf_job_scheduler:'0',perf_multitasking:'0',perf_sqlite_tuning:'0',perf_app_standby:'0',perf_low_swap:'0',perf_persist_log_tags:'0',perf_logging_diagnostics:'0',perf_selected_diagnostics:'0',perf_debug_props:'0',perf_long_press_latency:'0',perf_oem_tuning:'0',perf_compile_keyboard:'0',value_job_scheduler_max_job_count_active:'72',value_multitasking_preset:'medium',value_sqlite_tuning_wal_checkpoint:'56',value_sqlite_tuning_journal_size:'229376',value_app_standby_strong_usage_duration:'43200000',value_low_swap_threshold_percent:'0.50',value_long_press_latency_timeout_ms:'350',recommended_value_job_scheduler_max_job_count_active:'72',recommended_value_multitasking_preset:'medium',recommended_value_sqlite_tuning_wal_checkpoint:'56',recommended_value_sqlite_tuning_journal_size:'229376',recommended_value_app_standby_strong_usage_duration:'43200000',recommended_value_low_swap_threshold_percent:'0.50',recommended_value_long_press_latency_timeout_ms:'350',perf_doze:'0'};
const TRACE_ITEM_COUNT=99;
const TK_PRESET_ORDER=['default','lite','medium','high','maximum'];
const TK_PRESET_META={
  default:{title:'Default',desc:'Clears every Trace Guard override. Device behaves exactly as stock.',count:'0 tweaks'},
  lite:{title:'Lite',desc:'AdServices ad-measurement/topics logging, plus the ad-download service\'s sharing log.',count:'28 tweaks'},
  medium:{title:'Medium',desc:'Lite, plus full download-service logging, on-device AI model telemetry, app-compat runtime metrics, and on-device personalization/ad-detection logging.',count:'60 tweaks'},
  high:{title:'High',desc:'Medium, plus device personalization services logging, activity manager telemetry, jank/frame monitoring, and input latency tracking.',count:'85 tweaks'},
  maximum:{title:'Maximum',desc:'High, plus telephony log limits, misc UI event logging, legacy netstats imports, low-memory-killer logging, and content-capture buffering.',count:'99 tweaks'}
};
let traceModeEpoch=0;
let traceModeBusy=false;

function tweaksBackend(cmd,value=''){
 const r='/data/local/tmp/liqinghe/tweaks.sh';
 const m='/data/adb/modules/LQlzy';
 const parts=String(value??'').trim()?String(value).trim().split(/\s+/).map(shellQuote).join(' '):'';
 const args=`${shellQuote(cmd)}${parts?' '+parts:''}`;
 // `sh file` only needs the file to be readable, not executable (and /data/local/tmp may be noexec),
 // so test -f instead of -x. If the bridge is missing, fall back to the module's own script.
 return `if [ -f ${shellQuote(r)} ]; then sh ${shellQuote(r)} ${args} 2>&1; elif [ -f ${m}/modules/tweaks.sh ]; then MODDIR=${m} sh ${m}/modules/tweaks.sh ${args} 2>&1; else echo __LQ_ERR__NO_BACKEND; fi`;
}
const LQ_STATE_REQUIRED=Object.keys(tweakState).filter(k=>/^(idle_profile|surface_flinger|helper_|perf_)/.test(k));
// Returns true only when check-state answered with EVERY required key, so an empty or
// cut-off answer (slow device, bridge hiccup) is never mistaken for "all tweaks are off".
async function tweaksGetState(){
 const epochAtStart=traceModeEpoch;
 const raw=await exec(`sh /data/local/tmp/liqinghe/tweaks.sh check-state 2>/dev/null`);
 lqDbg(`check-state len=${String(raw||'').length} ${String(raw||'').split(/\r?\n/).filter(l=>/^(idle_profile|perf_)/.test(l)).join(',')}`);
 const seen=new Set();
 String(raw||'').split(/\r?\n/).forEach(line=>{
   const i=line.indexOf('=');
   if(i<=0)return;
   const k=line.slice(0,i), v=line.slice(i+1);
   if(!(k in tweakState))return;
   seen.add(k);
   if(k==='trace_guard_preset' && epochAtStart!==traceModeEpoch)return;
   tweakState[k]=(v||'').trim();
 });
 return LQ_STATE_REQUIRED.every(k=>seen.has(k));
}
// Splash: keep reading until the status is really there (no defaults shown as fact).
function lqSplashNote(t){ /* the line under the bar is driven by lqBootStep */ }
let lqTweakStateReady=false;
// The one place that flips "the UI state is now backed by a real backend answer".
// While it is false the tweak controls are dimmed + untouchable (html.lq-sync-pending)
// and the dashboard idle-profile tile shows its placeholder, so a default is never
// shown as if the backend had said it.
function lqSetStateReady(v){
 lqTweakStateReady=!!v;
 document.documentElement.classList.toggle('lq-sync-pending',!lqTweakStateReady);
 try{ lqUpdateSyncNotice(); }catch(_){}
 try{ lqDashProfilePaint(); }catch(_){}
}
async function lqLoadTweakStateVerified(){
 const t0=performance.now();
 for(let attempt=1;;attempt++){
   let ok=false;
   try{ ok=await tweaksGetState(); }catch(_){ ok=false; }
   if(ok){ lqSetStateReady(true); lqSplashNote(''); return true; }
   lqDbg(`check-state incomplete, attempt ${attempt}`);
   if(performance.now()-t0>38000) return false;
   lqSplashNote(`Reading tweak status... (try ${attempt+1})`);
   lqBootStep('tweakState','run',`try ${attempt+1}`);
   await new Promise(r=>setTimeout(r,Math.min(400*attempt,2500)));
 }
}
// If boot gave up, keep trying quietly and paint the moment the real status arrives.
function lqTweakStateRecover(){
 const tick=async()=>{
   let ok=false;
   try{ ok=await tweaksGetState(); }catch(_){}
   if(ok){ lqSetStateReady(true); lqPaintTweakStateAll(); return; }
   setTimeout(tick,3000);
 };
 setTimeout(tick,3000);
}
// True while something is being applied or a control is busy: a refresh must wait.
function lqLiveBusy(){
 return lqExecPending>0||!!document.querySelector('[aria-busy="true"],.is-applying,[data-busy="1"]');
}
// Reads the real state from the backend once and repaints. Used only by pull to refresh,
// nothing polls the toggle state in the background any more.
async function lqPullTweakState(){
 if(lqLiveBusy()) return false;
 let ok=false;
 try{ ok=await tweaksGetState(); }catch(_){ ok=false; }
 if(ok){
   if(!lqTweakStateReady) lqSetStateReady(true);
   if(!lqLiveBusy()) lqPaintTweakStateAll();
   try{ lqDashProfilePaint(); }catch(_){}
 }
 return ok;
}

function lqPaintTweakStateAll(){
 renderTweaksUI();
 syncHelperToggle('helperFilyToggle','helper_fily');
 syncHelperToggle('helperTctlToggle','helper_tctl');
 document.querySelectorAll('[data-system-tuning-group]').forEach(row=>{
   const group=row.getAttribute('data-system-tuning-group');
   if(group) systemTuningSyncSliders(group,row);
 });
 document.querySelectorAll('[data-system-tuning-toggle-group]').forEach(el=>{
   const group=el.getAttribute('data-system-tuning-toggle-group');
   if(group) {
     const row=el.closest('.lq-tweak-subrow');
     const on=tweakState[`perf_${group.replace(/-/g,'_')}`]==='1';
     el.classList.toggle('on',on);
     el.setAttribute('aria-pressed',on?'true':'false');
     if(row) systemTuningSyncSliders(group,row);
   }
 });
 syncFilyMultitaskingConflict();
}
function lqDbg(msg){ try{ execBg(`printf '%s\\n' ${lqSq('[ui '+new Date().toISOString().slice(11,19)+'] '+String(msg).replace(/\s+/g,' ').slice(0,300))} >> /data/local/tmp/liqinghe/debug.log 2>/dev/null`); }catch(_){} }
async function applyTweak(cmd,value){
  // Never change anything on top of a UI that was never confirmed by the backend:
  // try to get the real status first; if it still is not there, refuse (nothing ran).
  if(!lqTweakStateReady){
    let got=false;
    try{ got=await tweaksGetState(); }catch(_){}
    if(got){ lqSetStateReady(true); lqPaintTweakStateAll(); }
    else{ lqDbg(`apply ${cmd} refused: backend status not confirmed yet`); return false; }
  }
  const r=await exec(tweaksBackend(cmd,value));
  const ok=String(r||'').includes('__LQ_OK__');
  lqDbg(`apply ${cmd} ${value??''} -> ${ok?'OK':'FAIL'} spawn=${lqHasSpawn()} out=${String(r||'').slice(0,200)}`);
  return ok;
}


// ── Targeted resync helpers ──────────────────────────────────────
// Full `tweaksGetState()` re-runs check-state, which re-scans idle profile,
// surface flinger, trace guard, every System Tuning group, and battery
// extras in one shell call, overkill when only one toggle/slider changed.
// These read just the one thing that needs re-checking (e.g. after a
// failed apply, to see what the backend actually left it at), so a single
// action never has to pay for a full-page rescan or a WebUI reload.
function applyLinesToState(raw){
  String(raw||'').split(/\r?\n/).forEach(line=>{
    const [k,v]=line.split('=');
    if(!(k in tweakState))return;
    tweakState[k]=(v||'').trim();
  });
}
// Both return true ONLY when the backend really answered. An empty answer (timeout,
// bridge hiccup) used to be written into tweakState as '' and reported as success,
// which is exactly how the UI ended up "confirmed" without the backend saying anything.
async function fetchValueState(key){
  const raw=await exec(`sh /data/local/tmp/liqinghe/tweaks.sh get-value ${shellQuote(key)} 2>/dev/null`);
  const val=String(raw||'').trim();
  if(!val || val.includes('__LQ_ERR__'))return false;
  if(key in tweakState) tweakState[key]=val;
  return true;
}
async function fetchGroupState(group){
  const raw=await exec(`sh /data/local/tmp/liqinghe/tweaks.sh get-group-state ${shellQuote(group)} 2>/dev/null`);
  if(!String(raw||'').trim() || String(raw).includes('__LQ_ERR__'))return false;
  applyLinesToState(raw);
  return true;
}

// ── Apply, then ask the backend what is REALLY the case ──────────────
// A change is only shown once the backend has confirmed it. Sequence:
//   1. run the change command (never blocks the UI, see exec())
//   2. read the state back from the backend (fetchFn fills tweakState)
//   3. the UI is painted from what the backend reports, not from what was asked
// The read-back also runs when the apply answer got lost (timeout): the backend
// may well have finished, and the UI must follow the backend either way.
//   fetchFn()    -> Promise<boolean>   true only if the backend answered
//   isExpected() -> boolean            does tweakState now hold the wanted value
// Resolves { ok, confirmed }: confirmed=false means the read-back itself was not
// possible, so ok falls back to the apply answer alone.
async function lqVerifyState(fetchFn,isExpected){
  for(let t=0;t<3;t++){
    let got=false;
    try{ got=await fetchFn(); }catch(_){ got=false; }
    if(got) return isExpected()?'match':'mismatch';
    await new Promise(r=>setTimeout(r,300*(t+1)));
  }
  return 'unknown';
}
async function lqApplyConfirmed(cmd,value,fetchFn,isExpected){
  let applied=false;
  try{ applied=await applyTweak(cmd,value); }catch(_){ applied=false; }
  const v=await lqVerifyState(fetchFn,isExpected);
  lqDbg(`confirm ${cmd} ${value??''} applied=${applied} readback=${v}`);
  if(v==='match') return {ok:true,confirmed:true};
  if(v==='mismatch') return {ok:false,confirmed:true};
  return {ok:applied,confirmed:false};
}

/* ── UNIFIED POST-APPLY TOGGLE FEEDBACK ───────────────────────────
 * Every toggle follows the same sequence: backend completes -> whole-switch
 * press cue -> next frame -> visual ON/OFF commit -> cue fades.
 * The thumb continues to use the existing transform transition.
 */
async function commitToggleVisual(el, commit){
  if(!el){ commit(); return; }
  el.classList.add('is-pressed');
  await new Promise(resolve=>requestAnimationFrame(resolve));
  commit();
  await new Promise(resolve=>requestAnimationFrame(resolve));
  setTimeout(()=>el.classList.remove('is-pressed'),110);
}

function syncHelperToggle(id,stateKey){
  const el=document.getElementById(id);
  if(!el)return;
  const on=tweakState[stateKey]==='1';
  el.classList.toggle('active',on);
  el.setAttribute('aria-pressed',on?'true':'false');
}

// Fily (memory-pressure helper) and Multitasking both drive ActivityManager
// memory-factor/background tuning, so they conflict if run together.
// Whichever activates first locks the other out until it's switched off --
// the locked side's card/toggle always stays visible, just disabled and
// unable to be changed, with its description swapped to explain why. Called
// after every state change to either one, and once during initial
// wiring/resync.
function syncFilyMultitaskingConflict(){
  const filyOn=tweakState.helper_fily==='1';
  const mtOn=tweakState.perf_multitasking==='1';

  const mtBtn=document.getElementById('perfMultitaskingToggle');
  const mtRow=mtBtn ? mtBtn.closest('.lq-tweak-subrow') : null;
  const mtSub=mtRow?.querySelector('.pkg-sub');
  if(mtBtn){
    const lockMt=filyOn && !mtOn;
    mtRow?.classList.toggle('lq-tweak-locked',lockMt);
    mtBtn.disabled=lockMt;
    mtBtn.setAttribute('aria-disabled',lockMt?'true':'false');
    if(mtSub){
      if(lockMt){
        if(!mtSub.dataset.originalText) mtSub.dataset.originalText=mtSub.textContent;
        mtSub.textContent='Disabled while Fily is active.';
      }else if(mtSub.dataset.originalText){
        mtSub.textContent=mtSub.dataset.originalText;
      }
    }
  }

  const filyBtn=document.getElementById('helperFilyToggle');
  if(filyBtn){
    const lockFily=mtOn && !filyOn;
    filyBtn.classList.toggle('lq-fily-locked',lockFily);
    filyBtn.disabled=lockFily;
    filyBtn.setAttribute('aria-disabled',lockFily?'true':'false');
    const small=filyBtn.querySelector('.lq-profile-copy small');
    if(small){
      if(lockFily){
        if(!small.dataset.originalText) small.dataset.originalText=small.textContent;
        small.textContent='Disabled while Multitasking is active.';
      }else if(small.dataset.originalText){
        small.textContent=small.dataset.originalText;
      }
    }
  }
}

// Shared status-flash used by titled apply actions across the module:
// swap the title to a "working" label before the backend call, then to
// Success/Failed once it resolves, then restore the original title after
// a short hold so the user gets clear pass/fail feedback without the row
// staying stuck on a status word.
// Crossfades a title/label element's text instead of swapping it in place,
// so a status word replacing a longer/shorter label doesn't visually snap
// or fight with any expand/collapse animation happening around it.
// Crossfades a title/label element's text instead of swapping it in place.
// Deliberately synchronous -- no setTimeout/rAF wait before the text swap.
// This bridge's exec() blocks the whole JS thread, including pending
// timers, so any crossfade that *awaits* a gap before swapping text can get
// starved for seconds if some unrelated blocking call (a periodic stat
// poll, another apply in flight) happens to land in that gap -- the label
// would sit blank until that other call finally finishes. Setting
// opacity:0, swapping the text, then forcing a reflow before flipping back
// to opacity:1 triggers the same fade-in visually without ever depending on
// a timer that could be delayed.
function crossfadeText(el, text){
  if(!el) return;
  if(!el.style.transition) el.style.transition='opacity 110ms ease';
  el.style.opacity='0';
  el.textContent=text;
  void el.offsetHeight; // force layout so the opacity:0 write isn't coalesced away
  el.style.opacity='1';
}

// ── Toasts ────────────────────────────────────────────────────
// Status of an apply is shown as a toast that comes out from behind the bottom
// nav, instead of rewriting a title or a button label. Up to 2 show one above
// the other; from the 3rd on they pile into one stack (front card + the edges of
// the ones behind), and a tap on the stack opens it. A toast leaves by itself 15s
// after it has its result, or by swiping it down into the nav. One toast per
// action: it starts as "Applying…" and turns into the result in place.
const LQ_TOAST_H = 64, LQ_TOAST_GAP = 8, LQ_TOAST_MAX = 5, LQ_TOAST_LIFE = 15000;
const lqToasts = [];                 // newest first
let lqToastLayer = null, lqToastControls = null, lqToastExpanded = false;
let lqToastBulk = false;             // Clear all is handing the cards out one by one: the ones still waiting must stay in their slots (no re-layout)

const LQ_TOAST_ICONS = {
    ok:  '<svg viewBox="0 0 24 24" aria-hidden="true"><path pathLength="1" d="M5 12.5l4.2 4.2L19 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    err: '<svg viewBox="0 0 24 24" aria-hidden="true"><path pathLength="1" d="M7 7l10 10" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><path pathLength="1" d="M17 7L7 17" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>',
    pending: '<span class="lq-toast-spin"></span>',
    info: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 8v.01M12 11.5V17" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>'
};

function lqToastEnsureLayer() {
    if (lqToastLayer && lqToastLayer.isConnected) return lqToastLayer;
    const layer = document.createElement('div');
    layer.className = 'lq-toast-layer';
    layer.setAttribute('role', 'status');
    layer.setAttribute('aria-live', 'polite');
    const controls = document.createElement('div');
    controls.className = 'lq-toast-controls';
    controls.innerHTML = '<button type="button" data-act="less">Show less</button><button type="button" data-act="clear">Clear all</button>';
    controls.addEventListener('click', e => {
        const act = e.target?.closest('button')?.dataset.act;
        if (act === 'less') { lqToastExpanded = false; lqToastLayout(false, 'collapse'); }
        else if (act === 'clear') lqToastClearAll();
    });
    layer.appendChild(controls);
    // same parent as the nav so it sits right under it in the stacking order
    const pill = document.getElementById('navPill');
    (pill?.parentNode || document.body).insertBefore(layer, pill || null);
    lqToastLayer = layer;
    if (lqNavCompact) lqNavCompactVars();
    lqToastControls = controls;
    return layer;
}

function lqToastFill(t, { title, text, state }) {
    if (title != null) t.title = title;
    if (text != null) t.text = text;
    if (state) t.state = state;
    t.el.dataset.state = t.state;
    t.el.querySelector('.lq-toast-icon').innerHTML = LQ_TOAST_ICONS[t.state] || LQ_TOAST_ICONS.info;
    t.el.querySelector('.lq-toast-title').textContent = t.title;
    t.el.querySelector('.lq-toast-text').textContent = t.text;
}

// How far (px) a toast has to travel down from where it rests to be centered
// on the bottom nav. The layer has no height, so its top edge is exactly the
// bottom edge of the toasts.
function lqToastNavDistance(t) {
    const src = lqToastSource();
    if (!src || !lqToastLayer) return 70;
    const lr = lqToastLayer.getBoundingClientRect();
    const ty = parseFloat(t.el.style.getPropertyValue('--ty')) || 0;
    const restCenter = lr.top + ty - LQ_TOAST_H / 2;
    return Math.max(40, src.cy - restCenter);
}

// Where a toast leaves from and goes back to, which depends on the nav in use:
//   float   Pill and Capsule: the whole bar. The toast is the bar pulling apart, with a glass neck.
//   bubble  Material bar: the round bubble, wherever it is now.
//   tab     Indicator bar: the selected tab, rising out from behind the bar.
// dx = how far that is from the middle of the toasts (sideways), cy = its middle (screen y), w / h = its size.
function lqNavKind() {
    const d = LQ_NAV_STYLES[lqNavCfg.style] || {};
    return d.notch ? 'bubble' : d.bar ? 'tab' : 'float';
}
function lqToastSource() {
    const pill = document.getElementById('navPill');
    if (!pill || !lqToastLayer) return null;
    const pr = pill.getBoundingClientRect(), lr = lqToastLayer.getBoundingClientRect();
    const lcx = lr.left + lr.width / 2;
    const kind = lqNavKind();
    const lens = pill.querySelector('.nav-lens');
    // the lens is the bubble on the Material bar and the slim indicator on the Indicator bar
    if ((kind === 'bubble' || kind === 'tab') && lens) {
        const r = lens.getBoundingClientRect(), cs = getComputedStyle(lens);
        let bg = cs.backgroundColor;
        if (!bg || /rgba?\(0,\s*0,\s*0,\s*0\)|transparent/.test(bg)) bg = getComputedStyle(document.documentElement).getPropertyValue('--ac') || '#fff';
        return { kind, dx: r.left + r.width / 2 - lcx, cy: r.top + r.height / 2, w: r.width, h: r.height, r: Math.min(r.width, r.height) / 2, bg };
    }
    const cs = getComputedStyle(pill);
    return { kind: 'float', dx: pr.left + pr.width / 2 - lcx, cy: pr.top + pr.height / 2, w: pr.width, h: pr.height, r: Math.min(parseFloat(cs.borderTopLeftRadius) || pr.height / 2, pr.height / 2), bg: cs.backgroundColor };
}

// The toast starts out exactly as big as the nav pill (and sits behind it),
// then grows into its own shape while it rises: it looks like it peels off the nav.
function lqToastNavShape(el) {
    const src = lqToastSource();
    const w = el.offsetWidth || 312;
    if (!src) return { sx: 0.9, sy: 0.9 };
    return { sx: Math.max(0.12, Math.min(src.w / w, 1.3)), sy: Math.max(0.3, Math.min(src.h / LQ_TOAST_H, 1.2)) };
}

// `mode` staggers the cards so they don't all move at once:
//   'expand'   a stack opens: each card leaves the front one after another
//   'collapse' the stack folds back, nearest card first
//   'push'     a new toast arrived: the older ones make room one by one
// (`calm` = something just left: the rest glide down, also one by one)
const LQ_STAGGER = { expand: 55, collapse: 70, push: 30 };
// Folding the stack back is slower and softer than opening it: longer travel,
// only a hint of overshoot, and the cards that end up hidden fade out late.
// A card that goes behind the front one (or comes out from behind it) does not swap its glass in one frame. Like the nav thinning
// its glass in, its glass runs down (or up) as one number p: the blur, the saturation and the bend of the picture behind it all go
// with p (the bend through a filter of the card's own, because the filter of the toasts is shared), and its tint firms up (or thins
// out) at the same time. Going behind it starts when the card is about half way to its place and ends as it arrives; coming out it
// starts at once. When p has reached 0 the backdrop filter is switched off (is-flat): a card in the stack costs nothing.
let lqGlN = 0;
function lqGlRamp(el, to, delayMs, durMs) {
    if (el._glR) { cancelAnimationFrame(el._glR); el._glR = 0; }
    const stage = el.closest && el.closest('.lq-gp');
    const src = LQ_GXF.get(stage ? 'lqf-gt' : 'lqf-toast');
    const from = el._glP === undefined ? (to ? 0 : 1) : el._glP;
    let id = el._glId || '';
    if (!id && src && src.o) { id = 'lqf-c' + (++lqGlN); lqGxFilter(id, { ...src.o }); el._glId = id; }
    const bf = `blur(calc(var(--lq-glass-blur, 4px) * var(--lq-gp, 1)))${id ? ` url(#${id})` : ''} saturate(calc(1 + (var(--lq-glass-sat, 1.5) - 1) * var(--lq-gp, 1)))`;
    el.classList.remove('is-flat');
    el.style.setProperty('-webkit-backdrop-filter', bf);
    el.style.setProperty('backdrop-filter', bf);
    const put = p => { el._glP = p; el.style.setProperty('--lq-gp', p.toFixed(3)); if (id) lqGxK([id], p); };
    put(from);
    const t0 = performance.now() + delayMs;
    const finish = () => {
        el._glR = 0;
        el.style.removeProperty('--lq-gp');
        el.style.removeProperty('backdrop-filter');
        el.style.removeProperty('-webkit-backdrop-filter');
        if (el._glId) { lqGxDrop(el._glId); el._glId = ''; }
        el._glP = undefined;
        if (to === 0) el.classList.add('is-flat');
    };
    const step = now => {
        el._glR = 0;
        if (!el.isConnected) { finish(); return; }
        const k = lqClamp((now - t0) / Math.max(durMs, 1), 0, 1);
        if (now >= t0) put(from + (to - from) * (k * k * (3 - 2 * k)));
        if (k >= 1) finish(); else el._glR = requestAnimationFrame(step);
    };
    el._glR = requestAnimationFrame(step);
}
// Every toast has its own layers in the liquid body (the sheet and the tint), and they must sit right under THAT toast and over the
// ones behind it. With one fixed level for all of them (under every toast) a stacked card's body was painted under the older cards
// that sit a few px behind it, so the new card looked see-through while it came out and only got its fill once it had landed.
function lqToastLiqZ(t) {
    const B = parseInt(t.el.style.zIndex, 10) || 400;
    if (t._sheet) t._sheet.style.zIndex = String(B - 3);
    if (t._tint) t._tint.style.zIndex = String(B - 2);
}
function lqGlMorph(el, behind, travelMs, delayMs) {
    if (el.classList.contains('is-behind') === behind) return;
    el.classList.toggle('is-behind', behind);
    const glass = document.documentElement.classList.contains('lq-glass-on') || !!(el.closest && el.closest('.lq-gp.is-glass'));
    if (!glass || lqReduced()) { el.classList.toggle('is-flat', behind && glass); return; }
    const delay = behind ? delayMs + travelMs * 0.5 : delayMs, dur = behind ? travelMs * 0.46 : Math.min(travelMs * 0.5, 420);
    el.style.setProperty('--gl-delay', Math.round(delay) + 'ms');
    el.style.setProperty('--gl-dur', Math.round(dur) + 'ms');
    el.classList.add('lq-gl-morph');
    clearTimeout(el._glT);
    el._glT = setTimeout(() => el.classList.remove('lq-gl-morph'), delay + dur + 150);
    lqGlRamp(el, behind ? 0 : 1, delay, dur);
}
const LQ_COLLAPSE = { dur: '1.05s', ease: 'cubic-bezier(.22,1,.36,1)', fade: '.65s' };
function lqToastLayout(calm = false, mode = '') {
    const n = lqToasts.length;
    if (n < 3) lqToastExpanded = false;
    const stacked = n >= 3 && !lqToastExpanded;
    lqToasts.forEach((t, i) => {
        const y = stacked ? i * 9 : i * (LQ_TOAST_H + LQ_TOAST_GAP);
        const s = stacked ? 1 - i * 0.05 : 1;
        const o = stacked ? (i < 3 ? 1 : 0) : 1;          // never see-through: dimmed instead
        t.el.style.setProperty('--ty', `${-y}px`);
        t.el.style.setProperty('--s', String(s));
        t.el.style.setProperty('--sy', '1');
        t.el.style.setProperty('--o', String(o));
        t.el.style.setProperty('--dim', stacked ? String(Math.min(i * 0.2, 0.4)) : '0');
        // when something just left, the others glide down calmly (no bounce that
        // would overshoot into the toast that is still shrinking into the nav)
        const step = LQ_STAGGER[mode] || (calm ? 30 : 0);
        t.el.style.setProperty('--tr-delay', `${i * step}ms`);
        const fold = mode === 'collapse';
        t.el.style.setProperty('--tr-dur', fold ? LQ_COLLAPSE.dur : (calm ? '.42s' : '.62s'));
        t.el.style.setProperty('--tr-ease', fold ? LQ_COLLAPSE.ease : 'cubic-bezier(.22,1,.36,1)');
        t.el.style.setProperty('--op-dur', fold ? LQ_COLLAPSE.fade : '.2s');
        t.el.style.zIndex = String(4 * (100 - i));
        lqToastLiqZ(t);
        lqGlMorph(t.el, stacked && i > 0, fold ? 1050 : (calm ? 420 : 620), i * step);
        t.el.dataset.stacked = stacked && i === 0 ? '1' : '';
        const more = t.el.querySelector('.lq-toast-more');
        if (more) more.textContent = stacked && i === 0 ? `+${n - 1}` : '';
    });
    if (lqToastControls) {
        lqToastControls.style.setProperty('--ty', `${-(n * (LQ_TOAST_H + LQ_TOAST_GAP))}px`);
        const on = n >= 3 && lqToastExpanded;
        // "Show less" then "Clear all" rise in one after the other, once the
        // last card has (nearly) finished opening. They leave at once, no delay.
        lqToastControls.style.setProperty('--d', on ? `${(n - 1) * LQ_STAGGER.expand + 260}ms` : '0ms');
        lqToastControls.classList.toggle('is-on', on);
    }
}

function lqToastArm(t, ms) {
    clearTimeout(t.timer);
    t.left = ms;
    t.armedAt = performance.now();
    t.timer = setTimeout(() => lqToastDismiss(t), ms);
}
function lqToastPause(t) {
    if (!t.timer) return;
    clearTimeout(t.timer);
    t.timer = 0;
    t.left = Math.max(1500, t.left - (performance.now() - t.armedAt));
}
function lqToastResume(t) {
    if (!t.timer && lqToasts.includes(t)) lqToastArm(t, t.left);
}

// ── Liquid motion ─────────────────────────────────────────────
// The toast peels off the nav like a droplet: it is pulled out (stretched tall
// and thin), a "neck" of glass still joins it to the nav, the neck thins and
// snaps, and the toast rebounds with a little jelly squash. Swiping it down
// does the reverse: the neck reconnects and the toast is absorbed.
// Everything here is transform + opacity only (no SVG goo filter, no extra
// backdrop blur, no layout reads while moving), so it stays on the compositor
// and doesn't load the WebUI. Frames are sampled from a spring ahead of time
// and played with the Web Animations API.
const LQ_ENTRY_MS = 820;
const lqReduced = () => !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
const lqLerp = (a, b, k) => a + (b - a) * k;
const lqSmooth = k => { k = Math.max(0, Math.min(1, k)); return k * k * (3 - 2 * k); };

// ── Liquid: one signed-distance field, smoothly unioned ─────────────────────────────────────────────────────────────────
// What makes it a liquid is the mechanism, not a drawn neck: the card, the bar (or the bubble / the indicator) and a short
// bridge between them are shapes in ONE distance field, joined with a smooth minimum. The neck is whatever that field does
// between them: it forms by itself as they come close, is as wide as the shapes are, runs tangent into both, thins as they
// are pulled apart and lets go on its own, and where the card goes into the bar it turns into the meniscus that runs round it.
// Everything is a continuous function of one number (how far the card is out of the bar), so nothing switches on or off in a
// single frame: no pop when the neck forms or lets go, and nothing is left on the bar when the card has gone in.
// It is drawn with WebGL on one small canvas over the toast layer: the same edge shader as the resting glass (LQ_GX_RIM), so a
// card that moves and a card that rests have the same rim. The card's own text stays a normal element on top. Without
// WebGL the card still moves, it is just not joined to the bar.
const lqClamp = (v, a, b) => Math.max(a, Math.min(b, v));
// resolution of the liquid canvas (device pixels per css px, at most): it only draws a soft shadow and a hairline ring
const LQ_LIQ_DPR = 1.5;
const LQ_LIQ = { ok: null, cv: null, gl: null, prog: null, loc: {}, bodies: new Map(), pool: [], n: 0, raf: 0, CW: 560, CH: 380, NY: 300 };
// how far the neck flares into the card and into the nav (1 = the old, tighter fillet): the wider it is, the more the two read as one
// piece of liquid that is drawn out, not two shapes with a bar between them. The shader and lqLiqField use the same number.
const LQ_FLARE = 1.5;
const LQ_NECK_SOFT = 0.88;      // 0 = the edge light runs on round the whole neck, 1 = it is gone at the blend into the card / the nav
const LQ_NECK_ZONE = 48;       // px: how far from the neck the edge light starts to thin out (and it thins out the closer it gets)
// Where the card and the bar are about to touch (or have touched) their glass thins out, in the card, in the bar, in the edge ring and
// in the shadow, so the two read as one piece of liquid. It follows how close they are (not only whether a neck exists) and goes with
// the card: it builds up as the card goes toward the bar, is deepest when they overlap, and closes again as the card sinks in.
const LQ_CONTACT_NEAR = 72;    // px: the card's bottom edge this close to the bar's top edge, the thinning begins
const LQ_CONTACT_RAMP = 0.3;   // the thinning builds up over this share of the way into the bar (u)
// The merge gradient fills the whole card ONCE, as one continuous move from the first px of the pull to LQ_COVER_END of the way to the bar
// (a share of the card's travel, not of its distance to the bar), and it is the same value on the way back. The thinning of the glass
// (the soft hole: edge light and shadow at the contact, see prox) only starts once the fill has got LQ_HOLE_FROM of the way, so by the
// time it shows the gradient already covers it.
const LQ_COVER_END = 0.7;
// How much longer the toast's coming out / going into the bar (and the tail of its fill) takes: 1 = the original speed, 1.4 = 40% slower.
const LQ_SLOW = 1.4;
// The fill is a round gradient that starts as a small spot at the middle of the card's bottom edge and grows with the card's position on its way
// to the bar (the same position-based value both ways, so a card coming out of the bar plays it in reverse) until it covers the whole card.
const LQ_FILL_START_X = 0.7, LQ_FILL_START_Y = 0.35;      // the spot at the start, as a share of the setting's reach (wide, high)
const LQ_HOLE_FROM = 0.6;
const LQ_LIQ_FS = LQ_GX_RIM + `
uniform vec2 uSize; uniform float uNY; uniform float uPx;
uniform vec4 uA; uniform float uAr;        // the card: centre, half size, radius
uniform vec4 uB; uniform float uBr;        // the bar / bubble / indicator
uniform vec4 uS1; uniform vec2 uS2;        // the bridge: xt, xb, yt, y2  /  half width, on
uniform vec4 uT1; uniform vec2 uT2;        // a second, short one (the stub left on the bar when the bridge breaks): same layout
uniform float uK; uniform float uKc; uniform float uCut;
uniform vec4 uRing;
uniform float uZone;                       // px around the neck where the edge light thins out
uniform float uSoft;                       // how much the edge light fades where the neck blends into the card / the nav
uniform vec3 uCt;                          // contact: how close card and bar are (0..1), where (x) and how wide (half width)
uniform float uFade;                       // 0..1: the body hands over to the card's own glass (1 = nothing drawn here)
float sdBox(vec2 p, vec2 c, vec2 h, float r) {
    vec2 q = abs(p - c) - h + r;
    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
}
float smin(float a, float b, float k) {
    float h = max(k - abs(a - b), 0.0) / max(k, 0.0001);
    return min(a, b) - h * h * k * 0.25;
}
// the normal distribution's cumulative curve (what a blurred edge looks like), without tanh (GLSL ES 1.0 has none)
float cdf(float x) {
    float y = clamp(1.5957691 * x * (1.0 + 0.044715 * x * x), -20.0, 20.0);
    float e = exp(y);
    return e / (e + 1.0);
}
// x = the whole body, y = the card and its bridge alone, z = the bar alone
vec3 field(vec2 p) {
    float dA = sdBox(p, uA.xy, uA.zw, uAr);
    float dAS = dA;
    float dSB = 1e4;
    if (uS2.y > 0.5) {
        float f = clamp((p.y - uS1.z) / max(uS1.w - uS1.z, 0.001), 0.0, 1.0);
        float xc = mix(uS1.x, uS1.y, f);
        float hh = 0.5 * (uS1.w - uS1.z);
        float dS = sdBox(p - vec2(xc, 0.0), vec2(0.0, 0.5 * (uS1.z + uS1.w)), vec2(uS2.x, hh), min(hh, 12.0));
        dAS = smin(dA, dS, uK * ${LQ_FLARE.toFixed(2)});
        dSB = dS;
    }
    if (uT2.y > 0.5) {
        float f2 = clamp((p.y - uT1.z) / max(uT1.w - uT1.z, 0.001), 0.0, 1.0);
        float hh2 = 0.5 * (uT1.w - uT1.z);
        float dT = sdBox(p - vec2(mix(uT1.x, uT1.y, f2), 0.0), vec2(0.0, 0.5 * (uT1.z + uT1.w)), vec2(uT2.x, hh2), min(hh2, 12.0));
        dAS = smin(dAS, dT, uK * ${LQ_FLARE.toFixed(2)});
    }
    float dB = sdBox(p, uB.xy, uB.zw, uBr);
    // The card and the bar are joined through the bridge, not across their whole width: the bridge blends into the card and into
    // the bar (its two fillets), and the card and the bar blend directly only once the card is in the bar (uKc closes as they part).
    // That is what makes a waist, not a pedestal with a hook at each corner.
    float dCB = smin(dA, dB, uKc);
    float dBr = smin(dSB, dB, uK * ${LQ_FLARE.toFixed(2)});
    return vec3(min(min(dAS, dBr), dCB), dAS, dB);
}
void main() {
    vec2 p = vec2(gl_FragCoord.x * uPx - 0.5 * uSize.x, (uSize.y - gl_FragCoord.y * uPx) - uNY);
    if (p.y > uCut) discard;                              // from the bar's top edge down it is the bar's own glass, never drawn here
    vec3 f = field(p);
    float d = f.x;
    // Inside the body there is nothing to draw (the card's own glass, or the sheet, is there) and far outside the shadow is gone:
    // most pixels of the box stop here, before the normal and the shadow field are read.
    if (d < -2.5 || d > 70.0) { gl_FragColor = vec4(0.0); return; }
    float aa = uPx * 0.75;
    float edge = 1.0 - clamp((d + aa) / (2.0 * aa), 0.0, 1.0);       // 1 inside the body
    // The edge belongs to the body where the card or its bridge is the nearer shape; where it is only the bar, the bar's own
    // glass (see lqGxMapURL) is already there, so nothing is drawn twice and nothing stays on the bar afterwards.
    float own = smoothstep(-3.0, 5.0, f.z - f.y);
    float e = 0.75;
    vec2 n = vec2(0.0);
    if (abs(d) < 12.0) {                                 // only the rim and the ring use the normal: no need for it elsewhere
        n = vec2(field(p + vec2(e, 0.0)).x - field(p - vec2(e, 0.0)).x, field(p + vec2(0.0, e)).x - field(p - vec2(0.0, e)).x);
        n = n / (length(n) + 1e-5);
    }
    vec4 rim;
    if (uQ.y > 0.5) {
        rim = lqRim(-d, n) * edge;
    } else {
        // a solid card: the faint light on its rim (inset 0 1px 0 rgba(255,255,255,.06)), thin and soft
        float rimOld = pow(clamp(-(n.x * -0.5 + n.y * -0.85), 0.0, 1.0), 2.2) * clamp(1.0 + d / 1.5, 0.0, 1.0);
        float ra = 0.08 * rimOld * edge;
        rim = vec4(vec3(ra), ra);
    }
    // Where the neck runs into the card and into the nav (the part of the field that only exists because of the smooth union) the
    // edge light fades out instead of running on unchanged: the glass thins out into the two pieces and there is no line where
    // one ends and the next begins.
    float dAo = sdBox(p, uA.xy, uA.zw, uAr);
    float blend = max(smoothstep(0.0, 6.0, dAo - f.y), smoothstep(0.0, 6.0, min(f.y, f.z) - f.x));
    float zone = 0.0;
    if (uS2.y > 0.5) {
        float fz = clamp((p.y - uS1.z) / max(uS1.w - uS1.z, 0.001), 0.0, 1.0);
        float hz = 0.5 * (uS1.w - uS1.z);
        float dz = sdBox(p - vec2(mix(uS1.x, uS1.y, fz), 0.0), vec2(0.0, 0.5 * (uS1.z + uS1.w)), vec2(uS2.x, hz), min(hz, 12.0));
        zone = (1.0 - smoothstep(0.0, uZone, dz)) * smoothstep(0.0, 8.0, uS2.x);   // grows with the neck: nothing pops when it forms
    }
    // where the card and the bar touch (no neck needed) the edge light and the shadow thin out too
    float ct = 0.0;
    if (uCt.x > 0.001) {
        float yT = uB.y - uB.w;
        ct = uCt.x * (1.0 - smoothstep(0.0, uZone * 2.4, abs(p.y - yT))) * (1.0 - smoothstep(uCt.z * 0.85, uCt.z + 50.0, abs(p.x - uCt.y)));
    }
    float soft = 1.0 - uSoft * max(max(blend, zone), ct);
    rim *= own * soft;
    float rb = clamp(1.0 - abs(d + 0.6), 0.0, 1.0) * uRing.a * own * soft;
    vec4 fill = vec4(uRing.rgb * rb, rb) + rim * (1.0 - rb);
    // the shadow is the card's own (0 12px 30px rgba(0,0,0,.4): a blur of 30px is a sigma of 15), for the card and its bridge
    float dsh = field(p - vec2(0.0, 12.0)).y;
    float sh = 0.0 * (1.0 - cdf(dsh / 15.0)) * (1.0 - edge) * (1.0 - 0.95 * ct);       // no shadow (was 0.4: the card's old 0 12px 30px drop shadow)
    gl_FragColor = (fill + vec4(0.0, 0.0, 0.0, sh) * (1.0 - fill.a)) * (1.0 - uFade);
}`;
function lqLiqInit() {
    if (LQ_LIQ.ok !== null) return LQ_LIQ.ok;
    LQ_LIQ.ok = false;
    try {
        const cv = document.createElement('canvas');
        const gl = cv.getContext('webgl', { alpha: true, premultipliedAlpha: true, antialias: false, depth: false, stencil: false });
        if (!gl) return false;
        const prog = lqGxProgram(gl, LQ_GX_VS, LQ_LIQ_FS);
        gl.useProgram(prog);
        lqGxQuad(gl, prog);
        gl.enable(gl.BLEND);
        gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
        for (const n of ['uSize', 'uNY', 'uPx', 'uA', 'uAr', 'uB', 'uBr', 'uS1', 'uS2', 'uK', 'uKc', 'uCut', 'uRing', 'uP', 'uQ', 'uFade', 'uT1', 'uT2', 'uSoft', 'uZone', 'uCt']) LQ_LIQ.loc[n] = gl.getUniformLocation(prog, n);
        cv.className = 'lq-liquid';
        cv.style.cssText = `position:absolute;left:50%;margin-left:${-LQ_LIQ.CW / 2}px;top:${-LQ_LIQ.NY}px;width:${LQ_LIQ.CW}px;height:${LQ_LIQ.CH}px;pointer-events:none;z-index:399;display:none`;
        cv.addEventListener('webglcontextlost', e => { e.preventDefault(); LQ_LIQ.ok = false; LQ_LIQ.bodies.clear(); cv.style.display = 'none'; });
        LQ_LIQ.cv = cv; LQ_LIQ.gl = gl; LQ_LIQ.prog = prog;
        LQ_LIQ.ok = true;
    } catch (_) { LQ_LIQ.ok = false; }
    return LQ_LIQ.ok;
}
// the part of the canvas a body can touch (layer css px): the card, its bridge, and room for the shadow. Only this is drawn.
function lqLiqBox(b) {
    const A = b.a;
    let x0 = A[0] - A[2], x1 = A[0] + A[2];
    if (b.s) {
        x0 = Math.min(x0, b.s.xt - b.s.rs, b.s.xb - b.s.rs);
        x1 = Math.max(x1, b.s.xt + b.s.rs, b.s.xb + b.s.rs);
    }
    return { x0: x0 - 48, x1: x1 + 48, y0: A[1] - A[3] - 48, y1: b.cut + 1 };
}
function lqLiqScissor(box, dpr, H) {
    const L = LQ_LIQ;
    const cx0 = lqClamp(box.x0 + L.CW / 2, 0, L.CW), cx1 = lqClamp(box.x1 + L.CW / 2, 0, L.CW);
    const cy0 = lqClamp(box.y0 + L.NY, 0, L.CH), cy1 = lqClamp(box.y1 + L.NY, 0, L.CH);
    const x = Math.floor(cx0 * dpr), x2 = Math.ceil(cx1 * dpr), yt = Math.floor(cy0 * dpr), yb = Math.ceil(cy1 * dpr);
    return [x, H - yb, Math.max(0, x2 - x), Math.max(0, yb - yt)];
}
function lqLiqRender() {
    const L = LQ_LIQ;
    L.raf = 0;
    if (!L.ok || !L.gl) return;
    const gl = L.gl, dpr = Math.min(window.devicePixelRatio || 1, LQ_LIQ_DPR);
    const W = Math.round(L.CW * dpr), H = Math.round(L.CH * dpr);
    if (L.cv.width !== W || L.cv.height !== H) { L.cv.width = W; L.cv.height = H; }
    gl.viewport(0, 0, W, H);
    gl.disable(gl.SCISSOR_TEST);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    if (!L.bodies.size) { L.cv.style.display = 'none'; return; }
    const u = L.loc;
    gl.enable(gl.SCISSOR_TEST);
    gl.uniform2f(u.uSize, L.CW, L.CH);
    gl.uniform1f(u.uNY, L.NY);
    gl.uniform1f(u.uPx, 1 / dpr);
    for (const b of L.bodies.values()) {
        const s = lqLiqScissor(lqLiqBox(b), dpr, H);
        if (s[2] <= 0 || s[3] <= 0) continue;
        gl.scissor(s[0], s[1], s[2], s[3]);
        gl.uniform4f(u.uA, b.a[0], b.a[1], b.a[2], b.a[3]); gl.uniform1f(u.uAr, b.a[4]);
        gl.uniform4f(u.uB, b.b[0], b.b[1], b.b[2], b.b[3]); gl.uniform1f(u.uBr, b.b[4]);
        if (b.s) { gl.uniform4f(u.uS1, b.s.xt, b.s.xb, b.s.yt, b.s.y2); gl.uniform2f(u.uS2, b.s.rs, 1); }
        else { gl.uniform4f(u.uS1, 0, 0, 0, 1); gl.uniform2f(u.uS2, 0, 0); }
        if (b.s2) { gl.uniform4f(u.uT1, b.s2.xt, b.s2.xb, b.s2.yt, b.s2.y2); gl.uniform2f(u.uT2, b.s2.rs, 1); }
        else { gl.uniform4f(u.uT1, 0, 0, 0, 1); gl.uniform2f(u.uT2, 0, 0); }
        gl.uniform1f(u.uK, b.k);
        gl.uniform1f(u.uKc, b.kcb);
        gl.uniform1f(u.uCut, b.cut);
        gl.uniform4f(u.uRing, b.ring[0], b.ring[1], b.ring[2], b.ring[3]);
        gl.uniform4f(u.uP, b.gx.bezel, b.gx.curve, b.gx.lip, b.gx.str);
        gl.uniform2f(u.uQ, b.gx.split, b.glass ? 1 : 0);
        gl.uniform1f(u.uFade, b.fade || 0);
        gl.uniform1f(u.uSoft, LQ_NECK_SOFT);
        gl.uniform1f(u.uZone, LQ_NECK_ZONE);
        gl.uniform3f(u.uCt, b.prox || 0, (b.a[0] + b.b[0]) / 2, Math.min(b.a[2], b.b[2]));
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }
    L.cv.style.display = 'block';
}
// The same field in JS (the sheet's outline is read from it, so the sheet and the canvas edge always agree).
// (the two helpers are outside lqLiqField on purpose: it runs thousands of times a frame and two closures per call were garbage)
function lqFieldSd(x, y, cx, cy, hw, hh, r) {
    const qx = Math.abs(x - cx) - hw + r, qy = Math.abs(y - cy) - hh + r;
    return Math.min(Math.max(qx, qy), 0) + Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) - r;
}
function lqFieldSm(a, c, k) { const h = Math.max(k - Math.abs(a - c), 0) / Math.max(k, 1e-4); return Math.min(a, c) - h * h * k * 0.25; }
function lqLiqField(b, x, y) {
    const A = b.a, B = b.b;
    const dA = lqFieldSd(x, y, A[0], A[1], A[2], A[3], A[4]), dB = lqFieldSd(x, y, B[0], B[1], B[2], B[3], B[4]);
    let d = dA, dSB = 1e4;
    if (b.s) {
        const s = b.s, f = lqClamp((y - s.yt) / Math.max(s.y2 - s.yt, 0.001), 0, 1), hh = 0.5 * (s.y2 - s.yt);
        dSB = lqFieldSd(x, y, s.xt + (s.xb - s.xt) * f, 0.5 * (s.yt + s.y2), s.rs, hh, Math.min(hh, 12));
        d = lqFieldSm(d, dSB, b.k * LQ_FLARE);
    }
    if (b.s2) {
        const s = b.s2, f = lqClamp((y - s.yt) / Math.max(s.y2 - s.yt, 0.001), 0, 1), hh = 0.5 * (s.y2 - s.yt);
        d = lqFieldSm(d, lqFieldSd(x, y, s.xt + (s.xb - s.xt) * f, 0.5 * (s.yt + s.y2), s.rs, hh, Math.min(hh, 12)), b.k * LQ_FLARE);
    }
    return Math.min(d, lqFieldSm(dSB, dB, b.k * LQ_FLARE), lqFieldSm(dA, dB, b.kcb));
}
// The outline of the body above the bar's top edge (card + bridge + meniscus): for every row the left and right edge. The
// edges are found by bisection from a point that is inside, so this is a few thousand field reads, not a scan of every pixel.
// Where the body is joined to the bar, its last row is carried a little way into the bar (b.ext), so the neck stands on the bar
// without the bar's own top line showing through its foot.
function lqLiqOutline(b) {
    const A = b.a, B = b.b, joined = !!b.s || b.gap <= 0.6;
    const yEnd = b.cut;
    const top = A[1] - A[3], bot = A[1] + A[3];
    if (yEnd <= top - 3 + 2) return null;
    const xmin = -270, xmax = 270;
    const L = [], R = [], Y = [];
    const ST = b.s ? 2 : 3;                       // a neck needs the finer rows; a plain card does not
    // The rows are not an even grid: the polygon that cuts the glass has to be the card's own shape. Rows sit exactly on the card's top
    // and bottom edge, and in the four corners they are spaced by the angle of the arc (a 3 px grid turned a 26 px corner into a
    // chamfer and left the card up to 3 px short at the bottom, which is why the moving card did not look like the resting one).
    const ys = [], rc = Math.max(0, Math.min(A[4], A[2], A[3])), NC = 14;
    if (rc > 1) {
        for (let i = 0; i <= NC; i++) ys.push(top + Math.max(0.03, rc * (1 - Math.cos(i / NC * Math.PI / 2))));
        const mid = Math.max(1, Math.ceil((bot - rc - (top + rc)) / ST)), ms = (bot - rc - (top + rc)) / mid;
        if (ms > 0) for (let i = 1; i < mid; i++) ys.push(top + rc + ms * i);
        for (let i = NC; i >= 0; i--) ys.push(bot - Math.max(0.03, rc * (1 - Math.cos(i / NC * Math.PI / 2))));
    } else { ys.push(top + 0.03, bot - 0.03); }
    // under the card: the neck's fillet needs fine rows right below the card's edge, then the usual grid down to the bar
    const fine = b.s ? 12 : 0;
    for (let y = bot + 0.03; y < yEnd; y += (y - bot < fine ? 1 : ST)) ys.push(y);
    ys.push(yEnd);
    ys.sort((p, q) => p - q);
    const rows = [];
    for (const y of ys) if (y <= yEnd + 1e-6 && y > top && (!rows.length || y - rows[rows.length - 1] > 0.02)) rows.push(y);
    for (const y of rows) {
        let cx = null;
        const tryX = x => { if (cx === null && lqLiqField(b, x, y) < 0) cx = x; };
        tryX(A[0]);
        if (cx === null && b.s) tryX(b.s.xt + (b.s.xb - b.s.xt) * lqClamp((y - b.s.yt) / Math.max(b.s.y2 - b.s.yt, 0.001), 0, 1));
        if (cx === null) tryX(B[0]);
        if (cx === null) continue;
        const edge = (xo, xi) => {       // xo outside, xi inside: the sub-pixel position where the field crosses 0
            let fo = lqLiqField(b, xo, y);
            if (fo < 0) return xo;
            let fi = lqLiqField(b, xi, y);
            for (let i = 0; i < 6; i++) {
                const xm = (xo + xi) / 2, fm = lqLiqField(b, xm, y);
                if (fm < 0) { xi = xm; fi = fm; } else { xo = xm; fo = fm; }
            }
            return fo - fi > 1e-6 ? xo + (xi - xo) * fo / (fo - fi) : (xo + xi) / 2;
        };
        const l = edge(xmin, cx), r = edge(xmax, cx);
        if (r - l > 0.5) { L.push(l); R.push(r); Y.push(y); }
    }
    if (Y.length < 2) return null;
    // Material bubble: the neck's foot is cut flat at the bubble's top (+ a few px) and the fillet around it is wider than the bubble's round
    // top at that depth, so a flat solid ledge (a "leg") stuck out on both sides of the bubble. Below the bubble's top edge the body is
    // therefore narrowed row by row, from its own width at the top edge down to the chord of the bubble at that depth, so the foot runs
    // into the round shape instead of ending in a shelf.
    if (b.nk === 'bubble' && yEnd > b.top + 0.5) {
        let iT = -1;
        for (let i = 0; i < Y.length; i++) if (Y[i] <= b.top + 0.01) iT = i;
        if (iT >= 0) {
            const hwT = 0.5 * (R[iT] - L[iT]), rb = Math.max(1, Math.min(B[4], B[2], B[3])), Dc = Math.max(1, yEnd - b.top);
            for (let i = iT + 1; i < Y.length; i++) {
                const e = Y[i] - b.top;
                if (e <= 0) continue;
                const ch = e >= rb ? B[2] : B[2] - rb + Math.sqrt(Math.max(0, rb * rb - (rb - e) * (rb - e)));
                const q = lqClamp(e / Dc, 0, 1), allow = ch + Math.max(0, hwT - ch) * (1 - q * q * (3 - 2 * q)) * (1 - q);
                const mid = 0.5 * (L[i] + R[i]), cx = mid + (B[0] - mid) * lqClamp(q, 0, 1);
                L[i] = Math.max(L[i], cx - allow); R[i] = Math.min(R[i], cx + allow);
                if (R[i] - L[i] < 0.5) { L[i] = cx - 0.25; R[i] = cx + 0.25; }
            }
        }
    }
    // Where the neck lands on the bar, its foot takes the width of the piece it stands on instead of coming down as wide as the bridge is:
    // on the Indicator bar the slim indicator (a narrow strip: a wide foot hung over its two ends), on the floating bars the flat part of the
    // top edge (the corners curve away from it). Over the last stretch above the bar the body narrows from its own width to that one and
    // slides to the piece's centre, so the join ends on the piece with no ledge. Only rows under the card (the card itself is never narrowed),
    // and the stretch shrinks with the gap, so a card that is almost there is not pinched.
    if ((b.nk === 'tab' || b.nk === 'float') && b.s) {
        const rr = Math.max(0, Math.min(B[4], B[2], B[3]));
        const capEnd = b.nk === 'tab' ? Math.max(6, B[2]) : Math.max(10, B[2] - rr * 0.7);
        const gapB = b.top - bot, Lf = Math.min(30, 0.6 * gapB);
        if (Lf > 3) {
            for (let i = 0; i < Y.length; i++) {
                if (Y[i] <= bot + 0.5 || Y[i] <= b.top - Lf) continue;
                const q = lqSmooth(lqClamp((Y[i] - (b.top - Lf)) / Lf, 0, 1));
                const mid = 0.5 * (L[i] + R[i]), half = 0.5 * (R[i] - L[i]);
                const nh = half + (Math.min(half, capEnd) - half) * q, nc = mid + (B[0] - mid) * q;
                L[i] = nc - nh; R[i] = nc + nh;
            }
        }
    }
    // carried into the bar only if the body really reaches it (a short drip left hanging from the card after the bridge broke does not)
    // The rows are carried on in small steps (a step over 2.6 px would count as a gap and start a separate shape, which left the foot
    // out and a gap between the neck and the bar) and only as wide as the bar itself is at that depth: its top corners curve away,
    // and a foot that kept its width stuck out past them as two square wings (the leftover cuts at the sides of the neck).
    if (joined && b.ext > 0 && Y[Y.length - 1] >= yEnd - 2.5) {
        const l0 = L[L.length - 1], r0 = R[R.length - 1], rr = Math.max(0, Math.min(B[4], B[2], B[3])), n = Math.max(1, Math.ceil(b.ext / 2));
        const mid = 0.5 * (l0 + r0), hw0 = 0.5 * (r0 - l0);
        for (let i = 1; i <= n; i++) {
            const e = b.ext * i / n, half = e >= rr ? B[2] : B[2] - rr + Math.sqrt(Math.max(0, rr * rr - (rr - e) * (rr - e)));
            const q = i / n, hw = hw0 * (1 - 0.3 * q * q * (3 - 2 * q));        // the foot narrows only a little as it goes into the bar: the flare still reaches it, no cut wings
            L.push(Math.max(mid - hw, B[0] - half + 0.75)); R.push(Math.min(mid + hw, B[0] + half - 0.75)); Y.push(b.top + e);
        }
    }
    // pieces that are apart (rows with nothing in them between) are separate shapes: a card and a stub left on the bar must not be
    // joined by a thread drawn between their nearest rows
    const runs = [];
    let st = 0;
    for (let i = 1; i <= Y.length; i++) if (i === Y.length || Y[i] - Y[i - 1] > 3.3) { runs.push([st, i - 1]); st = i; }
    return { L, R, Y, runs };
}
const lqRgba = c => `rgba(${Math.round(c[0] * 255)},${Math.round(c[1] * 255)},${Math.round(c[2] * 255)},${c[3].toFixed(3)})`;
// Where the neck really is, read off the outline that is drawn (not off the numbers the neck is built from): the centre and the
// half-width at its waist, and the centre and half-width at its foot on the bar's top edge. The holes in the glass (the card's
// and the bar's) use these, so they sit on the neck that is seen, are as wide as it is, and follow it frame by frame.
function lqNeckMetrics(b, o) {
    if (!b.s || !o) return null;
    const yA = b.a[1] + b.a[3], yB = b.top;
    let wMin = 1e9, cxW = 0, hasW = false, iF = -1;
    for (let i = 0; i < o.Y.length; i++) {
        if (o.Y[i] <= yB + 0.01) iF = i;
        if (o.Y[i] >= yA + 2 && o.Y[i] <= yB + 0.01) { const w = o.R[i] - o.L[i]; if (w < wMin) { wMin = w; cxW = 0.5 * (o.L[i] + o.R[i]); hasW = true; } }
    }
    if (iF < 0) return null;
    const cxF = 0.5 * (o.L[iF] + o.R[iF]), hwF = 0.5 * (o.R[iF] - o.L[iF]);
    return { cxW: hasW ? cxW : cxF, hwW: hasW ? 0.5 * wMin : hwF, cxF, hwF, yA, yB };
}
// The bend filter of a moving body is the same for every toast, so the filters are kept in a small pool and handed out again instead
// of being built (and their map decoded) from scratch for each toast. One displacement pass: the colour fringe is only on the resting card.
function lqLiqFilterTake(src) {
    const id = LQ_LIQ.pool.pop() || ('lqf-b' + (++LQ_LIQ.n));
    lqGxFilter(id, { ...src.o, free: true, split: 0 });
    return id;
}
function lqLiqFilterGive(id) {
    if (!id) return;
    if (LQ_LIQ.pool.length < 6 && !LQ_LIQ.pool.includes(id)) LQ_LIQ.pool.push(id); else lqGxDrop(id);
}
// One sheet of glass for the whole body: the card and what joins it are the same material (same blur, same tint), cut to the
// outline of the field. The card's own surface steps aside while it moves (class lq-liq); its text stays on top. The edge of
// the body is drawn by the canvas with the same shader as the resting glass, so there is no map and no SVG filter here.
function lqLiqSheet(t, b) {
    let sh = t._sheet;
    if (!sh) {
        sh = document.createElement('div');
        sh.className = 'lq-liq-sheet';
        let bf = t._bf;
        if (t._bfT) {
            const src = LQ_GXF.get('lqf-toast'), id = src && src.o ? lqLiqFilterTake(src) : null;
            if (src && src.o) { // one displacement pass while it moves (the colour fringe is only on the resting card)
                t._fid = id; bf = t._bfT.replace('@FID@', id);
            }
        }
        t._sbf = bf || '';
        if (bf) { sh.style.backdropFilter = bf; sh.style.webkitBackdropFilter = bf; }
        lqToastLayer.appendChild(sh);
        t._sheet = sh;
        lqToastLiqZ(t);
    }
    // the tint (colour, the light at the waist) is its own layer over the sheet: the sheet keeps only the glass (blur, saturation,
    // bend), which is what fades out near the neck, while the colour keeps the body's shape
    let tn = t._tint;
    if (!tn) {
        tn = document.createElement('div');
        tn.className = 'lq-liq-tint';
        tn.style.cssText = 'position:absolute;left:50%;top:0;z-index:56;pointer-events:none';
        lqToastLayer.appendChild(tn);
        t._tint = tn;
        lqToastLiqZ(t);
    }
    const o = lqLiqOutline(b);
    b.nm = lqNeckMetrics(b, o);
    if (!o) { sh.style.display = 'none'; tn.style.display = 'none'; t._geo = null; return; }      // _geo: forget what was written, so it is written again when the body comes back
    let x0 = 1e9, x1 = -1e9;
    for (let i = 0; i < o.Y.length; i++) { if (o.L[i] < x0) x0 = o.L[i]; if (o.R[i] > x1) x1 = o.R[i]; }
    x0 -= 1; x1 += 1;
    const y0 = o.Y[0] - 1, y1 = o.Y[o.Y.length - 1] + 1, f = v => v.toFixed(2);
    let d = '';
    const f1 = v => v.toFixed(1);
    for (const [a, z] of o.runs) {
        d += `M${f1(o.L[a] - x0)} ${f1(o.Y[a] - y0)}`;
        for (let i = a + 1; i <= z; i++) d += `L${f1(o.L[i] - x0)} ${f1(o.Y[i] - y0)}`;
        for (let i = z; i >= a; i--) d += `L${f1(o.R[i] - x0)} ${f1(o.Y[i] - y0)}`;
        d += 'Z';
    }
    const pa = Math.max(0, b.a[1] + b.a[3] - y0), pb = Math.max(pa + 1, b.top - y0);
    const st = sh.style, ts = tn.style;
    // only what changed is written: the same value written again still makes the browser redo the layer
    const geo = `${b.fade > 0.001 ? (1 - b.fade).toFixed(3) : ''}|${f(x0)}|${f(y0)}|${f(x1 - x0)}|${f(y1 - y0)}`;
    if (t._geo !== geo) {
        t._geo = geo;
        for (const q of [st, ts]) {
            q.display = 'block';
            q.opacity = b.fade > 0.001 ? (1 - b.fade).toFixed(3) : '';
            q.marginLeft = f(x0) + 'px';
            q.top = f(y0) + 'px';
            q.width = f(x1 - x0) + 'px';
            q.height = f(y1 - y0) + 'px';
        }
    }
    if (t._pathD !== d) {
        t._pathD = d;
        const cp = `path('${d}')`;
        st.clipPath = cp; ts.clipPath = cp;
    }
    if (t._fid) lqGxPlace(t._fid, b.a[0] - b.a[2] - x0, b.a[1] - b.a[3] - y0, 2 * b.a[2], 2 * b.a[3]);     // the bend follows the card
    // the part that runs on into the nav fades out downward, so the neck's glass dissolves into the nav's own glass
    const feather = b.feather > 0.5 ? `linear-gradient(180deg,#000 0,#000 ${f(Math.max(0, y1 - y0 - b.feather))}px,rgba(0,0,0,0) ${f(y1 - y0)}px)` : '';
    const gm = [feather].filter(Boolean);
    if (gm.length) {
        st.webkitMaskImage = st.maskImage = gm.join(',');
        st.webkitMaskComposite = 'source-in'; st.maskComposite = 'intersect';
    } else if (st.maskImage) { st.webkitMaskImage = ''; st.maskImage = ''; }
    if (feather) { ts.webkitMaskImage = ts.maskImage = feather; }
    else if (ts.maskImage) { ts.webkitMaskImage = ''; ts.maskImage = ''; }
    // the colour runs from the card's to the bar's along the bridge. The neck is made of a SOLID fill (no hole in anything), and the card
    // above it takes that fill as a gradient: solid where the neck starts, fading out upward over its reach. The bar takes the same fill
    // as a gradient around the foot of the neck (lqLiqHalo). So the three share one colour at the joint and fade out from it.
    const gw = b.glow || 0, gl = (0.05 * gw).toFixed(3), lit = `rgba(255,255,255,${gl})`;
    const fadeK = 1 - (b.fade || 0);
    const inMode = b.grow !== undefined;        // a card coming out of the bar (b.grow: 0 when it leaves, 1 when the neck lets go)
    const csRaw = lqClamp(b.cs || 0, 0, 1), touchK = csRaw * fadeK;     // the whole card's solidity: by contact depth only
    // What the neck gives the gradient (its strength, and the size of the fill at its foot) is kept as it was the last frame before the neck let go
    // and goes down with the hand-over (fadeK, by position) instead of with the neck: the neck is a thread within a frame or two of letting go, and
    // the gradient used to drop from solid to its resting look in that one frame.
    let nPres = b.s ? lqSmooth(b.s.rs / 9) : 0, nNeck = b.s ? lqSmooth((b.nm ? b.nm.hwW : b.s.rs) / 3) : 0;
    let nCx = (b.s ? b.s.xt : b.a[0]), nCore = b.nm && b.s ? Math.min(1.15 * b.nm.hwW + 4, 1.4 * b.s.rs + 10) : 24;
    if (b.held) { if (t._nHold) [nPres, nNeck, nCx, nCore] = t._nHold; } else t._nHold = [nPres, nNeck, nCx, nCore];
    const presN = nPres * fadeK, prx = (b.prox0 || 0) * fadeK, sol = lqClamp(Math.max(presN, prx, touchK), 0, 1);
    // The gradient around the foot of the neck on the card comes with the neck, not with the touch: the neck's width ramps it in over its first
    // few px (it used to need a neck 30 px wide, which only exists near the bar), so the glass that is cleared around the neck is covered
    // by the card's colour from the first moment the neck is there.
    const neckK = nNeck * fadeK;        // 0 -> 1 over the neck's first ~3 px of half-width, so it does not wait for the neck to be 9 px wide
    const solC = lqClamp(Math.max(sol, neckK), 0, 1);
    // Joined to the nav the body is painted (nearly) solid anyway, so the glass under it is wasted work: once it is solid the sheet's
    // backdrop filter (blur + the bend filter) is switched off, and the body stays one solid colour while it stretches. Only when it lets
    // go (fade) does the card's own glass come back, cross-dissolving in under it. It stays off until the body is released.
    if (!t._gOff && csRaw > 0.995 && !(b.fade > 0.001) && (t._sbf || st.backdropFilter)) {
        t._gOff = true;
        st.backdropFilter = 'none'; st.webkitBackdropFilter = 'none';
    } else if (t._gOff && csRaw < 0.98 && !(b.fade > 0.001)) {
        // the card is leaving the bar (or being pulled back): the glass comes back under the solid fill as it thins out
        t._gOff = false;
        if (t._sbf) { st.backdropFilter = t._sbf; st.webkitBackdropFilter = t._sbf; }
    }
    const solid = a => a + (1 - a) * sol;
    const rgbaA = (c, al) => `rgba(${Math.round(c[0] * 255)},${Math.round(c[1] * 255)},${Math.round(c[2] * 255)},${al.toFixed(3)})`;
    // below the card's bottom edge there is only the neck (the sheet is cut to its outline), so the run turns solid from that edge down
    // and never touches the card above it
    const stops = [`${lqRgba(b.ca)} ${f(Math.max(0, pa - 1))}px`];
    for (let i = 0; i <= 4; i++) {
        const w = lqSmooth(i / 4), c = b.ca.map((v, j) => v + (b.cb[j] - v) * w);
        stops.push(`${rgbaA(c, solid(c[3]))} ${f(pa + (pb - pa) * i / 4)}px`);
    }
    const run = `linear-gradient(180deg,${lqRgba(b.ca)} 0px,${stops.join(',')},${rgbaA(b.cb, solid(b.cb[3]))} 100%)`;
    // the card's share of the joint: the neck's fill as a round gradient on the card's bottom edge, centred on where the neck leaves the
    // card. It is solid across the width of the neck and fades out sideways and upward from there, so it follows the neck, not the card
    // how far the fill has grown: a function of the card's position on its way to the bar (same value both ways)
    const cover = lqClamp(b.fill !== undefined ? b.fill : lqSmooth((prx - 0.3) / 0.7), 0, 1);
    let cardG = '';
    if (solC > 0.01 && !(inMode && b.held && lqGradOn())) {
        const wN = presN / (presN + prx + 1e-4), mixN = (c, n) => c + (n - c) * wN;
        const cxC = (b.a[0] + b.b[0]) / 2 - x0, coreC = 0.35 * Math.min(b.a[2], b.b[2]) + 20;
        const cxN = nCx - x0, coreN = nCore;
        const cx = mixN(cxC, cxN), core = mixN(coreC, coreN), P = inMode ? 0.55 : 0.4, yO = Math.min(pa, pb);
        // only the bottom of the card, and only as far up as the neck is long (a short neck, a short fill; never up the card)
        const reach = lqClamp(0.45 * Math.max(b.gap, 0) + 6, 8, 24) + (lqGradOn() ? 0.5 * lqSurfCfg().gradReach * neckK * cover : 0), k = solC;
        const gs = [`${rgbaA(b.ca, k)} 0%`, `${rgbaA(b.ca, k)} ${P * 100}%`];
        for (let j = 1; j <= 5; j++) gs.push(`${rgbaA(b.ca, k * (1 - lqSmooth(j / 5)))} ${((P + (1 - P) * j / 5) * 100).toFixed(1)}%`);
        // a card coming out: the fill starts as a round gradient around where the neck leaves the card and grows with the way out until it is
        // the whole card (the farthest corner is inside its solid part); the vertical fill below takes over from there and goes down to the setting
        let rx = core / P, ry = reach;
        if (inMode) { const far = Math.hypot(Math.abs(cx - (b.a[0] - x0)) + b.a[2], 2 * b.a[3]) * 1.03 / P; rx = ry = rx + (far - rx) * b.grow; }
        cardG = `radial-gradient(ellipse ${f(rx)}px ${f(ry)}px at ${f(cx)}px ${f(yO)}px,${gs.join(',')}),`;
    }
    // a soft light gathered where the neck is: the body is brightest at its waist and calms toward the card and the bar
    let spot = '';
    const sn = b.s;
    if (sn && gw > 0.01) {
        // the same light all along the neck and up into the card (the layer is cut to the body, so it is as wide as the body is
        // at every height): even, instead of a bright spot at the waist
        const g1 = (0.12 * gw).toFixed(3);
        spot = `linear-gradient(180deg,rgba(255,255,255,0) ${f(Math.max(0, pa - 46))}px,rgba(255,255,255,${g1}) ${f(pa)}px,rgba(255,255,255,${g1}) 100%),`;
    }
    // at the touch the fill covers the whole card, not only the foot of the neck (a card that is all one colour goes into the bar)
    const cardAll = '';
    // the solid body under the tint: its opacity IS the contact solidity, so glass and solid cross-fade (no step, no swap)
    const baseA = t._gOff ? 1 : touchK;
    const base = baseA > 0.003 ? `,linear-gradient(${rgbaA(b.ca, baseA)},${rgbaA(b.ca, baseA)})` : '';
    // The merge gradient from the Liquid Glass page (reach / solidity / softness) on the card, from its bottom edge up. The card's own
    // .lq-grad layer is hidden while the body is drawn as one sheet (html .lq-toast.lq-liq .lq-grad), so without this the card only had
    // the thin 8 px fill above and the gradient of the settings was gone exactly when the card and the bar are joined.
    let userG = '';
    // cover: how much the fill has taken over the whole card. It builds up with how close the card is to the bar (prx: 0 at LQ_CONTACT_NEAR away,
    // 1 touching), so the closer it gets the farther the gradient reaches up the card and the more solid it is, until the card is one solid fill.
    // It goes back down the same way as the card moves off, and with fade when the body lets go.
    // One progress for the whole thing (b.fill, from the start of the pull). The gradient is there from the first frame of the sheet at the
    // strength of the setting (the card at rest has it too, and its own .lq-grad layer is hidden under the sheet, so without it the gradient
    // went off when the pull began and came back later), and it only grows from there: reach and solidity rise together up to a solid card.
    // A card coming out of the bar: the fill is the whole card as it leaves the bar and gets smaller the farther it is (b.away: 0 at the bar,
    // 1 when the neck lets go), down to the setting's own look along the bottom edge by the time the neck lets go. The rest of it (narrowing
    // toward the middle, the slow fade, gone) happens after that, on the card's own layer (lqGradTail).
    t._gLast = null;
    if (lqGradOn()) {
        // A round gradient centred on the middle of the card's bottom edge: a small spot at first, growing (wider and higher) as the card gets
        // closer to the bar, until it is the whole card. Coming out of the bar it is the same thing played backwards (cover is a function of
        // the card's position). Its strength comes in over the first part of the growth, so it appears from nothing.
        const gc = lqSurfCfg(), gst = lqGradStops(gc), cardH = 2 * b.a[3], hw = b.a[2];
        const e = cover, eg = Math.pow(e, 1.6), amp = lqSmooth(e * 3.5), full = lqSmooth((e - 0.72) / 0.28);
        const rx0 = Math.max(10, gc.gradReach * LQ_FILL_START_X), ry0 = Math.max(6, gc.gradReach * LQ_FILL_START_Y);
        const rx = lqLerp(rx0, hw * 2.4, eg), ry = lqLerp(ry0, cardH + 24, eg), cxg = b.a[0] - x0;
        const ga = a => { const v = a * amp; return v + (1 - v) * full; };
        if (amp > 0.002) {
            const stp = gst.map(([tt, al]) => `${rgbaA(b.ca, ga(al))} ${(tt * 100).toFixed(1)}%`);
            userG = `radial-gradient(ellipse ${f(rx)}px ${f(ry)}px at ${f(cxg)}px ${f(pa)}px,${stp.join(',')},${rgbaA(b.ca, ga(gst[gst.length - 1][1]))} 100%),`;
            t._gLast = { rx, ry, amp, cxl: cxg - (b.a[0] - hw - x0), gst };
        }
    }
    const bg = `${cardAll}${userG}${cardG}${spot}linear-gradient(${lit},${lit}),${run}${base}`;
    if (t._bgS !== bg) { t._bgS = bg; ts.background = bg; }
}
// The nav is not part of the sheet (it keeps its own glass), so the light of the neck is also laid on the nav's top edge: a soft
// glow on the nav around the foot of the neck, clipped to the nav's own shape. It rises and fades with the neck, so the nav, the
// neck and the card pick up the same light at the same time and read as one family.
// The nav's own glass (blur + bend) gets the same soft hole as the sheet, centred on the foot of the neck: the nav is not touched
// anywhere else. Several toasts can have a neck at once, so the holes are kept per toast and put together on the one element.
const LQ_NAVHOLE = new Map();          // toast -> { el, g }
function lqNavHoleFlush(el) {
    if (!el) return;
    const ls = [];
    for (const h of LQ_NAVHOLE.values()) if (h.el === el) ls.push(h.g);
    const v = ls.join(',');
    if (el._holeV === v) return;
    el._holeV = v;
    el.style.backgroundImage = v;       // the fill laid around the foot of each neck (see lqLiqHalo); '' when there is none
}
function lqNavHole(t, el, g) {
    const prev = LQ_NAVHOLE.get(t);
    if (el && g) LQ_NAVHOLE.set(t, { el, g }); else LQ_NAVHOLE.delete(t);
    if (prev && prev.el !== el) lqNavHoleFlush(prev.el);
    lqNavHoleFlush(el || (prev && prev.el));
}
// The layer of the bar that takes the neck's fill (the bar's own colour layer), by style. null: the bar is a plain solid fill, which the
// neck's foot stands on by itself.
function lqNavFillEl(kind) {
    const pill = document.getElementById('navPill'), root = document.documentElement;
    if (!pill) return null;
    if (kind === 'float') {
        if (root.classList.contains('lq-nav-glass-bar')) return pill.querySelector('.nav-glassbg');
        if (root.classList.contains('lq-nav-surf') && !root.classList.contains('lq-nav-notch')) return pill;
        return null;
    }
    if (root.classList.contains('lq-nav-glass')) return pill.querySelector('.nav-lens');
    // plain Material bubble (no glass, no surface): the bubble itself takes the neck's colour (the card's) while the neck is on it, then goes back
    if (kind === 'bubble') return pill.querySelector('.nav-lens');
    return null;
}
// the radial fill laid on the bar around the foot of a neck, at strength k (solid core, then a smooth fall to nothing)
const LQ_FILL_TAU = 0.2;       // s: how fast the bar's fill lets go once the neck is gone (the time it takes to fall to 37%)
const LQ_FILL_SPREAD = 0.3;    // how much wider it gets while it settles
function lqFillCss(g, k) {
    const sp = g.sp || 0, rx = g.rx * (1 + sp), ry = g.ry * (1 + 0.5 * sp);
    const st = [`rgba(${g.rgb},${k.toFixed(3)}) 0%`, `rgba(${g.rgb},${k.toFixed(3)}) ${g.P * 100}%`];
    for (let j = 1; j <= 5; j++) st.push(`rgba(${g.rgb},${(k * (1 - lqSmooth(j / 5))).toFixed(3)}) ${((g.P + (1 - g.P) * j / 5) * 100).toFixed(1)}%`);
    return `radial-gradient(ellipse ${rx.toFixed(2)}px ${ry.toFixed(2)}px at ${g.cx.toFixed(2)}px 0px,${st.join(',')})`;
}
// When a card is released the bar's fill lets go over a short time instead of being removed in one frame (that was the pop: the bar's
// glass changed all at once around the foot of the neck while the card was still going out of sight under it).
function lqNavFillOut(t) {
    const g = t._fg; t._fg = null; t._fk = 0;
    if (!g || !(g.k > 0.03) || lqReduced()) { lqNavHole(t, null, null); return; }
    let last = performance.now(), k = g.k, sp = g.sp || 0;
    const step = now => {
        const dt = Math.min(0.1, (now - last) / 1000); last = now;
        k *= Math.exp(-dt / LQ_FILL_TAU); sp = Math.min(LQ_FILL_SPREAD, sp + dt / 0.6 * LQ_FILL_SPREAD);
        if (k < 0.02) { lqNavHole(t, null, null); return; }
        lqNavHole(t, g.el, lqFillCss({ ...g, sp }, k));
        requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
}
function lqLiqHalo(t, b) {
    let h = t._halo;
    const sn = b.s, a = sn ? 0.2 * (b.glow || 0) * (1 - (b.fade || 0)) : 0;
    // the bar's share of the joint: the neck's fill (the bar's colour, solid) laid on the bar around the foot of the neck, fading out
    // sideways and downward. It rises with the neck (and with how close the card is when there is none), so the bar, the neck and the
    // card fade out of the same colour. Nothing is cut out of the bar.
    let fillG = null, geo = null, kT = 0;
    const B0 = b.b, prx = (b.prox0 || 0) * (1 - (b.fade || 0));
    const tc = lqClamp((b.touch || 0) * (1 - (b.fade || 0)), 0, 1);
    if (sn || prx > 0.01 || tc > 0.01) {
        // a thin neck paints the bar only a little (nS), a thick one fully: the fill is as strong as the neck is
        const nS = sn ? lqSmooth(sn.rs / 30) * (1 - (b.fade || 0)) : 0, pres = Math.max(nS, prx, tc);
        const wN = nS / (nS + prx + 1e-4), mix = (c, n) => c + (n - c) * wN;       // blended, never switched: no jump between the two
        const nel = pres > 0.01 ? lqNavFillEl(b.nk) : null;
        if (nel) {
            const x0 = B0[0] - B0[2], P = 0.5, nm = b.nm;
            const cxC = (b.a[0] + B0[0]) / 2 - x0, rxC = (0.35 * Math.min(b.a[2], B0[2]) + 20) / P;
            // solid across the foot of the neck as it is drawn, and only a thin lip of the bar deep (never half the bar), fading out from there
            const cxN = nm ? nm.cxF - x0 : cxC, rxN = nm && sn ? Math.min(nm.hwF, 2.6 * sn.rs + 10) / P : rxC;
            // The Material bubble is a round piece, 52px tall, and the fill is laid from its top edge: with the bar's reach (a thin lip) only its upper
            // part ever took the colour. Its fill reaches deeper while the neck stands on it, and spreads over the whole bubble once the two touch.
            const bub = b.nk === 'bubble';
            let cx = mix(cxC, cxN), rx = mix(rxC, rxN), ry = Math.min(2 * B0[3], bub ? mix(40, 30) : mix(26, 16));
            // from the moment they touch (the neck is only a hair of a neck now) the fill spreads over the whole width of the bar, so it does
            // not shrink to the size of the neck: centre of the bar, solid from end to end, a little deeper
            // The Material bubble does it like the pill and the capsule: the fill is a gradient around the foot of the neck, and the closer the
            // card gets the more of the bubble it takes, until the whole bubble is the card's solid colour. Leaving the bubble is the same backwards.
            const cov = bub ? Math.max(tc, lqClamp(1 - lqSmooth(((b.gap || 0) - 2) / 64), 0, 1) * lqClamp(pres * 1.6, 0, 1)) : tc;
            cx += (B0[2] - cx) * cov; rx += (B0[2] / P * (bub ? 1.2 : 1) - rx) * cov; ry += ((bub ? 2 * B0[3] / P : Math.min(2 * B0[3], 20)) - ry) * cov;       // bubble: solid from its top to its bottom
            const c = b.cb, rgb = `${Math.round(c[0] * 255)},${Math.round(c[1] * 255)},${Math.round(c[2] * 255)}`;
            geo = { el: nel, rgb, P, cx, rx, ry };
            kT = 0.97 * pres;
        }
    }
    // the strength rises at once and lets go over a few frames, in place (the neck snaps in a frame or two; the fill must not)
    // Once the neck is gone (or the card has touched the bar) the fill does not just go: it settles. It stays where the neck stood, spreads
    // a little along the bar's top edge and eases out over about half a second (time based, so it is the same on every frame rate).
    const now = performance.now(), dt = Math.min(0.1, Math.max(0, (now - (t._fT || now)) / 1000)); t._fT = now;
    const kPrev = t._fk || 0;
    let kS = kT >= kPrev ? kT : kT + (kPrev - kT) * Math.exp(-dt / LQ_FILL_TAU);
    // A card coming out of the bar: once its neck has let go, the fill holds the strength it had and goes down with the hand-over (b.fade, which
    // follows the card's position and is complete when it reaches rest), so it is gone before the spring goes past rest instead of settling on
    // its own clock through the overshoot.
    if (b.held) { if (t._fHold === undefined) t._fHold = kPrev; kS = t._fHold * (1 - (b.fade || 0)); } else t._fHold = undefined;
    t._fSp = kT >= kPrev ? (t._fSp || 0) * 0.8 : Math.min(LQ_FILL_SPREAD, (t._fSp || 0) + dt / 0.6 * LQ_FILL_SPREAD);
    if (!geo && t._fg && kS > 0.02) geo = t._fg;
    if (geo && kS > 0.01) {
        t._fg = { ...geo, k: kS, sp: t._fSp }; t._fk = kS;
        fillG = lqFillCss(t._fg, kS);
    } else { t._fg = null; t._fk = 0; t._fSp = 0; }
    lqNavHole(t, fillG ? t._fg.el : lqNavFillEl(b.nk), fillG);
    if (a < 0.004) { if (h) h.style.display = 'none'; return; }
    if (!h) {
        h = document.createElement('div');
        h.className = 'lq-liq-halo';
        h.style.cssText = 'position:absolute;left:50%;top:0;z-index:54;pointer-events:none;display:none';
        lqToastLayer.appendChild(h);
        t._halo = h;
    }
    const B = b.b, f = v => v.toFixed(2), x0 = B[0] - B[2], cx = (sn ? sn.xb : (b.a[0] + B[0]) / 2) - x0;
    const rx = sn ? 36 + 2.6 * sn.rs : 36, ry = Math.min(2 * B[3], 30 + (sn ? 0.5 * sn.rs : 0));
    const st = h.style;
    st.display = 'block';
    st.marginLeft = f(x0) + 'px';
    st.top = f(B[1] - B[3]) + 'px';
    st.width = f(2 * B[2]) + 'px';
    st.height = f(2 * B[3]) + 'px';
    st.borderRadius = f(B[4]) + 'px';
    st.background = `radial-gradient(ellipse ${f(rx)}px ${f(ry)}px at ${f(cx)}px 0px,rgba(255,255,255,${Math.max(0, a).toFixed(3)}) 0%,rgba(255,255,255,${Math.max(0, a).toFixed(3)}) 30%,rgba(255,255,255,${(a * 0.4).toFixed(3)}) 62%,rgba(255,255,255,0) 100%)`;
}
function lqLiqSet(t, body) {
    const L = LQ_LIQ;
    if (!L.ok || t._dead) return;          // a card that has been removed never draws again (a late frame must not leave a body behind)
    if (!L.cv.isConnected && lqToastLayer) lqToastLayer.appendChild(L.cv);
    L.bodies.set(t, body);
    lqLiqSheet(t, body);                                         // the sheet and the card's own surface swap in the same frame
    lqLiqHalo(t, body);
    // While the body hands over (fade > 0) the card's own glass is on again under it, and the body (sheet + canvas) thins out while it
    // still follows the card: a cross-dissolve over the end of the move instead of one swap in a single frame at the end.
    t.el.classList.toggle('lq-liq', !(body.fade > 0.001));
    // (the card's own gradient layer, .lq-grad, is not handed anything here: it is hidden at rest and only the tail below it, lqGradTail, shows it)
    // the canvas is drawn right now, in the same frame as the sheet: scheduled for the next frame it trailed the sheet (and the nav)
    // by one frame, which is what made the neck lag behind a nav that moves
    if (L.raf) { cancelAnimationFrame(L.raf); L.raf = 0; }
    lqLiqRender();
    lqToastOverSync();
}
const lqColorCache = new Map();
let lqColorCtx = null;
function lqColor(css) {
    if (!css) return [0, 0, 0, 0];
    if (lqColorCache.has(css)) return lqColorCache.get(css);
    let out = [0, 0, 0, 0];
    try {
        if (!lqColorCtx) { const c = document.createElement('canvas'); c.width = c.height = 1; lqColorCtx = c.getContext('2d', { willReadFrequently: true }); }
        lqColorCtx.clearRect(0, 0, 1, 1);
        lqColorCtx.fillStyle = '#000';
        lqColorCtx.fillStyle = css;
        lqColorCtx.fillRect(0, 0, 1, 1);
        const d = lqColorCtx.getImageData(0, 0, 1, 1).data;
        out = [d[0] / 255, d[1] / 255, d[2] / 255, d[3] / 255];
    } catch (_) {}
    if (lqColorCache.size > 40) lqColorCache.clear();
    lqColorCache.set(css, out);
    return out;
}
// Reads what the sheet and the canvas need so the body looks like the card and the bar it joins. Done once per toast, before
// the card's own surface steps aside.
function lqLiqPrepare(t, src) {
    if (!lqLiqInit() || !lqToastLayer) return false;
    if (t._ca) return true;
    try {
        const cs = getComputedStyle(t.el, '::before');
        const ca = lqColor(cs.backgroundColor).slice();
        const op = parseFloat(cs.opacity);
        if (!isNaN(op)) ca[3] *= op;                               // glass: the fill is only a thin tint
        let cb = lqColor(src.bg);
        if (cb[3] < 0.02 || (src.kind !== 'float' && cb[3] < 0.5)) cb = ca;       // a bar (or a glass / see-through bubble: the plain Material bubble is only white at 20%) with no fill of its own: the card's colour, so the neck is one colour from the card into the bubble
        const probe = document.createElement('span');
        probe.style.cssText = 'position:absolute;visibility:hidden;color:var(--bdr)';
        t.el.appendChild(probe);
        const rc = lqColor(getComputedStyle(probe).color);
        probe.remove();
        // the same blur and saturation as the card itself
        const cst = getComputedStyle(t.el);
        const bf = (cst.backdropFilter || cst.webkitBackdropFilter || '').trim();
        t._bf = bf && bf !== 'none' ? bf : '';
        // glass: the card's filter holds the toast's displacement filter (sized for the card alone). The body gets its own copy
        // (made when the sheet is made) that follows the card inside the sheet, so the picture behind is bent the whole time it moves.
        const fm = /url\((["']?)#lqf-toast\1\)/.exec(t._bf);
        t._bfT = fm ? t._bf.replace(fm[0], 'url(#@FID@)') : '';
        t._glass = document.documentElement.classList.contains('lq-glass-on');
        t._gx = lqGxParams();
        t._ca = ca; t._cb = cb; t._ring = [rc[0], rc[1], rc[2], Math.max(rc[3], 0.2)];
        return true;
    } catch (_) { return false; }
}
function lqLiqRelease(t) {
    LQ_LIQ.bodies.delete(t);
    t._gOff = false; t._geo = null; t._pathD = null; t._bgS = null;      // a new sheet starts from nothing: glass on, nothing written yet
    if (t._sheet) { t._sheet.remove(); t._sheet = null; }
    if (t._tint) { t._tint.remove(); t._tint = null; }
    if (t._halo) { t._halo.remove(); t._halo = null; }
    lqNavFillOut(t);
    if (t._fid) { lqLiqFilterGive(t._fid); t._fid = null; }          // kept for the next toast (already built and decoded), not thrown away
    if (t.el) t.el.classList.remove('lq-liq');
    t._fHold = undefined; t._nHold = null; t._gc0 = undefined;
    if (LQ_LIQ.ok && !LQ_LIQ.raf) LQ_LIQ.raf = requestAnimationFrame(lqLiqRender);
    lqToastOverSync();
}
// ── How the liquid splits (read off the reference) ──────────────────────────────────────────────────────────────────────────
// One piece of liquid does not let go by fading: the bridge between the two pieces thins slowly at first and then very fast
// (its width goes with the square root of the time left before it breaks), it breaks at a set length, and the two torn ends
// run back into their pieces (a short drip on the card runs back up). The card itself is pulled out on a spring that goes a
// little past rest and settles, so the piece has weight. Everything is a function of the card's position, so it works the
// same for a card that is let go of at any point.
const LQ_FLUID = {
    zeta: 0.68, omega: 9,     // spring of the card coming out: damping ratio (< 1 = a little past rest) and speed (rad/s); zeta is only the fallback
    overshootPx: 4.5,         // how far past rest it goes, in px, whatever the distance it travels (a card coming from under the screen has a much longer way than one from the bar)
    breakFrac: 0.4,            // the bridge breaks this share of the way (from the card's resting height back toward the bar) BEFORE the card reaches rest, so the neck, its gradient and the hand-over to the card's own glass are all done by the time the spring goes past rest
    tailNarrowMs: 360,         // after the neck has let go the fill (by then only along the bottom edge) narrows from the sides toward the middle
    tailFadeMs: 560,           // then it fades out slowly. It is on the clock, not on the card's position: the card is long at rest by then
    handoffMs: 170,            // the hand-over to the card's own glass (after the neck has let go) takes this long
    exp: 0.35,                 // how it thins: width ~ (1 - gap / breakGap) ^ exp (below 1: it stays wide, then goes fast)
    width: 0.2,                // half width of the bridge where it starts, as a share of the card's width
    thread: 1.4,               // half width of the thread just before it breaks (px)
    recoilMs: 90,              // how long the torn ends take to run back into their pieces
    recoilLen: 5               // how long those stubs are when the bridge breaks (px): short, so no hook is left standing
};
// The tail of the fill, after the card has come out of the bar. The fill is the whole card as the card leaves the bar and shrinks with the
// distance (in the sheet, see cover) down to the setting's look along the bottom edge by the time the neck lets go. From there the card's own
// gradient layer (.lq-grad, under the card's content), which has that same look, takes over and, on its own clock: narrows from the sides
// toward the middle of the bottom edge, fades out slowly, and is gone. After it the card at rest has no gradient. It runs on its own, past the end of the move; a new move of the card (lqToastRun) stops it.
function lqGradTailStop(t) {
    const T = t._gTail;
    if (T && T.raf) cancelAnimationFrame(T.raf);
    t._gTail = null;
    const gl = t._gradEl;
    if (gl) { gl.style.background = ''; gl.style.opacity = ''; gl.style.webkitMaskImage = gl.style.maskImage = ''; }
}
function lqGradTailStart(t) {
    const gl = t._gradEl || (t._gradEl = t.el.querySelector('.lq-grad'));
    if (!gl || !lqGradOn()) return;
    lqGradTailStop(t);
    // the layer starts from the look the sheet ended on (small), not from the setting's full reach
    const L = t._gLast;
    if (!L) return;      // nothing was drawn on the last frame (the card is at or past rest, e.g. in the overshoot): no tail. Without this the CSS default (a full, solid band) flashed.
    gl.style.background = `radial-gradient(ellipse ${L.rx.toFixed(1)}px ${L.ry.toFixed(1)}px at ${L.cxl.toFixed(1)}px 100%,${L.gst.map(([tt, al]) => `${lqSurfGradColor(al * L.amp)} ${(tt * 100).toFixed(1)}%`).join(',')},${lqSurfGradColor(L.gst[L.gst.length - 1][1] * L.amp)} 100%)`;
    const T = { t0: performance.now(), raf: 0 };
    t._gTail = T;
    const F = LQ_FLUID, B = F.tailNarrowMs, C = F.tailFadeMs;
    const step = now => {
        T.raf = 0;
        if (t._gTail !== T) return;
        if (t._dead || !t.el.isConnected) { lqGradTailStop(t); return; }
        const e = (now - T.t0) / LQ_SLOW;
        if (e >= B + C) { lqGradTailStop(t); return; }
        // the layer's own background is the setting's look along the bottom edge (--lq-grad-up), which is where the fill has got to by now
        const pB = lqSmooth(e / B), pC = lqSmooth((e - B) / C);
        // in: from the sides toward the middle, with soft ends
        let mask = '';
        if (pB > 0.001) {
            const hw = lqLerp(50, 7, pB), soft = 22;
            mask = `linear-gradient(90deg, transparent ${(50 - hw - soft).toFixed(1)}%, #000 ${(50 - hw).toFixed(1)}%, #000 ${(50 + hw).toFixed(1)}%, transparent ${(50 + hw + soft).toFixed(1)}%)`;
        }
        gl.style.webkitMaskImage = gl.style.maskImage = mask;
        // out
        gl.style.opacity = (1 - pC).toFixed(3);
        T.raf = requestAnimationFrame(step);
    };
    gl.style.opacity = '1';
    T.raf = requestAnimationFrame(step);
}
// 0 -> 1 on an underdamped spring, time in seconds
function lqSpringU(tt, zeta) {
    const z = zeta || LQ_FLUID.zeta, w = LQ_FLUID.omega, wd = w * Math.sqrt(1 - z * z), e = Math.exp(-z * w * tt);
    return 1 - e * (Math.cos(wd * tt) + (z * w / wd) * Math.sin(wd * tt));
}
// The bridge of a card coming out of its bar: `st` remembers whether it has broken (it never forms again), `tt` is the time.
function lqNeckIn(g, p, st, tt) {
    const R = Math.max(10, (g.top0 === undefined ? g.top : g.top0) - g.ty), Gb = R * (1 - LQ_FLUID.breakFrac);
    const gap = g.top - p.yb, rsMax = LQ_FLUID.width * Math.min(p.cwv, 2 * g.fh);
    if (!st.snapped) {
        const x = lqClamp(gap / Gb, 0, 1);
        const rs = (LQ_FLUID.thread + (rsMax - LQ_FLUID.thread) * Math.pow(1 - x, LQ_FLUID.exp)) * lqSmooth(gap / 6);   // grows from nothing as the card leaves the bar, ends as a thread
        if (x >= 1) { st.snapped = true; st.ts = tt; st.at = p.dx; }
        else return { s: rs > 0.05 ? { xt: p.dx, xb: g.dx, yt: p.yb - 5, y2: g.top + 5, rs } : null, alive: rs / Math.max(rsMax, 1), x };
    }
    const a = lqSmooth((tt - st.ts) * 1000 / LQ_FLUID.recoilMs);
    if (a >= 1) return { s: null, alive: 0, held: true, x: 1 };
    const L = LQ_FLUID.recoilLen * (1 - a);                                            // a drip hanging from the card, running back up
    const Lb = LQ_FLUID.recoilLen * 0.8 * (1 - a), yBar = g.top + 5;                  // and a short stub standing on the bar, sinking back into it
    return {
        held: true, x: 1,
        s: { xt: p.dx, xb: p.dx, yt: p.yb - 5, y2: p.yb + L, rs: LQ_FLUID.thread * Math.sqrt(1 - a) },      // the torn ends start as wide as the thread was and thin to nothing: no hook is left
        s2: g.kind === 'bubble' ? null : { xt: g.dx, xb: g.dx, yt: yBar - Lb - 2, y2: yBar, rs: LQ_FLUID.thread * 1.2 * Math.sqrt(1 - a) },      // no stub on the round Material bubble: it only stood there as a solid foot
        alive: 0.4 * (1 - a)
    };
}
// u = 0 the card at rest, u = 1 it has gone into the bar, u < 0 pulled past rest while the bridge still holds it.
// Going in: the card narrows a little to the width of the bar's flat top, comes down to it, and sinks into it. Nothing is
// faded, and the part below the bar's top edge is simply not drawn: the card never shows behind or under the bar.
// Coming out is the same motion backwards.
function lqToastGeo(t, src) {
    const el = t.el, w = el.offsetWidth || 312, h = LQ_TOAST_H;
    const R = parseFloat(getComputedStyle(el).borderTopLeftRadius) || 26;
    const ty = parseFloat(el.style.getPropertyValue('--ty')) || 0;
    const lr = lqToastLayer.getBoundingClientRect();
    const top = src.cy - src.h / 2 - lr.top, kind = src.kind, fl = kind === 'float';
    const cut = fl ? 1 : kind === 'bubble' ? 5 : 3;      // how far inside the piece's top edge the card is cut off
    const F = fl ? 14 : 8;                               // size of the meniscus where the card goes in
    let fh;                                              // half of the flat top the card can stand on
    if (fl) fh = Math.max(24, src.w / 2 - src.r * 0.7);
    else if (kind === 'bubble') { const rb = src.w / 2, d = cut + 1.5; fh = Math.max(8, Math.sqrt(Math.max(0, 2 * rb * d - d * d))); }
    else fh = Math.max(14, src.w * 0.46);
    const bw = Math.max(fl ? 60 : 22, Math.min(w, 2 * (fh - F) + (fl ? 0 : 4)));
    const bh = fl ? h * 0.92 : kind === 'bubble' ? 30 : 20;
    return {
        kind, w, h, R, ty, top, fh, F, cut, bw, bh, dx: src.dx || 0, span: Math.max(50, (top - ty) + h + cut),
        by: src.cy - lr.top, bhw: src.w / 2, bhh: src.h / 2, br: src.r || 0, kf: fl ? 28 : 16,
        top0: top, bhw0: src.w / 2, bhh0: src.h / 2, br0: src.r || 0      // as it was when the toast started (the live numbers below move with the nav)
    };
}
// The piece the card is joined to (bar / bubble / indicator) is not still: while a toast leaves it, the bar is pressed in and
// lets go, the bubble squeezes, and the user can switch tabs. The body of liquid is drawn from this piece, so its numbers are
// read again on every frame (a rect read, no style reads): the neck stays on the nav's top edge, its foot is as wide as the nav
// is right now, and the card's cut line moves with it. Only what depends on the nav is replaced; the toast's own numbers stay.
function lqGeoLive(g) {
    if (!g || !lqToastLayer) return g;
    const pill = document.getElementById('navPill');
    if (!pill) return g;
    let el = pill;
    if (g.kind !== 'float') { const lens = pill.querySelector('.nav-lens'); if (lens) el = lens; }
    const r = el.getBoundingClientRect();
    if (!(r.width > 1 && r.height > 1)) return g;
    const lr = lqToastLayer.getBoundingClientRect();
    const hw = r.width / 2, hh = r.height / 2, top = r.top - lr.top;
    const sc = g.bhh0 > 0 ? hh / g.bhh0 : 1;
    return Object.assign({}, g, {
        top, by: top + hh, bhw: hw, bhh: hh,
        br: Math.min((g.br0 || 0) * sc, hw, hh),
        dx: r.left + hw - (lr.left + lr.width / 2)
    });
}
const LQ_SHRINK_FROM = 0.12;
// The whole body is scaled (for its text) and the corner radius is counter-scaled; k = stretch along the motion (volume is kept).
function lqToastBodyPose(g, u, k = 0) {
    const uc = lqClamp(u, 0, 1), fl = g.kind === 'float';
    // The card is exactly its real size until the neck has formed (the neck is complete by u = .12), and only then shrinks toward the piece it
    // goes into (it is the bar's size from u = .55 on). It used to start shrinking from the first px, so by the time the neck was there it
    // was already a few px smaller than the card at rest.
    const t1 = lqSmooth((uc - LQ_SHRINK_FROM) / (0.55 - LQ_SHRINK_FROM));
    const a = lqSmooth(uc / (fl ? 0.45 : 0.55)), b = lqSmooth((uc - (fl ? 0.38 : 0.55)) / (fl ? 0.62 : 0.45));
    const cw = lqLerp(g.w, g.bw, t1), ch = lqLerp(g.h, g.bh, t1);
    const cwv = cw / Math.pow(1 + k, 0.7), chv = ch * (1 + k);
    // float: the bottom edge comes down to the bar, then sinks until the card is under the cut.
    // bubble / indicator: ONE straight move to the end pose (the card is entirely under the cut). With the two phases above the card
    // reached the bubble's top, stood there for a moment (the sink starts with an ease-in) and only then went down; the exit spring
    // already eases the whole trip, so no second ease is put on it here. Coming out is the same path backwards.
    let yb = fl ? lqLerp(g.ty, g.top, a) + (chv + g.cut) * b : lqLerp(g.ty, g.top + chv + g.cut, Math.min(1, uc / 0.88));      // under the cut by u = .88: the last bit of the spring is slow, the card must not crawl into the bubble on it
    if (u < 0) yb += u * g.span;                               // past rest (the spring of a card coming out): 1 : 1
    const cy = yb - chv / 2, cutY = g.top + g.cut;
    const dx = g.dx * lqSmooth(uc / 0.55);
    const sx = Math.max(cwv / g.w, 0.001), sy = Math.max(chv / g.h, 0.001);
    const r = lqLerp(g.R, Math.min(g.R, chv / 2, cwv / 2), t1);
    const bi = g.h / 2 - (cutY - cy) / sy;                     // local px to cut off at the bottom
    return {
        tf: `translate3d(${dx.toFixed(2)}px,${(cy + g.h / 2).toFixed(2)}px,0) scale(${sx.toFixed(4)},${sy.toFixed(4)})`,
        br: `${(r / sx).toFixed(2)}px / ${(r / sy).toFixed(2)}px`,
        clip: bi > 0.5 ? `inset(-40px -40px ${bi.toFixed(2)}px -40px)` : '',
        co: fl ? 1 - lqSmooth((uc - 0.3) / 0.25) : 1 - lqSmooth(uc / 0.2),          // the text gets out of the way before the card sinks
        yb, cy, cwv, chv, dx, sx, sy, r, u: uc, T: cy + g.h / 2,
        vis: Math.max(0, Math.min(chv, cutY - (cy - chv / 2)))                       // how much of the card is still above the cut
    };
}
// What the canvas draws for a pose. The bridge is a short wide box between the card's bottom edge and the bar's top edge;
// its width follows a volume law (it thins as the two are pulled apart). pres = how far it has formed (0 .. 1).
// Every number here is a continuous function of the pose: the bridge grows from zero width and goes back to zero width, the
// blend radius closes as the card sinks into the bar, so there is no frame where something appears or disappears.
function lqToastLiqBody(t, g, p, pres, fade = 0, neck = null) {
    const gap = g.top - p.yb;                              // the card's bottom edge to the bar's top edge (< 0: it has gone into the bar)
    const sink = lqSmooth(((p.u || 0) - 0.8) / 0.2);       // over the last fifth of the way in the liquid lets go of the card
    // the card rests only a few px above the bar, so the neck has to let go by itself as the card settles (not by being pulled
    // past rest and snapped, which is the hop the old spring made): the closer to rest, the thinner it is, and it is gone at rest
    const hold = p.u === undefined ? 1 : lqSmooth((p.u - 0.01) / 0.12);
    const k = g.kf * (1 - sink) * (neck ? lqSmooth(neck.alive * 2.5) : 0.2 + 0.8 * hold);       // after the bridge breaks the blend closes with it: no wings left at the card's corners
    let s = null;
    if (neck) s = neck.s;
    else if (gap > 0 && pres > 0) {
        const len0 = Math.max(10, (g.top0 === undefined ? g.top : g.top0) - g.ty);
        const thin = 1 - lqSmooth((gap - Math.max(16, len0)) / 30);
        let rs = (LQ_FLUID.width * 1.3) * Math.min(p.cwv, 2 * g.fh) * pres * Math.min(1.15, Math.sqrt(len0 / Math.max(gap, len0 * 0.6))) * thin * lqSmooth(gap / 6) * hold;
        rs *= lqSmooth(rs / 7);                          // a hair of a neck fades out instead of being cut off
        if (rs > 0.05) s = { xt: p.dx, xb: g.dx, yt: p.yb - 5, y2: g.top + 5, rs };
    }
    // The liquid layer is drawn OVER the bar while a body exists (lqToastOverSync), so whatever of the neck goes below the bar's top edge is
    // painted on the bar. With a solid neck that read as the neck lying on top of the bar. So the neck stops at the bar's top edge (a hair
    // of overlap only, so no seam) and the bar's own fill (lqLiqHalo) carries the colour on from there. No feather: nothing runs into the bar.
    const feather = 0;
    // how close the card and the bar are to each other: nothing at rest, building up as the card goes toward the bar (or leaves it),
    // deepest while they overlap, and closing again over the last fifth of the way in (sink), so nothing pops when the body lets go
    const nearK = gap <= 0 ? 1 : 1 - lqSmooth(gap / LQ_CONTACT_NEAR);
    // the fill: how far the card has travelled from where it rests to the bar's top edge, from the very start of the pull (0) to touching (1)
    const trav = g.ty === undefined ? lqClamp(+p.u || 0, 0, 1) : lqClamp((p.yb - g.ty) / Math.max(1, g.top - g.ty), 0, 1);
    const fill = lqSmooth(trav / LQ_COVER_END);
    if (neck && trav < 1 && t._gc0 === undefined) t._gc0 = performance.now();      // the card has left the bar's top edge: its fill starts to grow
    const holeK = lqSmooth((fill - LQ_HOLE_FROM) / (1 - LQ_HOLE_FROM));        // the hole comes in only over the second half of the fill
    const prox = holeK * nearK * (p.u === undefined ? 1 : lqSmooth(p.u / LQ_CONTACT_RAMP)) * (1 - sink) * lqClamp(+pres || 0, 0, 1);
    // how far the two have come together (0 = apart, 1 = touching or overlapping): the holes in the glass close over the last ~18 px
    // of the way, so when the card and the bar meet there is no hole left in the middle of them, and the merge light rises as they do
    const close = lqClamp(1 - lqSmooth((gap - 2) / 18), 0, 1);
    // the merge light: on for as long as the two are together (touching, pushed into the bar, pulled back out), whatever the neck or the
    // contact are doing; it only goes as the card is absorbed (the last 15% of the way in), and it needs the body to have formed (pres)
    const mg = close * lqClamp(+pres || 0, 0, 1) * (1 - lqSmooth(((p.u || 0) - 0.85) / 0.15));
    // how much the two are together for the joint's fill: it does not drop with the sink (the card is still there while it goes into the
    // bar) and it is not cut at the end either: it is held to the last frame and then let go in time (see lqNavFillOut), so it never pops
    // The Material bubble is small and the card shrinks to its size on the way (by u = .55, the same moment it reaches the bubble), so with the
    // bar's numbers its fill only came when the card was already as small as the bubble. For the bubble the fill is therefore built from
    // farther away and over the first fifth of the way, so it is full while the card is still big.
    const bubK = g.kind === 'bubble', rampF = bubK ? 0.2 : LQ_CONTACT_RAMP;
    const prox0 = nearK * (p.u === undefined ? 1 : lqSmooth(p.u / rampF)) * lqClamp(+pres || 0, 0, 1);
    // the moment the card and the bar touch (the neck is gone, it is only two edges now) until the card has gone into the bar: 0 apart, 1 touching
    const closeF = bubK ? lqClamp(1 - lqSmooth((gap - 2) / 40), 0, 1) : close;       // how close, for the fill (the bubble's reaches farther)
    const touch = closeF * (p.u === undefined ? 1 : lqSmooth(p.u / rampF)) * lqClamp(+pres || 0, 0, 1);
    // how solid the WHOLE card is: only a function of how far its bottom edge has actually gone into the bar (gap < 0), never of the
    // neck or of how long the drag has been going. It starts a hair before the edges meet and is complete a few px inside, so the
    // glass turns into the solid fill while the two are joined, and turns back into glass the same way as the card leaves the bar.
    const cs = lqSmooth((6 - gap) / 22) * lqClamp(+pres || 0, 0, 1);
    return {
        prox, prox0, touch, close, mg, cs, fill,
        a: [p.dx, p.cy, p.cwv / 2, p.chv / 2, p.r], b: [g.dx, g.by, g.bhw, g.bhh, g.br], s, s2: neck ? neck.s2 || null : null, k, kcb: k * (1 - lqSmooth(gap / 8)),
        nk: g.kind, cut: g.kind === 'float' ? g.top + 0.8 : g.kind === 'bubble' ? g.top + 1.5 : g.top - 0.5, top: g.top, ext: g.kind === 'float' ? 2.2 : 0, feather,      // Indicator bar: the neck ends right at the indicator's top edge (cut 0.5px above it, no carry-on into it): it touches the line and does not lie over it
        held: !!(neck && neck.held), grow: neck ? 0 : undefined, away: neck ? lqSmooth(neck.x === undefined ? 1 : neck.x) : undefined, awayRaw: neck ? lqClamp(neck.x === undefined ? 1 : neck.x, 0, 1) : undefined, ca: t._ca, cb: t._cb, ring: neck ? [t._ring[0], t._ring[1], t._ring[2], t._ring[3] * lqSmooth(neck.alive * 3)] : t._ring, gap, gx: t._gx, glass: !!t._glass, glow: 0, fade
    };
}
// The way into the bar is a critically damped spring (not a timed curve): u(t) runs from u0 to 1 with the speed the finger had
// when it let go (v0, in u per second), so the card keeps its momentum, and it never passes 1: nothing bounces.
function lqExitSpring(u0, v0) {
    const w = 11, y0 = u0 - 1;
    const v = Math.min(v0, 0.92 * w * (1 - u0));          // never faster than the spring can take without overshooting
    const B = v + w * y0;
    return tt => {
        const x = 1 + (y0 + B * tt) * Math.exp(-w * tt);
        return tt > 0.6 ? lqLerp(x, 1, lqSmooth((tt - 0.6) / 0.25)) : x;       // the small leftover lands exactly on 1
    };
}
// Plays the card and the liquid together, frame by frame from one spring, so they cannot drift apart.
//   'in'   coming out of the bar            'out'  going back into it (from rest or from where the finger let go)
//   'back' released before the point of no return: the card goes home on the spring
function lqToastRun(t, g, src, mode, o = {}) {
    const el = t.el;
    let ms, X;
    if (mode === 'in') {
        const R = Math.max(10, (g.top0 === undefined ? g.top : g.top0) - g.ty), ln = Math.log(lqClamp(LQ_FLUID.overshootPx / R, 0.012, 0.06));
        var zIn = -ln / Math.sqrt(Math.PI * Math.PI + ln * ln);        // the damping that gives that overshoot on this distance
        ms = 720; X = tt => { const q = 1 - lqSpringU(tt, zIn); return tt > 0.58 ? lqLerp(q, 0, lqSmooth((tt - 0.58) / 0.14)) : q; }; }       // the small leftover lands on rest
    else if (mode === 'out') {
        const sp = lqExitSpring(o.u0 || 0, lqClamp(o.v0 || 0, -2, 7));
        let i = 1;
        while (i < 60 && sp(i / 60) < 0.985) i++;
        ms = Math.max(200, Math.round(i / 60 * 1000));
        X = tt => sp(tt);
    } else { ms = 640; X = tt => { const q = (o.u0 || 0) * (1 - lqSpringU(tt)); return tt > 0.5 ? lqLerp(q, 0, lqSmooth((tt - 0.5) / 0.14)) : q; }; }       // let go early: back home with a little give
    let raf = 0, done = false, fadeNow = 0;
    const nst = { snapped: false, ts: 0, at: 0 };
    let tailOn = false;
    lqGradTailStop(t);
    const liq = lqLiqPrepare(t, src);
    el.style.transition = 'none';                 // every frame is set here: a css transition would fight it
    el.classList.add('lq-txt-drv');
    const draw = tt => {
        const tau = Math.min(1, tt * 1000 / ms);
        const u = mode === 'out' && tau >= 1 ? 1 : X(tt);
        const e = 1 / 120, vel = (X(Math.min(tt + e, ms / 1000)) - X(Math.max(tt - e, 0))) / (2 * e);   // u per second
        let k = 0;
        if (mode === 'out') k = 0.12 * lqClamp(vel / 6, 0, 1) * lqSmooth(tt / 0.06);                  // a little longer while it is fast
        else if (mode === 'in') k = vel < 0 ? 0.16 * lqClamp(-vel / 3.3, 0, 1) * (1 - lqSmooth((tau - 0.5) / 0.5)) : -0.05 * lqClamp(vel / 3, 0, 1);   // stretched while it leaves, a little squashed as it settles back
        const gv = lqGeoLive(g);                       // the nav as it is on this frame (pressed, squeezed, moved)
        const p = lqToastBodyPose(gv, u, k);
        el.style.transform = p.tf;
        el.style.opacity = '1';
        el.style.borderRadius = p.br;
        el.style.clipPath = p.clip;
        // the text is a part of the liquid: it blurs out as the card is drawn into the bar and sharpens as the card comes away from it
        const rv = mode === 'out' ? 1 - lqSmooth(u / 0.38) : lqSmooth((0.62 - u) / 0.5);
        el.style.setProperty('--co', Math.pow(lqClamp(rv, 0, 1), 1.15).toFixed(3));
        if (!liq) return;
        let pres = 1;
        if (mode === 'out') pres = lqLerp(o.pres0 || 0, 1, lqSmooth(tau / 0.25));
        else if (mode === 'back') pres = (o.pres0 === undefined ? 1 : o.pres0) * (1 - lqSmooth(tau / 0.3));
        // the last stretch of coming out (and of going home): the card's own glass takes over from the body
        // coming out: only once the bridge has broken (the liquid has to be seen while it is stretched); going home: by position
        const neck = mode === 'in' ? lqNeckIn(gv, p, nst, tt) : null;
        if (mode === 'in') { if (nst.snapped) fadeNow = Math.max(fadeNow, lqSmooth((tt - nst.ts) * 1000 / LQ_FLUID.handoffMs)); }      // once the neck has let go: the hand-over to the card's own glass takes handoffMs, a smooth tail with nothing popping in it
        else if (mode === 'back') fadeNow = Math.max(fadeNow, lqSmooth((0.32 - u) / 0.27));
        if (mode === 'in' && fadeNow > 0.001 && !tailOn) { tailOn = true; lqGradTailStart(t); }      // the fill is the whole card and the neck has let go: the tail begins
        lqLiqSet(t, lqToastLiqBody(t, gv, p, pres, mode === 'out' ? 0 : fadeNow, neck));
    };
    const end = (finished, cancelled) => {
        if (mode !== 'out') {         // back at its place: the css rest pose takes over again
            el.style.transform = ''; el.style.opacity = ''; el.style.borderRadius = ''; el.style.clipPath = '';
            el.style.removeProperty('--co');
            el.classList.remove('lq-txt-drv');
            el.style.transition = '';
            lqLiqRelease(t);
        }
        if (finished && h.onfinish) h.onfinish();
        if (cancelled && h.oncancel) h.oncancel();
    };
    const h = {
        ms, liq, onfinish: null, oncancel: null,
        finish() { if (done) return; done = true; if (raf) cancelAnimationFrame(raf); draw(ms / 1000); end(true, false); },
        cancel() { if (done) return; done = true; if (raf) cancelAnimationFrame(raf); end(false, true); }
    };
    const t0 = performance.now();
    const step = now => {
        raf = 0;
        if (done) return;
        const tt = (now - t0) / 1000 / LQ_SLOW;
        if (tt * 1000 >= ms) { h.finish(); return; }
        draw(tt);
        raf = requestAnimationFrame(step);
    };
    draw(0);
    raf = requestAnimationFrame(step);
    return h;
}
let lqToastLeavingN = 0;
function lqToastOverSync() {
    if (!lqToastLayer) return;
    // the layer is over the bar only while the liquid canvas has something on it (the canvas draws over the bar's top edge)
    lqToastLayer.classList.toggle('is-over', LQ_LIQ.bodies.size > 0);
}
// the fill goes from the colour of the bubble / line to the colour of the card (and back)
function lqToastFillMorph(el, from, ms, back) {
    try {
        const to = getComputedStyle(el, '::before').backgroundColor;
        if (!from || !to) return;
        const frames = back ? [{ backgroundColor: to, offset: 0 }, { backgroundColor: to, offset: 0.5 }, { backgroundColor: from, offset: 1 }]
                            : [{ backgroundColor: from, offset: 0 }, { backgroundColor: to, offset: 0.5 }, { backgroundColor: to, offset: 1 }];
        el.animate(frames, { duration: ms, easing: 'ease-out', fill: back ? 'forwards' : 'none', pseudoElement: '::before' });
    } catch (_) {}
}
// A fill animation that is held (paused) so a swipe can scrub it: bubble / line colour <-> card colour
function lqToastFillScrub(el, from) {
    try {
        const to = getComputedStyle(el, '::before').backgroundColor;
        if (!from || !to) return null;
        const a = el.animate([{ backgroundColor: to, offset: 0 }, { backgroundColor: to, offset: 0.5 }, { backgroundColor: from, offset: 1 }],
            { duration: 1000, easing: 'ease-out', fill: 'both', pseudoElement: '::before' });
        a.pause(); a.currentTime = 0;
        return a;
    } catch (_) { return null; }
}

// When a result lands, a soft ring of light leaves the icon and passes over the
// card, and the card's edge catches it as it goes by. Opacity + transform only.
function lqToastGlow(t) {
    const el = t.el;
    el.classList.remove('is-glow');
    void el.offsetWidth;
    el.classList.add('is-glow');
}

function lqToastDismiss(t, delay = 0, swiped = false, drag = null, quiet = false) {
    const i = lqToasts.indexOf(t);
    if (i < 0) return;
    // A card that is not on screen (the ones piled behind the front three, or one pushed out by a newer toast) has nothing to give
    // back to the nav: it just fades where it is. Before, it flew into the bar and made the bar blur a second time for one apply.
    const hiddenNow = !swiped && lqToasts.length >= 3 && !lqToastExpanded && i >= 3;
    if (hiddenNow) quiet = true;
    lqToasts.splice(i, 1);
    clearTimeout(t.timer);
    t.timer = 0;
    if (!lqToastBulk) lqToastLayout(true);
    const leave = () => {
        if (t.anim) { t.anim.onfinish = null; t.anim.cancel(); t.anim = null; }
        if (quiet) {
            t._dead = true;
            if (t.exitRun) { t.exitRun.cancel(); t.exitRun = null; }
            lqLiqRelease(t);
            t.el.style.pointerEvents = 'none';
            t.el.style.transition = 'opacity .18s ease-out';
            t.el.style.opacity = '0';
            setTimeout(() => { t.el.remove(); lqToastOverSync(); }, 200);
            return;
        }
        // shrinks back into the nav, wherever it was (resting or mid-swipe).
        // A swiped card carries on from the exact pose and speed the finger left it in, along the same path the timed exit takes.
        const src = (drag && drag.src) || lqToastSource();
        const dist = drag ? drag.limit : lqToastNavDistance(t);
        t.el.style.setProperty('--nav-d', `${dist}px`);
        if (src && src.kind !== 'float') {
            // goes back into the bubble / the selected tab: sideways too, and shrinks to its size
            const sh = lqToastNavShape(t.el);
            t.el.style.setProperty('--nav-x', `${src.dx}px`);
            t.el.style.setProperty('--nav-sx', String(Math.min(sh.sx, 0.5)));
            t.el.style.setProperty('--nav-sy', String(Math.min(sh.sy, 0.5)));
        }
        t.el.classList.remove('is-settling', 'is-entering');
        // a swipe that was scrubbed through the morph needs no css exit; only the plain fallback keeps the old one
        const morphOk = !!src && !lqReduced() && !!t.el.animate && (!swiped || !!(drag && drag.morph));
        t.el.classList.toggle('is-swiped', swiped && !morphOk);
        t.el.classList.add('is-leaving');
        let outMs = 0, held = false;
        if (morphOk) {
            try {
                const g = drag && drag.geo ? drag.geo : lqToastGeo(t, src);
                const run = lqToastRun(t, g, src, 'out', { u0: drag ? drag.u : 0, v0: drag ? drag.v : 0, pres0: drag ? drag.pres : 0 });
                outMs = run.ms;
                t.exitRun = run;
                t.dragOver = false;
                t.el.classList.add('is-morph');
                if (src.kind !== 'float' && !run.liq) {
                    if (drag && drag.fill) {
                        // the held fill carries on from where the finger left it
                        const a = drag.fill, u0 = drag.u;
                        a.currentTime = u0 * 1000;
                        a.updatePlaybackRate(Math.max(0.1, (1 - u0) * 1000 / outMs));
                        a.play();
                    } else lqToastFillMorph(t.el, src.bg, outMs, true);
                }
            } catch (_) {
                outMs = 0; t.el.classList.remove('is-morph');
            }
        }
        // the bar answers when the card reaches it (the exit ends exactly there)
        setTimeout(() => lqNavFeel('in'), outMs ? Math.round(outMs * ((lqNavGlassOn() || lqNavKind() === 'bubble') ? 0.6 : 0.9)) : (swiped ? 190 : 230));   // glass: the bar blurs a beat before the card lands
        setTimeout(() => { t._dead = true; if (t.exitRun) { t.exitRun.cancel(); t.exitRun = null; } t.el.remove(); lqLiqRelease(t); if (held) lqToastLeavingN = Math.max(0, lqToastLeavingN - 1); lqToastOverSync(); }, outMs ? outMs + 40 : (swiped ? 320 : 380));
    };
    if (delay > 0) setTimeout(leave, delay); else leave();
}
// `lead` is the toast that was swiped (it glides out on its own curve);
// the rest of a stack follows one after another.
function lqToastClearAll(lead, drag = null) {
    // Newest first = the front card (the one nearest the bar) goes first, then the next one behind it, and so on. Each card leaves from the
    // slot it is in: nothing is re-laid while they wait (before, every dismissal re-laid the rest, so the whole stack slid down onto the front
    // slot and the cards that had been farthest looked like the first to go).
    const all = lqToasts.slice();
    if (lqToastControls) lqToastControls.classList.remove('is-on');
    lqToastBulk = true;
    try { all.forEach((t, i) => lqToastDismiss(t, i * 60, t === lead, t === lead ? drag : null)); }
    finally { lqToastBulk = false; }
}

// A toast goes away with a short swipe down: past LQ_SWIPE_GO px while the finger is still down, or let go after LQ_SWIPE_REL px
// (LQ_SWIPE_FLICK px if it was a quick flick). It no longer has to be pulled all the way to the bar.
const LQ_SWIPE_GO = 40, LQ_SWIPE_REL = 22, LQ_SWIPE_FLICK = 10;
// Pushed toward the bar, the card stays the real toast (its own glass, rim and bend) for the first part of the way. Only past LQ_SWIPE_LIQ_IN
// (share of the way to the bar) does the liquid sheet take over, and it hands the card back below LQ_SWIPE_LIQ_OUT. The sheet is a different
// layer that never looks quite like the card (brighter, a smaller rim, no bend at the edge), so it is kept for where the liquid is needed.
const LQ_SWIPE_LIQ_IN = 0.02, LQ_SWIPE_LIQ_OUT = 0.01;
// What a stretch does to the glass bend (only with Liquid Glass on; its displacement map is baked for the card at rest and shimmers when
// the card is scaled):  'freeze' = the card is not scaled at all, it follows the finger with resistance in whole pixels and the bend stays
// exactly as it is at rest;  'off' = the card is scaled and the bend is left out until it has settled.
//  'snap' = the card is scaled, but its size and position are rounded to whole device pixels (its edges never sit on a half pixel) and its
//           corner radius is left alone, so the bend and the rim only ever change in whole pixel steps;
//  freeze's travel (px): the most the card moves with the finger, sideways / up-down.
const LQ_STRETCH_BEND = 'snap', LQ_STRETCH_PX_X = 18, LQ_STRETCH_PX_Y = 14;
function lqToastWire(t) {
    const el = t.el;
    let drag = null, raf = 0, pose = null;
    // pointermove only records the pose; one write per frame
    const apply = () => {
        raf = 0;
        if (!pose) return;
        el.style.transform = pose.tf;
        el.style.opacity = pose.op;
        el.style.borderRadius = pose.br || '';
        el.style.clipPath = pose.clip || '';
        el.style.setProperty('--co', pose.co);
        if (pose.fa) { try { pose.fa.currentTime = pose.fu * 1000; } catch (_) {} }
        if (pose.body) lqLiqSet(t, pose.body);
    };
    const write = p => { pose = p; if (!raf) raf = requestAnimationFrame(apply); };
    const flush = () => { if (raf) { cancelAnimationFrame(raf); raf = 0; } apply(); };
    // With Liquid Glass on, the card's glass holds a displacement filter whose map is baked for the card at rest. While the card is stretched
    // the map no longer fits it, and the bend around the edge (and the border with it) shimmers as the finger moves. So for the length of the
    // stretch the card only keeps its blur and saturation (the filter without the bend) and the bend comes back once it has settled.
    const plainBf = () => {
        if (el._bfPlain) return;
        const cs = getComputedStyle(el), bf = (cs.backdropFilter || cs.webkitBackdropFilter || '').trim();
        if (!/url\(/.test(bf)) return;
        const p = bf.replace(/\s*url\([^)]*\)/g, '').trim();
        if (!p || p === 'none') return;
        el._bfPlain = true;
        el.style.backdropFilter = p; el.style.webkitBackdropFilter = p;
    };
    const restoreBf = () => {
        if (!el._bfPlain) return;
        el._bfPlain = false;
        el.style.backdropFilter = ''; el.style.webkitBackdropFilter = '';
    };
    // scale + position of the card with every edge on a whole device pixel (see LQ_STRETCH_BEND 'snap'). ox / oy: where the card's centre is
    // from where it rests, sx / sy: its scale about the centre.
    const snapTf = (sx, sy, ox, oy, ty) => {
        const dpr = window.devicePixelRatio || 1, W0 = el.offsetWidth || 312, H0 = el.offsetHeight || 64;
        const fit = (s0, o0, L0) => {
            // each edge is rounded on its own to a whole device pixel (an edge that should stay put then stays exactly put)
            const L = Math.max(1, Math.round(L0 * dpr)), half = (s0 - 1) * L0 / 2;
            const dT = Math.round((o0 - half) * dpr), dB = Math.round((o0 + half) * dpr), q = Math.max(1, L + dB - dT);
            return [q / L, (dT + dB) / 2 / dpr];
        };
        const [fx, gx] = fit(sx, ox, W0), [fy, gy] = fit(sy, oy, H0);
        return `translate3d(${gx.toFixed(3)}px,${(Math.round(ty * dpr) / dpr + gy).toFixed(3)}px,0) scale(${fx.toFixed(5)},${fy.toFixed(5)})`;
    };
    // back from the liquid sheet to the real card (the finger came back, or the drag turned into a stretch)
    const liqDrop = () => {
        if (!drag || !drag.liqOn) return;
        drag.liqOn = false; drag.liq = false;
        lqLiqRelease(t);
    };
    const clearInline = () => { el.style.transform = ''; el.style.opacity = ''; el.style.borderRadius = ''; el.style.clipPath = ''; el.style.removeProperty('--co'); };
    const dismissFromDrag = d => {
        const stackedFront = el.dataset.stacked === '1';
        // finger speed at the moment of letting go, in u per second (a finger that had stopped has no speed to give)
        d.v = performance.now() - d.lt > 90 ? 0 : Math.max(0, d.v) * 1000 / Math.max(1, d.limit);
        flush();
        void el.offsetHeight;              // commit the drag pose so the exit continues from it
        clearInline();
        restoreBf();
        el.classList.remove('is-dragging');
        // the exit carries on from the progress the finger reached (d.u), along the path of the nav in use
        if (stackedFront) lqToastClearAll(t, d); else lqToastDismiss(t, 0, true, d);
        lqToasts.forEach(lqToastResume);
    };
    el.addEventListener('pointerdown', e => {
        if (e.button > 0 || el.classList.contains('is-behind')) return;
        if (t.anim) t.anim.finish();                       // still coming out: land it first
        const src = lqToastSource();
        // pushing the card toward the bar plays the same motion as the timed exit (the card joins the bar), not a plain slide
        const morph = !!src && !lqReduced() && !!el.animate;
        const g = morph ? lqToastGeo(t, src) : null;
        const limit = g ? g.span : lqToastNavDistance(t);
        drag = {
            id: e.pointerId, x0: e.clientX, y0: e.clientY, side: false, t0: performance.now(), dy: 0, moved: false, limit,
            src, morph, geo: g, liq: false, liqOn: false, w: el.offsetWidth || 312, h: el.offsetHeight || 56, R: parseFloat(getComputedStyle(el).borderTopLeftRadius) || 26,
            u: 0, pres: 0, fill: null, pose: null, v: 0, ly: e.clientY, lt: performance.now()
        };
        {   // a truncated line (title / text) under the finger can be dragged sideways to read the rest
            const hs = e.target.closest ? e.target.closest('.lq-toast-title, .lq-toast-text') : null;
            drag.hs = hs && hs.scrollWidth > hs.clientWidth + 1 ? { el: hs, x0: hs.scrollLeft, on: false, off: false } : null;
        }
        try { el.setPointerCapture(e.pointerId); } catch (_) {}
        el.classList.remove('is-settling');
        el.classList.add('is-dragging');
        lqToasts.forEach(lqToastPause);
    });
    el.addEventListener('pointermove', e => {
        if (!drag || e.pointerId !== drag.id) return;
        const raw = e.clientY - drag.y0;
        {   // the finger's speed (px/ms), smoothed: the card leaves with it
            const now = performance.now(), dtm = now - drag.lt;
            if (dtm > 0) { drag.v = 0.55 * ((e.clientY - drag.ly) / dtm) + 0.45 * drag.v; drag.ly = e.clientY; drag.lt = now; }
        }
        drag.dy = raw;
        const mvx = e.clientX - drag.x0;
        if (Math.abs(raw) > 6 || Math.abs(mvx) > 6) drag.moved = true;
        if (drag.hs && !drag.hs.off) {
            // mostly sideways from the start: the line scrolls and the card stays put (no stretch, no push); mostly vertical: the usual push
            if (!drag.hs.on && (Math.abs(mvx) > 6 || Math.abs(raw) > 6)) { if (Math.abs(mvx) > Math.abs(raw)) drag.hs.on = true; else drag.hs.off = true; }
            if (drag.hs.on) { drag.hs.el.scrollLeft = drag.hs.x0 - mvx; lqHsMark(drag.hs.el); return; }
        }
        const ty = parseFloat(el.style.getPropertyValue('--ty')) || 0;
        const limit = drag.limit;
        const rawX = e.clientX - drag.x0;
        if (drag.bend === undefined) drag.bend = /url\(/.test(getComputedStyle(el).backdropFilter || '');
        // a drag that starts out mostly sideways stays a fluid pull (it never becomes the push into the bar)
        if (!drag.side && raw < 14 && Math.abs(rawX) > Math.max(raw, 0) + 8) drag.side = true;
        // The card's surface goes over to the canvas only when it is pushed toward the bar (that is where the liquid joins it to the bar).
        // A stretch up or to the side stays on the card itself: the canvas redraws the rim and the sheet's outline every frame, which made
        // the border thin out, change shape and flicker while the finger moved; the card's own glass just scales.
        // (the sheet is switched on and off further down, by how far the card has been pushed)
        if (raw <= 0 || drag.side) {
            // pulled away from the bar (up) or off to the side: the card stretches a little toward the finger and the liquid holds on.
            // Kept short on purpose: it should read as fluid, not as rubber. No neck: that only exists on the way into the bar.
            // The card stays where it is and its far edge is held: the near edge follows the finger with a resistance that grows
            // (it eases in, then holds at a short limit). So it is a stretch toward the finger, not the card sliding after it.
            const cv = v => 1 - Math.exp(-Math.pow(Math.abs(v) / 110, 1.4));
            const cx = cv(rawX), cy2 = cv(raw);
            const ex = 0.06 * cx, ey = 0.14 * cy2;                       // how much longer it gets along each axis (fraction of its own size)
            const sx = 1 + ex - 0.35 * ey, sy = 1 + ey - 0.35 * ex;      // the other axis gives in a little (volume is roughly kept)
            const ox = (rawX < 0 ? -1 : 1) * ex * (drag.w || 312) / 2, oy = (raw < 0 ? -1 : 1) * ey * (drag.h || 56) / 2;   // far edge stays put
            drag.u = 0; drag.pose = null;
            drag.pres = 0;
            liqDrop();
            if (!drag.liq && drag.bend && LQ_STRETCH_BEND === 'freeze') {
                // no scale: whole-pixel travel toward the finger (the card is not resampled, so the bend does not move or shimmer)
                const px = Math.round((rawX < 0 ? -1 : 1) * LQ_STRETCH_PX_X * (1 - Math.exp(-Math.abs(rawX) / 60))), py = Math.round((raw < 0 ? -1 : 1) * LQ_STRETCH_PX_Y * (1 - Math.exp(-Math.abs(raw) / 46)));
                write({ tf: `translate3d(${px}px,${Math.round(ty) + py}px,0)`, op: '1', br: '', clip: '', co: '1', fa: null, fu: 0, body: null });
                return;
            }
            if (!drag.liq && drag.bend && LQ_STRETCH_BEND === 'off') plainBf();
            let body = null;
            if (drag.liq) {
                const g = lqGeoLive(drag.geo), chv = g.h * sy, cwv = g.w * sx, cy = ty - g.h / 2 + oy;
                body = lqToastLiqBody(t, g, { dx: ox, cy, cwv, chv, r: g.R, yb: cy + chv / 2 }, 0, false);
                body.s = null; body.s2 = null; body.k = 0; body.kcb = 0;
            }
            const rr = drag.R || 26;       // each corner is divided by its own scale, so it stays a quarter circle of the same size while the card stretches
            if (!drag.liq && drag.bend && LQ_STRETCH_BEND === 'snap') {
                write({ tf: snapTf(sx, sy, ox, oy, ty), op: '1', br: '', clip: '', co: '1', fa: null, fu: 0, body: null });
                return;
            }
            write({ tf: `translate3d(${ox.toFixed(2)}px,${(ty + oy).toFixed(2)}px,0) scale(${sx.toFixed(4)},${sy.toFixed(4)})`, op: '1', br: `${(rr / sx).toFixed(2)}px / ${(rr / sy).toFixed(2)}px`, clip: '', co: '1', fa: null, fu: 0, body });
            return;
        }
        const p = Math.min(raw / limit, 1);
        if (drag.morph) {
            // pushed toward the bar: the card follows the finger along the motion of the nav in use. Same motion as the timed exit.
            const g = lqGeoLive(drag.geo), pz = lqToastBodyPose(g, p);
            if (!drag.liqOn && !drag.side && p >= LQ_SWIPE_LIQ_IN) { drag.liqOn = true; drag.liq = lqLiqPrepare(t, drag.src); }
            else if (drag.liqOn && p < LQ_SWIPE_LIQ_OUT) liqDrop();
            drag.u = p; drag.pose = pz; drag.pres = lqSmooth(p / 0.12);
            if (!drag.liq && drag.src.kind !== 'float' && !drag.fill) drag.fill = lqToastFillScrub(el, drag.src.bg);
            // the real card (no sheet yet): with the bend on, its size and position are kept to whole device pixels
            const snap = !drag.liq && drag.bend && LQ_STRETCH_BEND === 'snap' && !pz.clip;
            write({ tf: snap ? snapTf(pz.sx, pz.sy, pz.dx, pz.T - ty, ty) : pz.tf, op: '1', br: snap ? '' : pz.br, clip: pz.clip, co: String(pz.co), fa: drag.fill, fu: p, body: drag.liq ? lqToastLiqBody(t, g, pz, drag.pres, false) : null });
        } else {
            // fallback (reduced motion / no Web Animations): plain follow, shrinking and fading as it is absorbed
            const dy = p * limit, s2 = 1 - 0.58 * p;
            write({ tf: `translate3d(0,${(ty + dy).toFixed(2)}px,0) scale(${s2.toFixed(4)},${s2.toFixed(4)})`, op: String(1 - 0.85 * p), br: '', clip: '', co: '1', fa: null, fu: 0, body: null });
        }
        if (raw >= LQ_SWIPE_GO || p >= 0.94) {
            const d = drag; drag = null;
            try { el.releasePointerCapture(d.id); } catch (_) {}
            dismissFromDrag(d);
        }
    });
    const end = e => {
        if (!drag || e.pointerId !== drag.id) return;
        const d = drag; drag = null;
        const v = d.dy / Math.max(1, performance.now() - d.t0);
        const stackedFront = el.dataset.stacked === '1';
        if (e.type !== 'pointercancel' && !d.side && (d.dy > LQ_SWIPE_REL || (d.dy > LQ_SWIPE_FLICK && v > 0.5))) {
            dismissFromDrag(d);                  // let go past the point of no return
            return;
        }
        flush();
        void el.offsetHeight;
        clearInline();
        el.classList.remove('is-dragging');
        if (d.morph && d.pose && d.liqOn) {
            // let go before the point of no return: back home on the spring, the liquid lets go as it goes
            if (d.fill) { try { d.fill.cancel(); } catch (_) {} }
            restoreBf();
            t.anim = lqToastRun(t, d.geo, d.src, 'back', { u0: d.u, pres0: d.pres });
            t.anim.onfinish = t.anim.oncancel = () => { t.anim = null; };
        } else {
            if (d.fill) { try { d.fill.cancel(); } catch (_) {} }
            lqLiqRelease(t);
            el.classList.add('is-settling');
            clearTimeout(el._settleT);
            el._settleT = setTimeout(() => { el.classList.remove('is-settling'); if (!drag) restoreBf(); }, 520);
        }
        if (!d.moved && stackedFront && e.type !== 'pointercancel') {
            lqToastExpanded = true;
            lqToastLayout(false, 'expand');
        }
        lqToasts.forEach(lqToastResume);
    };
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
}

// The bar answers when a toast peels off it: it gives a little under the toast
// as it leaves (press), then springs back with a thin overshoot right when the neck snaps (~0.5 of the
// entry), and settles. Same length as the entry. transform only, added on top of whatever the bar
// is already doing (hold, resize), so it never fights those. A new toast simply restarts it.
let lqNavBumpAnim = null;
// dir 'out': a toast peels off the bar.  dir 'in': a toast is absorbed again (a shorter, softer answer).
// ── Liquid Glass nav: while a toast leaves the bar / comes back into it, the bar's icons and label go out of focus for a
// moment and the bar itself is pressed in a little (as the "Select" pill does in the reference), then both let go smoothly.
// Only in Liquid Glass; every other style keeps its own, quieter give.
const LQ_NAV_BLUR = 6;                 // px of blur the icons / label reach
const LQ_NAV_BLUR_FADE = 0.4;          // how much of them is left at the peak of the blur (0 = gone, 1 = nothing fades)
const LQ_NAV_SQUASH = [0.968, 0.93];   // the bar's scale (x, y) at the peak of the press when a toast leaves it
function lqNavGlassOn() {
    return document.documentElement.classList.contains('lq-glass-on');
}
// the bar presses in fast, holds a beat, and lets go with the smallest swell on the way back (one move, no wobble)
// A sampled underdamped spring (0 -> 1, overshooting): the bar lets go like a liquid, not like an ease curve
function lqNavSpring(t, z, w) { const wd = w * Math.sqrt(1 - z * z), e = Math.exp(-z * w * t); return 1 - e * (Math.cos(wd * t) + (z * w / wd) * Math.sin(wd * t)); }
// sx, sy: scale at the peak of the press (out) or of the swell (in); ts: when the neck lets go (0..1 of dur)
function lqNavLiquidFrames(dir, sx, sy, dur, wob) {
    const out = dir !== 'in', N = 34, fr = [], ts = out ? 0.4 : 0.26, tp = out ? 0.16 : ts;
    const z = wob ? 0.34 : 0.5, w = 15;
    for (let i = 0; i <= N; i++) {
        const t = i / N;
        let a;                                              // 0 = rest, 1 = the peak of the press / swell
        if (t < tp) a = 1 - Math.pow(1 - t / tp, 2.2);     // fast in
        else if (t < ts) a = 1;                             // held while the neck stretches
        else a = 1 - lqNavSpring((t - ts) * dur / 1000, z, w);   // let go, with give
        const m = out ? 1 : -1;                             // out: pressed in (<1); in: swells (>1)
        fr.push({ transform: `translateY(${(-1.2 * a).toFixed(2)}px) scale(${(1 + (sx - 1) * a * m * 1).toFixed(4)},${(1 + (sy - 1) * a * m * 1).toFixed(4)})`, offset: t, easing: 'linear' });
    }
    fr[N].transform = 'translateY(0) scale(1,1)';
    return fr;
}
const LQ_NAV_SWELL = [0.97, 0.9];        // the bar's swell (x, y deficit mirrored) when a toast is absorbed
function lqNavSquishFrames(dir) {
    return dir === 'in' ? lqNavLiquidFrames('in', 1 - (1 - LQ_NAV_SWELL[0]) * 0.8, 1 - (1 - LQ_NAV_SWELL[1]) * 0.65, 520, true)
                        : lqNavLiquidFrames('out', LQ_NAV_SQUASH[0], LQ_NAV_SQUASH[1], 720, true);
}
function lqNavBlur(pill, dir, force) {
    if (!pill || !pill.animate || lqReduced() || !(force || lqNavGlassOn())) return;
    try {
        if (pill._blurAnims) pill._blurAnims.forEach(a => a.cancel());
        const f = (b, o) => `blur(${b}px) opacity(${o})`, e = 'cubic-bezier(.3,.6,.4,1)';
        const frames = [
            { filter: f(0, 1),                                  offset: 0,    easing: 'ease-out' },
            { filter: f(LQ_NAV_BLUR, LQ_NAV_BLUR_FADE),         offset: 0.2,  easing: 'linear' },
            { filter: f(LQ_NAV_BLUR, LQ_NAV_BLUR_FADE),         offset: 0.32, easing: e },
            { filter: f(0, 1),                                  offset: 1 }
        ];
        const dur = dir === 'in' ? 520 : 720;
        const list = pill._blurAnims = [];
        pill.querySelectorAll('.nav-item .lq-svg-icon, .nav-item-label').forEach(el => {
            const a = el.animate(frames, { duration: dur });
            list.push(a);
            a.onfinish = a.oncancel = () => { if (pill._blurAnims === list && list.every(x => x.playState !== 'running')) pill._blurAnims = null; };
        });
    } catch (_) {}
}
function lqNavBump(dir = 'out') {
    const pill = document.getElementById('navPill');
    if (!pill || !pill.animate || lqReduced() || !pill.classList.contains('nav-in')) return;
    try {
        if (lqNavBumpAnim) lqNavBumpAnim.cancel();
        const absorb = dir === 'in';
        const e = 'cubic-bezier(.3,.6,.4,1)';
        if (lqNavGlassOn()) {
            const g = lqNavBumpAnim = pill.animate(lqNavSquishFrames(dir), { duration: absorb ? 520 : 720, composite: 'add' });
            g.onfinish = g.oncancel = () => { if (lqNavBumpAnim === g) lqNavBumpAnim = null; };
            return;
        }
        // one smooth give and return (no oscillation): the bar is pulled a hair toward the card, then settles
        const a = lqNavBumpAnim = pill.animate(absorb ? [
            { transform: 'translateY(0) scale(1,1)',               offset: 0,   easing: e },
            { transform: 'translateY(-.8px) scale(1.007,1.02)',    offset: 0.4, easing: e },
            { transform: 'translateY(0) scale(1,1)',               offset: 1 }
        ] : [
            { transform: 'translateY(0) scale(1,1)',               offset: 0,   easing: e },
            { transform: 'translateY(-1px) scale(.996,1.022)',     offset: 0.3, easing: e },
            { transform: 'translateY(0) scale(1,1)',               offset: 1 }
        ], { duration: absorb ? 480 : LQ_ENTRY_MS, composite: 'add' });
        a.onfinish = a.oncancel = () => { if (lqNavBumpAnim === a) lqNavBumpAnim = null; };
    } catch (_) {}
}

// What the nav does when a toast comes out of it or goes back in, by style. The squash that looks good on a
// floating bar looks wrong on a docked one (it spans the screen), so a docked bar never moves:
//   float   the whole bar gives and springs back (lqNavBump)
//   bubble  the bubble itself pops: it lets go (small dip, then a swell) as the toast leaves and swells as it comes back
//   tab     the slim indicator over the selected tab stretches and thickens for a moment, like a pulse
// `pill` and `kind` are given so the preview on the Liquid Glass page can use the same motion on its copy of the bar.
// the bubble: squeezed while the toast is pulled off it, then it lets go with a spring (out); swells and relaxes (in)
function lqNavLensFrames(sx, sy, dur, press) {
    const N = 34, fr = [], ts = press ? 0.4 : 0.26, tp = press ? 0.16 : ts;
    for (let i = 0; i <= N; i++) {
        const t = i / N;
        let a;
        if (t < tp) a = 1 - Math.pow(1 - t / tp, 2.2);
        else if (t < ts) a = 1;
        else a = 1 - lqNavSpring((t - ts) * dur / 1000, 0.3, 15);
        fr.push({ transform: `scale(${(1 + (sx - 1) * a).toFixed(4)},${(1 + (sy - 1) * a).toFixed(4)})`, offset: t, easing: 'linear' });
    }
    fr[N].transform = 'scale(1,1)';
    return fr;
}
function lqNavFeelOn(pill, dir, kind) {
    if (!pill || !pill.animate || lqReduced()) return;
    if (kind !== 'bubble' && kind !== 'tab') return;
    const lens = pill.querySelector('.nav-lens');
    if (!lens || !lens.animate) return;
    const out = dir === 'out', e = 'cubic-bezier(.3,.6,.4,1)';
    const frames = kind === 'bubble' ? (out ? lqNavLensFrames(0.88, 0.84, 720, true) : lqNavLensFrames(1.12, 1.16, 520, false)) : (out ? [
        { transform: 'scale(1,1)',     offset: 0,   easing: e },
        { transform: 'scale(1.6,1.5)', offset: 0.3, easing: e },
        { transform: 'scale(1,1)',     offset: 1 }
    ] : [
        { transform: 'scale(1,1)',     offset: 0,   easing: e },
        { transform: 'scale(1.7,1.5)', offset: 0.35, easing: e },
        { transform: 'scale(1,1)',     offset: 1 }
    ]);
    try {
        if (pill._feelAnim) pill._feelAnim.cancel();
        const a = pill._feelAnim = lens.animate(frames, { duration: out ? 720 : 520, composite: 'add' });
        a.onfinish = a.oncancel = () => { if (pill._feelAnim === a) pill._feelAnim = null; };
    } catch (_) {}
}
function lqNavFeel(dir) {
    const kind = lqNavKind();
    lqNavBlur(document.getElementById('navPill'), dir, kind === 'bubble');
    if (kind === 'float') lqNavBump(dir);
    else lqNavFeelOn(document.getElementById('navPill'), dir, kind);
}

function lqToastShow({ title = '', text = '', state = 'pending' } = {}) {
    const layer = lqToastEnsureLayer();
    const el = document.createElement('div');
    el.className = 'lq-toast';
    el.innerHTML = '<span class="lq-toast-icon"></span><span class="lq-toast-copy"><span class="lq-toast-title"></span><span class="lq-toast-text"></span></span><span class="lq-toast-more"></span><span class="lq-grad"></span><span class="lq-toast-rim"></span><span class="lq-toast-glow"><i class="lq-glow-ring"></i><i class="lq-glow-edge"></i></span>';
    const t = { el, title, text, state, timer: 0, left: LQ_TOAST_LIFE, armedAt: 0, anim: null, neck: null, neckAnim: null, neckPose: null };
    lqToastFill(t, {});
    layer.appendChild(el);                    // a new element never transitions: it just starts at its rest pose
    el.classList.add('is-entering');          // content stays hidden until the card has left the nav
    lqToasts.unshift(t);
    while (lqToasts.length > LQ_TOAST_MAX) lqToastDismiss(lqToasts[lqToasts.length - 1], 0, false, null, true);
    lqToastWire(t);
    lqToastLayout(false, 'push');             // rest pose for this one, the others move up one by one
    const src0 = lqReduced() || !el.animate ? null : lqToastSource();
    if (src0) {
        try {
            // a body grows out of the bar's top edge, joined to it by the liquid; it is pulled out, the neck thins and lets go
            const g = lqToastGeo(t, src0);
            t.anim = lqToastRun(t, g, src0, 'in');
            t.anim.onfinish = t.anim.oncancel = () => { t.anim = null; };
            if (src0.kind !== 'float' && !t.anim.liq) lqToastFillMorph(el, src0.bg, LQ_ENTRY_MS * 0.6, false);
            lqNavFeel('out');
        } catch (_) {}
    }
    requestAnimationFrame(() => el.classList.remove('is-entering'));
    if (state === 'ok' || state === 'err') setTimeout(() => { if (el.isConnected) { el.classList.add('is-pop'); lqToastGlow(t); } }, 420);
    if (state !== 'pending') lqToastArm(t, LQ_TOAST_LIFE); else lqToastArm(t, 200000);
    return {
        update(o = {}) {
            if (!lqToasts.includes(t)) return;
            lqToastFill(t, o);
            el.classList.remove('is-pop'); void el.offsetWidth; el.classList.add('is-pop');
            if (t.state === 'ok' || t.state === 'err') lqToastGlow(t);
            if (t.state !== 'pending') lqToastArm(t, LQ_TOAST_LIFE);
        },
        dismiss() { lqToastDismiss(t); }
    };
}

// Runs `run` while showing one toast for it: "Applying…" -> result, in place.
// Nothing on the page (titles, buttons) is rewritten any more.
async function flashActionStatus(titleEl, run, opts={}){
  const label=(opts.label||titleEl?.textContent||'').trim()||'Tweak';
  const toast=lqToastShow({title:label,text:opts.pendingText||(lqExecPending>0?'Queued…':'Applying…'),state:'pending'});
  await new Promise(requestAnimationFrame);
  let ok=false;
  try{ ok=await run(); }catch(_){ ok=false; }
  toast.update({state:ok?'ok':'err',text:ok?(opts.okText||'Applied'):(opts.failText||'Failed to apply')});
  return ok;
}

// One toast per package action: pending -> result. The buttons keep their
// resting label (Add/Added, Select/Selected); only the toast reports status.
function pkgToastStart(title, text) {
  return lqToastShow({ title, text: lqExecPending > 0 ? 'Queued…' : text, state: 'pending' });
}
function pkgListTitle(key) {
  return key === 'whitelist' ? 'Whitelist' : `${pkgActions[key]?.label || 'Package'} list`;
}

async function wireHelperToggle(id,stateKey,command){
  const el=document.getElementById(id);
  if(!el)return;
  const titleEl=el.querySelector('b');
  const sync=()=>{
    syncHelperToggle(id,stateKey);
    if(stateKey==='helper_fily') syncFilyMultitaskingConflict();
  };
  el.addEventListener('click',async evt=>{
    evt.preventDefault();
    evt.stopPropagation();
    if(el.classList.contains('is-locked') || el.dataset.busy==='1')return;
    if(stateKey==='helper_fily' && tweakState[stateKey]!=='1' && tweakState.perf_multitasking==='1')return;
    const next=tweakState[stateKey]==='1'?'0':'1';
    const previous=tweakState[stateKey];
    el.dataset.busy='1';
    el.classList.add('is-locked');
    el.setAttribute('aria-busy','true');
    let res={ok:false,confirmed:false};
    const ok=await flashActionStatus(titleEl, async()=>{
      res=await lqApplyConfirmed(command,next,()=>fetchValueState(stateKey),()=>tweakState[stateKey]===next);
      return res.ok;
    }, {okText:next==='1'?'Enabled':'Disabled'});
    if(ok){
      // confirmed by the read-back (or, if it could not be read, by the apply answer)
      await commitToggleVisual(el,()=>{ tweakState[stateKey]=next; sync(); });
    }else{
      // after a read-back tweakState already holds what the backend has; if it could not be read, fall back
      if(!res.confirmed) tweakState[stateKey]=previous;
      sync();
    }
    {
      el.classList.remove('is-locked');
      el.removeAttribute('aria-busy');
      el.dataset.busy='';
    }
  });
  sync();
}

// Refreshes every System Tuning group toggle/slider from the current
// tweakState in one pass. Used after One-Click Optimization applies,
// since that one backend call can change many groups at once -- unlike a
// single toggle, it isn't worth a targeted resync per group.
function refreshSystemTuningUI(){
 syncPerformanceExtraToggles();
 document.querySelectorAll('[data-system-tuning-group]').forEach(row=>{
   const group=row.getAttribute('data-system-tuning-group');
   if(group) systemTuningSyncSliders(group,row);
 });
 document.querySelectorAll('[data-system-tuning-toggle-group]').forEach(el=>{
   const group=el.getAttribute('data-system-tuning-toggle-group');
   if(!group) return;
   const row=el.closest('.lq-tweak-subrow');
   const on=tweakState[`perf_${group.replace(/-/g,'_')}`]==='1';
   el.classList.toggle('on',on);
   el.setAttribute('aria-pressed',on?'true':'false');
   if(row) systemTuningSyncSliders(group,row);
 });
 syncFilyMultitaskingConflict();
 // Surface Flinger isn't a [data-system-tuning-group] row -- it's its own
 // module -- so the loops above never touch it. Anything that calls this
 // function (One-Click Optimization toggle, any System Tuning group
 // change, etc.) has already refreshed tweakState.surface_flinger via
 // tweaksGetState(), so repaint SF here too or its Apply/Reset buttons
 // go stale relative to the state that was just fetched.
 if(typeof renderSurfaceFlingerSlider==='function') renderSurfaceFlingerSlider();
}

// ── Recommended profile: detect + apply ─────────────────────────
// "Detect profile" runs the real detect in the backend (hardware -> recommended
// System Tuning profile). The animation follows how long that takes. Nothing is
// applied until the person taps Apply in the popup or Apply now on the card.
function lqDetectParse(raw){
  const m={};
  String(raw||'').split(/\r?\n/).forEach(l=>{ const i=l.indexOf('='); if(i>0) m[l.slice(0,i).trim()]=l.slice(i+1).trim(); });
  if(!m.recommended_spec_ram_mb) return null;
  const v=k=>m['recommended_value_'+k];
  const cap=s=>String(s||'').replace(/\b\w/g,c=>c.toUpperCase());
  const lines=[];
  // Device: brand + model (model only when it fits on one line)
  const brand=cap(m.recommended_spec_brand||'');
  const model=String(m.recommended_spec_model||'');
  const nameFull=model && model.toLowerCase().indexOf(brand.toLowerCase())!==0 ? (brand+' '+model).trim() : (model||brand);
  const dev=nameFull.length<=24 ? nameFull : (brand||nameFull.slice(0,24));
  if(dev) lines.push(['Device',dev]);
  // Hardware: nominal RAM (MemTotal is a few % under the box number), cores, top clock
  const ramGb=Math.max(1,Math.round(Number(m.recommended_spec_ram_mb)/1024*1.06));
  const ghz=(Number(m.recommended_spec_max_mhz)/1000).toFixed(1);
  lines.push(['Hardware',ramGb+' GB · '+m.recommended_spec_cores+' cores · '+ghz+' GHz']);
  // Memory: Fily and Multitasking exclude each other, so the profile picks one
  if(m.recommended_helper_fily==='1') lines.push(['Memory','Fily']);
  else if(v('multitasking_preset')) lines.push(['Memory','Multitasking · '+cap(stSnapPreset(v('multitasking_preset')))]);
  if(v('job_scheduler_max_job_count_active')) lines.push(['Job scheduler',v('job_scheduler_max_job_count_active')+' jobs']);
  if(v('sqlite_tuning_wal_checkpoint')&&v('sqlite_tuning_journal_size')) lines.push(['SQLite','WAL '+v('sqlite_tuning_wal_checkpoint')+' · '+Math.round(Number(v('sqlite_tuning_journal_size'))/1024)+' KB']);
  if(Number(v('app_standby_strong_usage_duration'))) lines.push(['App standby',(Math.round(Number(v('app_standby_strong_usage_duration'))/360000)/10)+' h']);
  if(m.recommended_perf_low_swap==='0') lines.push(['Low swap','No swap, skipped']);
  else if(v('low_swap_threshold_percent')) lines.push(['Low swap',Math.round(Number(v('low_swap_threshold_percent'))*100)+'%']);
  if(v('long_press_latency_timeout_ms')) lines.push(['Long press',v('long_press_latency_timeout_ms')+' ms']);
  const fam=m.recommended_spec_oem_family;
  lines.push(['OEM tuning',m.recommended_perf_oem_tuning==='1'?(fam==='samsung'?'Samsung':'Xiaomi'):'Skipped']);
  lines.push(['Tctl',m.recommended_helper_tctl==='1'?'On':'Not supported']);
  return lines;
}

const LQ_DETECT_STAGES=[[0,'Reading memory'],[14,'Counting CPU cores'],[28,'Reading CPU frequency'],[42,'Reading storage and display'],[56,'Picking tuning values'],[66,'Checking memory pressure'],[76,'Checking vendor support'],[86,'Writing profile'],[94,'Finishing up']];

function lqDetectOpen(){
  const N=90, BANDS=10;
  const W=window.innerWidth, H=window.innerHeight;
  // only the upper part of a big ring is shown, rising from the bottom of the
  // screen and built from loose particles (the text sits apart, mid-screen).
  // Bigger radius so the ring is wide, centre low so the ring top sits at ~74% of H
  const R=Math.round(Math.min(W*1.05,480)), cx=W/2, BAND=84;
  const cy=Math.round(H*0.74+R);
  // angular span that actually lands on screen, so no particle is wasted off the sides
  const PHI=Math.min(Math.PI/2,Math.asin(Math.min(1,(W/2+40)/R)));
  // rise timeline (ms): soft wind-up per particle (top -> bottom, short stagger), bands lift
  // off at the bottom of that dip, the overlay only fades during the last stretch
  const MICRO=800, PRE=120, STAG=150, BAND_GAP=16, LIFT=1100, FADE=420;
  const LAUNCH=PRE+Math.round(MICRO*0.62);
  const tEnd=LAUNCH+(BANDS-1)*BAND_GAP+LIFT;
  const D=H*0.6, TAU=Math.PI*2;
  const dpr=Math.min(window.devicePixelRatio||1,2);
  const root=document.createElement('div');
  root.className='lq-detect';
  root.setAttribute('aria-hidden','true');
  // intro: the glow runs and the blur behind comes in slowly (css); only then do the percentage and the particles show up and start
  const INTRO=1700;
  const introP=new Promise(r=>setTimeout(r,INTRO));
  root.innerHTML='<div class="lq-detect-scrim"></div><div class="lq-detect-stage">'
    +'<canvas class="lq-detect-svg" width="'+Math.round(W*dpr)+'" height="'+Math.round(H*dpr)+'"></canvas>'
    +'<div class="lq-detect-center" style="left:0;top:'+Math.round(H/2-40)+'px;width:'+W+'px"><div class="lq-detect-num"></div><div class="lq-detect-log"></div></div>'
    +'</div>';
  const stage=root.querySelector('.lq-detect-stage');
  const scrim=root.querySelector('.lq-detect-scrim');
  const canvas=root.querySelector('.lq-detect-svg');
  const center=root.querySelector('.lq-detect-center');
  const log=root.querySelector('.lq-detect-log');
  const numNode=document.createTextNode('1%');
  root.querySelector('.lq-detect-num').appendChild(numNode);
  const ctx=canvas.getContext('2d');
  if(center.animate) center.animate([
    {opacity:0,transform:'translate3d(0,12px,0) scale(.94)'},
    {opacity:1,transform:'translate3d(0,0,0) scale(1)'}
  ],{duration:560,delay:INTRO-440,easing:'cubic-bezier(.2,.8,.25,1)',fill:'both'});
  else center.style.opacity='0', introP.then(()=>{ center.style.opacity=''; });

  // every particle is drawn on ONE canvas from ONE rAF loop (motion, twinkle and
  // lift-off are all computed here), instead of ~180 separate SVG animations
  const bez=(x1,y1,x2,y2)=>t=>{
    if(t<=0) return 0; if(t>=1) return 1;
    let lo=0,hi=1,s=t;
    for(let k=0;k<14;k++){
      const x=3*(1-s)*(1-s)*s*x1+3*(1-s)*s*s*x2+s*s*s;
      if(Math.abs(x-t)<1e-4) break;
      if(x<t) lo=s; else hi=s;
      s=(lo+hi)/2;
    }
    return 3*(1-s)*(1-s)*s*y1+3*(1-s)*s*s*y2+s*s*s;
  };
  const eW1=bez(.33,0,.2,1), eW2=bez(.4,0,.3,1), eLift=bez(.5,.02,.25,1);

  // stratified placement (shuffled angle slots x shuffled radius slots): spread
  // evenly with some jitter, so nothing clumps or sits on top of a neighbour
  const shuffle=()=>{ const o=[...Array(N).keys()]; for(let i=N-1;i>0;i--){ const k=Math.floor(Math.random()*(i+1)); [o[i],o[k]]=[o[k],o[i]]; } return o; };
  const order=shuffle(), orderR=shuffle();
  const sx=[], sy=[], ex=[], ey=[], bx=[], by=[], op=[], rr=[], dur=[], tp=[], tph=[], jx=[], pd=[], bd=[];
  const t0=new Float64Array(N).fill(-1);
  for(let i=0;i<N;i++){
    const a=-Math.PI/2-PHI+2*PHI*(order[i]+Math.random())/N;
    const rad=R+(((orderR[i]+Math.random())/N)-0.5)*2*BAND;   // wide, even band
    ex[i]=cx+rad*Math.cos(a); ey[i]=cy+rad*Math.sin(a);
    sx[i]=W*Math.random(); sy[i]=H+8+Math.random()*56;        // they start just below the bottom edge
    const mx=(sx[i]+ex[i])/2, my=(sy[i]+ey[i])/2;
    const dx=ex[i]-sx[i], dy=ey[i]-sy[i], len=Math.hypot(dx,dy)||1, off=(Math.random()-0.5)*0.5*len;
    bx[i]=mx-dy/len*off; by[i]=my+dx/len*off;
    dur[i]=700+Math.random()*600;
    op[i]=0.3+Math.random()*0.7;
    rr[i]=0.8+Math.random()*0.9;
    tp[i]=2800+Math.random()*2200;          // slow bright <-> dim breathing, own period and phase
    tph[i]=Math.random();
    jx[i]=(Math.random()-0.5)*5;
  }
  const minY=Math.min(...ey), spanY=Math.max(...ey)-minY+1;
  for(let i=0;i<N;i++){
    pd[i]=PRE+(ey[i]-minY)/spanY*STAG+Math.random()*24;
    bd[i]=Math.max(0,Math.min(BANDS-1,Math.floor((ey[i]-minY)/spanY*BANDS)));
  }
  document.body.appendChild(root);
  document.body.classList.add('lq-detecting');   // the nav stays put (covered by the overlay) but is not tappable
  ctx.setTransform(dpr,0,0,dpr,0,0);
  ctx.fillStyle=getComputedStyle(canvas).color||'#fff';
  if(typeof lqMarkMotion==='function') lqMarkMotion(9000);

  const T0=performance.now();
  let alive=true, raf=0, last=performance.now(), lastDraw=0, p=0, target=0, shown=0, launched=0, landed=0, doneRes=null;
  let auto=false, autoT0=0, finishing=false, stageIdx=-1, riseT0=-1, riseRes=null;
  const active=[];
  function setLine(text,isErr){
    const d=document.createElement('div');
    d.className='lq-detect-line'+(isErr?' is-err':'');
    d.textContent=text;
    log.replaceChildren(d);                 // one line only: the new one replaces the old
  }
  function draw(now){
    ctx.clearRect(0,0,W,H);
    const rising=riseT0>=0, tr=now-riseT0;
    for(let i=0;i<N;i++){
      if(t0[i]<0) continue;
      let x,y,a,rad=rr[i];
      const u=(now-t0[i])/dur[i];
      if(u<1){
        const e=1-Math.pow(1-u,3), q=1-e;
        x=q*q*sx[i]+2*q*e*bx[i]+e*e*ex[i];
        y=q*q*sy[i]+2*q*e*by[i]+e*e*ey[i];
        a=Math.min(1,u*3)*op[i];
      }else{ x=ex[i]; y=ey[i]; a=op[i]; }
      // slow twinkle for the whole life of the particle
      a*=1-0.8*(0.5-0.5*Math.cos(TAU*((now-T0)/tp[i]+tph[i])));
      if(rising){
        const w=tr-pd[i];
        if(w>0 && w<MICRO){
          // soft wind-up: ease down a few px, then back, so the turn into the lift has no hard edge
          const h=w/MICRO;
          if(h<.5){ const e=eW1(h/.5); x+=jx[i]*e; y+=7*e; rad*=1+.18*e; }
          else{ const e=eW2((h-.5)/.5); x+=jx[i]*(1-e); y+=7*(1-e); rad*=1.18-.18*e; }
        }
        const l=tr-LAUNCH-bd[i]*BAND_GAP;
        if(l>0){
          const e=eLift(Math.min(1,l/LIFT)), s=1+1.4*e;
          x=cx+s*(x-cx); y=cy+s*(y-cy)-D*e; rad*=s;
          if(e>.5) a*=Math.max(0,1-(e-.5)*2);
        }
      }
      if(a<=0.005) continue;
      ctx.globalAlpha=a;
      ctx.beginPath(); ctx.arc(x,y,rad,0,TAU); ctx.fill();
    }
    ctx.globalAlpha=1;
  }
  function finishRise(){ if(riseRes){ const r=riseRes; riseRes=null; cleanup(); r(); } }
  function frame(now){
    raf=0;
    if(!alive) return;
    const dt=Math.min(50,now-last); last=now;
    // the build-up follows how long the detect has been running: it climbs
    // toward 93% while the backend works and only finishes when it returns
    if(auto){ const t=93*(1-Math.exp(-(now-autoT0)/1800)); if(t>target) target=t; }
    if(p<target) p=Math.min(target,p+Math.max((target-p)*(1-Math.exp(-dt/260)),dt*(finishing?0.04:0.012)));
    const pct=Math.max(1,Math.floor(p));
    if(pct!==shown){ shown=pct; numNode.nodeValue=pct+'%'; }
    if(!finishing){
      let k=Math.max(0,stageIdx);
      while(k+1<LQ_DETECT_STAGES.length && p>=LQ_DETECT_STAGES[k+1][0]) k++;
      if(k!==stageIdx){ stageIdx=k; setLine(LQ_DETECT_STAGES[k][1]); }
    }
    const want=Math.min(N,Math.ceil(p/100*N));
    for(;launched<want;launched++){ t0[launched]=now; active.push(launched); }
    for(let k=active.length-1;k>=0;k--){
      const i=active[k];
      if((now-t0[i])>=dur[i]){ active.splice(k,1); landed++; }
    }
    // full rate while something moves; only the slow twinkle is left otherwise, so ~30fps is plenty
    if(riseT0>=0 || active.length || launched<want || now-lastDraw>=33){ draw(now); lastDraw=now; }
    if(doneRes && p>=99.9 && landed>=N){ const r=doneRes; doneRes=null; r(); }
    if(riseT0>=0 && now-riseT0>=tEnd){ finishRise(); return; }
    kick();
  }
  function kick(){ if(alive && !raf){ last=performance.now(); raf=requestAnimationFrame(frame); } }
  function cleanup(){ alive=false; if(raf) cancelAnimationFrame(raf); raf=0; root.remove(); document.body.classList.remove('lq-detecting'); }
  function fadeOut(delay){
    if(!stage.animate){ cleanup(); return; }
    scrim.style.animation='none'; scrim.style.opacity='1';
    scrim.animate([{opacity:1},{opacity:0}],{duration:400,delay,fill:'forwards'});
    const a=stage.animate([{opacity:1},{opacity:0}],{duration:400,delay,fill:'forwards'});
    a.onfinish=cleanup;
  }
  const api={
    startAuto(){ introP.then(()=>{ if(!alive||finishing) return; auto=true; autoT0=performance.now(); kick(); }); },
    // the detect returned: finish the count, wait until every particle is on the ring
    complete(finalText){
      return introP.then(()=>new Promise(res=>{
        auto=false; finishing=true; doneRes=res; target=100;
        if(finalText) setLine(finalText);
        kick();
        setTimeout(()=>{ if(doneRes){ const r=doneRes; doneRes=null; r(); } },5000);
      }));
    },
    // percent + log fade out (drift up a little, scale down), then the particles
    // wind up and sweep off the top of the screen, top of the ring first
    rise(){
      return new Promise(res=>{
        if(!stage.animate){ cleanup(); res(); return; }
        center.animate([
          {opacity:1,transform:'translate3d(0,0,0) scale(1)'},
          {opacity:0,transform:'translate3d(0,-16px,0) scale(.82)'}
        ],{duration:380,easing:'cubic-bezier(.4,0,.2,1)',fill:'forwards'});
        scrim.style.animation='none'; scrim.style.opacity='1';
        scrim.animate([{opacity:1},{opacity:0}],{duration:FADE,delay:tEnd-FADE,easing:'ease-out',fill:'forwards'});
        if(typeof lqMarkMotion==='function') lqMarkMotion(tEnd+400);
        riseRes=res; riseT0=performance.now();
        kick();
        setTimeout(finishRise,tEnd+1500);
      });
    },
    fail(msg){
      return introP.then(()=>{
        auto=false; finishing=true;
        if(raf) cancelAnimationFrame(raf); raf=0;   // freeze the particles where they are
        setLine(msg,true);
        fadeOut(1100);
      });
    }
  };
  kick();
  return api;
}

// Runs the detect with the animation. Resolves with the parsed profile lines,
// or null when the detect failed.
async function lqRecDetectRun(srcEl){
  const fx=lqReduced()?null:lqDetectOpen();
  // the glow of the scan (lqEdgeGlow) starts at the Detect button, above the blur that is coming in behind it
  const glow=(fx&&srcEl&&typeof lqEdgeGlow==='function')?lqEdgeGlow(srcEl,{z:161,veil:false}):null;
  if(fx) fx.startAuto();
  let raw='';
  try{ raw=await exec(tweaksBackend('detect-recommended-profile')); }catch(_){ raw=''; }
  const lines=lqDetectParse(raw);
  if(!lines){ if(fx) fx.fail('Detection failed'); if(glow) glow.end(); return null; }
  if(fx){
    await fx.complete('Detected '+lines[0][1]+' profile');
    if(glow) glow.end();          // the wave sinks back into the border while the particles lift off
    await fx.rise();
  }
  return lines;
}

// Apply / skip popup. Resolves 'apply' or 'skip' (tapping outside is a skip).
function lqRecPopup(lines){
  return new Promise(res=>{
    const el=document.createElement('div');
    el.className='lq-rec-modal';
    el.innerHTML='<div class="lq-rec-modal-scrim"></div><div class="lq-rec-modal-card" role="dialog" aria-modal="true">'
      +'<div class="pkg-title">Profile detected</div>'
      +'<div class="pkg-sub">Apply the recommended tuning for this device now?</div>'
      +'<div class="lq-rec-modal-list is-stacked"></div>'
      +'<div class="lq-rec-modal-actions"><button class="lq-rec-modal-btn is-skip" type="button">Skip</button><button class="lq-rec-modal-btn is-apply" type="button">Apply</button></div></div>';
    const list=el.querySelector('.lq-rec-modal-list');
    lines.forEach(([k,v])=>{
      const row=document.createElement('div'); row.className='lq-rec-modal-row';
      const a=document.createElement('span'), b=document.createElement('b');
      a.textContent=k; b.textContent=v; row.appendChild(a); row.appendChild(b); list.appendChild(row);
    });
    let done=false;
    const close=v=>{
      if(done) return; done=true;
      el.classList.add('is-out');
      setTimeout(()=>{ el.remove(); res(v); },220);
    };
    el.querySelector('.is-apply').addEventListener('click',()=>close('apply'));
    el.querySelector('.is-skip').addEventListener('click',()=>close('skip'));
    el.querySelector('.lq-rec-modal-scrim').addEventListener('click',()=>close('skip'));
    document.body.appendChild(el);
    // the card is only promoted to its own layer while the pop-in runs
    const card=el.querySelector('.lq-rec-modal-card');
    card.addEventListener('animationend',()=>{ card.style.willChange='auto'; },{once:true});
  });
}

// ── Display: Refresh rate + Renderer tiles (Tweaks, Display & Input) ──────────
// Each tile opens a popup that grows out of the tile and shrinks back into it.
// Picking an option applies it right away (the popup closes first, the toast shows the result).
const LQ_DISP_RENDERERS=[
  {id:'default',label:'Default'},
  {id:'skiavk',label:'SkiaVK'},
  {id:'skiavkthreaded',label:'SkiaVK (Threaded)'},
  {id:'skiagl',label:'SkiaGL'},
  {id:'skiaglthreaded',label:'SkiaGL (Threaded)'},
  {id:'gles',label:'OpenGL ES'},
  {id:'glesthreaded',label:'OpenGL ES (Threaded)'}
];
const lqDispName=id=>(LQ_DISP_RENDERERS.find(o=>o.id===id)||{label:id==='custom'?'Custom':id}).label;
let lqDispPipeline='', lqDispProbed=false, lqDispBusy=false;
function lqDispRates(){ return String(tweakState.display_rates||'').split(',').map(Number).filter(n=>n>=30); }
function lqDispPaint(){
  const r=document.getElementById('dispRefreshValue'), g=document.getElementById('dispRendererValue');
  if(r){
    const v=Number(tweakState.display_refresh)||0;
    r.textContent=(!tweakState.display_rates && !v)?'|':(v?`${v} Hz`:(tweakState.display_adaptive==='1'?'Adaptive':'Default'));
  }
  if(g){
    const id=tweakState.display_renderer;
    g.textContent=!id?'|':(id==='default'?(lqDispPipeline?lqDispName(lqDispPipeline):'Default'):lqDispName(id));
  }
}
// What apps really draw with while no renderer is forced: read once, only to label the tile.
async function lqDispProbe(){
  if(lqDispProbed || !lqTweakStateReady) return;
  lqDispProbed=true;
  try{
    const raw=await exec(`sh /data/local/tmp/liqinghe/tweaks.sh get-value display_pipeline 2>/dev/null`);
    const v=String(raw||'').trim();
    if(/^skia(gl|vk)$/.test(v)){ lqDispPipeline=v; lqDispPaint(); }
  }catch(_){}
}
function lqDispPopup(srcEl,{title,sub,options,current}){
  return new Promise(res=>{
    const el=document.createElement('div');
    el.className='lq-rec-modal';
    el.innerHTML='<div class="lq-rec-modal-scrim"></div><div class="lq-rec-modal-card" role="dialog" aria-modal="true"><div class="pkg-title"></div><div class="pkg-sub"></div><div class="lq-disp-opts"></div></div>';
    const card=el.querySelector('.lq-rec-modal-card');
    el.querySelector('.pkg-title').textContent=title;
    el.querySelector('.pkg-sub').textContent=sub;
    const list=el.querySelector('.lq-disp-opts');
    options.forEach(o=>{
      const b=document.createElement('button');
      b.type='button'; b.className='lq-disp-opt'+(o.id===current?' is-active':''); b.dataset.id=o.id;
      const t=document.createElement('span'); t.textContent=o.label;
      b.appendChild(t);
      b.insertAdjacentHTML('beforeend','<svg class="lq-disp-check" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"></path></svg>');
      list.appendChild(b);
    });
    document.body.appendChild(el);
    // opens and closes exactly like the "Profile detected" popup (lqRecPop / lqRecPopOut in the css)
    card.addEventListener('animationend',()=>{ card.style.willChange='auto'; },{once:true});
    let done=false;
    const close=v=>{
      if(done) return; done=true;
      el.classList.add('is-out');
      res(v);                       // the apply starts now, the popup finishes closing meanwhile
      setTimeout(()=>el.remove(),220);
    };
    list.addEventListener('click',e=>{ const b=e.target.closest('.lq-disp-opt'); if(b) close(b.dataset.id); });
    el.querySelector('.lq-rec-modal-scrim').addEventListener('click',()=>close(null));
  });
}
async function lqDispApply(title,cmd,value,key,isExpected,okText){
  const toast=lqToastShow({title,text:lqExecPending>0?'Queued…':'Applying…',state:'pending'});
  let ok=false;
  try{
    await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
    ok=(await lqApplyConfirmed(cmd,value,()=>fetchValueState(key),isExpected)).ok;
  }catch(_){ ok=false; }
  lqDispPaint();
  toast.update({state:ok?'ok':'err',text:ok?okText:'Failed to apply'});
}
async function lqDispOpenRefresh(card){
  const cur=String(Number(tweakState.display_refresh)||0);
  // Adaptive is only offered where its real value is known (Transsion, Samsung). Elsewhere the list is
  // just the Hz choices, and tapping the rate that is currently locked releases the lock.
  const adaptive=tweakState.display_adaptive==='1';
  const opts=[...(adaptive?[{id:'0',label:'Adaptive'}]:[]),...lqDispRates().map(r=>({id:String(r),label:`${r} Hz`}))];
  let pick=await lqDispPopup(card,{title:'Refresh rate',sub:adaptive?'Adaptive, or lock the display to one rate':'Lock the display to one rate · tap the current one to release',options:opts,current:cur});
  if(pick==null) return;
  let release=false;
  if(pick===cur){
    if(adaptive || cur==='0') return;
    pick='0'; release=true;
  }
  await lqDispApply('Refresh rate','set-display-refresh',pick,'display_refresh',
    ()=>String(Number(tweakState.display_refresh)||0)===pick, pick==='0'?(release?'Lock released':'Adaptive'):`Set to ${pick} Hz`);
}
async function lqDispOpenRenderer(card){
  const cur=tweakState.display_renderer||'default';
  const pick=await lqDispPopup(card,{title:'Renderer',sub:'Apps pick it up when they open · reboot for the rest',options:LQ_DISP_RENDERERS,current:cur});
  if(pick==null || pick===cur) return;
  await lqDispApply('Renderer','set-display-renderer',pick,'display_renderer',
    ()=>String(tweakState.display_renderer)===pick, pick==='default'?'Default · reboot to finish':`${lqDispName(pick)} · reboot to finish`);
}
document.addEventListener('click',async e=>{
  const card=e.target.closest('#dispRefreshCard,#dispRendererCard');
  if(!card || lqDispBusy || !lqTweakStateReady) return;
  lqDispBusy=true;
  try{ await (card.id==='dispRefreshCard'?lqDispOpenRefresh(card):lqDispOpenRenderer(card)); }
  finally{ lqDispBusy=false; }
});

// ── Power button: ask first, then soft reboot ─────────────────────────────
// Yes / No popup that grows out of the power button (same motion as the Display tiles).
function lqConfirmPopup(srcEl,{title,text,yes='Yes',no='No'}){
  return new Promise(res=>{
    const el=document.createElement('div');
    el.className='lq-rec-modal';
    el.innerHTML='<div class="lq-rec-modal-scrim"></div><div class="lq-rec-modal-card" role="dialog" aria-modal="true"><div class="pkg-title"></div><div class="pkg-sub"></div><div class="lq-rec-modal-actions lq-pw-actions"><button class="lq-rec-modal-btn is-skip" type="button"></button><button class="lq-rec-modal-btn is-apply" type="button"></button></div></div>';
    const card=el.querySelector('.lq-rec-modal-card');
    el.querySelector('.pkg-title').textContent=title;
    el.querySelector('.pkg-sub').textContent=text;
    el.querySelector('.is-skip').textContent=no;
    el.querySelector('.is-apply').textContent=yes;
    document.body.appendChild(el);
    // opens and closes exactly like the "Profile detected" popup (lqRecPop / lqRecPopOut in the css)
    card.addEventListener('animationend',()=>{ card.style.willChange='auto'; },{once:true});
    let done=false;
    const close=v=>{
      if(done) return; done=true;
      el.classList.add('is-out');
      res(v);
      setTimeout(()=>el.remove(),220);
    };
    el.querySelector('.is-apply').addEventListener('click',()=>close(true));
    el.querySelector('.is-skip').addEventListener('click',()=>close(false));
    el.querySelector('.lq-rec-modal-scrim').addEventListener('click',()=>close(false));
  });
}
// ── Game scan (Apps > Game) ────────────────────────────────────────────────────────────
// The scan button sits next to the search button (Game tab only). It asks the backend to scan the device (loading popup), shows what was
// found, and the user decides: Cancel throws the result away and nothing is written, Replace writes it to gamelist_detected.txt (the file the
// Game tab prefers). This is what the Action button of the module manager used to do.
function lqPkgScanSync() {
    const bar = document.getElementById('topBar');
    if (!bar) return;
    const on = pkgState.active === 'game';
    bar.classList.toggle('has-scan', on);
    const b = document.getElementById('pkgScanBtn');
    if (b) b.tabIndex = (on && bar.classList.contains('has-search')) ? 0 : -1;
}
// The popup of the game scan. It opens and closes exactly like the "Profile detected" popup (lqRecPopup): the same jelly pop-in on the card
// (lqRecPop) and the same soft drop-out (lqRecPopOut), both in the css. Only when the content changes does the card grow or shrink to fit.
function lqGameScanPopup(srcEl, opt) {
    const el = document.createElement('div');
    el.className = 'lq-rec-modal lq-gs-modal' + (opt && opt.swap ? ' is-swapin' : '');
    el.innerHTML = '<div class="lq-rec-modal-scrim"></div><div class="lq-rec-modal-card" role="dialog" aria-modal="true"><div class="lq-gs-body"></div></div>';
    const card = el.querySelector('.lq-rec-modal-card'), body = el.querySelector('.lq-gs-body'), scrim = el.querySelector('.lq-rec-modal-scrim');
    document.body.appendChild(el);
    // the card is only promoted to its own layer while the pop-in runs
    card.addEventListener('animationend', () => { card.style.willChange = 'auto'; }, { once: true });
    const calm = typeof lqReduced === 'function' && lqReduced();
    let done = false, onScrim = null, first = true;
    const api = {
        el, card, body,
        show(html) {
            const h0 = card.offsetHeight;
            body.innerHTML = html;
            // the first content is there from the start of the pop-in; later changes grow or shrink the card to the new content instead of jumping
            if (first) { first = false; return; }
            if (calm || !card.animate) return;
            const h1 = card.offsetHeight;
            if (Math.abs(h1 - h0) < 2) return;
            card.style.overflow = 'hidden';
            const a = card.animate([{ height: h0 + 'px' }, { height: h1 + 'px' }], { duration: 300, easing: 'cubic-bezier(.2,.85,.25,1)' });
            const end = () => { card.style.overflow = ''; };
            a.onfinish = end; a.oncancel = end;
        },
        scrim(fn) { onScrim = fn; },
        close(o) {
            if (done) return Promise.resolve();
            done = true;
            el.classList.add('is-out');
            if (o && o.swap) el.classList.add('is-swapout');   // handing over to a new popup: the scrim stays, only the card goes
            return new Promise(res => setTimeout(() => { el.remove(); res(); }, 220));
        }
    };
    scrim.addEventListener('click', () => { if (onScrim) onScrim(); });
    return api;
}
let lqGameScanBusy = false;
// The scan is shown by ONE wave with three layers that runs round the whole border of the screen (a canvas, see .lq-edge-cv in the css).
// Stages: (1) a small bloom lights up at the scan button, (2) the wave rises there and runs both ways round the border (corners included)
// until the two ends meet at the far side, (3) it keeps flowing and breathing while the scan runs, (4) at the end it sinks back into the
// border and fades. effect.spread resolves when stage 2 is done; effect.end() starts stage 4 and resolves when the wave is gone.
const LQ_WAVE_SPREAD_MS = 2400, LQ_WAVE_FADE_MS = 1100;
let lqEdgeActive = null;
function lqEdgeGlow(srcEl, opt) {
    opt = opt || {};
    if (typeof lqReduced === 'function' && lqReduced()) return null;
    if (lqEdgeActive) lqEdgeActive.end();
    const r = srcEl.getBoundingClientRect();
    const ox = r.left + r.width / 2, oy = r.top + r.height / 2;
    const root = document.createElement('div');
    root.className = 'lq-edge';
    root.style.setProperty('--ox', Math.round(ox) + 'px');
    root.style.setProperty('--oy', Math.round(oy) + 'px');
    const cv = document.createElement('canvas');
    cv.className = 'lq-edge-cv';
    root.innerHTML = opt.veil === false ? '' : '<div class="lq-edge-veil"></div>';
    if (opt.z) root.style.zIndex = String(opt.z);
    root.appendChild(cv);
    document.body.appendChild(root);
    const ctx = cv.getContext('2d');
    if (!ctx) { root.remove(); return null; }

    // the theme colour -> rgb (the browser parses whatever --ac is), and a lighter tone of it for the lit parts
    let rgb = [255, 255, 255];
    try {
        const raw = getComputedStyle(document.documentElement).getPropertyValue('--ac').trim() || '#ffffff';
        const c1 = document.createElement('canvas'); c1.width = c1.height = 1;
        const x1 = c1.getContext('2d', { willReadFrequently: true });
        x1.fillStyle = '#ffffff'; x1.fillStyle = raw; x1.fillRect(0, 0, 1, 1);
        const p = x1.getImageData(0, 0, 1, 1).data; rgb = [p[0], p[1], p[2]];
    } catch (_) {}
    const lite = rgb.map(v => Math.round(v + (255 - v) * .55));
    const col = (c, a) => 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + Math.max(0, Math.min(1, a)).toFixed(3) + ')';

    // three layers of the SAME wave: each one a little smaller, brighter and a little behind the one outside it, so they read as one ribbon
    const LAYERS = [
        { D: 54, a1: 8,   n1: 8,  w1: .80, p1: 0,    a2: 3.5, n2: 13, w2: -.6, p2: 0,   al: .20, ln: 0,  rot: 0 },
        { D: 37, a1: 7,   n1: 8,  w1: .80, p1: -1.0, a2: 3,   n2: 13, w2: -.6, p2: .8,  al: .28, ln: .45, rot: 2.1 },
        { D: 21, a1: 5,   n1: 8,  w1: .80, p1: -2.0, a2: 2.5, n2: 13, w2: -.6, p2: 1.6, al: .38, ln: .75, rot: 4.2 }
    ];
    const TAU = Math.PI * 2, SOFT = 340, EDGE_R = 40;
    const SUB = [1, .74, .48], SUBA = [.40, .34, .30];   // each layer is filled three times, shallower each time: a soft fall-off inwards
    const NT = 28, NV = 70, NA = 10;                      // samples on a top/bottom side, on a left/right side, on a corner
    const SEGN = [NT, NA, NV, NA, NT, NA, NV, NA];
    const SEG = SEGN.reduce((a, v) => a + v, 0);
    let W = 0, H = 0, P = 0, S0 = 0, SC = .5;
    let edge = null, deep = null, U = null;   // the screen's own border ring; the inner ring of each layer; where each sample is along the ring (0..1)
    // a rounded rectangle, clockwise from the end of the top-left corner. Every ring has the same samples in the same places (a fixed number
    // on each side and each corner), so one ring can be blended into another without a fold, however round their corners are.
    function ring(inset, rad) {
        const x0 = inset, y0 = inset, w = W - 2 * inset, h = H - 2 * inset, k = Math.min(rad, w / 2, h / 2);
        const segs = [
            { t: 's', len: w - 2 * k, x: x0 + k, y: y0, dx: 1, dy: 0 },
            { t: 'a', len: Math.PI * k / 2, cx: x0 + w - k, cy: y0 + k, a0: -Math.PI / 2 },
            { t: 's', len: h - 2 * k, x: x0 + w, y: y0 + k, dx: 0, dy: 1 },
            { t: 'a', len: Math.PI * k / 2, cx: x0 + w - k, cy: y0 + h - k, a0: 0 },
            { t: 's', len: w - 2 * k, x: x0 + w - k, y: y0 + h, dx: -1, dy: 0 },
            { t: 'a', len: Math.PI * k / 2, cx: x0 + k, cy: y0 + h - k, a0: Math.PI / 2 },
            { t: 's', len: h - 2 * k, x: x0, y: y0 + h - k, dx: 0, dy: -1 },
            { t: 'a', len: Math.PI * k / 2, cx: x0 + k, cy: y0 + k, a0: Math.PI }
        ];
        const o = { x: new Float32Array(SEG), y: new Float32Array(SEG), nx: new Float32Array(SEG), ny: new Float32Array(SEG), len: 0 };
        let n = 0;
        for (let j = 0; j < segs.length; j++) {
            const s = segs[j];
            for (let c = 0; c < SEGN[j]; c++, n++) {
                const d = s.len * c / SEGN[j];
                if (s.t === 's') { o.x[n] = s.x + s.dx * d; o.y[n] = s.y + s.dy * d; o.nx[n] = -s.dy; o.ny[n] = s.dx; }   // inward normal of a clockwise path
                else { const a = s.a0 + (k ? d / k : 0); o.x[n] = s.cx + Math.cos(a) * k; o.y[n] = s.cy + Math.sin(a) * k; o.nx[n] = -Math.cos(a); o.ny[n] = -Math.sin(a); }
            }
            o.len += s.len;
        }
        return o;
    }
    function resize() {
        W = window.innerWidth; H = window.innerHeight;
        cv.width = Math.max(2, Math.round(W * SC)); cv.height = Math.max(2, Math.round(H * SC));
        edge = ring(0, EDGE_R);
        // the inner ring of each layer: pushed in by the layer's depth, with corners rounder than the screen's so the wave never folds over itself there
        deep = LAYERS.map(L => ring(L.D, EDGE_R + L.D * .9));
        P = edge.len;
        // where each sample is along the border (in px, then 0..1), and where the scan button is: its x on the top edge
        U = new Float32Array(SEG);
        let acc = 0;
        for (let i = 0; i < SEG; i++) { U[i] = acc / P; const j = (i + 1) % SEG; acc += Math.hypot(edge.x[j] - edge.x[i], edge.y[j] - edge.y[i]); }
        let best = 1e9; S0 = 0;
        for (let i = 0; i < SEG; i++) { const d = Math.hypot(edge.x[i] - ox, edge.y[i] - oy); if (d < best) { best = d; S0 = U[i]; } }
    }
    resize();
    const onResize = () => resize();
    window.addEventListener('resize', onResize);

    const ease = x => x <= 0 ? 0 : x >= 1 ? 1 : x * x * (3 - 2 * x);
    const easeOut = x => 1 - Math.pow(1 - Math.max(0, Math.min(1, x)), 3);
    const t0 = performance.now();
    let tEnd = 0, raf = 0, dead = false;
    const wv = new Float32Array(SEG), mm = new Float32Array(SEG), env = new Float32Array(SEG);

    function frame(now) {
        if (dead) return;
        const t = (now - t0) / 1000;
        const q = tEnd ? ease((now - tEnd) / LQ_WAVE_FADE_MS) : 0;       // 0 -> 1 while it sinks away
        // stage 2: how far the front has run from the button (in px along the border, each way); stage 3: slow rise and breathing
        const prog = easeOut(t / (LQ_WAVE_SPREAD_MS / 1000 - .2));
        const front = prog * (P / 2 + SOFT);
        const rise = .55 + .45 * ease(t / 3.2);
        const breath = 1 + .06 * Math.sin(t * 1.25);
        const gain = rise * breath * (1 - q);
        const aIn = ease(t / .7) * (1 - q * q);
        ctx.setTransform(SC, 0, 0, SC, 0, 0);
        ctx.clearRect(0, 0, W, H);
        ctx.globalCompositeOperation = 'source-over';

        // stage 1: the bloom at the scan button
        const bl = (1 - ease((t - .15) / 1.3)) * (1 - q);
        if (bl > .01) {
            const br = 40 + 150 * easeOut(t / 1.2);
            const g = ctx.createRadialGradient(ox, oy, 0, ox, oy, br);
            g.addColorStop(0, col(lite, .5 * bl)); g.addColorStop(.45, col(rgb, .2 * bl)); g.addColorStop(1, col(rgb, 0));
            ctx.fillStyle = g; ctx.fillRect(ox - br, oy - br, br * 2, br * 2);
        }

        // the envelope of every sample: 1 where the front has passed, 0 where it has not come yet
        for (let i = 0; i < SEG; i++) {
            let du = Math.abs(U[i] - S0); if (du > .5) du = 1 - du;
            env[i] = ease((front - du * P) / SOFT);
        }

        for (let li = 0; li < LAYERS.length; li++) {
            const L = LAYERS[li];
            // the shape of this layer: how far it is pushed in (0 = on the border, 1 = full depth) and the two ripples (a whole number of them round the ring, so the ends join)
            for (let i = 0; i < SEG; i++) {
                const e = env[i], u = U[i];
                mm[i] = Math.min(1.08, e * gain);
                wv[i] = (L.a1 * Math.sin(TAU * L.n1 * u - L.w1 * t + L.p1) + L.a2 * Math.sin(TAU * L.n2 * u - L.w2 * t + L.p2));
            }
            // colour that runs round the border: a lit patch travelling along the wave
            const cg = ctx.createConicGradient(t * .42 + L.rot, W / 2, H / 2);
            cg.addColorStop(0,   col(rgb, 1)); cg.addColorStop(.18, col(lite, 1)); cg.addColorStop(.38, col(rgb, .78));
            cg.addColorStop(.62, col(rgb, .95)); cg.addColorStop(.8, col(lite, 1)); cg.addColorStop(1, col(rgb, 1));
            for (let s = 0; s < SUB.length; s++) {
                ctx.beginPath();
                ctx.rect(-4, -4, W + 8, H + 8);
                ringPath(deep[li], SUB[s]);
                ctx.globalAlpha = Math.max(0, Math.min(1, L.al * SUBA[s] * 2 * aIn));
                ctx.fillStyle = cg;
                ctx.fill('evenodd');
            }
            // the lit edge of the two inner layers
            if (L.ln) {
                ctx.beginPath(); ringPath(deep[li], 1);
                ctx.globalAlpha = Math.max(0, Math.min(1, L.ln * aIn));
                ctx.strokeStyle = cg; ctx.lineWidth = 2; ctx.lineJoin = 'round'; ctx.stroke();
            }
        }
        ctx.globalAlpha = 1;
        raf = requestAnimationFrame(frame);
    }
    // a closed smooth path: every sample sits between the screen's border (mm = 0) and this layer's inner ring plus its ripple (mm = 1);
    // f < 1 gives the shallower copies that make the soft fall-off
    function ringPath(Dp, f) {
        const px = i => { const m = Math.min(1.08, mm[i] * f), ex = edge.x[i]; return ex + (Dp.x[i] + Dp.nx[i] * wv[i] - ex) * m; };
        const py = i => { const m = Math.min(1.08, mm[i] * f), ey = edge.y[i]; return ey + (Dp.y[i] + Dp.ny[i] * wv[i] - ey) * m; };
        ctx.moveTo((px(SEG - 1) + px(0)) / 2, (py(SEG - 1) + py(0)) / 2);
        for (let i = 0; i < SEG; i++) {
            const j = (i + 1) % SEG, xi = px(i), yi = py(i);
            ctx.quadraticCurveTo(xi, yi, (xi + px(j)) / 2, (yi + py(j)) / 2);
        }
        ctx.closePath();
    }
    raf = requestAnimationFrame(frame);
    requestAnimationFrame(() => requestAnimationFrame(() => root.classList.add('is-on')));

    let endP = null;
    const api = {
        spread: new Promise(res => setTimeout(res, LQ_WAVE_SPREAD_MS)),
        end() {
            if (endP) return endP;
            if (lqEdgeActive === api) lqEdgeActive = null;
            tEnd = performance.now();
            root.classList.add('is-off');
            endP = new Promise(res => setTimeout(() => {
                dead = true; cancelAnimationFrame(raf);
                window.removeEventListener('resize', onResize);
                root.remove(); res();
            }, LQ_WAVE_FADE_MS));
            return endP;
        }
    };
    lqEdgeActive = api;
    return api;
}
async function lqGameScanFlow(btn) {
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    // No loading popup: the waves are the loading. They start at the button and spread over the borders of the screen while the scan runs in
    // the backend; when the scan is over AND the waves have spread, they fade away, and only then comes the popup with what was found.
    const edge = lqEdgeGlow(btn);
    const scanP = (async () => { try { return String(await exec(pkgBackendScript('game', 'scan-games')) || ''); } catch (_) { return ''; } })();
    const out = await scanP;
    const ok = out.includes('__LQ_OK__');
    const m = out.match(/__LQ_LIST__\r?\n([\s\S]*?)\r?\n?__LQ_LIST_END__/);
    const list = ok && m ? normalizePkgLines(m[1]) : [];
    // while the waves finish (they spread, then fade), the names of the apps are looked up (the labels the app already knows, a short wait at most)
    const labelsP = list.length ? Promise.race([lqLabelsEnsure(list, 1500), sleep(1700)]).catch(() => {}) : Promise.resolve();
    await Promise.all([edge ? edge.spread.then(() => edge.end()) : sleep(200), labelsP]);
    const pop = lqGameScanPopup(btn);
    if (!ok || !list.length) {
        const r = out.match(/LQ_REASON:([^\n\r]*)/);
        const reason = r ? r[1].trim() : (out.includes('NO_BACKEND') ? 'The module backend was not found' : 'The scan did not finish');
        await new Promise(res => {
            pop.show(`<div class="pkg-title">Scan failed</div><div class="pkg-sub">${esc(reason)}</div><div class="lq-rec-modal-actions" style="grid-template-columns:1fr;margin-top:18px"><button class="lq-rec-modal-btn is-apply" style="border-radius:var(--split-out)" type="button">Close</button></div>`);
            const go = () => pop.close().then(res);
            pop.el.querySelector('.is-apply').addEventListener('click', go);
            pop.scrim(go);
        });
        return;
    }

    const rows = list.map(pkg => {
        const lab = lqLabels.map.get(pkg);
        return lab && lab !== pkg ? `<div class="lq-rec-modal-row"><b>${esc(lab)}</b><span>${esc(pkg)}</span></div>` : `<div class="lq-rec-modal-row"><b>${esc(pkg)}</b></div>`;
    }).join('');
    const n = list.length;
    pop.show(`<div class="pkg-title">Scan result</div><div class="pkg-sub">${n} ${n === 1 ? 'app' : 'apps'} found on this device. Replace writes them to the detected game list, Cancel leaves everything as it is.</div><div class="lq-rec-modal-list is-stacked lq-gs-list">${rows}</div><div class="lq-gs-note" hidden></div><div class="lq-rec-modal-actions"><button class="lq-rec-modal-btn is-skip" type="button">Cancel</button><button class="lq-rec-modal-btn is-apply" type="button">Replace</button></div>`);

    await new Promise(res => {
        const cancel = skip => { exec(pkgBackendScript('game', 'discard-games')).catch(() => {}); pop.close().then(res); };
        const bCancel = pop.el.querySelector('.is-skip'), bGo = pop.el.querySelector('.is-apply'), note = pop.el.querySelector('.lq-gs-note');
        let writing = false;
        bCancel.addEventListener('click', () => { if (!writing) cancel(); });
        pop.scrim(() => { if (!writing) cancel(); });
        bGo.addEventListener('click', async () => {
            if (writing) return;
            writing = true;
            bGo.disabled = true; bCancel.disabled = true; bGo.textContent = 'Writing…';
            let r = '';
            try { r = String(await exec(pkgBackendScript('game', 'commit-games')) || ''); } catch (_) {}
            if (r.includes('__LQ_OK__')) {
                await pop.close();
                try { lqToastShow({ title: 'Game list', text: `Replaced with ${n} ${n === 1 ? 'app' : 'apps'}`, state: 'ok' }); } catch (_) {}
                // the Game tab reads the new file
                pkgState.loaded.game = false;
                if (pkgState.active === 'game') switchPkgTab('game', { force: true, skipNavAnimation: true });
                res();
            } else {
                const rr = r.match(/LQ_REASON:([^\n\r]*)/);
                note.hidden = false; note.className = 'lq-gs-note is-err';
                note.textContent = rr ? rr[1].trim() : 'Could not write the list';
                writing = false; bGo.disabled = false; bCancel.disabled = false; bGo.textContent = 'Try again';
            }
        });
    });
}
document.addEventListener('click', e => {
    const btn = e.target.closest('#pkgScanBtn');
    if (!btn || lqGameScanBusy) return;
    lqGameScanBusy = true;
    lqGameScanFlow(btn).catch(() => {}).finally(() => { lqGameScanBusy = false; if (lqEdgeActive) lqEdgeActive.end(); });
});

let lqPowerBusy=false;
document.addEventListener('click',async e=>{
  const btn=e.target.closest('#forceStopBtn');
  if(!btn || lqPowerBusy) return;
  lqPowerBusy=true;
  try{
    const yes=await lqConfirmPopup(btn,{title:'Force stop all apps',text:'Closes every running app so changes like a new renderer apply to them. The screen blinks once.'});
    if(!yes) return;
    const toast=lqToastShow({title:'Force stop',text:'Closing apps…',state:'pending'});
    let ok=false;
    try{
      await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
      const r=await exec(tweaksBackend('soft-reboot'));
      ok=String(r||'').includes('__LQ_OK__');
    }catch(_){ ok=false; }
    lqDbg(`soft-reboot -> ${ok?'OK':'FAIL'}`);
    toast.update({state:ok?'ok':'err',text:ok?'Closing all apps':'Failed to start'});
  }finally{ lqPowerBusy=false; }
});

// Settings > System > Refresh WebUI: reloads the page. The icon makes one turn first so the tap is seen, then the page reloads.
let lqRefreshBusy=false;
document.addEventListener('click',e=>{
  const btn=e.target.closest('#refreshUiBtn');
  if(!btn || lqRefreshBusy) return;
  lqRefreshBusy=true;
  const ico=btn.querySelector('.lq-refresh-ico');
  if(ico && !lqReduced()){ ico.classList.remove('is-spin'); void ico.getBoundingClientRect(); ico.classList.add('is-spin'); }
  window.setTimeout(()=>{ try{ location.reload(); }catch(_){ lqRefreshBusy=false; } },lqReduced()?150:560);
});

let lqRecBusy=false;
function lqRecSetMode(mode,animate){
  const row=document.getElementById('recRow');
  const lbl=document.querySelector('#recApplyBtn .lq-rec-lbl');
  if(!row||!lbl) return;
  const text=mode==='applied'?'Revert':'Apply now';
  if(lbl.textContent!==text){
    lbl.textContent=text;
    if(animate && row.dataset.mode!=='idle'){ lbl.classList.remove('is-swap'); void lbl.offsetWidth; lbl.classList.add('is-swap'); }
  }
  row.dataset.mode=mode;
  document.getElementById('recApplyBtn')?.setAttribute('tabindex',mode==='idle'?'-1':'0');
}
// keeps the card in step with the saved state (boot value, full state refresh)
function lqRecSync(){
  const row=document.getElementById('recRow');
  if(!row||lqRecBusy) return;
  if(tweakState.perf_one_click_optimization==='1') lqRecSetMode('applied',false);
  else if(row.dataset.mode==='applied') lqRecSetMode('ready',false);
}
function lqRecLock(on){
  const row=document.getElementById('recRow');
  if(!row) return;
  lqRecBusy=on;
  row.toggleAttribute('aria-busy',on);
  if(on) row.setAttribute('aria-busy','true'); else row.removeAttribute('aria-busy');
  row.querySelectorAll('button').forEach(b=>{ b.disabled=on; });
}
async function lqRecApply(){
  const ok=await flashActionStatus(null, async()=>{
    const r=await lqApplyConfirmed('set-one-click-optimization','1',()=>fetchValueState('perf_one_click_optimization'),()=>tweakState.perf_one_click_optimization==='1');
    return r.ok;
  }, {label:'Recommended profile',okText:'Applied'});
  if(ok){
    tweakState.perf_one_click_optimization='1';
    lqRecSetMode('applied',true);
    // one backend call can change many groups, so pull a full state refresh
    await tweaksGetState().catch(()=>{});
    refreshSystemTuningUI();
    syncHelperToggle('helperFilyToggle','helper_fily');
    syncHelperToggle('helperTctlToggle','helper_tctl');
    syncFilyMultitaskingConflict();
  }else{
    lqRecSetMode('ready',true);
  }
}
async function lqRecRevert(){
  const ok=await flashActionStatus(null, async()=>{
    const r=await lqApplyConfirmed('set-one-click-optimization','0',()=>fetchValueState('perf_one_click_optimization'),()=>tweakState.perf_one_click_optimization==='0');
    return r.ok;
  }, {label:'Recommended profile',okText:'Reverted'});
  if(ok){
    tweakState.perf_one_click_optimization='0';
    lqRecSetMode('ready',true);
    await tweaksGetState().catch(()=>{});
    refreshSystemTuningUI();
    syncHelperToggle('helperFilyToggle','helper_fily');
    syncHelperToggle('helperTctlToggle','helper_tctl');
    syncFilyMultitaskingConflict();
  }
}

function wireOneClickOptimizationToggle(){
  const detectBtn=document.getElementById('recDetectBtn');
  const applyBtn=document.getElementById('recApplyBtn');
  if(!detectBtn||!applyBtn) return;
  detectBtn.addEventListener('click',async()=>{
    if(lqRecBusy) return;
    lqRecLock(true);
    try{
      const lines=await lqRecDetectRun(detectBtn);
      if(!lines){
        lqToastShow({title:'Recommended profile',text:'Detection failed',state:'err'});
      }else{
        const choice=await lqRecPopup(lines);
        if(choice==='apply') await lqRecApply();
        else lqRecSetMode(tweakState.perf_one_click_optimization==='1'?'applied':'ready',true);
      }
    }catch(_){
      lqToastShow({title:'Recommended profile',text:'Detection failed',state:'err'});
    }
    lqRecLock(false);
  });
  applyBtn.addEventListener('click',async()=>{
    if(lqRecBusy) return;
    const row=document.getElementById('recRow');
    if(!row||row.dataset.mode==='idle') return;
    lqRecLock(true);
    try{
      if(row.dataset.mode==='applied') await lqRecRevert(); else await lqRecApply();
    }catch(_){}
    lqRecLock(false);
  });
  lqRecSync();
}

async function wireExtraToggle(id,stateKey,cmd){
 const el=document.getElementById(id); if(!el)return;
 const row=el.closest('.lq-tweak-subrow');
 const titleEl=row?.querySelector('.lq-tweak-subtitle');
 const sync=()=>{const on=tweakState[stateKey]==='1';el.classList.toggle('on',on);el.setAttribute('aria-pressed',on?'true':'false');};
 el.addEventListener('click',async()=>{
   if(el.disabled)return;
   const next=tweakState[stateKey]==='1'?'0':'1';
   el.disabled=true;
   const ok=await flashActionStatus(titleEl, async()=>{
     try{ return await applyTweak(cmd,next); }catch(_){ return false; }
   }, {okText:next==='1'?'Enabled':'Disabled'});
   if(ok){await commitToggleVisual(el,()=>{tweakState[stateKey]=next;sync();});}
   el.disabled=false;
 });
 sync();
}


function renderSurfaceFlingerSlider(){if(typeof paintSurfaceFlinger==='function'){paintSurfaceFlinger(Number(tweakState.surface_flinger)||0);return;}const el=document.getElementById('surfaceFlingerSlider');if(!el)return;const raw=/^\d+$/.test(tweakState.surface_flinger)?Number(tweakState.surface_flinger):50;const v=Math.max(50,Math.min(100,raw));el.value=String(v);el.style.setProperty('--lq-progress',`${(v-50)/50}`);const out=document.getElementById('surfaceFlingerValue');if(out)out.textContent=`${v}%`;}

let traceModesExpanded=false;
function toggleTraceModes(){
 const body=document.getElementById('traceGuardBody');
 const card=document.getElementById('traceGuardCard');
 const btn=document.getElementById('traceGuardModeToggle');
 if(!body)return;
 const open=!body.classList.contains('is-open');
 traceModesExpanded=open;
 if(open){
   renderTraceModes();
 }
 body.classList.toggle('is-open',open);
 card?.classList.toggle('tk-modes-open',open);
 btn?.setAttribute('aria-expanded',open?'true':'false');
}
function renderTraceModes(){
 const root=document.getElementById('traceGuardModes');
 if(!root)return;
 const active=tweakState.trace_guard_preset;
 root.innerHTML=TK_PRESET_ORDER.map((p,i)=>`<button class="tk-mode-card ${active===p?'active':''}" style="--tk-i:${i}" type="button" data-trace-preset="${p}">
   <span class="tk-mode-copy">
     <span class="tk-mode-title-row"><span class="tk-mode-title">${TK_PRESET_META[p].title}</span><span class="tk-mode-count">${TK_PRESET_META[p].count}</span></span>
     <span class="tk-mode-desc">${TK_PRESET_META[p].desc}</span>
   </span>
 </button>`).join('');

 root.querySelectorAll('[data-trace-preset]').forEach(b=>b.addEventListener('click',async()=>{
   const p=b.dataset.tracePreset;
   if(b.classList.contains('is-applying'))return;

   if(p===tweakState.trace_guard_preset)return;

   const title=b.querySelector('.tk-mode-title');
   const all=root.querySelectorAll('[data-trace-preset]');
   all.forEach(x=>x.disabled=true);
   b.classList.add('is-applying');

   const myEpoch=++traceModeEpoch;
   traceModeBusy=true;

   await new Promise(requestAnimationFrame);
   await new Promise(requestAnimationFrame);

   const previousPreset=tweakState.trace_guard_preset;
   let traceRes={ok:false,confirmed:false};
   const ok=await flashActionStatus(title, async()=>{
     traceRes=await lqApplyConfirmed('set-trace-preset',p,()=>fetchValueState('trace_guard_preset'),()=>tweakState.trace_guard_preset===p);
     return traceRes.ok;
   }, {label:'Trace Guard',okText:`${TK_PRESET_META[p].title} applied`});

   if(myEpoch===traceModeEpoch){
      // confirmed read-back already put the backend's preset into tweakState
      if(ok) tweakState.trace_guard_preset=p;
      else if(!traceRes.confirmed) tweakState.trace_guard_preset=previousPreset;
      await refreshTraceCount();
   }

   traceModeBusy=false;
   all.forEach(x=>x.disabled=false);
   // Re-rendering the preset cards replaces the focused button. On Android WebView
   // that can trigger scroll anchoring/focus correction and make the Trace Guard
   // list jump after apply. Preserve the main content scroll position across the
   // re-render instead of letting the browser choose a new anchor.
   const mainScroll=document.querySelector('.main-content');
   const savedScrollTop=mainScroll?.scrollTop ?? 0;
   renderTraceModes();
   if(mainScroll){
     mainScroll.scrollTop=savedScrollTop;
     requestAnimationFrame(()=>requestAnimationFrame(()=>{ mainScroll.scrollTop=savedScrollTop; }));
   }
 }));
}
function paintTraceCount(){
 const el=document.getElementById('traceGuardActiveCount');
 if(el)el.textContent=`${tweakState.trace_guard_count||0} / ${TRACE_ITEM_COUNT}`;
}
async function refreshTraceCount(){
 const raw=await exec(`sh /data/local/tmp/liqinghe/tweaks.sh trace-count 2>/dev/null`);
 const n=parseInt(String(raw||'0').trim(),10);
 if(Number.isFinite(n)){
   tweakState.trace_guard_count=String(Math.max(0,Math.min(TRACE_ITEM_COUNT,n)));
   paintTraceCount();
 }
}
function traceEsc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);}

// Multitasking keeps its five presets (levels). Every other slider is free inside
// a safe range (min / max / step) instead of a few fixed steps, so any value in the
// range can be picked; the backend enforces the same ranges.
const SYSTEM_TUNING_SLIDERS={
  'job-scheduler':[{key:'max_job_count_active',title:'Active Job Limit',unit:' jobs',range:{min:24,max:120,step:2},defaultValue:72}],
  'multitasking':[{key:'preset',title:'Multitasking',unit:'',levels:['lowest','low','medium','high','highest'],labelMap:{lowest:'Lowest',low:'Low',medium:'Medium',high:'High',highest:'Highest'},defaultValue:'medium'}],
  'sqlite-tuning':[
    {key:'wal_checkpoint',title:'WAL Checkpoint',unit:' pages',range:{min:16,max:512,step:4},defaultValue:56},
    {key:'journal_size',title:'Journal Size',unit:' KB',fmt:v=>Math.round(Number(v)/1024),range:{min:65536,max:2097152,step:4096},defaultValue:229376}
  ],
  'app-standby':[{key:'strong_usage_duration',title:'Strong Usage Duration',unit:' h',fmt:v=>Math.round(Number(v)/3600000),range:{min:3600000,max:259200000,step:3600000},defaultValue:43200000}],
  'low-swap':[{key:'threshold_percent',title:'Low Swap Threshold',unit:'%',fmt:v=>Math.round(Number(v)*100),range:{min:0.05,max:1,step:0.05},defaultValue:'0.50'}],
  'long-press-latency':[{key:'timeout_ms',title:'Long-Press Timeout',unit:' ms',range:{min:150,max:800,step:5},defaultValue:350}]
};
// Helpers: values are compared in a normalised form (range sliders: clamped and
// snapped to the step; multitasking: always a preset name, a number saved by an
// earlier build is snapped to the nearest preset).
function stSnapPreset(s){
  if(['lowest','low','medium','high','highest'].includes(s)) return s;
  const n=Number(s); if(!Number.isFinite(n)) return s;
  return n<0.625?'lowest':n<0.875?'low':n<1.125?'medium':n<1.375?'high':'highest';
}
function stAttrs(def){ return def.range?{min:def.range.min,max:def.range.max,step:def.range.step}:{min:0,max:def.levels.length-1,step:1}; }
function stNorm(def,v){
  if(v===undefined||v===null) return '';
  const s=String(v).trim(); if(s==='') return '';
  if(def.range){
    const r=def.range; let n=Number(s); if(!Number.isFinite(n)) return '';
    n=Math.min(r.max,Math.max(r.min,n));
    n=Math.min(r.max,r.min+Math.round((n-r.min)/r.step)*r.step);
    return r.step<1?n.toFixed(2):String(Math.round(n));
  }
  return stSnapPreset(s);
}
// slider position <-> value
function stValueAt(def,pos){ return def.range?stNorm(def,pos):def.levels[Math.max(0,Math.min(def.levels.length-1,Math.round(Number(pos)||0)))]; }
function stFromInput(def,input){ return stValueAt(def,input?.value); }
function stToInput(def,raw){
  const n=stNorm(def,raw); if(n==='') return null;
  return def.range?Number(n):def.levels.indexOf(n);
}
function stProgress(def,pos){ const a=stAttrs(def); return a.max>a.min?(pos-a.min)/(a.max-a.min):0; }
function stLabelFor(def,val){
  if(def.labelMap && def.labelMap[val]) return def.labelMap[val];
  return String(def.fmt?def.fmt(val):val);
}
function systemTuningFindWrap(group,row){
  return row?.parentElement?.classList.contains('lq-system-tuning-item')
    ? row.parentElement.querySelector(`[data-system-tuning-values="${group}"]`)
    : row?.querySelector(`[data-system-tuning-values="${group}"]`);
}
function systemTuningSliderHTML(group, row){
  const defs=SYSTEM_TUNING_SLIDERS[group];
  if(!defs || !row) return;
  let wrap=systemTuningFindWrap(group,row);
  if(!wrap){
    const item=document.createElement('div');
    item.className='lq-system-tuning-item';
    row.parentNode.insertBefore(item,row);
    item.appendChild(row);
    wrap=document.createElement('div');
    wrap.className='ui-settings-expand-wrap lq-system-tuning-values';
    wrap.dataset.systemTuningValues=group;
    wrap.innerHTML='<div class="ui-settings-expand"><div class="ui-settings-expand-inner lq-system-slider-expand-inner"></div></div>';
    item.appendChild(wrap);
  }
  const inner=wrap.querySelector('.ui-settings-expand-inner');
  if(!inner) return wrap;
  inner.innerHTML='';
  defs.forEach(def=>{
    const at=stAttrs(def);
    const line=document.createElement('div');
    line.className='lq-system-slider-row';
    line.innerHTML=`<div class="lq-system-slider-head"><span>${def.title}</span><b data-system-value="${group}:${def.key}">N/A</b></div><input type="range" class="lq-range-native lq-system-slider" min="${at.min}" max="${at.max}" step="${at.step}" value="${at.min}" data-system-slider-group="${group}" data-system-slider-key="${def.key}">`;
    inner.appendChild(line);
  });
  const actions=document.createElement('div');
  actions.className='lq-system-slider-actions';
  actions.innerHTML='<button class="ui-custom-apply lq-system-apply" type="button">Apply</button><button class="ui-custom-apply lq-system-reset" type="button">Reset</button>';
  inner.appendChild(actions);
  return wrap;
}
function systemTuningSetVisual(group,row,active){
  const wrap=systemTuningFindWrap(group,row); if(!wrap) return;
  wrap.classList.toggle('is-open',!!active);
}
function systemTuningRecommendedValue(group,def){
  const key=`recommended_value_${group.replace(/-/g,'_')}_${def.key}`;
  const raw=tweakState[key];
  return raw!==undefined && raw!==null && String(raw)!=='' ? String(raw) : String(def.defaultValue);
}
function systemTuningUpdateButtons(group,row,wrap){
  const defs=SYSTEM_TUNING_SLIDERS[group]; if(!defs || !wrap) return;
  const active=tweakState[`perf_${group.replace(/-/g,'_')}`]==='1';
  const applyBtn=wrap.querySelector('.lq-system-apply');
  const resetBtn=wrap.querySelector('.lq-system-reset');
  const getAppliedValue=(def)=>{
    const raw=tweakState[`value_${group.replace(/-/g,'_')}_${def.key}`];
    const n=stNorm(def,raw);
    return n!=='' && (def.range || def.levels.includes(n)) ? n : stNorm(def,systemTuningRecommendedValue(group,def));
  };
  const sameAsApplied=defs.every(def=>{
    const input=wrap.querySelector(`[data-system-slider-key="${def.key}"]`);
    const pending=input ? stFromInput(def,input) : undefined;
    return stNorm(def,pending)===getAppliedValue(def);
  });
  const appliedDiffersFromDefaults=defs.some(def=>getAppliedValue(def)!==stNorm(def,systemTuningRecommendedValue(group,def)));
  if(applyBtn){
    const disabled=!active || sameAsApplied || applyBtn.classList.contains('is-applying') || resetBtn?.classList.contains('is-applying');
    applyBtn.disabled=disabled;
    applyBtn.setAttribute('aria-disabled',disabled?'true':'false');
    applyBtn.style.pointerEvents=disabled?'none':'auto';
  }
  if(resetBtn){
    const disabled=!active || !appliedDiffersFromDefaults || resetBtn.classList.contains('is-applying') || applyBtn?.classList.contains('is-applying');
    resetBtn.disabled=disabled;
    resetBtn.setAttribute('aria-disabled',disabled?'true':'false');
    resetBtn.style.pointerEvents=disabled?'none':'auto';
  }
}
function systemTuningSyncSliders(group,row){
  const defs=SYSTEM_TUNING_SLIDERS[group]; if(!defs) return;
  let wrap=systemTuningFindWrap(group,row);
  if(!wrap) wrap=systemTuningSliderHTML(group,row);
  if(!wrap) return;
  const active=tweakState[`perf_${group.replace(/-/g,'_')}`]==='1';
  wrap.classList.toggle('is-open',active);
  defs.forEach(def=>{
    const raw=tweakState[`value_${group.replace(/-/g,'_')}_${def.key}`];
    let pos=stToInput(def,raw);
    if(pos===null||pos<0) pos=stToInput(def,systemTuningRecommendedValue(group,def));
    if(pos===null||pos<0) pos=stAttrs(def).min;
    const input=wrap.querySelector(`[data-system-slider-key="${def.key}"]`);
    const out=wrap.querySelector(`[data-system-value="${group}:${def.key}"]`);
    if(input && document.activeElement!==input) input.value=String(pos);
    if(input) input.style.setProperty('--lq-progress',`${stProgress(def,pos)}`);
    if(out) out.textContent=stLabelFor(def,stValueAt(def,pos))+def.unit;
  });
  systemTuningUpdateButtons(group,row,wrap);
}
async function systemTuningApply(group,row,values,action='apply'){
  const defs=SYSTEM_TUNING_SLIDERS[group]; if(!defs || !row) return false;
  const wrap=systemTuningFindWrap(group,row); if(!wrap) return false;
  const applyBtn=wrap.querySelector('.lq-system-apply');
  const resetBtn=wrap.querySelector('.lq-system-reset');
  const buttons=[applyBtn,resetBtn].filter(Boolean);
  buttons.forEach(b=>{b.disabled=true;b.classList.add('is-applying');});
  const stTitle=(row.querySelector('.lq-tweak-subtitle')?.textContent||group).trim();
  const stToast=lqToastShow({title:stTitle,text:action==='reset'?'Resetting…':(lqExecPending>0?'Queued…':'Applying…'),state:'pending'});
  await new Promise(requestAnimationFrame);
  let ok=true;
  try{
    // One exec() call for the whole group (all its fields), instead of one
    // exec() per field -- each exec() is a full root-shell round-trip, the
    // real cost on a throttled device, and each used to also trigger its
    // own separate _Y rebuild.
    const resolved=defs.map(def=>({def, value: values?.[def.key] ?? systemTuningRecommendedValue(group,def)}));
    const parts=resolved.flatMap(({def,value})=>[def.key,value]);
    const vKey=def=>`value_${group.replace(/-/g,'_')}_${def.key}`;
    // apply, then read the group's values back and compare them (normalised) with what was asked
    const r=await lqApplyConfirmed('set-extra-values',`${group} ${parts.join(' ')}`,
      ()=>fetchGroupState(group),
      ()=>resolved.every(({def,value})=>stNorm(def,tweakState[vKey(def)])===stNorm(def,value)));
    if(r.ok){
      // confirmed: tweakState holds the backend's values; only without a read-back use the asked ones
      if(!r.confirmed) resolved.forEach(({def,value})=>{ tweakState[vKey(def)]=String(value); });
    } else {
      ok=false;
    }
    // NOTE: previously did a full `tweaksGetState()` (tweaks.sh check-state)
    // refresh here after every apply. check-state re-scans idle profile,
    // surface flinger, trace guard, driver/helper state, and *all* system
    // tuning groups/values via several shell exec round-trips, very slow
    // on the WebUI exec bridge, even though we only changed one group's
    // value(s). The values just applied are already written into
    // tweakState above, so the UI stays in sync without the extra
    // round-trip and without needing to reopen the WebUI.
  }catch(_){ok=false;}
  stToast.update({state:ok?'ok':'err',text:ok?(action==='reset'?'Reset to default':'Values applied'):'Failed to apply'});
  buttons.forEach(b=>b.classList.remove('is-applying'));
  systemTuningSyncSliders(group,row);
  return ok;
}
function systemTuningDefaultValues(group){
  const defs=SYSTEM_TUNING_SLIDERS[group]; if(!defs) return {};
  const out={};
  defs.forEach(def=>{out[def.key]=systemTuningRecommendedValue(group,def);});
  return out;
}
function wireSystemTuningSliders(group,row){
  const defs=SYSTEM_TUNING_SLIDERS[group]; if(!defs) return;
  let wrap=systemTuningFindWrap(group,row);
  if(!wrap || !wrap.querySelector('.lq-system-slider')) wrap=systemTuningSliderHTML(group,row);
  defs.forEach(def=>{
    const input=wrap?.querySelector(`[data-system-slider-key="${def.key}"]`); if(!input || input.dataset.wired==='1') return;
    input.dataset.wired='1';
    input.addEventListener('input',()=>{
      const pos=Number(input.value);
      input.style.setProperty('--lq-progress',`${stProgress(def,pos)}`);
      const out=wrap.querySelector(`[data-system-value="${group}:${def.key}"]`); if(out) out.textContent=stLabelFor(def,stValueAt(def,pos))+def.unit;
      systemTuningUpdateButtons(group,row,wrap);
    });
  });
  const applyBtn=wrap?.querySelector('.lq-system-apply');
  const resetBtn=wrap?.querySelector('.lq-system-reset');
  if(applyBtn && applyBtn.dataset.wired!=='1'){
    applyBtn.dataset.wired='1';
    applyBtn.addEventListener('click',async()=>{
      if(tweakState[`perf_${group.replace(/-/g,'_')}`]!=='1' || applyBtn.classList.contains('is-applying')) return;
      const values={};
      defs.forEach(def=>{const input=wrap.querySelector(`[data-system-slider-key="${def.key}"]`);values[def.key]=stFromInput(def,input);});
      await systemTuningApply(group,row,values,'apply');
    });
  }
  if(resetBtn && resetBtn.dataset.wired!=='1'){
    resetBtn.dataset.wired='1';
    resetBtn.addEventListener('click',async()=>{
      if(tweakState[`perf_${group.replace(/-/g,'_')}`]!=='1' || resetBtn.classList.contains('is-applying')) return;
      const values=systemTuningDefaultValues(group);
      defs.forEach(def=>{
        let pos=stToInput(def,values[def.key]);
        if(pos===null||pos<0) pos=stAttrs(def).min;
        const input=wrap.querySelector(`[data-system-slider-key="${def.key}"]`);
        const out=wrap.querySelector(`[data-system-value="${group}:${def.key}"]`);
        if(input){
          input.value=String(pos);
          input.style.setProperty('--lq-progress',`${stProgress(def,pos)}`);
        }
        if(out) out.textContent=stLabelFor(def,stValueAt(def,pos))+def.unit;
      });
      await systemTuningApply(group,row,values,'reset');
    });
  }
  systemTuningSyncSliders(group,row);
}

function wireExtraGroupToggle(id, group){
  const el=document.getElementById(id);
  if(!el) return;
  // Mark every System Tuning toggle so the init-time backend resync can
  // restore both slider-backed and plain toggles from check-state.
  el.setAttribute('data-system-tuning-toggle-group',group);
  const stateKey=`perf_${group.replace(/-/g,'_')}`;
  const row=el.closest('.lq-tweak-subrow');
  const titleEl=row?.querySelector('.lq-tweak-subtitle');
  const subEl=row?.querySelector('.pkg-sub');
  const originalTitle=titleEl?.textContent || '';
  const originalSub=subEl?.textContent || '';
  const sync=()=>{
    const on=tweakState[stateKey]==='1';
    el.classList.toggle('on',on);
    el.setAttribute('aria-pressed',on?'true':'false');
    if(group==='multitasking') syncFilyMultitaskingConflict();
  };
  const disableUnsupported=(message)=>{
    el.disabled=true;
    el.classList.remove('on');
    el.setAttribute('aria-pressed','false');
    el.setAttribute('aria-disabled','true');
    row?.classList.add('lq-tweak-unsupported');
    if(subEl) subEl.textContent=message;
  };
  if(group==='oem-tuning'){
    exec('echo "$(getprop ro.product.manufacturer) $(getprop ro.product.brand) $(getprop ro.product.system.brand) $(getprop ro.product.vendor.brand)" 2>/dev/null').then(raw=>{
      const maker=String(raw||'').trim().toLowerCase();
      const supported=/xiaomi|redmi|poco|samsung/.test(maker);
      if(!supported){
        disableUnsupported('Not supported on this device. OEM tuning is available for Xiaomi/Redmi/POCO and Samsung only.');
        return;
      }
      el.removeAttribute('aria-disabled');
      sync();
    }).catch(()=>disableUnsupported('OEM validation failed; toggle disabled for safety.'));
  }
  el.addEventListener('click',async evt=>{
    evt.preventDefault();
    evt.stopPropagation();
    if(el.disabled || el.dataset.busy==='1') return;
    if(group==='multitasking' && tweakState[stateKey]!=='1' && tweakState.helper_fily==='1') return;
    const next=tweakState[stateKey]==='1'?'0':'1';
    const previous=tweakState[stateKey];
    el.dataset.busy='1';
    el.setAttribute('aria-busy','true');
    // On first activation, use the device-specific recommended value unless
    // the user has already selected a genuine manual override.
    if(next==='1' && SYSTEM_TUNING_SLIDERS[group]){
     try{
      const defs=SYSTEM_TUNING_SLIDERS[group];
      const wrap=systemTuningFindWrap(group,row);
      const hasManualValue=defs.some(def=>{
        const raw=tweakState[`value_${group.replace(/-/g,'_')}_${def.key}`];
        if(raw===undefined || raw===null || raw==='') return false;
        const rec=systemTuningRecommendedValue(group,def);
        return stNorm(def,raw)!==stNorm(def,def.defaultValue) && stNorm(def,raw)!==stNorm(def,rec);
      });
      if(!hasManualValue){
        defs.forEach(def=>{
          const rec=systemTuningRecommendedValue(group,def);
          const pos=stToInput(def,rec);
          const input=wrap?.querySelector(`[data-system-slider-key="${def.key}"]`);
          if(input) input.value=String(pos===null||pos<0?stAttrs(def).min:pos);
        });
      }
      systemTuningSyncSliders(group,row);
     }catch(_){}
    }
    try{
      let res={ok:false,confirmed:false};
      const ok=await flashActionStatus(titleEl, async()=>{
        // apply, then read the group back: the toggle AND its slider values (the
        // recommended value used on first activation) come from the backend.
        res=await lqApplyConfirmed('set-extra-group',`${group} ${next}`,()=>fetchGroupState(group),()=>tweakState[stateKey]===next);
        return res.ok;
      }, {label:originalTitle,okText:next==='1'?'Enabled':'Disabled'});
      if(ok){
        await commitToggleVisual(el,()=>{
          tweakState[stateKey]=next;
          sync();
          systemTuningSetVisual(group,row,next==='1');
          systemTuningSyncSliders(group,row);
        });
      }else{
        if(!res.confirmed) tweakState[stateKey]=previous;
        sync();
        systemTuningSetVisual(group,row,tweakState[stateKey]==='1');
        systemTuningSyncSliders(group,row);
      }
    }catch(_){
      await fetchGroupState(group).catch(()=>{});
      sync();
      systemTuningSetVisual(group,row,tweakState[stateKey]==='1');
      systemTuningSyncSliders(group,row);
    }finally{
      el.removeAttribute('aria-busy');
      el.dataset.busy='';
    }
  });
  systemTuningSyncSliders(group,row);
  wireSystemTuningSliders(group,row);
  sync();
}

function initExtraPerfAccordion(){
  // One independent accordion per System Tuning category card.
  document.querySelectorAll('.lq-system-tuning-card, .lq-acc-card').forEach(card=>{
    const summary=card.querySelector(':scope > .ui-settings-summary');
    const wrap=card.querySelector(':scope > .ui-settings-expand-wrap');
    if(!summary||!wrap)return;
    summary.addEventListener('click',()=>{
      const open=summary.getAttribute('aria-expanded')==='true';
      const next=!open;
      summary.setAttribute('aria-expanded',String(next));
      wrap.classList.toggle('is-open',next);
    });
  });
}

function initTweaksPage(){
  initExtraPerfAccordion();
  wireExtraGroupToggle('perfJobSchedulerToggle','job-scheduler');
  wireExtraGroupToggle('perfMultitaskingToggle','multitasking');
  wireExtraGroupToggle('perfSqliteToggle','sqlite-tuning');
  wireExtraGroupToggle('perfAppStandbyToggle','app-standby');
  wireExtraGroupToggle('perfLowSwapToggle','low-swap');
  wireExtraGroupToggle('perfPersistLogToggle','persist-log-tags');
  wireExtraGroupToggle('perfLoggingToggle','logging-diagnostics');
  wireExtraGroupToggle('perfDiagnosticsToggle','selected-diagnostics');
  wireExtraGroupToggle('perfDebugPropsToggle','debug-props');
  wireExtraGroupToggle('perfDozeToggle','doze');
  wireExtraGroupToggle('perfLongPressToggle','long-press-latency');
  wireExtraGroupToggle('perfOemToggle','oem-tuning');
  wireExtraGroupToggle('perfKeyboardToggle','compile-keyboard');
 wireHelperToggle('helperFilyToggle','helper_fily','set-helper-fily');
 wireHelperToggle('helperTctlToggle','helper_tctl','set-helper-tctl');
 wireOneClickOptimizationToggle();
 const idleButtons=[...document.querySelectorAll('[data-idle-profile]')];
 idleButtons.forEach(button=>{
   button.addEventListener('click',async()=>{
     if(button.classList.contains('is-locked')) return;
     const target=button.dataset.idleProfile;
     const previous=tweakState.idle_profile;
     if(target===previous) return;

     idleButtons.forEach(b=>b.classList.add('is-locked'));
     button.setAttribute('aria-busy','true');

     const idleName=(button.querySelector('b')?.textContent||'').trim()||'Idle profile';
     const idleToast=lqToastShow({title:'Idle Profile',text:lqExecPending>0?'Queued…':'Applying…',state:'pending'});
     await new Promise(requestAnimationFrame);

     let ok=false, confirmed=false;
     try{
       const res=await lqApplyConfirmed('set-idle-profile',target,()=>fetchValueState('idle_profile'),()=>tweakState.idle_profile===target);
       ok=res.ok; confirmed=res.confirmed;
     }catch(_){ ok=false; }

     // what the backend reports wins; only without a read-back do we fall back
     const resolved=confirmed?String(tweakState.idle_profile):(ok?target:previous);
     tweakState.idle_profile=resolved;
     lqDashProfilePaint();


     idleButtons.forEach(b=>b.classList.toggle('active',b.dataset.idleProfile===resolved));

     if(ok){
       renderSurfaceFlingerSlider();
       syncPerformanceExtraToggles();
       paintTraceCount();
       if(traceModesExpanded) renderTraceModes();
     }

     idleToast.update({state:ok?'ok':'err',text:ok?`${idleName} applied`:'Failed to apply'});

     button.removeAttribute('aria-busy');
     idleButtons.forEach(b=>b.classList.remove('is-locked'));
   });
 });
 const fp=document.getElementById('surfaceFlingerSlider');
 const fpApply=document.getElementById('surfaceFlingerApply');
 const fpReset=document.getElementById('surfaceFlingerReset');
 let pendingSurfaceFlinger=50;
 // True once the user has actually dragged the slider since the last time
 // SF was confirmed off. This is real, persistent state -- NOT a one-shot
 // function argument -- specifically because a one-shot argument gets
 // forgotten by every later no-arg resync call (that was the bug: after
 // Reset finished, a trailing bare `syncSurfaceFlingerButtons()` call had
 // no way to remember "we just went off" and wrongly re-enabled Apply).
 let sfTouchedSinceOff=false;

 // Single source of truth for both SF buttons' enabled/disabled state.
 // Every place that can change what these buttons should show (slider
 // drag, apply/reset start/success/fail, any full-state resync from
 // renderTweaksUI) MUST funnel through this instead of writing
 // `.disabled` directly -- that ad-hoc duplication across half a dozen
 // spots is exactly what let Apply/Reset drift out of sync with the
 // real state before. Takes no argument on purpose: everything it needs
 // (tweakState.surface_flinger, pendingSurfaceFlinger, sfTouchedSinceOff,
 // each button's own `is-applying` busy flag) is already persistent
 // state, so calling it bare from anywhere always recomputes correctly.
 const syncSurfaceFlingerButtons=()=>{
   const current=tweakState.surface_flinger;
   const currentOn=/^(?:5[0-9]|[6-9][0-9]|100)$/.test(String(current));
   const applyBusy=fpApply?.classList.contains('is-applying');
   const resetBusy=fpReset?.classList.contains('is-applying');
   const anyBusy=applyBusy||resetBusy; // either in flight locks both, avoids racing apply against reset

   if(fpApply){
     const unchanged=currentOn && Number(pendingSurfaceFlinger)===Number(current);
     const disabled=(!currentOn && !sfTouchedSinceOff)||unchanged||anyBusy;
     fpApply.disabled=disabled;
     fpApply.setAttribute('aria-disabled',disabled?'true':'false');
   }
   if(fpReset){
     const disabled=!currentOn||anyBusy;
     fpReset.disabled=disabled;
     fpReset.setAttribute('aria-disabled',disabled?'true':'false');
     fpReset.style.pointerEvents=disabled?'none':'auto';
   }
 };

 const paintSurfaceFlinger=(v,fromUserInput)=>{
   const raw=Number(v);
   const off=!Number.isFinite(raw)||raw===0;
   const value=Math.max(50,Math.min(100,off?50:raw));
   pendingSurfaceFlinger=value;
   if(off){
     sfTouchedSinceOff=false; // fresh off-state paint (initial load, or right after Reset) resets the baseline
   }else if(fromUserInput){
     sfTouchedSinceOff=true; // user deliberately picked a % while off -- let them turn SF on at that value
   }
   if(fp){
     fp.value=String(value);
     fp.style.setProperty('--lq-progress',`${(value-50)/50}`);
   }
   const out=document.getElementById('surfaceFlingerValue');
   if(out) out.textContent=off?'Off':`${value}%`;
   syncSurfaceFlingerButtons();
 };
 fp?.addEventListener('input',()=>paintSurfaceFlinger(fp.value,true));
 fpApply?.addEventListener('click',async()=>{
   const value=String(pendingSurfaceFlinger);
   fpApply.classList.add('is-applying');
   syncSurfaceFlingerButtons();
   const sfToast=lqToastShow({title:'Surface Flinger',text:lqExecPending>0?'Queued…':'Applying…',state:'pending'});
   let ok=false;
   try{
     await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
     ok=(await lqApplyConfirmed('set-surface-flinger',value,()=>fetchValueState('surface_flinger'),()=>String(tweakState.surface_flinger)===String(value))).ok;
   }catch(_){ ok=false; }
   if(ok){
     tweakState.surface_flinger=value;
     paintSurfaceFlinger(Number(value));
   }else{
     paintSurfaceFlinger(Math.max(50,Math.min(100,Number(tweakState.surface_flinger)||50)));
   }
   sfToast.update({state:ok?'ok':'err',text:ok?`Set to ${value}%`:'Failed to apply'});
   fpApply.classList.remove('is-applying');
   syncSurfaceFlingerButtons();
 });
 paintSurfaceFlinger(Number(tweakState.surface_flinger)||0);
 fpReset?.addEventListener('click',async()=>{
   if(fpReset.classList.contains('is-applying') || Number(tweakState.surface_flinger)<=0)return;
   fpReset.classList.add('is-applying');
   syncSurfaceFlingerButtons();
   const sfrToast=lqToastShow({title:'Surface Flinger',text:'Resetting…',state:'pending'});
   let ok=false;
   try{
     await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
     ok=(await lqApplyConfirmed('reset-surface-flinger','',()=>fetchValueState('surface_flinger'),()=>String(tweakState.surface_flinger)==='0')).ok;
     if(ok){
       tweakState.surface_flinger='0';
       paintSurfaceFlinger(0);
     }else{
       await fetchValueState('surface_flinger').catch(()=>{});
       paintSurfaceFlinger(Number(tweakState.surface_flinger)||0);
     }
     sfrToast.update({state:ok?'ok':'err',text:ok?'Reset to default':'Failed to reset'});
   }catch(_){
     await fetchValueState('surface_flinger').catch(()=>{});
     paintSurfaceFlinger(Number(tweakState.surface_flinger)||0);
     sfrToast.update({state:'err',text:'Failed to reset'});
   }finally{
     fpReset.classList.remove('is-applying');
     syncSurfaceFlingerButtons();
   }
 });
 lqBootStep('tweakState','run');
 lqBootTrack(lqLoadTweakStateVerified().then(ok=>{
   lqBootStep('tweakState',ok?'ok':'warn',ok?null:'retrying in background');
   // only paint what the backend really answered; if it never did, the controls
   // stay locked (lq-sync-pending) and the quiet retry paints the moment it does
   if(ok) lqPaintTweakStateAll();
   else lqTweakStateRecover();
 }));
 document.getElementById('traceGuardModeToggle')?.addEventListener('click',toggleTraceModes);
}

function syncPerformanceExtraToggles(){
 if(typeof lqRecSync==="function") lqRecSync();
}
function renderTweaksUI(){
 lqDashProfilePaint();
 document.querySelectorAll('[data-idle-profile]').forEach(b=>b.classList.toggle('active',b.dataset.idleProfile===tweakState.idle_profile));
 renderSurfaceFlingerSlider();
 syncPerformanceExtraToggles();
 if(traceModesExpanded)renderTraceModes();
 paintTraceCount();
 try{ lqDispPaint(); lqDispProbe(); }catch(_){}
}
// ── Package list ────────────────────────────────────────────
const LQ_USERPKG_EXTRA_FILE = '/data/local/tmp/liqinghe/userpkg_extra.txt';
const pkgSources = {
    user:      { file:'/data/local/tmp/liqinghe/userpkg.txt' },
    game:      { file:'/data/local/tmp/liqinghe/gamelist.txt' },
    preload:   { file:'/data/local/tmp/liqinghe/prelist.txt' },
    whitelist: { file:'/data/local/tmp/liqinghe/whitelist.txt' }
};

// Two-path source for the "game" tab:
//   path 1 (default): the module's own gamelist.txt, mirrored as-is to
//     pkgSources.game.file above -- kept pure/original, never edited here.
//   path 2 (preferred when present): the WebUI game scan's detection pass
//     (query-activities scan), written to a SEPARATE file so it can never
//     clobber the original gamelist.
// Read-time rule: if the game scan's result file exists (and has content),
// show that; otherwise fall back to the original gamelist untouched.
const LQ_GAME_DETECTED_FILE = '/data/local/tmp/liqinghe/gamelist_detected.txt';

const pkgActions = {
    game:      { label:'Game', file:pkgSources.game.file },
    preload:   { label:'Preload', file:pkgSources.preload.file },
    whitelist: { label:'Whitelist', file:pkgSources.whitelist.file }
};

const pkgNavDrag = {
    pointerId: null,
    holdTimer: null,
    dragging: false,
    suppressClick: false,
    startX: 0,
    pointerOffset: 0,
    baseIndex: 0,
    baseX: 0,
    targetIndex: 0,
    scaleTimer: null,
    lastXScale: 1.045,
    lastYScale: 1.045,
    lastX: 0
};

const pkgState = {
    active: 'user',
    query: '',
    expanded: null,
    data: { user: [], game: [], preload: [], whitelist: [] },
    // packages typed in by hand on the User tab that the detector missed
    userCustom: [],
    preloadModes: {},
    loaded: { user:false, game:false, preload:false, whitelist:false },
    busy: new Set(),
    renderToken: 0,
    navAnimToken: 0,
    searchFrame: 0,
    // 'detected' when the Game tab is showing the game scan's
    // detection results, 'bawaan' when it's still the module's bundled
    // gamelist.txt. Per-package driver toggles only make sense (and are
    // only shown) for 'detected' -- the bundled list is a static catalog
    // of known games, not necessarily anything actually installed.
    gameSource: null,
    // pkg -> {gfxdriver:'default'|'game'|'dev'|'system', angle:'default'|'angle'|'native'}
    driverStates: {}
};

// Two mutually-exclusive per-package driver groups, same options/order and
// same underlying Settings.Global keys as Specter's per-app driver override
// (webroot/spc.js): a 4-way "Graphics Driver" row (default/game/dev/system)
// followed by a 3-way "GL Driver" row (default/angle/native).
const driverGroupDefs = [
    {
        group: 'gfxdriver',
        options: [
            { id:'default', label:'Default' },
            { id:'game', label:'Game' },
            { id:'dev', label:'Dev' },
            { id:'system', label:'System' }
        ]
    },
    {
        group: 'angle',
        options: [
            { id:'default', label:'Default' },
            { id:'angle', label:'ANGLE' },
            { id:'native', label:'Native' }
        ]
    }
];

function normalizePkgLines(raw) {
    return [...new Set(String(raw || '')
        .split(/\r?\n/)
        .map(v => v.trim())
        .filter(v => v && !v.startsWith('#')))];
}

function shellQuote(value) {
    return `'${String(value).replace(/'/g, "'\\''")}'`;
}

const LQ_ICON_PATHS = {
    menu:'M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z',
    search:'M9.5 3a6.5 6.5 0 0 0 0 13c1.61 0 3.08-.59 4.21-1.57L19.49 20 21 18.49l-5.57-5.78A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 0 0 9.5 3zm0 2A4.5 4.5 0 1 1 5 9.5 4.5 4.5 0 0 1 9.5 5z',
    search_off:'M10.5 4a6.5 6.5 0 1 0 4.6 11.1l4.2 4.2 1.4-1.4-4.2-4.2A6.5 6.5 0 0 0 10.5 4zm0 2a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9zM4 4l16 16-1.4 1.4L2.6 5.4 4 4z',
    close:'M18.3 5.71 12 12l6.3 6.29-1.41 1.42L10.59 13.4 4.29 19.7 2.88 18.29 9.17 12 2.88 5.71 4.29 4.3l6.3 6.29 6.29-6.29z',
    expand_more:'M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z',
    chevron_right:'M9 6l6 6-6 6 1.41 1.41L17.83 12l-7.42-7.41z',
    dashboard:'M10.75 3.1a2 2 0 0 1 2.5 0l7 5.6A2 2 0 0 1 21 10.26V19a2.5 2.5 0 0 1-2.5 2.5H15v-5.25a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v5.25H5.5A2.5 2.5 0 0 1 3 19v-8.74a2 2 0 0 1 .75-1.56z',
    inventory_2:'M20 2H4c-1.1 0-2 .9-2 2v3h20V4c0-1.1-.9-2-2-2zm0 7H4v11h16V9zm-2 3h-3v-1h3v1z',
    tune:'M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM15 5v2h6V5h-6zM9 13v2h12v-2H9z',
    settings:'M19.43 12.98c.04-.32.07-.65.07-.98s-.02-.66-.07-.98l2.11-1.65-2-3.46-2.49 1a7.8 7.8 0 0 0-1.7-.98L15 3h-4l-.35 2.93c-.61.25-1.18.58-1.7.98l-2.49-1-2 3.46 2.11 1.65c-.04.32-.08.65-.08.98s.03.66.08.98l-2.11 1.65 2 3.46 2.49-1c.52.4 1.09.73 1.7.98L11 21h4l.35-2.93c.61-.25 1.18-.58 1.7-.98l2.49 1 2-3.46-2.11-1.65zM13 15.5A3.5 3.5 0 1 1 13 8a3.5 3.5 0 0 1 0 7.5z',
    loading:'M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46A7.94 7.94 0 0 0 20 12c0-4.42-3.58-8-8-8zm-6 8c0-1.01.25-1.97.7-2.8L5.24 7.74A7.94 7.94 0 0 0 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3c-3.31 0-6-2.69-6-6z',
    error_outline:'M11 15h2v2h-2v-2zm0-8h2v6h-2V7zm1-5a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 2a8 8 0 1 1 0 16 8 8 0 0 1 0-16z',
    apps:'M4 8h4V4H4v4zm6 0h4V4h-4v4zm6 0h4V4h-4v4zM4 14h4v-4H4v4zm6 0h4v-4h-4v4zm6 0h4v-4h-4v4zM4 20h4v-4H4v4zm6 0h4v-4h-4v4zm6 0h4v-4h-4v4z',
    bolt:'M11 21h-1l1-7H7.5c-.88 0-.33-.75-.31-.78C8.48 10.94 10.42 7.54 13 3h1l-1 7h3.5c.4 0 .62.19.4.66C12.97 17.33 11 21 11 21z',
    flash_on:'M7 2h10l-1.67 7H20l-9 13h-1l1.67-7H4L7 2z',
    check:'M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
    drag_handle:'M20 9H4v2h16V9zM4 15h16v-2H4v2z',
    texture:'M8 5L9.78 5L8.9 9.05L6.38 9.05zM10.22 5L11.78 5L11.71 9.05L9.48 9.05zM12.22 5L13.78 5L14.52 9.05L12.29 9.05zM14.22 5L16 5L17.62 9.05L15.1 9.05zM6.02 9.95L8.71 9.95L7.94 13.55L4.58 13.55zM9.31 9.95L11.7 9.95L11.65 13.55L8.64 13.55zM12.3 9.95L14.69 9.95L15.36 13.55L12.35 13.55zM15.29 9.95L17.98 9.95L19.42 13.55L16.06 13.55zM4.22 14.45L7.74 14.45L6.55 20L2 20zM8.48 14.45L11.63 14.45L11.55 20L7.45 20zM12.37 14.45L15.52 14.45L16.55 20L12.45 20zM16.26 14.45L19.78 14.45L22 20L17.45 20z'
};
function iconSVG(name, extraClass='') {
    const d=LQ_ICON_PATHS[name]||LQ_ICON_PATHS.tune;
    const cls=`lq-svg-icon${extraClass?' '+extraClass:''}`;
    return `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true"><path d="${d}"></path></svg>`;
}

function pkgBackendScript(scope, mode, pkg='', extra='') {
    const runtime = '/data/local/tmp/liqinghe/pkgmgr.sh';
    const extraArg = extra ? ` ${shellQuote(extra)}` : '';
    const command = mode === 'refresh-user'
        ? `sh ${shellQuote(runtime)} refresh-user 2>&1`
        : (mode === 'scan-games' || mode === 'commit-games' || mode === 'discard-games')
        ? `sh ${shellQuote(runtime)} ${mode} 2>&1`
        : `sh ${shellQuote(runtime)} ${shellQuote(mode)} ${shellQuote(scope)} ${shellQuote(pkg)}${extraArg} 2>&1`;
    return `if test -f ${shellQuote(runtime)}; then ${command}; else echo __LQ_ERR__NO_BACKEND; fi`;
}


// User tab = what the detector found (userpkg.txt, rebuilt on every refresh)
// plus whatever was added by hand (userpkg_extra.txt, never touched by it).
async function readUserPkgLists() {
    const [detectedRaw, extraRaw] = await Promise.all([
        exec(`cat ${shellQuote(pkgSources.user.file)} 2>/dev/null`),
        exec(`cat ${shellQuote(LQ_USERPKG_EXTRA_FILE)} 2>/dev/null`)
    ]);
    const detected = normalizePkgLines(detectedRaw);
    const detectedSet = new Set(detected);
    const extra = normalizePkgLines(extraRaw).filter(pkg => !detectedSet.has(pkg));
    pkgState.userCustom = extra;
    pkgState.data.user = [...detected, ...extra].sort();
    pkgState.loaded.user = true;
}

// Opening the User tab: show what is already on disk right away, and rescan the installed apps in the background.
// The rescan (cmd package list + rewriting userpkg.txt) is the slow part; it used to hold the list back every time.
// Only when there is nothing on disk yet does it wait for the scan.
const lqUserScan = { running: null };
async function loadPkgUserFast() {
    await readUserPkgLists();
    if (!pkgState.data.user.length) {
        await lqUserScanRun();
        return;
    }
    lqUserRescan();
}
// One scan of the installed apps: the backend runs the same isolated `cmd package list` the Action button runs (with its
// retries), then the lists are read back. Resolves { ok, reason } -- the reason is the backend's own, for a toast.
async function lqUserScanRun() {
    let out = '';
    try { out = String(await exec(pkgBackendScript('user', 'refresh-user')) || ''); } catch (_) {}
    const ok = out.includes('__LQ_OK__');
    let reason = '';
    if (!ok) {
        const m = out.match(/LQ_REASON:([^\n\r]*)/);
        reason = m ? m[1].trim() : (out.includes('NO_BACKEND') ? 'The module backend was not found' : 'The scan did not finish');
    }
    await readUserPkgLists();
    return { ok, reason };
}
// Single-flight: a second ask joins the scan that is already running. Resolves { ok, reason, changed }.
function lqUserRescan(opts = {}) {
    if (lqUserScan.running) return lqUserScan.running;
    const repaint = opts.repaint !== false;
    lqUserScan.running = (async () => {
        try {
            const before = (pkgState.data.user || []).join('\n');
            const res = await lqUserScanRun();
            await lqLabelsEnsure(pkgState.data.user, 2500);
            const changed = before !== (pkgState.data.user || []).join('\n');
            // apps installed or removed since the last scan: repaint only if nobody is in the middle of something on the list
            if (repaint && changed && pkgState.active === 'user' && !pkgState.expanded && !(pkgState.busy && pkgState.busy.size)) renderPkgList(false);
            return { ...res, changed };
        } catch (_) {
            return { ok: false, reason: 'The scan did not finish', changed: false };
        } finally {
            lqUserScan.running = null;
        }
    })();
    return lqUserScan.running;
}

async function loadPkgTab(key) {
    if (!pkgSources[key]) return;
    if (key === 'user') {
        await lqUserScanRun();
        return;
    }
    let raw;
    if (key === 'game') {
        // Prefer the game scan's detected list when it exists and isn't empty;
        // otherwise fall back to the module's original gamelist.txt as-is.
        // Two plain `cat` reads, run side by side: plain reads skip the exec queue (so they never wait behind the User scan or a
        // tweak apply) and skip the detached launch + polling. They used to be two `if [ -s ... ]` commands, one after the other.
        const [detRaw, bundledRaw] = await Promise.all([
            exec(`cat ${shellQuote(LQ_GAME_DETECTED_FILE)} 2>/dev/null`),
            exec(`cat ${shellQuote(pkgSources.game.file)} 2>/dev/null`)
        ]);
        const useDetected = String(detRaw || '').trim().length > 0;
        pkgState.gameSource = useDetected ? 'detected' : 'bawaan';
        raw = useDetected ? detRaw : bundledRaw;
    } else {
        raw = await exec(`cat ${shellQuote(pkgSources[key].file)} 2>/dev/null`);
    }
    if (key === 'preload') {
        const entries = String(raw || '').split(/\r?\n/).map(v => v.trim()).filter(Boolean);
        const modes = {};
        const packages = [];
        entries.forEach(line => {
            if (line.startsWith('#')) return;
            const keyPart = line.split('=', 1)[0].trim();
            if (!keyPart) return;
            const modePart = line.includes('=') ? line.slice(line.indexOf('=') + 1).trim() : '';
            if (!packages.includes(keyPart)) packages.push(keyPart);
            const normalizedMode = modePart === 'normal' || modePart === 'speed' ? 'normal' :
                (modePart === 'extra' || modePart === 'speed-profile' ? 'extra' : '');
            if (normalizedMode) modes[keyPart] = normalizedMode;
        });
        pkgState.data.preload = packages;
        pkgState.preloadModes = modes;
    } else {
        pkgState.data[key] = normalizePkgLines(raw);
    }
    pkgState.loaded[key] = true;
}


async function loadPkgStatus(force = false) {
    await Promise.all(['game','preload','whitelist'].filter(key => force || !pkgState.loaded[key]).map(key => loadPkgTab(key)));
}

// Names are only worth asking for apps that are really installed. The bundled game list has ~270 packages and most are not on this
// phone: asking for all of them held the UI thread and made the label code think the manager only answers one app at a time.
// The User tab's list is the installed apps, so on the Game tab only those are asked about (if that list is not known, ask for all).
function lqLabelCandidates(pkgs, key) {
    const list = pkgs || [];
    if (key !== 'game') return list;
    const inst = new Set(pkgState.data.user || []);
    return inst.size ? list.filter(p => inst.has(p)) : list;
}

// Re-read one list in the background after it was drawn from what was already in memory; repaint only if it really changed.
let lqPkgBgToken = 0;
async function lqPkgBgRefresh(key) {
    if (key === 'user') return;
    const token = ++lqPkgBgToken;
    const snap = () => (pkgState.data[key] || []).join('\n') + '|' + (key === 'game' ? pkgState.gameSource : '') + '|' + (key === 'preload' ? JSON.stringify(pkgState.preloadModes) : '');
    const before = snap();
    try { await loadPkgTab(key); } catch (_) { return; }
    if (token !== lqPkgBgToken || pkgState.active !== key || snap() === before) return;
    if (pkgState.expanded || (pkgState.busy && pkgState.busy.size)) return;
    try { await lqLabelsEnsure(lqLabelCandidates(pkgState.data[key], key), 2500); } catch (_) {}
    if (token !== lqPkgBgToken || pkgState.active !== key) return;
    renderPkgList(false);
}

function pkgHasAction(pkg, action) {
    return (pkgState.data[action] || []).includes(pkg);
}

function setPkgMeta(total, shown) {
    set('pkgTotal', total.toLocaleString());
    // the Apps title card is gone: the package count now lives in the search box hint
    const box = document.getElementById('pkgSearchInput');
    if (box) box.placeholder = `Search ${total.toLocaleString()} packages…`;
}


function createPreloadAddAction(pkg) {
    // Preload uses the exact same generic package-action implementation as
    // Game/Whitelist so its visual state transition, pending handling and
    // post-backend repaint timing stay identical.
    return createPkgAction(pkg, 'preload');
}

function createPkgAction(pkg, key) {
    const cfg = pkgActions[key];
    const active = pkgHasAction(pkg, key);
    const busy = pkgState.busy.has(`${pkg}:${key}`);

    const btn = document.createElement('button');
    btn.className = `pkg-action${active ? ' active' : ''}${busy ? ' pending' : ''}`;
    btn.type = 'button';
    btn.dataset.action = key;
    btn.innerHTML = `
        <span class="pkg-action-label">${cfg.label}</span>
        <span class="pkg-action-state">${active ? 'Added' : 'Add'}</span>
    `;
    btn.addEventListener('click', async event => {
        event.stopPropagation();
        if (pkgState.busy.has(`${pkg}:${key}`)) return;

        // Read the current membership at click time so the same button can
        // toggle Add -> Added -> Add without relying on stale render-time state.
        const currentlyActive = pkgHasAction(pkg, key);
        const mode = currentlyActive ? 'remove' : 'add';

        pkgState.busy.add(`${pkg}:${key}`);
        setActionVisual(btn, cfg.label, currentlyActive ? 'Added' : 'Add', true);
        const toast = pkgToastStart(pkgListTitle(key), mode === 'add' ? `Adding ${pkg}…` : `Removing ${pkg}…`);
        await waitApplyMotion(btn);

        const result = await exec(pkgBackendScript(key, mode, pkg));
        const ok = String(result || '').includes('__LQ_OK__');
        pkgState.busy.delete(`${pkg}:${key}`);

        if (!ok) {
            setActionVisual(btn, cfg.label, currentlyActive ? 'Added' : 'Add', false);
            btn.classList.toggle('active', currentlyActive);
            console.error('Li Qinghe package mutation failed:', result || '(no backend response)', {pkg,key,mode});
            // The answer may just have been lost (timeout) while the backend did finish:
            // ask the backend again and let the UI follow what it really holds.
            let reread = false;
            try { await loadPkgTab(key, true); reread = true; } catch (_) {}
            const latestActive = pkgHasAction(pkg, key);
            const landed = reread && latestActive === (mode === 'add');
            if (btn.isConnected) {
                setActionVisual(btn, cfg.label, latestActive ? 'Added' : 'Add', false);
                btn.classList.toggle('active', latestActive);
            }
            if (landed) toast.update({ state: 'ok', text: mode === 'add' ? `Added ${pkg}` : `Removed ${pkg}` });
            else toast.update({ state: 'err', text: mode === 'add' ? `Could not add ${pkg}` : `Could not remove ${pkg}` });
            return;
        }

        // Keep the in-memory package state in sync without rebuilding the
        // current User card. Recreating the button here interrupts the
        // existing fade/transition, while an in-place update stays smooth.
        const list = pkgState.data[key] || (pkgState.data[key] = []);
        const index = list.indexOf(pkg);
        if (mode === 'add') {
            if (index === -1) list.push(pkg);
        } else if (index !== -1) {
            list.splice(index, 1);
        }

        // Match the proven Driver/Preload Mode commit order exactly: clear
        // the pending state first, then commit the new active state and
        // final label. Keeping the class transition in one paint cycle
        // prevents the old active/background state from flashing between
        // Updating… and Added/Add.
        btn.classList.remove('pending');
        btn.classList.toggle('active', mode === 'add');
        setActionVisual(btn, cfg.label, mode === 'add' ? 'Added' : 'Add', false);
        toast.update({ state: 'ok', text: mode === 'add' ? `Added ${pkg}` : `Removed ${pkg}` });
        await waitPostActionPaint();
    });
    return btn;
}


function getPreloadMode(pkg) {
    return pkgState.preloadModes[pkg] || '';
}


function waitApplyMotion(btn) {
    return new Promise(resolve => {
        if (!btn) return resolve();
        btn.classList.remove('apply-press');
        void btn.offsetWidth;
        btn.classList.add('apply-press');
        const done = () => {
            btn.classList.remove('apply-press');
            resolve();
        };
        btn.addEventListener('animationend', done, { once:true });
        setTimeout(() => {
            btn.classList.remove('apply-press');
            resolve();
        }, 420);
    });
}

async function waitPostActionPaint(ms=220){
    // Let the browser paint the post-backend state before any list reload
    // destroys the current button node. Driver options already update in
    // place; package/preload actions need this small window as well.
    await new Promise(requestAnimationFrame);
    await new Promise(requestAnimationFrame);
    if (ms > 0) await new Promise(resolve => setTimeout(resolve, ms));
}

function setActionVisual(btn, label, state, pending=false) {
    if (!btn) return;
    const labelEl = btn.querySelector('.pkg-action-label');
    const stateEl = btn.querySelector('.pkg-action-state');
    if (labelEl) labelEl.textContent = label;
    if (stateEl) stateEl.textContent = state;
    btn.classList.toggle('pending', pending);
}

function createPreloadModeAction(pkg, mode) {
    const selected = getPreloadMode(pkg) === mode;
    const busy = pkgState.busy.has(`${pkg}:preload:${mode}`);
    const label = mode === 'normal' ? 'Normal' : 'Extra';
    const btn = document.createElement('button');
    btn.className = `pkg-action${selected ? ' active' : ''}${busy ? ' pending' : ''}`;
    btn.type = 'button';
    btn.innerHTML = `
        <span class="pkg-action-label">${label}</span>
        <span class="pkg-action-state">${selected ? 'Selected' : 'Select'}</span>
    `;
    btn.addEventListener('click', async event => {
        event.stopPropagation();
        if (busy || pkgState.busy.has(`${pkg}:preload:${mode}`)) return;

        pkgState.busy.add(`${pkg}:preload:${mode}`);
        setActionVisual(btn, label, btn.classList.contains('active') ? 'Selected' : 'Select', true);
        const toast = pkgToastStart('Preload mode', `Setting ${label}…`);

        await waitApplyMotion(btn);

        const result = await exec(pkgBackendScript(pkg, 'set-preload-mode', mode));
        const ok = String(result || '').includes('__LQ_OK__');
        pkgState.busy.delete(`${pkg}:preload:${mode}`);

        if (!ok) {
            setActionVisual(btn, label, 'Select', false);
            btn.classList.remove('active');
            toast.update({ state: 'err', text: `Could not set ${label} for ${pkg}` });
            btn.dataset.applyFailed = '1';
            console.error('Li Qinghe ywhy preload mode change failed:', result || '(no backend response)', {pkg, mode});
            await loadPkgTab('preload');
            setTimeout(() => {
                if (!btn.isConnected) return;
                const stillPending = pkgState.busy.has(`${pkg}:preload:${mode}`);
                if (stillPending) return;
                btn.dataset.applyFailed = '';
            }, 1800);
            return;
        }

        const track = btn.closest('.pkg-action-grid, .lq-preload-mode-track, [data-preload-mode-track]') || btn.parentElement;
        track?.querySelectorAll('.pkg-action').forEach(b => {
            const isSelected = b === btn;
            b.classList.toggle('active', isSelected);
            const bLabel = b.querySelector('.pkg-action-label')?.textContent || '';
            setActionVisual(b, bLabel, isSelected ? 'Selected' : 'Select', false);
        });
        toast.update({ state: 'ok', text: `${pkg}: ${label}` });
        await waitPostActionPaint();
        await loadPkgTab('preload');
        renderPkgList(false);
    });
    return btn;
}

function createDriverOptionButton(pkg, group, opt) {
    const busyKey = `${pkg}:driver:${group}`;
    const state = pkgState.driverStates[pkg] || {};
    const active = (state[group] || 'default') === opt.id;
    const busy = pkgState.busy.has(busyKey);

    const btn = document.createElement('button');
    btn.className = `pkg-action${active ? ' active' : ''}${busy ? ' pending' : ''}`;
    btn.type = 'button';
    btn.dataset.driverValue = opt.id;
    btn.innerHTML = `
        <span class="pkg-action-label">${opt.label}</span>
        <span class="pkg-action-state">${active ? 'Selected' : 'Select'}</span>
    `;
    btn.addEventListener('click', async event => {
        event.stopPropagation();
        if (pkgState.busy.has(busyKey)) return;
        // One option in this group is always selected -- there's no "off"
        // state to fall back to, so clicking the option that's already
        // active is a no-op instead of turning it off. Switching only
        // happens by picking a different option in the group.
        if (btn.classList.contains('active')) return;

        const track = btn.closest('.lq-driver-option-track');
        pkgState.busy.add(busyKey);
        track?.querySelectorAll('.pkg-action').forEach(b => b.classList.add('pending'));
        setActionVisual(btn, opt.label, 'Select', true);
        const driverTitle = group === 'gfxdriver' ? 'Graphics driver' : 'GL driver';
        const toast = pkgToastStart(driverTitle, `Setting ${opt.label}…`);
        await waitApplyMotion(btn);

        const result = await exec(pkgBackendScript(pkg, 'set-driver', group, opt.id));
        const ok = String(result || '').includes('__LQ_OK__');
        pkgState.busy.delete(busyKey);
        track?.querySelectorAll('.pkg-action').forEach(b => b.classList.remove('pending'));

        if (!ok) {
            setActionVisual(btn, opt.label, 'Select', false);
            toast.update({ state: 'err', text: `Could not set ${opt.label} for ${pkg}` });
            console.error('Li Qinghe driver group set failed:', result || '(no backend response)', {pkg, group, value: opt.id});
            return;
        }

        if (!pkgState.driverStates[pkg]) pkgState.driverStates[pkg] = {};
        pkgState.driverStates[pkg][group] = opt.id;
        syncAngleTexEntries(pkg);      // the Angle Texture card follows the GL Driver choice
        toast.update({ state: 'ok', text: `${pkg}: ${opt.label}` });
        // Flip the active option in place -- no renderPkgList() here.
        // Rebuilding the whole list would tear down and recreate the
        // .pkg-sheet-wrap this button lives inside, resetting its
        // grid-template-rows expand/collapse transition (the sheet would
        // just reappear already "open", with no animation to play).
        track?.querySelectorAll('.pkg-action').forEach(b => {
            const isActive = b.dataset.driverValue === opt.id;
            b.classList.toggle('active', isActive);
            const label = b.querySelector('.pkg-action-label')?.textContent || '';
            setActionVisual(b, label, isActive ? 'Selected' : 'Select', false);
        });
        syncPkgRowTags(pkg);
    });
    return btn;
}

function createDriverOptionTrack(pkg, group, options) {
    const track = document.createElement('div');
    track.className = `lq-driver-option-track lq-driver-option-track-${options.length}`;
    track.dataset.driverGroup = group;
    options.forEach(opt => track.appendChild(createDriverOptionButton(pkg, group, opt)));
    return track;
}

// Patches an already-expanded Game row's driver option buttons in place
// once loadDriverState() resolves, instead of re-rendering the package
// list. A full re-render would replace the expanded .pkg-item mid-animation
// with a fresh node that's already in its final "open" state, so the
// grid-template-rows expand transition never gets a chance to play -- the
// exact "teleport" this function exists to avoid.
function syncDriverToggleButtons(pkg) {
    const list = document.getElementById('pkgList');
    if (!list) return;
    const item = [...list.children].find(el => el.dataset.pkg === pkg);
    if (!item) return;
    const state = pkgState.driverStates[pkg] || {};
    driverGroupDefs.forEach(({ group }) => {
        const busyKey = `${pkg}:driver:${group}`;
        if (pkgState.busy.has(busyKey)) return; // don't clobber an in-flight toggle's own visual
        const track = item.querySelector(`.lq-driver-option-track[data-driver-group="${group}"]`);
        if (!track) return;
        const current = state[group] || 'default';
        track.querySelectorAll('.pkg-action').forEach(b => {
            const isActive = b.dataset.driverValue === current;
            b.classList.toggle('active', isActive);
            const label = b.querySelector('.pkg-action-label')?.textContent || '';
            setActionVisual(b, label, isActive ? 'Selected' : 'Select', false);
        });
    });
    syncPkgRowTags(pkg);
    syncAngleTexEntries(pkg);
}

async function loadDriverState(pkg, force = false) {
    if (!force && pkgState.driverStates[pkg]) return;
    const result = await execBg(pkgBackendScript(pkg, 'get-driver'));
    const text = String(result || '');
    const state = {};
    text.split(/\r?\n/).forEach(line => {
        const idx = line.indexOf('=');
        if (idx <= 0) return;
        state[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
    });
    pkgState.driverStates[pkg] = state;
}

// ── Angle Texture (one setting per game package) ───────────────────────────────────────────────────────────────────────────────
// Reached from the Game tab's detected list: a card under "GL Driver" that opens this page for that package, and that is only usable while
// the package's GL Driver is ANGLE. What was picked is kept per package (localStorage, mirrored into the auto backup like the other UI
// prefs) and drawn in the preview. Apply / Reset write it through the backend (set-angletex) as ANGLE feature overrides.
const LQ_ATX_LEVELS = ['Default', 'Light', 'Medium', 'Heavy', 'Extreme'];
const LQ_ATX_PRESETS = {
    smooth: { name: 'Smooth', pixel: false, blur: true,  level: 1 },
    retro:  { name: 'Retro',  pixel: true,  blur: false, level: 2 },
    bit8:   { name: '8-bit',  pixel: true,  blur: true,  level: 4 }
};
const LQ_ATX_DEFAULT = { preset: 'custom', pixel: false, blur: false, level: 0 };
let lqAtxBackScroll = 0;      // where the Apps page was scrolled when this page opened
const lqAtx = { pkg: null, manual: false, saved: null, draft: null, split: 50, raf: 0, beforeDirty: true };

function lqAtxMatch(c) {
    for (const k of Object.keys(LQ_ATX_PRESETS)) {
        const p = LQ_ATX_PRESETS[k];
        if (p.pixel === c.pixel && p.blur === c.blur && p.level === c.level) return k;
    }
    return 'custom';
}
function lqAtxNorm(raw) {
    const o = raw && typeof raw === 'object' ? raw : {};
    const lv = Number(o.level);
    const c = { pixel: o.pixel === true, blur: o.blur === true, level: Number.isFinite(lv) ? Math.min(4, Math.max(0, Math.round(lv))) : 0 };
    return { preset: o.preset === 'custom' ? 'custom' : lqAtxMatch(c), ...c };
}
const lqAtxIsDefault = c => !c.pixel && !c.blur && c.level === 0;
function lqAtxSummary(c) {
    if (lqAtxIsDefault(c)) return 'Default';
    const p = LQ_ATX_PRESETS[c.preset];
    return p ? p.name : 'Custom';
}
// the line under the title: only what is applied right now (texture detail, pixelated, distance blur), nothing else
function lqAtxDetail(c) {
    const on = [];
    if (c.level > 0) on.push('Texture detail');
    if (c.pixel) on.push('Pixelated');
    if (c.blur) on.push('Distance blur');
    if (!on.length) return 'Nothing applied';
    return on.map((t, i) => i ? t.charAt(0).toLowerCase() + t.slice(1) : t).join(', ');
}
function lqAtxRead() {
    try { const o = JSON.parse(localStorage.getItem(UI_ANGLETEX_KEY) || 'null'); return o && typeof o === 'object' ? o : {}; } catch (_) { return {}; }
}
const lqAtxGet = pkg => lqAtxNorm(lqAtxRead()[pkg]);
// Auto (the module switches the game's setting by itself) or Manual (the module never touches it). Kept next to the values, per game.
const lqAtxManualGet = pkg => { const o = lqAtxRead()[pkg]; return !!(o && o.manual === true); };
function lqAtxPut(pkg, cfg, manual = lqAtxManualGet(pkg)) {
    const all = lqAtxRead();
    if (lqAtxIsDefault(cfg) && !manual) delete all[pkg];
    else all[pkg] = { preset: cfg.preset, pixel: cfg.pixel, blur: cfg.blur, level: cfg.level, ...(manual ? { manual: true } : {}) };
    try { localStorage.setItem(UI_ANGLETEX_KEY, JSON.stringify(all)); } catch (_) {}
    if (typeof lqMirrorUIPrefs === 'function') lqMirrorUIPrefs();
}
// Writes the config through the backend (set-angletex): the game's line goes into the backend's table (zi.sh switches
// debug.angle.feature_overrides_enabled to it whenever that game comes to the front, force-stopping it once when stop is set), the
// property is set right away, and stop = also force-stop the game now. Resolves { ok, reason }.
async function lqAtxBackendApply(pkg, cfg, stop, manual = false) {
    const runtime = '/data/local/tmp/liqinghe/pkgmgr.sh';
    const args = [pkg, cfg.pixel ? 1 : 0, cfg.blur ? 1 : 0, cfg.level, stop ? 1 : 0, manual ? 1 : 0].map(v => shellQuote(String(v))).join(' ');
    let out = '';
    try { out = String(await exec(`if test -f ${shellQuote(runtime)}; then sh ${shellQuote(runtime)} set-angletex ${args} 2>&1; else echo __LQ_ERR__NO_BACKEND; fi`) || ''); } catch (_) {}
    if (out.includes('__LQ_OK__')) return { ok: true, reason: '' };
    return { ok: false, reason: out.includes('NO_BACKEND') ? 'The module backend was not found' : 'The change was not accepted' };
}

// Manual: only the hands-off line is written (set-angletex-mode), nothing is set and no game is stopped.
async function lqAtxBackendManual(pkg) {
    const runtime = '/data/local/tmp/liqinghe/pkgmgr.sh';
    let out = '';
    try { out = String(await exec(`if test -f ${shellQuote(runtime)}; then sh ${shellQuote(runtime)} set-angletex-mode ${shellQuote(pkg)} 2>&1; else echo __LQ_ERR__NO_BACKEND; fi`) || ''); } catch (_) {}
    if (out.includes('__LQ_OK__')) return { ok: true, reason: '' };
    return { ok: false, reason: out.includes('NO_BACKEND') ? 'The module backend was not found' : 'The change was not accepted' };
}
async function lqAtxSetMode(manual) {
    const pkg = lqAtx.pkg;
    if (lqAtxBusy || !pkg || lqAtx.manual === manual) return;
    lqAtxBusy = true;
    try {
        // Manual: leave everything as it is. Auto: put the game's saved values back (a normal apply, without stopping the game).
        const r = manual ? await lqAtxBackendManual(pkg) : await lqAtxBackendApply(pkg, lqAtxGet(pkg), false);
        if (pkg !== lqAtx.pkg) return;
        if (!r.ok) { lqToastShow({ title: 'Angle Texture', text: r.reason || 'Could not change the mode', state: 'err' }); return; }
        lqAtx.manual = manual;
        lqAtxPut(pkg, lqAtxGet(pkg), manual);
        lqAtxPaint();
        syncAngleTexEntries(pkg);
        lqToastShow({ title: 'Angle Texture', text: manual ? `${pkg}: Manual, the module leaves it alone` : `${pkg}: Auto, ${lqAtxIsDefault(lqAtxGet(pkg)) ? 'Default' : lqAtxDetail(lqAtxGet(pkg))}`, state: 'ok' });
    } finally { lqAtxBusy = false; }
}

// Apply and Reset both ask first: the overrides only reach a game when it starts, so either the game is stopped for you, or you stop it yourself.
// Resolves 'apply' (apply only), 'stop' (apply and force stop) or null (cancelled: tap outside the card).
function lqAtxAsk(srcEl, title, text) {
    return new Promise(res => {
        const pop = lqGameScanPopup(srcEl);
        let done = false;
        const fin = v => { if (done) return; done = true; pop.close().then(() => res(v)); };
        pop.show(`<div class="pkg-title">${title}</div><div class="pkg-sub">${text}</div><div class="lq-rec-modal-actions" style="margin-top:18px;grid-template-columns:1fr 1.85fr"><button class="lq-rec-modal-btn is-skip" data-k="apply" type="button" style="white-space:nowrap">Apply</button><button class="lq-rec-modal-btn is-apply" data-k="stop" type="button" style="white-space:nowrap">Apply &amp; stop</button></div><div style="margin:12px 0 0;text-align:center;font-size:calc(11px * var(--lq-ts,1)) !important;line-height:1.3;color:var(--lo);font-weight:500">Tap outside this popup to cancel.</div>`);
        pop.el.querySelectorAll('[data-k]').forEach(b => b.addEventListener('click', () => fin(b.dataset.k)));
        pop.scrim(() => fin(null));
    });
}
let lqAtxBusy = false;
async function lqAtxCommit(srcEl, kind) {
    const pkg = lqAtx.pkg;
    if (lqAtxBusy || !pkg || !lqAtx.draft) return;
    lqAtxBusy = true;
    try {
        const reset = kind === 'reset';
        const cfg = lqAtxNorm(reset ? LQ_ATX_DEFAULT : lqAtx.draft);
        const man = !!lqAtx.manual;
        const intro = reset ? 'Goes back to the default textures for this game.'
            : man ? 'Manual mode: it is applied once, right now. The module does not switch it on again when the game comes to the front.'
            : 'The setting is saved for this game and switched on by itself whenever the game comes to the front.';
        const stopNote = man
            ? `<br><br><b>Apply &amp; stop</b> force stops the game now, so its next start already uses this. Nothing happens again after that.`
            : `<br><br><b>Apply &amp; stop</b> force stops the game now. If you come back to it after another game, it may close once more to switch over; that is normal, and plain Apply avoids it.`;
        const choice = await lqAtxAsk(srcEl,
            reset ? 'Reset Angle Texture' : 'Apply Angle Texture',
            intro +
            `<br><br><b>Apply</b> keeps the game as it is. A game that is already open keeps its old look: close it and open it again to see the change.` +
            stopNote);
        if (!choice) return;
        const r = await lqAtxBackendApply(pkg, cfg, choice === 'stop', lqAtx.manual);
        if (pkg !== lqAtx.pkg) return;
        if (!r.ok) { lqToastShow({ title: 'Angle Texture', text: r.reason || 'Could not apply', state: 'err' }); return; }
        lqAtxPut(pkg, cfg);
        lqAtx.saved = cfg;
        lqAtx.draft = { ...cfg };
        lqAtxPaint();
        lqAtxQueue(false);
        syncAngleTexEntries(pkg);
        lqToastShow({ title: 'Angle Texture', text: `${pkg}: ${lqAtxIsDefault(cfg) ? "Default" : lqAtxDetail(cfg)}${choice === 'stop' ? ' · game stopped' : ' · close and reopen the game to see it'}`, state: 'ok' });
    } finally { lqAtxBusy = false; }
}

// The card under GL Driver (inside the open row). Disabled and dimmed unless this package's GL Driver is ANGLE.
function paintAngleTexEntry(card, pkg) {
    if (!card) return;
    const on = (pkgState.driverStates[pkg] || {}).angle === 'angle';
    card.classList.toggle('is-disabled', !on);
    const btn = card.querySelector('.lq-mon-entry-btn');
    if (btn) { btn.disabled = !on; btn.setAttribute('aria-disabled', on ? 'false' : 'true'); }
    const sum = card.querySelector('.lq-atx-sum'), sub = card.querySelector('.lq-atx-sub');
    const manual = lqAtxManualGet(pkg);
    if (sum) sum.textContent = manual ? 'Manual' : lqAtxSummary(lqAtxGet(pkg));
    if (sub) sub.textContent = !on ? 'Only works while GL Driver is ANGLE.' : manual ? 'The module leaves it alone' : lqAtxDetail(lqAtxGet(pkg));
}
function syncAngleTexEntries(pkg) {
    const list = document.getElementById('pkgList');
    const item = list && [...list.children].find(el => el.dataset.pkg === pkg);
    paintAngleTexEntry(item && item.querySelector('.lq-atx-entry'), pkg);
}
function createAngleTexEntry(pkg) {
    const card = document.createElement('div');
    card.className = 'card dev-card dev-azn lq-mon-entry lq-atx-entry';
    card.innerHTML = `<button aria-label="Open Angle Texture" class="dev-azn-head lq-mon-entry-btn" type="button">
        <span class="dev-azn-icon">${iconSVG('texture')}</span>
        <span class="lq-mon-entry-copy">
            <span class="dev-azn-title">Angle Texture <span class="ui-radius-value lq-atx-sum" style="margin-left:8px"></span></span>
            <span class="lq-mon-entry-sub lq-atx-sub"></span>
        </span>
        ${iconSVG('chevron_right', 'dev-azn-chev lq-mon-entry-chev')}
    </button>`;
    card.querySelector('.lq-mon-entry-btn').addEventListener('click', event => {
        event.stopPropagation();
        if (card.classList.contains('is-disabled')) return;
        lqAtxOpen(pkg);
    });
    paintAngleTexEntry(card, pkg);
    return card;
}

function lqNodesAngleTex() {
    const page = document.getElementById('page-angletex');
    if (!page) return [];
    return ['atxCard', 'atxPresetChips', 'atxToggleCard', 'atxLevelCard', 'atxActionCard', 'atxActions'].map(id => page.querySelector('#' + id)).filter(Boolean);
}
function lqAtxOpen(pkg) {
    lqAtx.pkg = pkg;
    lqAtx.manual = lqAtxManualGet(pkg);
    lqAtx.saved = lqAtxGet(pkg);
    lqAtx.draft = { ...lqAtx.saved };
    if (pageMeta.angletex) pageMeta.angletex.subtitle = `Li Qinghe · ${pkg}`;
    switchPage('angletex');
}

// ── the preview: a misty Gothic castle standing on a steep cliff (a keep with spired turrets, a big round bastion, a curtain wall, a pale crag
// behind, a grass slope in front, a final grain/tint/vignette pass), built from 12 layers stacked back to front. Every surface (bricks, rock, grass, slate) is a small height map
// that is lit from the upper left per pixel, so it has real relief instead of a flat fill; each layer also drops a soft shadow on the ones behind
// it and the far ones sit in mist. Every layer reaches down to the one in front of it, so nothing hovers, and the important parts stay away from
// the edges (the stage crops the picture a little). Texture detail = how far each layer is shrunk before it is shown again (Light .. Extreme),
// Pixelated = blown up without smoothing, Distance blur = extra blur on the layers that are far away. "Before" is always the untouched picture.
const LQ_ATX_W = 640, LQ_ATX_H = 440;
const LQ_ATX_F = [1, 3, 6, 10, 16];
let lqAtxScn = null, lqAtxBuilding = false, lqAtxUrgent = false;
const lqAtxDone = [];      // who is waiting for the layers (the boot step under the splash)
function lqAtxJobs() {
    const W = LQ_ATX_W, H = LQ_ATX_H, TAU = Math.PI * 2, FOGC = '216,223,236';
    const hash = (x, y, s) => { let h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(s | 0, 1274126177)) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967295; };
    const rnd = seed => () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
    const vn = (x, y, sc, s, sy) => {      // value noise, sc wide and sy (default sc) tall
        const gx = x / sc, gy = y / (sy || sc), x0 = Math.floor(gx), y0 = Math.floor(gy), fx = gx - x0, fy = gy - y0, sx = fx * fx * (3 - 2 * fx), sw = fy * fy * (3 - 2 * fy);
        const a = hash(x0, y0, s), b = hash(x0 + 1, y0, s), c = hash(x0, y0 + 1, s), d = hash(x0 + 1, y0 + 1, s), top = a + (b - a) * sx;
        return top + ((c + (d - c) * sx) - top) * sw;
    };
    const cl = (v, a, b) => v < a ? a : v > b ? b : v;
    const LX = -0.567, LY = -0.639, LZ = 0.577;      // light from the upper left, towards the viewer

    // surface: fills a shape and lights it per pixel. o.sample(px,py) -> [height, tone]; o.albedo(px,py,tone,nx,ny,nz,h) -> [r,g,b]; o.form(px,py) -> big shading
    const surface = (x, bb, path, o) => {
        const x0 = Math.max(0, Math.floor(bb[0])), y0 = Math.max(0, Math.floor(bb[1])), x1 = Math.min(W, Math.ceil(bb[2])), y1 = Math.min(H, Math.ceil(bb[3])), bw = x1 - x0, bh = y1 - y0;
        if (bw <= 0 || bh <= 0) return;
        const t = document.createElement('canvas'); t.width = bw; t.height = bh;
        const c = t.getContext('2d');
        c.translate(-x0, -y0); c.beginPath(); path(c); c.fillStyle = '#fff'; c.fill(); c.setTransform(1, 0, 0, 1, 0, 0);
        const im = c.getImageData(0, 0, bw, bh), p = im.data, Hh = new Float32Array(bw * bh), Tn = new Float32Array(bw * bh);
        for (let j = 0; j < bh; j++) for (let i = 0; i < bw; i++) { const k = j * bw + i; if (!p[k * 4 + 3]) continue; const s = o.sample(x0 + i, y0 + j); Hh[k] = s[0]; Tn[k] = s[1]; }
        const kk = o.k || 1, amb = o.amb == null ? 0.38 : o.amb;
        for (let j = 0; j < bh; j++) for (let i = 0; i < bw; i++) {
            const k = j * bw + i; if (!p[k * 4 + 3]) continue;
            const kl = i > 0 && p[(k - 1) * 4 + 3] ? k - 1 : k, kr = i < bw - 1 && p[(k + 1) * 4 + 3] ? k + 1 : k, ku = j > 0 && p[(k - bw) * 4 + 3] ? k - bw : k, kd = j < bh - 1 && p[(k + bw) * 4 + 3] ? k + bw : k;
            const gx = (Hh[kr] - Hh[kl]) * 0.5 * kk, gy = (Hh[kd] - Hh[ku]) * 0.5 * kk, inv = 1 / Math.sqrt(gx * gx + gy * gy + 1), nx = -gx * inv, ny = -gy * inv, nz = inv;
            const lam = Math.max(0, nx * LX + ny * LY + nz * LZ), px = x0 + i, py = y0 + j;
            const a = o.albedo(px, py, Tn[k], nx, ny, nz, Hh[k]), sh = (amb + (1 - amb) * lam * 1.3) * (o.form ? o.form(px, py) : 1);
            p[k * 4] = a[0] * sh; p[k * 4 + 1] = a[1] * sh; p[k * 4 + 2] = a[2] * sh;
        }
        c.putImageData(im, 0, 0); x.drawImage(t, x0, y0);
    };
    const bricks = (bx, by, bw, bh, seed) => (px, py) => {
        const row = Math.floor((py - by) / bh), ux = px - bx + ((row & 1) ? bw * 0.5 : 0), col = Math.floor(ux / bw), u = ux - col * bw, v = (py - by) - row * bh;
        const e = Math.min(u, bw - u, v, bh - v), r = hash(col, row, seed), bev = Math.min(1, e / 1.8);
        return e < 0.85 ? [0, 0.5] : [0.4 + 0.5 * bev + 0.3 * r + 0.25 * vn(px, py, 3, seed + 1), 0.8 + 0.36 * r + 0.18 * (vn(px, py, 9, seed + 2) - 0.5)];
    };
    const stoneAlb = (rgb, seed, moss) => (px, py, tn) => {      // weathered stone: dark streaks running down, damp and moss low down
        const st = 0.84 + 0.3 * vn(px, py, 2.6, seed, 30), dm = moss ? cl((py - moss) / 50, 0, 0.55) * vn(px, py, 14, seed + 3) : 0;
        return [(rgb[0] * (1 - dm) + 48 * dm) * tn * st, (rgb[1] * (1 - dm) + 68 * dm) * tn * st, (rgb[2] * (1 - dm) + 40 * dm) * tn * st];
    };
    const cylForm = (cx, hw, lo) => px => { const u = cl((px - cx) / hw, -1, 1), nz = Math.sqrt(1 - u * u); return (lo || 0.4) + 0.95 * Math.max(0, LX * u + LZ * nz); };
    const flatForm = (x0, x1, a, b) => px => a + (b - a) * cl((px - x0) / (x1 - x0), 0, 1);
    const crenel = (c, x0, x1, y, yb, mw, gw, mh) => {
        c.moveTo(x0, yb); c.lineTo(x0, y);
        for (let xx = x0; xx < x1; xx += mw + gw) { const e = Math.min(xx + mw, x1); c.lineTo(xx, y - mh); c.lineTo(e, y - mh); c.lineTo(e, y); c.lineTo(Math.min(xx + mw + gw, x1), y); }
        c.lineTo(x1, yb); c.closePath();
    };
    const wall = (x, x0, y0, x1, y1, seed, rgb, bw, bh, form, pathFn, moss) => surface(x, [x0 - 1, y0 - 12, x1 + 1, y1], pathFn || (c => { c.rect(x0, y0, x1 - x0, y1 - y0); }), { k: 2.2, amb: 0.34, sample: bricks(x0, y0, bw, bh, seed), albedo: stoneAlb(rgb, seed, moss), form });
    const lancet = (x, cx, top, bot, hw) => {
        const pth = (w, t, b) => { x.beginPath(); x.moveTo(cx - w, b); x.lineTo(cx - w, t + w * 1.3); x.quadraticCurveTo(cx - w, t + w * 0.3, cx, t); x.quadraticCurveTo(cx + w, t + w * 0.3, cx + w, t + w * 1.3); x.lineTo(cx + w, b); x.closePath(); };
        pth(hw + 1.6, top - 1.6, bot + 1); x.fillStyle = 'rgba(196,204,214,.3)'; x.fill();      // lit surround
        pth(hw, top, bot);
        const g = x.createLinearGradient(0, top, 0, bot); g.addColorStop(0, 'rgb(22,28,36)'); g.addColorStop(1, 'rgb(44,52,62)'); x.fillStyle = g; x.fill();
        x.fillStyle = 'rgba(0,0,0,.4)'; x.fillRect(cx - hw, top + hw * 1.3, hw * 0.9, bot - top - hw * 1.3);      // depth: the left reveal is in shadow
        x.fillStyle = 'rgba(214,220,228,.28)'; x.fillRect(cx - hw - 1.4, bot, hw * 2 + 2.8, 1.5);      // sill
    };
    const slit = (x, cx, top, bot) => { x.fillStyle = 'rgba(16,20,26,.9)'; x.fillRect(cx - 1.2, top, 2.4, bot - top); };
    const spire = (x, cx, hw, base, apex, seed) => surface(x, [cx - hw - 1, apex, cx + hw + 1, base + 1], c => { c.moveTo(cx - hw - 1, base); c.lineTo(cx - hw * 0.12, apex + 2); c.lineTo(cx, apex); c.lineTo(cx + hw * 0.12, apex + 2); c.lineTo(cx + hw + 1, base); c.closePath(); }, {
        k: 1.5, amb: 0.3,
        sample: (px, py) => [((py - apex) % 3.4) / 3.4 * 0.8 + 0.2 * hash(px >> 1, (py / 3.4) | 0, seed), 0.8 + 0.3 * hash(Math.floor((px - cx) / 3), Math.floor((py - apex) / 3.4), seed)],
        albedo: (px, py, tn) => [70 * tn, 80 * tn, 94 * tn],
        form: (px, py) => { const w = Math.max(1, hw * (py - apex) / (base - apex)); return cylForm(cx, w, 0.3)(px); }
    });
    // a round turret: cylinder of brick with a corbelled lip and, optionally, a cone roof
    const turret = (x, cx, hw, top, base, seed, rgb, apex) => {
        wall(x, cx - hw, top, cx + hw, base, seed, rgb, 9, 4.8, cylForm(cx, hw, 0.3), c => { c.rect(cx - hw, top, hw * 2, base - top); });
        x.fillStyle = 'rgba(8,12,18,.38)'; x.fillRect(cx - hw, top, hw * 2, 2.2);
        x.fillStyle = 'rgba(214,222,232,.2)'; x.fillRect(cx - hw, top + 2.2, hw * 2, 1.2);
        if (apex != null) spire(x, cx, hw + 3, top + 1, apex, seed + 30);
    };
    const fog = (x, cy, hh, a, seed, n, xa, xb) => {
        const r = rnd(seed);
        for (let i = 0; i < n; i++) {
            const cx = (xa == null ? 0 : xa) + r() * ((xb == null ? W : xb) - (xa == null ? 0 : xa)), rx = 110 + r() * 170, ry = hh * (0.5 + r() * 0.7), y = cy + (r() - 0.5) * hh * 0.9;
            x.save(); x.translate(cx, y); x.scale(1, ry / rx);
            const g = x.createRadialGradient(0, 0, 0, 0, 0, rx);
            g.addColorStop(0, `rgba(${FOGC},${a})`); g.addColorStop(0.55, `rgba(${FOGC},${a * 0.55})`); g.addColorStop(1, `rgba(${FOGC},0)`);
            x.fillStyle = g; x.fillRect(-rx, -rx, rx * 2, rx * 2); x.restore();
        }
    };
    const haze = (x, y0, y1, a0, a1) => {      // mist over what the layer already has: thick up high, thin low down
        x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = 'source-atop';
        const g = x.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, `rgba(${FOGC},${a0})`); g.addColorStop(1, `rgba(${FOGC},${a1})`);
        x.fillStyle = g; x.fillRect(0, 0, W, H); x.restore();
    };
    const shade = (x, y0, y1, a0, a1, rgb) => {      // a soft dark band over what the layer already has (contact shadow / depth)
        x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = 'source-atop';
        const g = x.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, `rgba(${rgb || '8,12,18'},${a0})`); g.addColorStop(1, `rgba(${rgb || '8,12,18'},${a1})`);
        x.fillStyle = g; x.fillRect(0, 0, W, H); x.restore();
    };
    const shadow = (x, a, blur, dx, dy) => {      // soft shadow of the layer, dropped behind it (it falls on the layers further back)
        x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.filter = `blur(${blur}px)`;
        if (x.filter === 'none') { x.restore(); return; }
        const t = document.createElement('canvas'); t.width = W; t.height = H;
        const c = t.getContext('2d'); c.drawImage(x.canvas, 0, 0); c.globalCompositeOperation = 'source-in'; c.fillStyle = '#0a0e14'; c.fillRect(0, 0, W, H);
        x.globalCompositeOperation = 'destination-over'; x.globalAlpha = a; x.drawImage(t, dx, dy); x.restore();
    };
    const soften = (x, path, blur) => {      // the layer keeps only a blurred copy of its own outline as alpha: the edge melts into the mist
        const t = document.createElement('canvas'); t.width = W; t.height = H;
        const c = t.getContext('2d'); c.filter = `blur(${blur}px)`;
        if (c.filter === 'none') return;
        c.beginPath(); path(c); c.fillStyle = '#000'; c.fill();
        x.save(); x.globalCompositeOperation = 'destination-in'; x.drawImage(t, 0, 0); x.restore();
    };
    const rockS = seed => (px, py) => {      // folded rock: warped ridged noise gives creases and broken faces, plus long vertical strata
        const wx = px + 14 * vn(px, py, 30, seed + 20), wy = py + 14 * vn(px, py, 30, seed + 21), rg = v => 1 - 2 * Math.abs(v - 0.5);
        const h = 0.8 * rg(vn(wx, wy, 70, seed + 4, 190)) + rg(vn(wx, wy, 26, seed, 70)) + 0.55 * rg(vn(wx, wy, 12, seed + 1, 34)) + 0.26 * rg(vn(wx, wy, 5, seed + 2)) + 0.95 * vn(px, py, 7, seed + 3, 70);
        return [h * 4, 0.5 + 0.62 * cl(h / 2.0, 0, 1) + 0.12 * vn(px, py, 40, seed + 6)];
    };
    const rockA = (rgb, seed, mossAmt, dryAmt) => (px, py, tn, nx, ny) => {
        const tint = vn(px, py, 60, seed + 7), m = cl((-ny - 0.05) * 3.0, 0, 1) * cl(vn(px, py, 15, seed + 8) * 1.6 - 0.35, 0, 1) * mossAmt,
              d = cl(vn(px, py, 22, seed + 9, 40) * 1.7 - 0.8, 0, 1) * (dryAmt || 0), st = 0.86 + 0.26 * vn(px, py, 3, seed + 10, 44);
        const r = (rgb[0] + 14 * (tint - 0.5)) * tn * st, g = (rgb[1] + 6 * (tint - 0.5)) * tn * st, b = (rgb[2] - 10 * (tint - 0.5)) * tn * st;
        const r1 = r * (1 - d) + 92 * d * tn, g1 = g * (1 - d) + 90 * d * tn, b1 = b * (1 - d) + 56 * d * tn;
        return [r1 * (1 - m) + 52 * m, g1 * (1 - m) + 74 * m, b1 * (1 - m) + 36 * m];
    };
    const blades = (x, r, n, x0, x1, y0, y1, pal, lmin, lmax, lean) => {
        for (let i = 0; i < n; i++) {
            const px = x0 + r() * (x1 - x0), py = y0 + Math.pow(r(), 0.85) * (y1 - y0), l = lmin + r() * (lmax - lmin), a = -Math.PI / 2 + (r() - 0.5) * 0.9 + lean;
            x.strokeStyle = pal[(r() * pal.length) | 0]; x.globalAlpha = 0.55 + r() * 0.4; x.lineWidth = 0.8 + r() * 0.9;
            x.beginPath(); x.moveTo(px, py); x.quadraticCurveTo(px + Math.cos(a) * l * 0.5 - 1.5, py + Math.sin(a) * l * 0.5, px + Math.cos(a) * l - 2.5, py + Math.sin(a) * l); x.stroke();
        }
        x.globalAlpha = 1;
    };

    // Composition (after the reference photo): a pale fog sky, a dark crag top left, a gothic castle that GROWS out of a steep mossy cliff (rock rises on
    // both sides of it, walls flare into the rock, moss and ivy spill over the ledge, mist sits on the joints), a grass slope bottom left.
    // The castle is drawn in its own coordinates and then scaled down as one group (so the cliff gets the lower half of the picture).
    // Every layer reaches down to the one in front of it, so nothing hovers; the important parts stay inside x 40..600 / y 30..420 (the stage crops a bit).
    const jobs = [], add = (name, d, fn, soft) => jobs.push({ name, d, fn: x => { fn(x); if (soft) blurSelf(x, soft); } });
    const STONE = [102, 108, 118];
    const blurSelf = (x, px) => {      // a hair of softness on the far layers: things in the distance are not razor sharp
        const t = document.createElement('canvas'); t.width = W; t.height = H;
        const c = t.getContext('2d'); c.drawImage(x.canvas, 0, 0);
        c.filter = 'blur(0)'; if (c.filter === 'none') return;
        x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, W, H); x.filter = `blur(${px}px)`; x.drawImage(t, 0, 0); x.restore();
    };
    const GS = 0.9, GAX = 360, GAY = 316, GTY = 284;      // the castle group: scale, anchor (own coordinates) and where the anchor lands
    const group = (x, fn) => {
        const t = document.createElement('canvas'); t.width = W; t.height = H;
        fn(t.getContext('2d'));
        x.save(); x.translate(GAX, GTY); x.scale(GS, GS); x.translate(-GAX, -GAY); x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high'; x.drawImage(t, 0, 0); x.restore();
    };
    const quoins = (x, x0, x1, y0, y1) => {      // lit edge on the left, dark edge on the right of a tower: reads as a corner of squared stone
        x.fillStyle = 'rgba(226,232,242,.26)'; x.fillRect(x0, y0, 2.2, y1 - y0);
        x.fillStyle = 'rgba(6,10,16,.3)'; x.fillRect(x1 - 3, y0, 3, y1 - y0);
    };
    const corbels = (x, x0, x1, y) => {      // the row of brackets that carries a battlement
        x.fillStyle = 'rgba(10,14,20,.55)'; for (let xx = x0 + 2; xx < x1 - 2; xx += 5) x.fillRect(xx, y, 2.6, 4);
        x.fillStyle = 'rgba(8,12,18,.4)'; x.fillRect(x0, y + 4, x1 - x0, 1.6);
        x.fillStyle = 'rgba(220,228,238,.2)'; x.fillRect(x0, y - 1, x1 - x0, 1.2);
    };
    const roof = (x, x0, x1, base, apex, seed) => surface(x, [x0 - 6, apex - 2, x1 + 6, base + 2], c => { c.moveTo(x0 - 5, base); c.lineTo((x0 + x1) / 2, apex); c.lineTo(x1 + 5, base); c.closePath(); }, {
        k: 1.3, amb: 0.3,
        sample: (px, py) => [((py - apex) % 4) / 4 * 0.8 + 0.25 * hash(px >> 2, (py / 4) | 0, seed), 0.8 + 0.3 * hash(Math.floor(px / 4), Math.floor((py - apex) / 4), seed)],
        albedo: (px, py, tn) => [60 * tn, 70 * tn, 86 * tn],
        form: (px, py) => px < (x0 + x1) / 2 ? 1.1 : 0.62
    });
    // the cliff's top edge: one function shared by the rock, the grass on the ledge and the ivy
    const EDGE = [[-10, 336], [60, 324], [110, 313], [160, 306], [220, 302], [300, 300], [380, 298], [450, 295], [505, 290], [545, 280], [585, 262], [625, 244], [W + 30, 232]];
    const edgeY = px => {
        let q = 1; while (q < EDGE.length - 1 && EDGE[q][0] < px) q++;
        const a = EDGE[q - 1], b = EDGE[q], t = cl((px - a[0]) / (b[0] - a[0]), 0, 1);
        return a[1] + (b[1] - a[1]) * t + (vn(px, 3, 11, 95) - 0.5) * 10 + (vn(px, 9, 3.4, 96) - 0.5) * 4;
    };

    // 1. sky: pale, cool, brighter in the middle where the castle stands
    add('sky', 0, x => {
        const im = x.createImageData(W, H), p = im.data;
        for (let y = 0; y < H; y++) for (let xx = 0; xx < W; xx++) {
            const t = y / H, n = vn(xx, y, 140, 1, 80) * 0.5 + vn(xx, y, 60, 2, 34) * 0.3 + vn(xx, y, 20, 3) * 0.2, k = 0.95 + 0.1 * n, i = (y * W + xx) * 4;
            p[i] = (234 - 26 * t) * k; p[i + 1] = (238 - 24 * t) * k; p[i + 2] = (248 - 20 * t) * k; p[i + 3] = 255;
        }
        x.putImageData(im, 0, 0);
    });
    // 2. the far crag at the top left: lit rock, pale and foggy high up, darker below, its edge dissolving into the mist
    add('crag', 0.1, x => {
        const crag = c => { c.moveTo(-80, -80); c.lineTo(296, -80); c.lineTo(286, 20); c.lineTo(262, 46); c.lineTo(246, 78); c.lineTo(214, 96); c.lineTo(196, 134); c.lineTo(160, 152); c.lineTo(140, 196); c.lineTo(104, 214); c.lineTo(82, 262); c.lineTo(40, 282); c.lineTo(-80, 316); c.closePath(); };
        x.save(); x.beginPath(); crag(x); x.clip();
        const cg = x.createLinearGradient(0, 0, 120, 330); cg.addColorStop(0, 'rgb(150,158,174)'); cg.addColorStop(0.5, 'rgb(104,112,128)'); cg.addColorStop(1, 'rgb(66,74,90)');
        x.fillStyle = cg; x.fillRect(0, 0, 330, 330);
        const q = rnd(12);
        for (let i = 0; i < 260; i++) {      // long gullies running down the face, dark ones and a few pale ones where the light catches an edge
            const px = q() * 330, py = q() * 180, l = 40 + q() * 150, dark = q() < 0.72, w = 1 + q() * 5;
            x.strokeStyle = dark ? `rgba(30,38,54,${0.1 + q() * 0.2})` : `rgba(206,214,230,${0.06 + q() * 0.12})`; x.lineWidth = w;
            x.beginPath(); x.moveTo(px, py); x.quadraticCurveTo(px + (q() - 0.4) * 14, py + l * 0.5, px + (q() - 0.3) * 26, py + l); x.stroke();
        }
        for (let i = 0; i < 40; i++) { const px = q() * 300, py = q() * 280; x.fillStyle = `rgba(20,28,42,${0.05 + q() * 0.08})`; x.beginPath(); x.ellipse(px, py, 10 + q() * 30, 20 + q() * 50, -0.25, 0, TAU); x.fill(); }
        x.restore();
        soften(x, crag, 12);
        haze(x, 0, 320, 0.5, 0.12);
        x.save(); x.globalCompositeOperation = 'destination-in';
        const g = x.createLinearGradient(0, 0, 300, 330); g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(0.55, 'rgba(0,0,0,.85)'); g.addColorStop(1, 'rgba(0,0,0,.25)');
        x.fillStyle = g; x.fillRect(0, 0, W, H); x.restore();
    }, 0.6);
    add('fog-far', 0.2, x => { fog(x, 150, 60, 0.3, 21, 8, 0, 420); fog(x, 90, 50, 0.2, 25, 5, 220, 640); });
    // 3. the back of the castle: hall with a slate gable, round tower, two small spired turrets
    add('castle-back', 0.34, x => group(x, g => {
        const T = [STONE[0] + 4, STONE[1] + 4, STONE[2] + 6];
        turret(g, 214, 11, 176, 360, 20, T, 122);
        turret(g, 242, 10, 190, 360, 21, T, 142);
        wall(g, 262, 150, 346, 360, 22, T, 10, 5, flatForm(262, 346, 1.12, 0.78), c => { c.moveTo(262, 360); c.lineTo(262, 176); c.lineTo(346, 176); c.lineTo(346, 360); c.closePath(); });
        roof(g, 262, 346, 178, 124, 24); corbels(g, 262, 346, 172);
        g.fillStyle = 'rgba(14,18,26,.9)'; g.fillRect(324, 138, 7, 22); g.fillStyle = 'rgba(214,222,232,.25)'; g.fillRect(324, 138, 1.6, 22);      // chimney
        wall(g, 348, 108, 386, 360, 23, T, 9, 5, cylForm(367, 19, 0.3), c => crenel(c, 348, 386, 108, 360, 7, 4, 6)); corbels(g, 348, 386, 110);
        lancet(g, 290, 196, 236, 5.5); lancet(g, 318, 196, 236, 5.5); lancet(g, 304, 262, 304, 7);
        lancet(g, 367, 136, 166, 4); lancet(g, 367, 200, 232, 4); slit(g, 214, 206, 234); slit(g, 242, 218, 246);
        haze(g, 100, 340, 0.5, 0.18);
        shadow(g, 0.2, 6, 3, 4);
    }), 0.5);
    // 4. the keep: tall tower, spired turrets, the block beside it
    add('castle', 0.5, x => group(x, g => {
        const T = [STONE[0] - 6, STONE[1] - 6, STONE[2] - 4];
        wall(g, 456, 152, 542, 360, 31, T, 11, 5.5, flatForm(456, 542, 1.0, 0.72), c => crenel(c, 456, 542, 152, 360, 8, 5, 6)); corbels(g, 456, 542, 154);
        wall(g, 396, 76, 458, 360, 32, T, 11, 5.5, flatForm(396, 458, 1.12, 0.86), c => crenel(c, 396, 458, 76, 360, 8, 5, 7)); corbels(g, 396, 458, 78); quoins(g, 396, 458, 82, 330);
        turret(g, 472, 13, 108, 360, 33, T, 52);
        turret(g, 528, 10, 130, 360, 34, T, 84);
        lancet(g, 412, 100, 134, 5); lancet(g, 440, 100, 134, 5);
        lancet(g, 412, 156, 194, 5); lancet(g, 440, 156, 194, 5);
        lancet(g, 426, 218, 262, 6);
        lancet(g, 496, 180, 216, 5); lancet(g, 510, 238, 276, 5); slit(g, 472, 130, 160); slit(g, 528, 150, 176);
        g.beginPath(); g.arc(426, 292, 6, 0, TAU); g.fillStyle = 'rgba(22,28,36,.8)'; g.fill();
        haze(g, 40, 340, 0.46, 0.06);
        shadow(g, 0.22, 6, 3, 4);
    }), 0.3);
    // mist between the keep and the wall: it veils the foot of the keep and the joints of the wall
    add('fog-mid', 0.46, x => { fog(x, 120, 80, 0.18, 22, 6, 300, 640); fog(x, 250, 26, 0.36, 26, 8, 150, 640); });
    // 5. the curtain wall climbing the cliff in steps, the big dark bastion at its left end, a battlemented tower at its right end
    add('wall', 0.7, x => {
        group(x, g => {
            const T = [88, 94, 102];
            wall(g, 228, 276, 336, 372, 51, T, 13, 6.2, flatForm(228, 336, 1.0, 0.8), c => crenel(c, 228, 336, 276, 372, 9, 6, 8), 306);
            wall(g, 336, 266, 446, 372, 52, T, 13, 6.2, flatForm(336, 446, 1.0, 0.78), c => crenel(c, 336, 446, 266, 372, 9, 6, 8), 306);
            wall(g, 446, 256, 568, 372, 56, T, 13, 6.2, flatForm(446, 568, 0.98, 0.76), c => crenel(c, 446, 568, 256, 372, 9, 6, 8), 306);
            wall(g, 540, 212, 596, 372, 53, [82, 88, 96], 11, 5.5, cylForm(568, 28, 0.3), c => crenel(c, 540, 596, 212, 372, 8, 6, 8), 300); corbels(g, 540, 596, 214);
            wall(g, 124, 242, 230, 372, 54, [66, 69, 76], 12, 6, cylForm(177, 53, 0.26), c => { c.rect(124, 242, 106, 130); });
            wall(g, 118, 226, 236, 246, 55, [60, 63, 70], 10, 5, cylForm(177, 59, 0.26), c => crenel(c, 118, 236, 226, 246, 10, 6, 8));
            g.fillStyle = 'rgba(8,12,18,.62)'; for (let i = 0; i < 8; i++) { g.beginPath(); g.arc(126 + i * 14.6, 247, 4.6, 0, Math.PI); g.fill(); }
            g.fillStyle = 'rgba(214,222,232,.22)'; g.fillRect(118, 246, 118, 1.4);
            slit(g, 160, 262, 288); slit(g, 190, 268, 294); slit(g, 176, 300, 322); slit(g, 568, 234, 258);
            [[284, 296], [316, 296], [372, 286], [408, 286], [480, 276], [520, 276]].forEach(([cx, ty]) => lancet(g, cx, ty, ty + 22, 3.4));
            const r = rnd(56);
            for (let i = 0; i < 46; i++) {      // ivy hanging from the corbel band of the bastion
                const t0 = Math.pow(r(), 1.6); let px = 126 + t0 * 80, py = 250 + r() * 6; const len = 3 + Math.floor(r() * 8 * (1.15 - t0 * 0.6));
                g.strokeStyle = `rgba(${30 + r() * 24},${54 + r() * 30},${28 + r() * 16},.9)`; g.lineWidth = 0.9 + r() * 0.9;
                g.beginPath(); g.moveTo(px, py);
                for (let k = 0; k < len; k++) { px += (r() - 0.5) * 4; py += 5 + r() * 5; g.lineTo(px, py); if (r() < 0.55) { g.fillStyle = `rgb(${40 + r() * 36},${70 + r() * 40},${34 + r() * 18})`; g.beginPath(); g.ellipse(px + (r() - 0.5) * 4, py, 2 + r() * 2, 1.4 + r() * 1.2, r() * 3, 0, TAU); g.fill(); g.beginPath(); g.moveTo(px, py); } }
                g.stroke();
            }
            shade(g, 292, 372, 0, 0.55, '6,10,16');      // the foot of every wall is dark where it meets the rock
            haze(g, 190, 372, 0.26, 0);
            shadow(g, 0.4, 6, 4, 6);
        });
    }, 0.25);
    // 6. the cliff: a mass of dark layered rock that rises on both sides of the castle; moss, grass and ivy spill over its ledge
    add('cliff', 0.88, x => {
        surface(x, [0, 214, W, H], c => {
            c.moveTo(-10, edgeY(-10));
            for (let px = -4; px <= W + 30; px += 5) c.lineTo(px, edgeY(px));
            c.lineTo(W + 30, H + 10); c.lineTo(-10, H + 10); c.closePath();
        }, { k: 2.0, amb: 0.28, sample: rockS(61), albedo: rockA([58, 61, 67], 61, 0.55, 0.6), form: (px, py) => 1.2 - 0.55 * cl((py - edgeY(px)) / 150, 0, 1) });
        shade(x, 262, 330, 0.5, 0, '6,10,14');      // the ledge sits in the shadow of the wall
        const r = rnd(66);
        x.save(); x.beginPath(); x.rect(0, 0, W, H); x.clip();
        for (let px = -4; px < W + 20; px += 2) {      // grass and weeds that grew on the ledge
            if (r() < 0.35) continue;
            const ey = edgeY(px) + 2, l = 3 + r() * 8;
            x.strokeStyle = `rgb(${30 + r() * 50},${52 + r() * 46},${28 + r() * 22})`; x.lineWidth = 0.8 + r() * 0.9; x.beginPath(); x.moveTo(px, ey); x.quadraticCurveTo(px + (r() - 0.4) * 3, ey - l * 0.6, px + (r() - 0.3) * 4, ey - l); x.stroke();
        }
        [[170, 230, 22], [338, 392, 16], [486, 548, 20], [96, 132, 12]].forEach(([a0, b0, n]) => {
            for (let i = 0; i < n; i++) {      // ivy and creepers falling over the ledge in a few places: strands of uneven length with leaves on them
                let px = a0 + r() * (b0 - a0), py = edgeY(px) + 1; const len = 3 + (r() * 7 | 0);
                x.strokeStyle = `rgba(${28 + r() * 22},${52 + r() * 30},${26 + r() * 14},.9)`; x.lineWidth = 0.9 + r() * 0.9;
                x.beginPath(); x.moveTo(px, py);
                for (let k = 0; k < len; k++) { px += (r() - 0.5) * 4; py += 4 + r() * 5; x.lineTo(px, py); if (r() < 0.5) { x.fillStyle = `rgb(${36 + r() * 34},${64 + r() * 38},${30 + r() * 16})`; x.beginPath(); x.ellipse(px + (r() - 0.5) * 4, py, 1.8 + r() * 2, 1.3 + r() * 1.2, r() * 3, 0, TAU); x.fill(); x.beginPath(); x.moveTo(px, py); } }
                x.stroke();
            }
        });
        x.restore();
        haze(x, 280, 440, 0.06, 0.0);
        shadow(x, 0.42, 9, 5, 7);
    });
    add('fog-near', 0.98, x => { fog(x, 306, 24, 0.2, 23, 8, 120, 640); fog(x, 360, 30, 0.1, 27, 5, 150, 640); });
    // 7. the grass slope in front on the left: a bumpy hillside running down to the right, tufts, shrubs, a few stones
    add('grass', 1.2, x => {
        const body = c => { c.moveTo(-40, 292); c.bezierCurveTo(60, 288, 170, 322, 240, 372); c.bezierCurveTo(282, 400, 312, 422, 334, H + 40); c.lineTo(-40, H + 40); c.closePath(); };
        surface(x, [0, 262, 340, H], body, {
            k: 1.7, amb: 0.34, sample: (px, py) => [vn(px, py, 2, 81, 5) * 1.1 + vn(px, py, 6, 82) + vn(px, py, 22, 83) * 2.4, 0.8 + 0.4 * vn(px, py, 5, 84)],
            albedo: (px, py, tn) => { const m = vn(px, py, 11, 85), s = 0.8 + 0.4 * vn(px, py, 1.4, 86, 9), dry = cl(1.3 - (py - 286) / 110, 0, 1) * m; return [(36 + 90 * dry) * tn * s, (52 + 52 * dry) * tn * s, (26 + 12 * dry) * tn * s]; },
            form: (px, py) => 1.08 - 0.5 * cl((py - 296) / 150, 0, 1) - 0.1 * cl(px / 340, 0, 1)
        });
        x.save(); x.beginPath(); body(x); x.clip();
        const r = rnd(71), PAL = ['rgb(146,138,84)', 'rgb(88,112,58)', 'rgb(34,56,34)', 'rgb(120,148,80)', 'rgb(172,162,108)', 'rgb(52,74,40)'];
        blades(x, r, 3400, -20, 360, 272, 440, PAL, 5, 16, 0.12);
        const clump = (cx, cy, rad, seed) => {      // a shrub: many small leaves, light on the upper left, dark underneath
            const q = rnd(seed);
            for (let i = 0; i < 260; i++) {
                const a = q() * TAU, d = Math.sqrt(q()) * rad, px = cx + Math.cos(a) * d, py = cy + Math.sin(a) * d * 0.62, lit = cl(0.5 + (-(px - cx) * 0.5 - (py - cy)) / (rad * 1.4), 0, 1);
                x.fillStyle = `rgb(${24 + 56 * lit + q() * 14},${44 + 70 * lit + q() * 16},${24 + 26 * lit + q() * 10})`;
                x.save(); x.translate(px, py); x.rotate(q() * Math.PI); x.beginPath(); x.ellipse(0, 0, 2 + q() * 3.4, 1 + q() * 1.6, 0, 0, TAU); x.fill(); x.restore();
            }
        };
        clump(46, 330, 52, 72); clump(186, 350, 34, 73); clump(262, 398, 22, 74);
        for (let i = 0; i < 7; i++) {
            const px = 80 + r() * 190, py = 356 + r() * 70, rr = 3.4 + r() * 5.5, g = x.createRadialGradient(px - rr * 0.4, py - rr * 0.4, 0, px, py, rr * 1.3);
            g.addColorStop(0, 'rgb(150,154,156)'); g.addColorStop(1, 'rgb(48,52,56)'); x.fillStyle = g; x.beginPath(); x.ellipse(px, py, rr * 1.3, rr, 0, 0, TAU); x.fill();
        }
        x.restore();
        shadow(x, 0.45, 8, 6, 5);
    });
    // 8. closest of all: dark wet rock in the bottom right corner and long blades along the bottom edge
    add('fore', 1.35, x => {
        surface(x, [430, 330, W, H], c => { c.moveTo(430, H + 20); c.lineTo(470, 404); c.lineTo(520, 384); c.lineTo(570, 366); c.lineTo(620, 352); c.lineTo(W + 20, 334); c.lineTo(W + 20, H + 20); c.closePath(); },
            { k: 1.7, amb: 0.26, sample: rockS(91), albedo: rockA([54, 58, 58], 91, 0.8, 0.3), form: (px, py) => 0.95 - 0.3 * cl((py - 340) / 60, 0, 1) });
        const r = rnd(92);
        for (let i = 0; i < 150; i++) {
            const px = r() * 600 + 40, py = H + 4, l = 16 + r() * 26, a = -Math.PI / 2 + (r() - 0.5) * 0.8 + 0.12;
            x.strokeStyle = `rgb(${20 + r() * 30},${40 + r() * 36},${24 + r() * 18})`; x.lineWidth = 1.4 + r() * 1.6;
            x.beginPath(); x.moveTo(px, py); x.quadraticCurveTo(px + Math.cos(a) * l * 0.5, py + Math.sin(a) * l * 0.6, px + Math.cos(a) * l + 5, py + Math.sin(a) * l); x.stroke();
        }
        shadow(x, 0.4, 8, 5, 4);
    });
    // 9. one finishing pass over everything: a cool tint, a darker rim and fine grain, so the layers read as one painting and not as cut-outs
    add('grade', 1.5, x => {
        x.fillStyle = 'rgba(150,176,214,.07)'; x.fillRect(0, 0, W, H);
        const g = x.createRadialGradient(W * 0.5, H * 0.46, H * 0.3, W * 0.5, H * 0.5, W * 0.62); g.addColorStop(0, 'rgba(6,10,18,0)'); g.addColorStop(1, 'rgba(6,10,18,.34)');
        x.fillStyle = g; x.fillRect(0, 0, W, H);
        const im = x.createImageData(W, H), p = im.data;
        for (let i = 0; i < W * H; i++) { const n = hash(i % W, (i / W) | 0, 7), v = n > 0.5 ? 255 : 0; p[i * 4] = p[i * 4 + 1] = p[i * 4 + 2] = v; p[i * 4 + 3] = 5 + 6 * Math.abs(n - 0.5) * 2; }
        const t = document.createElement('canvas'); t.width = W; t.height = H; t.getContext('2d').putImageData(im, 0, 0); x.drawImage(t, 0, 0);
    });
    return jobs;
}
// Boot step: build every layer while the splash is on screen, so opening Angle Texture only has to show the picture.
function lqAtxWarm() {
    return new Promise(res => {
        if (lqAtxScn) { res(true); return; }
        lqAtxDone.push(res);
        lqAtxUrgent = true;      // nobody is idle-waiting here: the splash waits for this step
        lqAtxKick();
    });
}
function lqAtxKick() {      // builds the layers one by one, yielding in between so the page never stalls
    if (lqAtxScn || lqAtxBuilding) return;
    lqAtxBuilding = true;
    const jobs = lqAtxJobs(), layers = [];
    let i = 0;
    const step = () => {
        if (i >= jobs.length) { lqAtxScn = layers; lqAtxBuilding = false; try { lqAtxEnsureDom(); } catch (_) {} lqAtxDone.splice(0).forEach(f => f(true)); lqAtxQueue(true); return; }
        const j = jobs[i++], c = document.createElement('canvas');
        c.width = LQ_ATX_W; c.height = LQ_ATX_H;
        try { j.fn(c.getContext('2d')); } catch (_) {}
        layers.push({ name: j.name, d: j.d, cv: c });
        later();
    };
    // normally they are built under the splash (lqAtxWarm); if that did not happen, they are built when the phone is idle, or at once if the page is already open
    const later = () => { if (lqAtxUrgent || !window.requestIdleCallback) setTimeout(step, 0); else window.requestIdleCallback(step, { timeout: 600 }); };
    later();
}

// the picture is two stacks of canvases (before / after), one canvas per layer; the "before" stack IS the drawn layers, the "after" stack is repainted on a change
function lqAtxEnsureDom() {
    const sb = document.getElementById('atxBefore'), sa = document.getElementById('atxAfter');
    if (!sb || !sa) return null;
    if (!lqAtxScn) { const st = document.getElementById('atxStage'); lqAtxUrgent = !!(st && st.clientWidth); lqAtxKick(); return null; }
    const L = lqAtxScn;
    if (!sb.dataset.built) {
        L.forEach(ly => {
            const b = document.createElement('div'), a = document.createElement('div'), c = document.createElement('canvas');
            b.className = a.className = 'lq-atx-ly'; b.style.setProperty('--d', String(ly.d)); a.style.setProperty('--d', String(ly.d));
            b.appendChild(ly.cv); sb.appendChild(b);
            c.width = LQ_ATX_W; c.height = LQ_ATX_H; a.appendChild(c); sa.appendChild(a);
        });
        sb.dataset.built = sa.dataset.built = '1';
    }
    return L;
}
function lqAtxShrink(src, w, h) {      // halve step by step so the result is a proper average, not a skipped sample
    let cur = src;
    while (cur.width > w * 2 || cur.height > h * 2) {
        const t = document.createElement('canvas'); t.width = Math.max(w, Math.ceil(cur.width / 2)); t.height = Math.max(h, Math.ceil(cur.height / 2));
        const x = t.getContext('2d'); x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high'; x.drawImage(cur, 0, 0, t.width, t.height);
        cur = t;
    }
    const o = document.createElement('canvas'); o.width = w; o.height = h;
    const x = o.getContext('2d'); x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high'; x.drawImage(cur, 0, 0, w, h);
    return o;
}
function lqAtxRender(cfg) {
    const L = lqAtxEnsureDom(), host = document.getElementById('atxAfter');
    if (!L || !host) return;      // the layers are still being built: the build asks for a redraw when it is done
    const outs = host.querySelectorAll('canvas'), W = LQ_ATX_W, H = LQ_ATX_H;
    // What the game does: a lower texture detail leaves fewer texels (forceTextureLodOffset). Magnified, they are hard square blocks only with
    // Pixelated on (forceNearestFiltering); with it off they are stretched smoothly, so the picture goes soft and blurry instead.
    // The effect is biggest on what is near (the same texel covers more screen there) and smaller far away; Pixelated also gives a minimum block size.
    const base = Math.max(LQ_ATX_F[cfg.level] || 1, cfg.pixel ? 4 : 1) * (cfg.pixel && cfg.level ? 1.45 : 1);
    L.forEach((ly, i) => {
        const out = outs[i]; if (!out) return;
        const x = out.getContext('2d');
        let cur = ly.cv;
        const far = Math.max(0, 1 - ly.d), fb = cfg.blur ? 1 + 5 * Math.pow(far, 1.5) : 1;
        if (fb > 1.08) cur = lqAtxShrink(cur, Math.max(2, Math.round(W / fb)), Math.max(2, Math.round(H / fb)));      // distance blur: far layers soften most
        x.clearRect(0, 0, W, H);
        const f = ly.name === 'grade' ? 1 : Math.max(1, base * (0.55 + 0.45 * Math.min(1, ly.d)));      // the finishing grain is not a texture
        if (f > 1.01) {
            const low = lqAtxShrink(cur, Math.max(2, Math.round(W / f)), Math.max(2, Math.round(H / f)));
            // Pixelated = forceNearestFiltering: hard square texels. Without it the game keeps its smooth (bilinear) filtering, so a lower
            // detail only makes the texture soft and blurry, not blocky: the small picture is stretched back up with smoothing on.
            x.imageSmoothingEnabled = !cfg.pixel;
            if (!cfg.pixel) x.imageSmoothingQuality = 'high';
            x.drawImage(low, 0, 0, W, H);
        } else { x.imageSmoothingEnabled = true; x.drawImage(cur, 0, 0, W, H); }
    });
}
function lqAtxDraw() {
    const stage = document.getElementById('atxStage');
    if (!stage || !stage.clientWidth || !lqAtx.draft) return;      // not on screen: nothing to draw
    if (!lqAtxEnsureDom()) return;
    lqAtx.beforeDirty = false;
    lqAtxRender(lqAtx.draft);
}
function lqAtxQueue(all) {      // at most one redraw per frame
    if (all) lqAtx.beforeDirty = true;
    if (lqAtx.raf) return;
    lqAtx.raf = requestAnimationFrame(() => { lqAtx.raf = 0; lqAtxDraw(); });
}
function lqAtxPaint() {
    const d = lqAtx.draft, s = lqAtx.saved;
    if (!d || !s) return;
    document.querySelectorAll('#atxPresetChips .lq-chip').forEach(b => {
        const on = b.dataset.atxPreset === d.preset;
        b.classList.toggle('is-active', on);
        b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    [['atxPixel', d.pixel], ['atxBlur', d.blur]].forEach(([id, on]) => {
        const b = document.getElementById(id);
        if (!b) return;
        b.classList.toggle('active', on);
        b.setAttribute('aria-pressed', on ? 'true' : 'false');
        const st = b.querySelector('.pkg-action-state');
        if (st) st.textContent = on ? 'On' : 'Off';
    });
    const sl = document.getElementById('atxSlider'), val = document.getElementById('atxLevelValue');
    if (sl) { sl.value = String(d.level); sl.style.setProperty('--lq-progress', String(d.level / 4)); }
    if (val) val.textContent = LQ_ATX_LEVELS[d.level];
    const apply = document.getElementById('atxApply'), reset = document.getElementById('atxReset');
    const man = !!lqAtx.manual;
    if (apply) apply.disabled = d.pixel === s.pixel && d.blur === s.blur && d.level === s.level && d.preset === s.preset;
    if (reset) reset.disabled = lqAtxIsDefault(d) && d.preset === 'custom';
    [['atxModeAuto', !man], ['atxModeManual', man]].forEach(([id, on]) => {
        const b = document.getElementById(id);
        if (!b) return;
        b.classList.toggle('active', on);
        b.setAttribute('aria-pressed', on ? 'true' : 'false');
        const st = b.querySelector('.pkg-action-state');
        if (st) st.textContent = on ? 'On' : 'Off';
    });
    const hint = document.getElementById('atxModeHint');
    if (hint) hint.textContent = man
        ? 'Manual: Apply and Reset work once, right now. The module never switches this game by itself, so nothing you set yourself gets overwritten.'
        : 'Auto: the module switches this game\u2019s setting by itself.';
}
function lqAtxShow() {      // the page has just opened
    lqAtx.split = 50;
    document.getElementById('atxStage')?.style.setProperty('--atx-split', '50');
    lqAtxPaint();
    lqAtxQueue(true);
}
function lqAtxEdit(patch) {      // a manual change: the preset chip follows what the values now match
    const c = { ...lqAtx.draft, ...patch };
    lqAtx.draft = { ...c, preset: lqAtxMatch(c) };
    lqAtxPaint();
    lqAtxQueue(false);
}

function initAngleTexturePage() {
    const $ = id => document.getElementById(id);
    const stage = $('atxStage'), handle = $('atxHandle');
    if (!stage || !handle) return;

    document.querySelectorAll('#atxPresetChips .lq-chip').forEach(b => b.addEventListener('click', () => {
        if (!lqAtx.draft) return;
        const key = b.dataset.atxPreset, p = LQ_ATX_PRESETS[key];
        lqAtx.draft = p ? { preset: key, pixel: p.pixel, blur: p.blur, level: p.level } : { ...lqAtx.draft, preset: 'custom' };      // Custom keeps the values as they are
        lqAtxPaint();
        lqAtxQueue(false);
    }));
    $('atxPixel')?.addEventListener('click', () => lqAtx.draft && lqAtxEdit({ pixel: !lqAtx.draft.pixel }));
    $('atxBlur')?.addEventListener('click', () => lqAtx.draft && lqAtxEdit({ blur: !lqAtx.draft.blur }));
    $('atxSlider')?.addEventListener('input', e => lqAtx.draft && lqAtxEdit({ level: Math.min(4, Math.max(0, Number(e.target.value) || 0)) }));

    $('atxModeAuto')?.addEventListener('click', () => lqAtxSetMode(false));
    $('atxModeManual')?.addEventListener('click', () => lqAtxSetMode(true));
    // both ask first (apply only, or apply and force stop the game), then write through the backend
    $('atxReset')?.addEventListener('click', e => lqAtxCommit(e.currentTarget, 'reset'));
    $('atxApply')?.addEventListener('click', e => lqAtxCommit(e.currentTarget, 'apply'));

    // dragging the picture (anywhere except the handle) pans the camera: near layers slide more than far ones, it eases back on release
    let panId = null, panX = 0, panCam = 0, cam = 0;
    const setCam = v => { cam = Math.min(1, Math.max(-1, v)); stage.style.setProperty('--cam', cam.toFixed(3)); };
    stage.addEventListener('pointerdown', e => {
        if (e.target.closest && e.target.closest('.lq-atx-handle')) return;
        panId = e.pointerId; panX = e.clientX; panCam = cam;
        stage.classList.add('is-pan');
        try { stage.setPointerCapture(e.pointerId); } catch (_) {}
    });
    stage.addEventListener('pointermove', e => {
        if (e.pointerId !== panId) return;
        const r = stage.getBoundingClientRect();
        if (r.width) setCam(panCam + (e.clientX - panX) / (r.width * 0.4));
    });
    const panEnd = e => {
        if (e.pointerId !== panId) return;
        panId = null; stage.classList.remove('is-pan'); setCam(0);
        try { stage.releasePointerCapture(e.pointerId); } catch (_) {}
    };
    stage.addEventListener('pointerup', panEnd);
    stage.addEventListener('pointercancel', panEnd);

    // before / after handle
    const setSplit = p => {
        lqAtx.split = Math.min(100, Math.max(0, p));
        stage.style.setProperty('--atx-split', lqAtx.split.toFixed(2));
        handle.setAttribute('aria-valuenow', String(Math.round(lqAtx.split)));
    };
    const fromEvent = e => { const r = stage.getBoundingClientRect(); if (r.width) setSplit((e.clientX - r.left) / r.width * 100); };
    handle.addEventListener('pointerdown', e => {
        e.preventDefault();
        try { handle.setPointerCapture(e.pointerId); } catch (_) {}
        handle.classList.add('is-drag');
        fromEvent(e);
    });
    handle.addEventListener('pointermove', e => { if (handle.hasPointerCapture && handle.hasPointerCapture(e.pointerId)) fromEvent(e); });
    const end = e => { handle.classList.remove('is-drag'); try { handle.releasePointerCapture(e.pointerId); } catch (_) {} };
    handle.addEventListener('pointerup', end);
    handle.addEventListener('pointercancel', end);
    handle.addEventListener('keydown', e => {
        if (e.key === 'ArrowLeft') { setSplit(lqAtx.split - 5); e.preventDefault(); }
        else if (e.key === 'ArrowRight') { setSplit(lqAtx.split + 5); e.preventDefault(); }
    });

    // sticky: a card like the others at rest, flush once it is stuck to the top (the same rule as the Frosted Glass preview)
    const card = $('atxCard'), sentinel = $('atxSentinel'), scroller = $('mainContent');
    if (card && sentinel && scroller) {
        const LEAD = 1;
        const check = () => {
            const dd = sentinel.getBoundingClientRect().top - scroller.getBoundingClientRect().top;
            const was = card.classList.contains('is-stuck');
            const stuck = !!sentinel.offsetHeight && dd < (was ? LEAD + 1 : LEAD);
            if (stuck !== was) card.classList.toggle('is-stuck', stuck);
        };
        scroller.addEventListener('scroll', check, { passive: true });
        window.addEventListener('resize', check, { passive: true });
    }
    let resizeTimer = 0;
    window.addEventListener('resize', () => {
        if (currentPage !== 'angletex') return;
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => lqAtxQueue(true), 120);
    }, { passive: true });
}

// Small labels under a package name for every list it has been added to
// (the list currently open is skipped, it is already obvious).
const pkgTagDefs = [
    { key:'game', label:'Game' },
    { key:'preload', label:'Preload' },
    { key:'whitelist', label:'Whitelist' }
];

// What has been picked for this package INSIDE the tab that is open. Only
// the tabs that offer a choice show it: Preload (Normal / Extra) and the Game
// tab's detected list (Graphics / GL driver). Other tabs return nothing.
function pkgChoiceLabels(pkg) {
    const out = [];
    if (pkgState.active === 'preload') {
        const mode = getPreloadMode(pkg);
        if (mode) out.push({ text: mode === 'normal' ? 'Normal' : mode === 'extra' ? 'Extra' : mode });
        else out.push({ text: 'No mode', muted: true });
    } else if (pkgState.active === 'game' && pkgState.gameSource === 'detected') {
        const state = pkgState.driverStates[pkg];
        if (state) { // only known once the driver state has been read
            const pick = (group, prefix) => {
                const def = driverGroupDefs.find(d => d.group === group);
                const id = state[group];
                if (!def || !id || id === 'default') return;
                const opt = def.options.find(o => o.id === id);
                out.push({ text: `${prefix}: ${opt ? opt.label : id}` });
            };
            pick('gfxdriver', 'Graphics');
            pick('angle', 'GL');
            if (!out.length) out.push({ text: 'Default', muted: true });
        }
    }
    return out;
}

function createPkgTags(pkg) {
    const keys = pkgTagDefs.filter(def => def.key !== pkgState.active && pkgHasAction(pkg, def.key));
    const choices = pkgChoiceLabels(pkg);
    if (!keys.length && !choices.length) return null;
    const wrap = document.createElement('div');
    wrap.className = 'pkg-row-tags';
    keys.forEach(def => {
        const tag = document.createElement('span');
        tag.className = 'pkg-tag';
        tag.textContent = def.label;
        wrap.appendChild(tag);
    });
    choices.forEach(c => {
        const tag = document.createElement('span');
        tag.className = `pkg-tag pkg-tag-choice${c.muted ? ' pkg-tag-muted' : ''}`;
        tag.textContent = c.text;
        wrap.appendChild(tag);
    });
    return wrap;
}

// Rebuilds just the tag line of one row, in place. A full renderPkgList()
// would replace the expanded row and cut its open/close transition short.
function syncPkgRowTags(pkg) {
    const list = document.getElementById('pkgList');
    if (!list) return;
    const item = [...list.children].find(el => el.dataset.pkg === pkg);
    const main = item && item.querySelector('.pkg-row-main');
    if (!main) return;
    const old = main.querySelector('.pkg-row-tags');
    const fresh = createPkgTags(pkg);
    // keep existing tags that did not change so only the new one animates
    if (old && fresh && old.textContent === fresh.textContent) return;
    if (old) old.remove();
    if (fresh) main.appendChild(fresh);
}

// Game tab (detected list): read each package's driver state in the
// background, one at a time, so the row labels fill in without hammering the
// shell. Stops as soon as the tab changes or the list is re-rendered.
let gameTagLoadToken = 0;
async function loadGameDriverTags() {
    const token = ++gameTagLoadToken;
    const live = () => token === gameTagLoadToken && pkgState.active === 'game' && pkgState.gameSource === 'detected';
    const pending = (pkgState.data.game || []).filter(pkg => !pkgState.driverStates[pkg]);
    for (const pkg of pending) {
        if (!live()) return;
        try { await loadDriverState(pkg); } catch (_) { continue; }
        if (!live()) return;
        syncPkgRowTags(pkg);
        await new Promise(r => setTimeout(r, 40)); // breathing room between reads
    }
}

// ── Sort + order of the package list (the bar under the tabs) ──────────────────────
// mode: 'az' | 'labeled' | 'custom'. dir: 'down' = as sorted, 'up' = reversed (A-Z / labeled only; Custom has its own order).
// Custom: the order the user dragged (kept per tab); `locked` hides the handles so the layout cannot be changed by accident.
// 'Labeled' = the package has small labels under its name (it is in another list, or has a choice picked here such as a Preload mode / driver).
const PKG_SORT_MODES = [
    { id: 'az', label: 'A–Z' },
    { id: 'labeled', label: 'Labeled' },
    { id: 'custom', label: 'Custom' }
];
const pkgSort = { mode: 'az', dir: 'down', locked: false };
const pkgCustom = {};          // tab -> [pkg, ...] in the order the user set
function loadPkgSort() {
    try {
        const o = JSON.parse(localStorage.getItem(UI_PKGSORT_KEY) || 'null');
        if (!o) return;
        let mode = o.mode, dir = o.dir;
        if (mode === 'default') mode = 'az';
        if (mode === 'unlabeled') { mode = 'labeled'; dir = 'up'; }
        if (PKG_SORT_MODES.some(m => m.id === mode)) pkgSort.mode = mode;
        if (dir === 'down' || dir === 'up') pkgSort.dir = dir;
        pkgSort.locked = !!o.locked;
        if (o.order && typeof o.order === 'object') {
            Object.keys(o.order).forEach(k => { if (Array.isArray(o.order[k])) pkgCustom[k] = o.order[k].filter(v => typeof v === 'string'); });
        }
    } catch (_) {}
}
loadPkgSort();
function savePkgSort() {
    try { localStorage.setItem(UI_PKGSORT_KEY, JSON.stringify({ mode: pkgSort.mode, dir: pkgSort.dir, locked: pkgSort.locked, order: pkgCustom })); } catch (_) {}
    if (typeof lqMirrorUIPrefs === 'function') lqMirrorUIPrefs();
}
const pkgEditOn = () => pkgSort.mode === 'custom' && !pkgSort.locked;

function pkgLabelCount(pkg) {
    let n = pkgTagDefs.filter(def => def.key !== pkgState.active && pkgHasAction(pkg, def.key)).length;
    n += pkgChoiceLabels(pkg).filter(c => !c.muted).length;
    return n;
}

// the saved custom order of a tab, completed: packages that are gone are dropped, new ones go to the end
function pkgCustomFull(tab, list) {
    const have = new Set(list);
    const saved = (pkgCustom[tab] || []).filter(p => have.has(p));
    const seen = new Set(saved);
    return saved.concat(list.filter(p => !seen.has(p)));
}

// ── App names ───────────────────────────────────────────────────────────────
// The list shows the app's name above its package (Free Fire / com.dts.freefireth). The names come from the manager's own
// package API (ksu.getPackagesInfo -> appLabel; AxManager follows the KernelSU one), asked in small batches so the UI thread is
// never held for long, and kept in localStorage so the next open already has them. Without that API (or for an app that is not
// installed) a row simply keeps showing the package name alone.
const LQ_LABEL_KEY = 'lq.appLabels.v1';
const lqLabels = { map: new Map(), miss: new Set(), loaded: false, chain: Promise.resolve(), batchOk: false, singles: 0, saveT: 0 };
function lqLabelsLoad() {
    if (lqLabels.loaded) return;
    lqLabels.loaded = true;
    try {
        const o = JSON.parse(localStorage.getItem(LQ_LABEL_KEY) || '{}');
        Object.keys(o || {}).forEach(k => { if (typeof o[k] === 'string' && o[k]) lqLabels.map.set(k, o[k]); });
    } catch (_) {}
}
function lqLabelsSave() {
    clearTimeout(lqLabels.saveT);
    lqLabels.saveT = setTimeout(() => {
        try { localStorage.setItem(LQ_LABEL_KEY, JSON.stringify(Object.fromEntries(lqLabels.map))); } catch (_) {}
    }, 800);
}
function pkgAppName(pkg) {
    lqLabelsLoad();
    const l = lqLabels.map.get(pkg);
    return l && l !== pkg ? l : '';
}
function pkgSearchText(pkg) {
    const l = pkgAppName(pkg);
    return (l ? `${l} ${pkg}` : pkg).toLowerCase();
}
function lqLabelHost() {
    for (const n of LQ_HOST_NAMES) {
        let h;
        try { h = window[n]; } catch (_) { h = undefined; }
        if (h && typeof h.getPackagesInfo === 'function') return h;
    }
    return null;
}
// null = the call itself failed; an array (maybe empty) = it answered
function lqLabelAsk(host, pkgs) {
    try {
        const out = JSON.parse(host.getPackagesInfo(JSON.stringify(pkgs)));
        return Array.isArray(out) ? out : (out && out.packageName ? [out] : []);
    } catch (_) { return null; }
}
function lqLabelFromPm(pkg) {
    try {
        const ai = $packageManager.getApplicationInfo(pkg, 0, 0);
        const l = typeof ai.getLabel === 'function' ? ai.getLabel() : ai.label;
        return l ? String(l) : '';
    } catch (_) { return ''; }
}
// Finds the names that are still missing for these packages. Runs one at a time, a small batch at a time, yielding in between,
// and stops after budgetMs (what is left stays unasked, so a later call carries on). Resolves to how many names were added.
function lqLabelsEnsure(pkgs, budgetMs = 2500) {
    lqLabels.chain = lqLabels.chain.then(async () => {
        lqLabelsLoad();
        const need = [...new Set(pkgs || [])].filter(p => p && !lqLabels.map.has(p) && !lqLabels.miss.has(p));
        if (!need.length) return 0;
        const host = lqLabelHost();
        const hasPm = typeof $packageManager !== 'undefined' && $packageManager;
        if (!host && !hasPm) { need.forEach(p => lqLabels.miss.add(p)); return 0; }
        const deadline = performance.now() + budgetMs;
        let added = 0;
        for (let i = 0; i < need.length; i += 30) {
            if (performance.now() > deadline) break;
            const chunk = need.slice(i, i + 30);
            const got = new Map();
            const tried = new Set();
            if (host) {
                const r = lqLabelAsk(host, chunk);
                chunk.forEach(p => tried.add(p));
                if (r) r.forEach(o => { if (o && o.packageName && o.appLabel) got.set(o.packageName, String(o.appLabel)); });
                if (got.size) lqLabels.batchOk = true;
                // a batch that failed or came back empty before any batch ever worked: some managers only answer one app at a time
                if ((r === null || !got.size) && !lqLabels.batchOk) {
                    tried.clear();
                    for (const p of chunk) {
                        if (performance.now() > deadline || lqLabels.singles >= 80) break;
                        lqLabels.singles++;
                        tried.add(p);
                        const one = lqLabelAsk(host, [p]);
                        if (one && one[0] && one[0].appLabel) got.set(p, String(one[0].appLabel));
                    }
                }
            } else {
                chunk.forEach(p => { tried.add(p); const l = lqLabelFromPm(p); if (l) got.set(p, l); });
            }
            tried.forEach(p => {
                if (got.has(p)) { lqLabels.map.set(p, got.get(p)); added++; }
                else lqLabels.miss.add(p);          // not installed (or no name): not asked again this session
            });
            await new Promise(r => setTimeout(r, 0));
        }
        if (added) lqLabelsSave();
        return added;
    }).catch(() => 0);
    return lqLabels.chain;
}
// puts a name into a row that was drawn before it was known
function pkgApplyLabel(item, animate) {
    if (!item || item.classList.contains('has-label')) return;
    const pkg = item.dataset.pkg, label = pkgAppName(pkg);
    const main = item.querySelector('.pkg-row-main'), name = main && main.querySelector('.pkg-row-name');
    if (!label || !name) return;
    const app = document.createElement('div');
    app.className = `pkg-row-app${animate ? ' is-new' : ''}`;
    app.textContent = label;
    main.insertBefore(app, name);
    item.classList.add('has-label');
    item.dataset.pkgSearch = pkgSearchText(pkg);
}
// after a list is drawn: ask for whatever names it still lacks and fill them into the rows that are already on screen
let lqLabelFillToken = 0;
function lqLabelsFillRendered() {
    const token = ++lqLabelFillToken;
    const list = document.getElementById('pkgList');
    if (!list) return;
    const pkgs = lqLabelCandidates([...list.children].map(el => el.dataset.pkg), pkgState.active).filter(p => p && !lqLabels.map.has(p) && !lqLabels.miss.has(p));
    if (!pkgs.length) return;
    lqLabelsEnsure(pkgs, 15000).then(n => {
        if (!n || token !== lqLabelFillToken) return;
        [...list.children].forEach(el => pkgApplyLabel(el, true));
        if (pkgState.query.trim()) filterRenderedPkgList();
    });
}

function pkgSortList(list, tab = pkgState.active) {
    if (pkgSort.mode === 'custom') return pkgCustomFull(tab, list);
    const items = list.map((pkg, i) => ({ pkg, i, k: pkgAppName(pkg) || pkg }));
    const alpha = (a, b) => a.k.localeCompare(b.k, undefined, { sensitivity: 'base', numeric: true }) || (a.i - b.i);
    if (pkgSort.mode === 'labeled') {
        items.forEach(it => { it.n = pkgLabelCount(it.pkg); });
        // labeled packages first (the ones with more labels first), then the rest; A-Z inside each group
        items.sort((a, b) => ((b.n > 0) - (a.n > 0)) || (b.n - a.n) || alpha(a, b));
    } else items.sort(alpha);
    const out = items.map(it => it.pkg);
    return pkgSort.dir === 'up' ? out.reverse() : out;
}

function syncPkgSortUI() {
    const val = document.getElementById('pkgSortValue');
    const bar = document.getElementById('pkgSortbar');
    const dir = document.getElementById('pkgDirBtn');
    const lock = document.getElementById('pkgOrderBtn');
    const menu = document.getElementById('pkgSortMenu');
    const mode = PKG_SORT_MODES.find(m => m.id === pkgSort.mode) || PKG_SORT_MODES[0];
    const custom = pkgSort.mode === 'custom';
    if (val) val.textContent = mode.label;
    if (bar) {
        bar.classList.toggle('is-custom', custom);
        bar.classList.toggle('is-up', pkgSort.dir === 'up');
    }
    if (dir) {
        dir.tabIndex = custom ? -1 : 0;
        dir.setAttribute('aria-label', pkgSort.dir === 'up' ? 'List runs bottom to top, tap to flip' : 'List runs top to bottom, tap to flip');
    }
    if (lock) {
        lock.tabIndex = custom ? 0 : -1;
        lock.classList.toggle('is-locked', pkgSort.locked);
        lock.setAttribute('aria-label', pkgSort.locked ? 'Unlock the order to rearrange' : 'Lock the order');
    }
    if (menu) menu.querySelectorAll('.pkg-sort-opt').forEach(b => {
        const on = b.dataset.sort === mode.id;
        b.classList.toggle('is-active', on);
        b.setAttribute('aria-selected', String(on));
    });
}

// the handles live on every row and are shown / hidden by one class on the list, so they can slide in and out without redrawing
function syncPkgEditClass() {
    const list = document.getElementById('pkgList');
    if (list) list.classList.toggle('is-custom-edit', pkgEditOn());
}

let pkgRedrawTimer = 0;
// redraw the open tab after the order changed (rows fade in again, the open row folds)
function redrawPkgList(delay = 0) {
    clearTimeout(pkgRedrawTimer);
    if (!pkgState.loaded[pkgState.active]) return;   // still loading: the first draw already uses the new order
    pkgState.expanded = null;
    if (delay) pkgRedrawTimer = setTimeout(() => renderPkgList(true), delay);
    else renderPkgList(true);
}

function setPkgSortMode(id) {
    if (pkgSort.mode === id) return;
    const tab = pkgState.active, all = pkgState.data[tab] || [];
    const wasEdit = pkgEditOn();
    const before = pkgSortList(all);
    // the first time Custom is used on a tab it starts from the order that is on screen, so nothing jumps
    if (id === 'custom' && !(pkgCustom[tab] && pkgCustom[tab].length)) pkgCustom[tab] = before.slice();
    pkgSort.mode = id;
    savePkgSort();
    syncPkgSortUI();
    syncPkgEditClass();
    const after = pkgSortList(all);
    if (before.length === after.length && before.every((p, i) => p === after[i])) return;   // same order: only the handles move
    redrawPkgList(wasEdit ? 240 : 0);     // leaving Custom: the handles slide away first
}

function initPkgSort() {
    const btn = document.getElementById('pkgSortBtn');
    const menu = document.getElementById('pkgSortMenu');
    const lock = document.getElementById('pkgOrderBtn');
    const dirBtn = document.getElementById('pkgDirBtn');
    if (!btn || !menu || !lock || !dirBtn) return;
    const setOpen = (on) => {
        menu.classList.toggle('is-open', on);
        btn.setAttribute('aria-expanded', String(on));
    };
    menu.replaceChildren();
    PKG_SORT_MODES.forEach(m => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'pkg-sort-opt';
        b.dataset.sort = m.id;
        b.setAttribute('role', 'option');
        b.innerHTML = `<span class="pkg-sort-opt-name"></span>${iconSVG('check')}`;
        b.firstChild.textContent = m.label;
        b.addEventListener('click', () => { setOpen(false); setPkgSortMode(m.id); });
        menu.appendChild(b);
    });
    btn.addEventListener('click', e => { e.stopPropagation(); setOpen(!menu.classList.contains('is-open')); });
    document.addEventListener('pointerdown', e => {
        if (menu.classList.contains('is-open') && !menu.contains(e.target) && !btn.contains(e.target)) setOpen(false);
    }, true);
    document.addEventListener('keydown', e => { if (e.key === 'Escape') setOpen(false); });
    lock.addEventListener('click', () => {
        setOpen(false);
        pkgSort.locked = !pkgSort.locked;
        savePkgSort();
        syncPkgSortUI();
        syncPkgEditClass();
    });
    dirBtn.addEventListener('click', () => {
        setOpen(false);
        if (pkgSort.mode === 'custom') return;
        pkgSort.dir = pkgSort.dir === 'up' ? 'down' : 'up';
        savePkgSort();
        syncPkgSortUI();
        redrawPkgList();
    });
    syncPkgSortUI();
    syncPkgEditClass();
}

// ── Custom order: drag a row by its handle ──────────────────────────────────────────
// The row follows the finger (translate / scale are separate properties, so the row's own enter animation never fights them), the rows it
// passes slide one slot out of the way, the list scrolls by itself near its edges, and on release the row glides into its slot. Only then
// are the nodes really moved and the order saved. Rows hidden by the search keep their place: the visible rows reuse the slots they held.
const pkgDrag = { active: false };

function makePkgDragHandle() {
    const h = document.createElement('div');
    h.className = 'pkg-row-drag';
    h.setAttribute('data-no-ptr', '');
    h.setAttribute('aria-hidden', 'true');
    h.innerHTML = iconSVG('drag_handle');
    h.addEventListener('pointerdown', startPkgDrag);
    h.addEventListener('click', e => e.stopPropagation());
    return h;
}

function startPkgDrag(e) {
    if (!pkgEditOn() || pkgDrag.active) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    lqPkgRestFlush();
    const handle = e.currentTarget;
    const item = handle.closest('.pkg-item');
    const list = document.getElementById('pkgList');
    const sc = document.getElementById('pkgListScroll');
    if (!item || !list || !sc) return;
    e.preventDefault();
    e.stopPropagation();

    // an open row folds at once (no animation) so the measurements below stay true
    list.classList.add('is-reordering');
    list.querySelectorAll('.pkg-item.open').forEach(it => {
        it.classList.remove('open');
        const r = it.querySelector('.pkg-row');
        if (r) r.setAttribute('aria-expanded', 'false');
    });
    pkgState.expanded = null;
    void list.offsetHeight;

    const tab = pkgState.active;
    const items = [...list.children].filter(el => !el.hidden);
    const from = items.indexOf(item);
    if (from < 0) { list.classList.remove('is-reordering'); return; }
    pkgDrag.active = true;

    const sc0 = sc.scrollTop;
    const rects = items.map(el => { const r = el.getBoundingClientRect(); return { top: r.top + sc0, h: r.height }; });
    const cs = getComputedStyle(item);
    const gap = (parseFloat(cs.marginBottom) || 0) + (parseFloat(cs.marginTop) || 0);
    const step = rects[from].h + gap;
    const centers = rects.map(r => r.top + r.h / 2);
    const startY = e.clientY;
    let lastY = startY, target = from, raf = 0, ended = false;

    item.classList.add('is-dragging');
    item.style.scale = '1.02';
    try { handle.setPointerCapture(e.pointerId); } catch (_) {}
    try { if (navigator.vibrate) navigator.vibrate(10); } catch (_) {}

    const update = () => {
        raf = 0;
        const dy = (lastY - startY) + (sc.scrollTop - sc0);
        item.style.translate = `0 ${dy}px`;
        const c = centers[from] + dy;
        let t = 0;
        for (let j = 0; j < items.length; j++) if (j !== from && centers[j] < c) t++;
        if (t === target) return;
        target = t;
        items.forEach((el, j) => {
            if (j === from) return;
            let sh = 0;
            if (from < target && j > from && j <= target) sh = -step;
            else if (from > target && j >= target && j < from) sh = step;
            el.style.translate = sh ? `0 ${sh}px` : '';
        });
        try { if (navigator.vibrate) navigator.vibrate(4); } catch (_) {}
    };
    const schedule = () => { if (!raf) raf = requestAnimationFrame(update); };

    // the list scrolls by itself while the finger is near its top / bottom edge
    const EDGE = 70;
    const autoScroll = () => {
        if (ended) return;
        const r = sc.getBoundingClientRect();
        const bottom = r.bottom - 96;     // the floating bar covers the lower part
        let v = 0;
        if (lastY < r.top + EDGE) v = -Math.min(18, 2 + (r.top + EDGE - lastY) / EDGE * 16);
        else if (lastY > bottom - EDGE) v = Math.min(18, 2 + (lastY - (bottom - EDGE)) / EDGE * 16);
        if (v) { sc.scrollTop += v; schedule(); }
        requestAnimationFrame(autoScroll);
    };
    requestAnimationFrame(autoScroll);

    const onMove = ev => { if (ev.pointerId !== e.pointerId) return; lastY = ev.clientY; schedule(); };
    const onEnd = ev => {
        if (ev.pointerId !== e.pointerId || ended) return;
        ended = true;
        if (raf) { cancelAnimationFrame(raf); update(); }
        handle.removeEventListener('pointermove', onMove);
        handle.removeEventListener('pointerup', onEnd);
        handle.removeEventListener('pointercancel', onEnd);
        try { handle.releasePointerCapture(e.pointerId); } catch (_) {}

        // where the dragged row lands: the top of its slot in the new order
        const order = items.map((_, j) => j).filter(j => j !== from);
        order.splice(target, 0, from);
        let top = rects[0].top;
        const newTops = {};
        order.forEach(j => { newTops[j] = top; top += rects[j].h + gap; });
        item.classList.remove('is-dragging');
        item.classList.add('is-dropping');
        item.style.scale = '1';
        item.style.translate = `0 ${newTops[from] - rects[from].top}px`;

        setTimeout(() => {
            const same = pkgState.active === tab && item.isConnected;
            if (same && target !== from) {
                list.insertBefore(item, target > from ? items[target].nextSibling : items[target]);
                const names = items.map(el => el.dataset.pkg);
                const moved = names.slice();
                moved.splice(from, 1);
                moved.splice(target, 0, names[from]);
                const full = pkgCustomFull(tab, pkgState.data[tab] || []);
                const vis = new Set(names);
                let k = 0;
                pkgCustom[tab] = full.map(p => vis.has(p) ? moved[k++] : p);
                savePkgSort();
            }
            items.forEach(el => { el.style.translate = ''; el.style.scale = ''; el.classList.remove('is-dragging', 'is-dropping'); });
            list.classList.remove('is-reordering');
            pkgDrag.active = false;
        }, 250);
    };
    handle.addEventListener('pointermove', onMove);
    handle.addEventListener('pointerup', onEnd);
    handle.addEventListener('pointercancel', onEnd);
}

function buildPkgRow(pkg, index) {
    const item = buildPkgRowCore(pkg, index);
    const row = item.querySelector(':scope > .pkg-row');
    if (row) row.appendChild(makePkgDragHandle());
    return item;
}

function buildPkgRowCore(pkg, index) {
    const item = document.createElement('div');
    const isUser = pkgState.active === 'user';
    const isPreload = pkgState.active === 'preload';
    // The Game tab only gets the expand/driver sheet when it's showing
    // the game scan's detected packages -- the bundled/bawaan gamelist stays
    // display-only, same as before this feature existed.
    const isGameDetected = pkgState.active === 'game' && pkgState.gameSource === 'detected';
    const expandable = isUser || isPreload || isGameDetected;
    item.className = `pkg-item${(expandable && pkgState.expanded === pkg) ? ' open' : ''}`;
    item.dataset.pkg = pkg;
    item.dataset.pkgSearch = pkgSearchText(pkg);
    item.dataset.pkgIndex = String(index);

    const row = document.createElement('div');
    row.className = 'pkg-row';
    row.setAttribute('role', 'button');
    row.setAttribute('aria-expanded', (expandable && pkgState.expanded === pkg) ? 'true' : 'false');

    const icon = document.createElement('div');
    icon.className = 'pkg-row-icon';
    icon.innerHTML = iconSVG('apps');

    const name = document.createElement('div');
    name.className = 'pkg-row-name';
    name.textContent = pkg;

    const main = document.createElement('div');
    main.className = 'pkg-row-main';
    const appName = pkgAppName(pkg);
    if (appName) {
        const app = document.createElement('div');
        app.className = 'pkg-row-app';
        app.textContent = appName;
        main.appendChild(app);
        item.classList.add('has-label');
    }
    main.appendChild(name);
    const tags = createPkgTags(pkg);
    if (tags) main.appendChild(tags);
    row.append(icon, main);

    if (expandable) {
        const chevron = document.createElement('div');
        chevron.className = 'pkg-row-chevron';
        chevron.innerHTML = iconSVG('expand_more');
        row.appendChild(chevron);

        const isCustomUser = isUser && pkgState.userCustom.includes(pkg);
        const removeBtn = (isPreload || isGameDetected || isCustomUser) ? document.createElement('button') : null;
        if (removeBtn) {
            const removeScope = isGameDetected ? 'game' : 'preload';
            removeBtn.className = 'pkg-row-remove';
            removeBtn.type = 'button';
            removeBtn.setAttribute('aria-label', isCustomUser
                ? `Remove ${pkg} from the User list`
                : `Remove ${pkg} from ${isGameDetected ? 'Game' : 'Preload'}`);
            removeBtn.innerHTML = iconSVG('close','lq-icon-18');
            removeBtn.addEventListener('click', async event => {
                event.stopPropagation();
                if (isCustomUser) await removeCustomUserPkg(pkg);
                else await togglePkgAction(pkg, removeScope);
            });
            row.appendChild(removeBtn);
        }

        const sheetWrap = document.createElement('div');
        sheetWrap.className = 'pkg-sheet-wrap';
        const sheet = document.createElement('div');
        sheet.className = 'pkg-sheet';
        const inner = document.createElement('div');
        inner.className = `pkg-sheet-inner${isPreload ? ' preload-mode-sheet' : ''}`;
        if (isPreload) {
            const hint = document.createElement('div');
            hint.className = 'pkg-mode-hint';
            hint.textContent = getPreloadMode(pkg) ? `Current: ${getPreloadMode(pkg)}` : 'Mode not selected';
            inner.appendChild(hint);
            inner.appendChild(createPreloadModeAction(pkg, 'normal'));
            inner.appendChild(createPreloadModeAction(pkg, 'extra'));
        } else if (isGameDetected) {
            const hint1 = document.createElement('div');
            hint1.className = 'pkg-mode-hint';
            hint1.textContent = 'Graphics Driver';
            inner.appendChild(hint1);
            inner.appendChild(createDriverOptionTrack(pkg, driverGroupDefs[0].group, driverGroupDefs[0].options));

            const hint2 = document.createElement('div');
            hint2.className = 'pkg-mode-hint';
            hint2.textContent = 'GL Driver';
            inner.appendChild(hint2);
            inner.appendChild(createDriverOptionTrack(pkg, driverGroupDefs[1].group, driverGroupDefs[1].options));
            inner.appendChild(createAngleTexEntry(pkg));
        } else {
            inner.appendChild(createPkgAction(pkg, 'game')); inner.appendChild(createPreloadAddAction(pkg)); inner.appendChild(createPkgAction(pkg, 'whitelist'));
        }
        sheet.appendChild(inner);
        sheetWrap.appendChild(sheet);
        row.addEventListener('click', () => togglePkgExpanded(pkg));
        item.append(row, sheetWrap);
        return item;
    }

    const removeBtn = document.createElement('button');
    removeBtn.className = 'pkg-row-remove';
    removeBtn.type = 'button';
    removeBtn.setAttribute('aria-label', `Remove ${pkg} from ${pkgState.active}`);
    removeBtn.innerHTML = iconSVG('close','lq-icon-18');
    removeBtn.addEventListener('click', async event => {
        event.stopPropagation();
        await togglePkgAction(pkg, pkgState.active);
    });
    row.appendChild(removeBtn);
    item.appendChild(row);
    return item;
}


function updatePkgEmpty(icon, text) {
    pkgShowEmpty(`${iconSVG(icon)}${text}`);
}

function filterRenderedPkgList() {
    lqPkgRestFlush();
    const list = document.getElementById('pkgList');
    const empty = document.getElementById('pkgEmpty');
    if (!list || !empty) return;

    const all = pkgState.data[pkgState.active] || [];
    const q = pkgState.query.trim().toLowerCase();

    if (!all.length) {
        list.hidden = true;
        updatePkgEmpty('inventory_2', 'No packages found in this list.');
        setPkgMeta(0, 0);
        return;
    }

    if (!list.children.length) {
        renderPkgList(false);
        return;
    }

    let shown = 0;
    let nextExpanded = pkgState.expanded;
    Array.from(list.children).forEach(item => {
        const haystack = item.dataset.pkgSearch || String(item.dataset.pkg || '').toLowerCase();
        const match = !q || haystack.includes(q);
        item.hidden = !match;
        if (match) shown += 1;
        if (!match && nextExpanded === item.dataset.pkg) {
            item.classList.remove('open');
            const row = item.querySelector('.pkg-row');
            if (row) row.setAttribute('aria-expanded', 'false');
            nextExpanded = null;
        }
    });

    pkgState.expanded = nextExpanded;
    setPkgMeta(all.length, shown);

    if (!shown) {
        list.hidden = true;
        updatePkgEmpty('search_off', 'No packages match your search.');
    } else {
        empty.hidden = true;
        list.hidden = false;
    }
}

// the rest of a list that was drawn in pieces (see renderPkgList)
let lqPkgRest = null;
function lqPkgRestStep() {
    const r = lqPkgRest;
    const list = document.getElementById('pkgList');
    if (!r || !list || r.token !== pkgState.renderToken) { if (lqPkgRest === r) lqPkgRest = null; return; }
    const end = Math.min(r.filtered.length, r.next + 40);
    const frag = document.createDocumentFragment();
    for (let i = r.next; i < end; i++) frag.appendChild(buildPkgRow(r.filtered[i], i));
    list.appendChild(frag);
    r.next = end;
    if (end >= r.filtered.length) { lqPkgRest = null; try { lqLabelsFillRendered(); } catch (_) {} }
}
function lqPkgRestSchedule() {
    const r = lqPkgRest;
    if (!r) return;
    requestAnimationFrame(() => {
        if (lqPkgRest !== r) return;
        lqPkgRestStep();
        if (lqPkgRest === r) lqPkgRestSchedule();
    });
}
// whatever needs every row to be there (search, drag to reorder) finishes the drawing first
function lqPkgRestFlush() {
    let guard = 0;
    while (lqPkgRest && guard++ < 50) lqPkgRestStep();
}

function renderPkgList(animate = true) {
    const list = document.getElementById('pkgList');
    const empty = document.getElementById('pkgEmpty');
    if (!list || !empty) return;

    const all = pkgState.data[pkgState.active] || [];
    const q = pkgState.query.trim().toLowerCase();
    const ordered = pkgSortList(all);
    const filtered = q ? ordered.filter(pkg => pkgSearchText(pkg).includes(q)) : ordered;

    setPkgMeta(all.length, filtered.length);
    pkgState.renderToken = (pkgState.renderToken || 0) + 1;
    const token = pkgState.renderToken;

    list.replaceChildren();
    list.classList.remove('is-reordering');
    list.classList.toggle('is-custom-edit', pkgEditOn());

    if (!all.length) {
        list.hidden = true;
        updatePkgEmpty('inventory_2', 'No packages found in this list.');
        return;
    }

    if (!filtered.length) {
        list.hidden = true;
        updatePkgEmpty('search_off', 'No packages match your search.');
        return;
    }

    empty.hidden = true;
    list.hidden = false;

    const fragment = document.createDocumentFragment();

    // A long list (the bundled game list has ~270 rows) is drawn in pieces on a tab switch: the rows that fit the screen first, the
    // rest in the next frames, so the tab answers at once and looks the same. Other redraws (an action, search, sort) stay in one
    // piece, because a shorter list would throw the scroll position back up.
    const FIRST = 24;
    const chunked = animate && filtered.length > FIRST + 8;
    const firstPart = chunked ? filtered.slice(0, FIRST) : filtered;

    firstPart.forEach((pkg, index) => {
        const item = buildPkgRow(pkg, index);
        if (animate) {
            item.classList.remove('pkg-enter','lq-lite-pkg');
            item.classList.add('pkg-stagger-pending');
        }
        fragment.appendChild(item);
    });

    if (token !== pkgState.renderToken) return;
    list.appendChild(fragment);
    lqPkgRest = chunked ? { token, filtered, next: FIRST } : null;
    if (lqPkgRest) lqPkgRestSchedule();

    if (animate) {
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                if (pkgState.renderToken !== token) return;
                lqReplayPkgRows();
            });
        });
    } else {
        list.querySelectorAll('.pkg-stagger-pending').forEach(el=>el.classList.remove('pkg-stagger-pending'));
    }

    if (pkgState.active === 'game' && pkgState.gameSource === 'detected') loadGameDriverTags();
    else gameTagLoadToken++;
    lqLabelsFillRendered();
}

function togglePkgExpanded(pkg) {
    const list = document.getElementById('pkgList');
    const isGameDetected = pkgState.active === 'game' && pkgState.gameSource === 'detected';
    if (!list || !(['user','preload'].includes(pkgState.active) || isGameDetected)) return;

    const prev = pkgState.expanded;
    const next = prev === pkg ? null : pkg;

    if (prev) {
        const prevItem = [...list.children].find(item => item.dataset.pkg === prev);
        if (prevItem) {
            prevItem.classList.remove('open');
            const prevRow = prevItem.querySelector('.pkg-row');
            if (prevRow) prevRow.setAttribute('aria-expanded', 'false');
        }
    }

    if (next) {
        const nextItem = [...list.children].find(item => item.dataset.pkg === next);
        if (nextItem) {
            nextItem.classList.add('open');
            const nextRow = nextItem.querySelector('.pkg-row');
            if (nextRow) nextRow.setAttribute('aria-expanded', 'true');
        }
    }

    pkgState.expanded = next;

    if (next && isGameDetected) {
        loadDriverState(next).then(() => {
            if (pkgState.expanded === next) syncDriverToggleButtons(next);
        });
    }
}

const PKG_NAME_RE = /^[A-Za-z0-9._-]+$/;

function setPkgAddVisible(on) {
    const row = document.getElementById('pkgSearchRow');
    const btn = document.getElementById('pkgSearchAdd');
    if (row) row.classList.toggle('has-add', !!on);
    if (btn) {
        btn.disabled = !on;
        btn.tabIndex = on ? 0 : -1;
    }
}

// Add is only offered when the typed text matches nothing in the open tab,
// i.e. the package really isn't in the list.
function updatePkgAddVisibility() {
    const q = String(pkgState.query || '').trim().toLowerCase();
    const list = pkgState.data[pkgState.active] || [];
    setPkgAddVisible(!!q && !list.some(pkg => pkg.toLowerCase().includes(q)));
}

// Header icon -> search card morph. The card starts clipped to the size of
// the icon and sitting on it, then drops below the header card and opens up
// to full size (width/height via clip-path, position via transform), while
// the glyph glides from the icon's spot to its own and the row height makes
// room underneath. Closing plays the same thing backwards.
const PKG_MORPH_MS = { open: 740, close: 580 };
// the wind up of the icon (leans back and up, smaller), shared by the button and by the icon of the card that takes over from it
const WIND = { x: 1.5, y: -3.5, s: .88, r: 16, ms: 170 };
const PKG_WOBBLE_MS = 380;       // after the icon has arrived: it shakes a little and settles
const PKG_MORPH_EASE = { open: 'cubic-bezier(.65,0,.2,1)', close: 'cubic-bezier(.65,0,.35,1)' };

// A small burst of dots from where the search button is (when it is pressed, and when the icon lands back on it)
function lqSearchBurst(cx, cy, n = 10) {
    if (typeof document.body.animate !== 'function') return;
    const layer = document.createElement('div');
    layer.className = 'pkg-burst';
    document.body.appendChild(layer);
    for (let i = 0; i < n; i++) {
        const d = document.createElement('i');
        const a = (i / n) * Math.PI * 2 + (Math.random() - .5) * .7;
        const r = 20 + Math.random() * 20, sz = 2.5 + Math.random() * 2.5;
        d.style.cssText = `left:${cx - sz / 2}px;top:${cy - sz / 2}px;width:${sz}px;height:${sz}px;`;
        layer.appendChild(d);
        d.animate(
            [{ transform: 'translate(0px, 0px) scale(1)', opacity: 1 }, { transform: `translate(${Math.cos(a) * r}px, ${Math.sin(a) * r}px) scale(.2)`, opacity: 0 }],
            { duration: 430 + Math.random() * 230, easing: 'cubic-bezier(.15,.7,.3,1)', fill: 'forwards' }
        );
    }
    setTimeout(() => layer.remove(), 820);
}

function setPkgSearchOpen(open) {
    const stack = document.getElementById('pkgStack');
    const wrap = document.getElementById('pkgSearchCollapse');
    const inner = wrap ? wrap.firstElementChild : null;
    const toggle = document.getElementById('pkgSearchToggle');
    const input = document.getElementById('pkgSearchInput');
    const clear = document.getElementById('pkgSearchClear');
    const card = wrap ? wrap.querySelector('.pkg-search') : null;
    if (!stack || !wrap || !inner || !toggle || !card) return;
    open = !!open;
    if (pkgState.searchBusy || !!pkgState.searchOpen === open) return;
    pkgState.searchOpen = open;
    pkgState.searchBusy = true;

    const glyph = card.querySelector(':scope > .lq-svg-icon');
    const canAnimate = typeof card.animate === 'function';
    const D = open ? PKG_MORPH_MS.open : PKG_MORPH_MS.close;
    const ease = open ? PKG_MORPH_EASE.open : PKG_MORPH_EASE.close;

    // where the icon button sits vs. where the card ends up
    // measured at rest size: when the search is open the button sits hidden at 0.6 scale, which would skew the close animation
    const tr0 = toggle.getBoundingClientRect();
    const tw = toggle.offsetWidth || tr0.width, th = toggle.offsetHeight || tr0.height;
    const tcx = tr0.left + tr0.width / 2, tcy = tr0.top + tr0.height / 2;
    const rest = tr0.width ? tr0.width / tw : 1;
    const t = { left: tcx - tw / 2, right: tcx + tw / 2, top: tcy - th / 2, bottom: tcy + th / 2, width: tw, height: th };
    const c = card.getBoundingClientRect();
    const g = glyph ? glyph.getBoundingClientRect() : null;
    const toggleIcon = toggle.querySelector('.pkg-toggle-icon');
    const ti0 = toggleIcon ? toggleIcon.getBoundingClientRect() : null;
    const ti = ti0 ? { width: ti0.width / rest } : null;
    const dx = t.right - c.right;
    const dy = (t.top + t.height / 2) - (c.top + c.height / 2);
    const vPad = Math.max(0, (c.height - t.height) / 2);
    const glyphShift = g ? ((t.left + t.width / 2) - (g.left + g.width / 2) - dx) : 0;
    const glyphScale = (g && ti && g.width) ? ti.width / g.width : 1;

    // corner radii: the icon slice uses the toggle's radius, the open card its own
    // (a % radius would be measured against the whole card, not the slice, so a round button is given in px)
    const srRaw = getComputedStyle(toggle).borderTopLeftRadius || '22px';
    const sr = srRaw.includes('%') ? Math.min(t.width, t.height) / 2 + 'px' : srRaw;
    const cs = getComputedStyle(card);
    const endRadii = [cs.borderTopLeftRadius, cs.borderTopRightRadius, cs.borderBottomRightRadius, cs.borderBottomLeftRadius]
        .map(v => v || '0px').join(' ');
    const clipStart = `inset(${vPad}px 0px ${vPad}px ${Math.max(0, c.width - t.width)}px round ${sr} ${sr} ${sr} ${sr})`;
    const clipEnd = `inset(0px 0px 0px 0px round ${endRadii})`;

    // the card drops first, then opens up; closing is the mirror image
    const moveMs = Math.round(D * .88);
    const growMs = Math.round(D * .82);
    const growDelay = open ? Math.round(D * .18) : 0;
    const moveDelay = open ? 0 : Math.round(D * .12);

    // The search button lives in the top bar, outside the scroll area that clips the card. So the morph is drawn by a copy of the card in a
    // layer of its own, above everything: the copy starts as a slice exactly on the button (same colour, same icon) and drops / grows from
    // there, so button, icon and card are ONE shape moving in ONE layer. The real card stays invisible until the copy is done.
    const fly = canAnimate && toggle.classList.contains('hdr-act');
    let flyLayer = null, flyCard = null;
    const swapToggle = (hide) => {
        toggle.style.transition = 'none';
        toggle.classList.toggle('is-hidden', hide);
        void toggle.offsetWidth;
        toggle.style.transition = '';
    };
    const mountFly = () => {
        flyLayer = document.createElement('div');
        flyLayer.className = 'pkg-fly-layer';
        const row = document.createElement('div');
        row.className = 'pkg-search-row';
        row.style.cssText = `position:absolute;left:${c.left}px;top:${c.top}px;width:${c.width}px;height:${c.height}px;`;
        flyCard = card.cloneNode(true);
        flyCard.querySelectorAll('[id]').forEach(n => n.removeAttribute('id'));
        flyCard.querySelectorAll('input,button').forEach(n => { n.tabIndex = -1; n.setAttribute('aria-hidden', 'true'); });
        row.appendChild(flyCard);
        // a soft veil over the page (it peaks in the middle of the move)
        const veil = document.createElement('div');
        veil.className = 'pkg-fly-veil';
        flyLayer.appendChild(veil);
        flyLayer.appendChild(row);
        document.body.appendChild(flyLayer);
        card.style.opacity = '0';
    };
    const unmountFly = () => {
        if (flyLayer) flyLayer.remove();
        flyLayer = null; flyCard = null;
        card.style.opacity = '';
    };

    const play = () => {
        const fill = open ? 'backwards' : 'forwards';
        const order = (a, b) => open ? [a, b] : [b, a];
        const anims = [];
        const el = flyCard || card;
        const gl = flyCard ? flyCard.querySelector(':scope > .lq-svg-icon') : glyph;
        const inp = flyCard ? flyCard.querySelector('.pkg-search-input') : input;
        const clr = flyCard ? flyCard.querySelector('.pkg-search-clear') : clear;
        // the card stays anchored on its right edge while it changes size, so the slice never leaves the button; it dips a few px past its place
        // and settles (closing plays it backwards).
        const kf = frames => open ? frames : frames.slice().reverse().map(f => ({ ...f, offset: 1 - f.offset }));
        if (flyCard) el.style.transformOrigin = '100% 50%';
        anims.push(el.animate(
            kf([
                { offset: 0, transform: `translate(${dx}px, ${dy}px) scale(1, 1)` },
                { offset: .76, transform: 'translate(0px, 5px) scale(1.012, 1.02)' },
                { offset: 1, transform: 'translate(0px, 0px) scale(1, 1)' }
            ]),
            { duration: moveMs, delay: moveDelay, easing: ease, fill }
        ));
        if (flyCard) {
            anims.push(el.animate(
                [{ boxShadow: '0 0 0 rgba(0,0,0,0)' }, { boxShadow: '0 16px 36px rgba(0,0,0,.4)', offset: .5 }, { boxShadow: '0 0 0 rgba(0,0,0,0)' }],
                { duration: D, easing: 'ease-in-out', fill }
            ));
            const veil = flyLayer.querySelector('.pkg-fly-veil');
            if (veil) anims.push(veil.animate([{ opacity: 0 }, { opacity: 1, offset: .45 }, { opacity: 0 }], { duration: D + 60, easing: 'linear', fill: 'both' }));
        }
        anims.push(el.animate(
            order({ clipPath: clipStart }, { clipPath: clipEnd }),
            { duration: growMs, delay: growDelay, easing: ease, fill }
        ));
        if (flyCard) {
            // the slice wears the button's colour at the button, and the card's colour once it is the card
            const bg1 = cs.backgroundColor;
            let bg0 = getComputedStyle(toggle).backgroundColor;
            // the button has no plate, so the slice starts fully see-through but already in the card's own colour (no dark tint on the way in)
            if (/^rgba\(.*,\s*0\)$|^transparent$/.test(bg0)) {
                bg0 = /^rgba?\(/.test(bg1) ? bg1.replace(/^rgba?\(([^,]+,[^,]+,[^,)]+).*$/, 'rgba($1, 0)') : 'rgba(0, 0, 0, 0)';
            }
            anims.push(el.animate(
                open
                    ? [{ backgroundColor: bg0 }, { backgroundColor: bg1, offset: .4 }, { backgroundColor: bg1 }]
                    : [{ backgroundColor: bg1 }, { backgroundColor: bg1, offset: .6 }, { backgroundColor: bg0 }],
                { duration: moveMs, delay: moveDelay, easing: 'linear', fill }
            ));
        }
        if (gl) {
            const gx = glyphShift, gs = glyphScale;
            // The icon travels on the same clock as the card's growth (same start, same end, same curve), so it arrives together with the card
            // and not before it. translate / scale / rotate are animated as separate properties, so they do not fight.
            if (open) {
                anims.push(gl.animate([{ translate: `${gx + WIND.x}px ${WIND.y}px`, scale: String(gs * WIND.s) }, { translate: '0px 0px', scale: '1' }],
                    { duration: growMs, delay: growDelay, easing: ease, fill }));
            } else {
                anims.push(gl.animate([{ translate: '0px 0px', scale: '1' }, { translate: `${gx}px 0px`, scale: String(gs) }],
                    { duration: growMs, delay: growDelay, easing: ease, fill }));
            }
            // The turn: NO spinning. The icon only turns the short way so the lens (the circle of the magnifier, up left at rest) points the way
            // it travels: opening (icon -> bar) it travels left, so the lens faces left; closing (bar -> icon) it travels right, so the lens
            // faces right. When it arrives it turns back a little to the upright resting pose, goes a bit past, shakes and settles.
            const vx = open ? (-dx - gx) : (dx + gx), vy = open ? -dy : dy;
            let lead = (((Math.atan2(vy, vx) * 180 / Math.PI) + 135) % 360 + 360) % 360;
            if (lead > 180) lead -= 360;                    // shortest way round, never more than half a turn
            const R0 = open ? WIND.r : 0, R1 = lead, F = 0, sg = open ? 1 : -1;
            const T = D + PKG_WOBBLE_MS, W = PKG_WOBBLE_MS;
            anims.push(gl.animate([
                { offset: 0, rotate: `${R0}deg`, easing: 'cubic-bezier(.3,.7,.3,1)' },
                { offset: .86 * D / T, rotate: `${R1}deg`, easing: 'cubic-bezier(.4,0,.3,1)' },
                { offset: (D + .4 * W) / T, rotate: `${F + sg * 9}deg`, easing: 'ease-in-out' },
                { offset: (D + .62 * W) / T, rotate: `${F - sg * 5}deg`, easing: 'ease-in-out' },
                { offset: (D + .82 * W) / T, rotate: `${F + sg * 2.5}deg`, easing: 'ease-in-out' },
                { offset: 1, rotate: `${F}deg` }
            ], { duration: T, fill: 'both' }));
        }
        [inp, clr].filter(Boolean).forEach(n => {
            anims.push(n.animate(
                open
                    ? [{ opacity: 0, filter: 'blur(6px)', transform: 'translateY(5px)' }, { opacity: 0, filter: 'blur(6px)', transform: 'translateY(5px)', offset: .45 }, { opacity: 1, filter: 'blur(0px)', transform: 'translateY(0px)' }]
                    : [{ opacity: 1, filter: 'blur(0px)', transform: 'translateY(0px)' }, { opacity: 0, filter: 'blur(5px)', transform: 'translateY(4px)', offset: .45 }, { opacity: 0, filter: 'blur(5px)', transform: 'translateY(4px)' }],
                { duration: growMs, delay: growDelay, easing: 'linear', fill }
            ));
        });
        return anims;
    };

    let fired = false;
    const once = (fn) => () => { if (fired) return; fired = true; fn(); };
    // the row height follows the card's drop so the tabs never get overlapped
    const heightTransition = `height ${moveMs}ms ${ease} ${moveDelay}ms`;

    const go = () => {
        if (open) {
            stack.classList.add('is-open');
            toggle.setAttribute('aria-expanded', 'true');
            wrap.classList.add('is-open');
            wrap.style.transition = heightTransition;
            wrap.style.height = '0px';
            void wrap.offsetHeight;
            wrap.style.height = inner.scrollHeight + 'px';

            if (fly) { mountFly(); swapToggle(true); } else toggle.classList.add('is-hidden');
            const anims = canAnimate ? play() : [];
            const finish = once(() => {
                wrap.style.height = 'auto';
                unmountFly();
                pkgState.searchBusy = false;
                // the keyboard waits for the morph to be over (it used to be asked for half way through, and it pushed the page while the card was still moving)
                setTimeout(() => { if (pkgState.searchOpen && input) input.focus({ preventScroll: true }); }, 90);
            });
            if (anims.length) Promise.all(anims.map(a => a.finished)).then(finish, finish);
            setTimeout(finish, D + PKG_WOBBLE_MS + 160);
        } else {
            const hadQuery = !!pkgState.query;
            if (input) { input.blur(); input.value = ''; }
            pkgState.query = '';
            if (clear) clear.classList.remove('visible');
            setPkgAddVisible(false);
            if (hadQuery) renderPkgList(false);

            stack.classList.remove('is-open');
            wrap.style.transition = 'none';
            wrap.style.height = wrap.offsetHeight + 'px';
            void wrap.offsetHeight;
            wrap.style.transition = heightTransition;
            wrap.style.height = '0px';

            if (fly) { mountFly(); setTimeout(() => lqSearchBurst(tcx, tcy), Math.round(D * .95)); }
            const anims = canAnimate ? play() : [];
            const finish = once(() => {
                wrap.classList.remove('is-open');
                unmountFly();
                if (fly) swapToggle(false); else toggle.classList.remove('is-hidden');
                toggle.setAttribute('aria-expanded', 'false');
                anims.forEach(a => { try { a.cancel(); } catch (e) {} });
                pkgState.searchBusy = false;
            });
            if (anims.length) Promise.all(anims.map(a => a.finished)).then(finish, finish);
            setTimeout(finish, D + PKG_WOBBLE_MS + 160);
        }
    };
    // opening: the icon winds up first, like about to launch (it leans back and up, a little smaller), the card comes out of it right after
    if (open && fly) {
        lqSearchBurst(tcx, tcy);
        const ico = toggle.querySelector('.pkg-toggle-icon') || toggle;
        try {
            ico.animate(
                [{ transform: 'translate(0px, 0px) scale(1) rotate(0deg)' }, { transform: `translate(${WIND.x}px, ${WIND.y}px) scale(${WIND.s}) rotate(${WIND.r}deg)` }],
                { duration: WIND.ms, easing: 'cubic-bezier(.25,.8,.35,1)', fill: 'forwards' }
            );
        } catch (e) {}
        setTimeout(() => { try { ico.getAnimations().forEach(a => a.cancel()); } catch (e) {} go(); }, WIND.ms);
    } else go();
}

// Adds the text from the search box to whichever tab is open. On the User
// tab it goes to the hand-added list, on the others to that tab's own list.
async function addTypedPackage(raw) {
    const pkg = String(raw || '').trim();
    if (!pkg.includes('.') || !PKG_NAME_RE.test(pkg)) {
        lqToastShow({ title: 'Add package', text: 'Invalid package name', state: 'err' });
        return false;
    }
    const tab = pkgState.active;
    if ((pkgState.data[tab] || []).includes(pkg)) {
        lqToastShow({ title: (tab === 'user' ? 'User list' : pkgListTitle(tab)), text: 'Already in this list', state: 'info' });
        return false;
    }
    const id = `${pkg}:add-typed`;
    if (pkgState.busy.has(id)) return false;
    pkgState.busy.add(id);

    const toast = pkgToastStart('Add package', `Adding ${pkg}…`);
    const scope = tab === 'user' ? 'userextra' : tab;
    const result = await exec(pkgBackendScript(scope, 'add', pkg, tab === 'preload' ? 'normal' : ''));
    pkgState.busy.delete(id);

    if (!String(result || '').includes('__LQ_OK__')) {
        console.error('Li Qinghe package add failed:', String(result || '(no backend response)'), {pkg, tab});
        toast.update({ state: 'err', text: `Could not add ${pkg}` });
        return false;
    }
    toast.update({ state: 'ok', text: `Added ${pkg}` });

    if (tab === 'user') await readUserPkgLists();
    else await loadPkgTab(tab);
    if (pkgState.active !== tab) return true;

    const input = document.getElementById('pkgSearchInput');
    const clear = document.getElementById('pkgSearchClear');
    if (input) input.value = '';
    if (clear) clear.classList.remove('visible');
    pkgState.query = '';
    setPkgAddVisible(false);
    renderPkgList(false);
    return true;
}

async function removeCustomUserPkg(pkg) {
    const id = `${pkg}:userextra`;
    if (pkgState.busy.has(id)) return;
    pkgState.busy.add(id);
    const toast = pkgToastStart('User list', `Removing ${pkg}…`);
    const result = await exec(pkgBackendScript('userextra', 'remove', pkg));
    pkgState.busy.delete(id);
    if (!String(result || '').includes('__LQ_OK__')) {
        console.error('Li Qinghe package remove failed:', String(result || '(no backend response)'), {pkg});
        toast.update({ state: 'err', text: `Could not remove ${pkg}` });
    } else {
        toast.update({ state: 'ok', text: `Removed ${pkg}` });
    }
    if (pkgState.expanded === pkg) pkgState.expanded = null;
    await readUserPkgLists();
    if (pkgState.active === 'user') renderPkgList(false);
}

async function togglePkgAction(pkg, key) {
    const cfg = pkgActions[key];
    const id = `${pkg}:${key}`;
    if (pkgState.busy.has(id)) return;

    const currentlyActive = pkgHasAction(pkg, key);
    pkgState.busy.add(id);
    renderPkgList(false);

    const mode = currentlyActive ? 'remove' : 'add';
    const toast = pkgToastStart(pkgListTitle(key), mode === 'add' ? `Adding ${pkg}…` : `Removing ${pkg}…`);
    const result = await exec(pkgBackendScript(key, mode, pkg, key === 'preload' && mode === 'add' ? 'normal' : ''));
    const resultText = String(result || '');
    const ok = resultText.includes('__LQ_OK__');

    pkgState.busy.delete(id);
    if (!ok) {
        toast.update({ state: 'err', text: mode === 'add' ? `Could not add ${pkg}` : `Could not remove ${pkg}` });
        console.error('Li Qinghe package mutation failed:', resultText || '(no backend response)', {pkg, key, mode});
        await loadPkgTab(key, true);
        renderPkgList(false);
        return;
    }

    toast.update({ state: 'ok', text: mode === 'add' ? `Added ${pkg}` : `Removed ${pkg}` });

    // A package pulled out of the Game tab shouldn't keep a stale driver
    // choice lying around -- reset any non-default group back to default.
    if (key === 'game' && mode === 'remove') {
        const state = pkgState.driverStates[pkg];
        if (state) {
            await Promise.all(
                driverGroupDefs
                    .filter(({ group }) => state[group] && state[group] !== 'default')
                    .map(({ group }) => exec(pkgBackendScript(pkg, 'set-driver', group, 'default')))
            );
            delete pkgState.driverStates[pkg];
        }
    }

    await loadPkgTab(key, true);
    await loadPkgTab('game', true);
    await loadPkgTab('preload', true);
    await loadPkgTab('whitelist', true);
    renderPkgList(false);
}

const pkgTabsUI = { touching: false, raf: 0, follow: 0 };

function pkgTabsParts() {
    const sc = document.getElementById('pkgTabsScroll');
    return { sc, btns: sc ? [...sc.querySelectorAll('.pkg-tab')] : [] };
}

// the sides of the strip fade only where there is still something to scroll to
function pkgTabsEdges() {
    const { sc } = pkgTabsParts();
    const wrap = document.getElementById('pkgTabs');
    if (!sc || !wrap) return;
    wrap.classList.toggle('can-left', sc.scrollLeft > 2);
    wrap.classList.toggle('can-right', sc.scrollLeft + sc.clientWidth < sc.scrollWidth - 2);
}

// keeps a tab fully in view. The active tab opens (grows) while this runs, so it follows the growing edge frame by frame
// instead of measuring a width that is still changing; it stops as soon as a finger touches the strip.
function pkgTabsReveal(key, smooth) {
    const { sc, btns } = pkgTabsParts();
    const b = btns.find(x => x.dataset.pkgTab === key);
    if (!sc || !b || !sc.clientWidth) return;
    const pad = 12;
    const goal = () => {
        const l = b.offsetLeft, r = l + b.offsetWidth;
        let t = sc.scrollLeft;
        if (l - pad < t) t = l - pad;
        else if (r + pad > t + sc.clientWidth) t = r + pad - sc.clientWidth;
        return Math.max(0, Math.min(t, sc.scrollWidth - sc.clientWidth));
    };
    cancelAnimationFrame(pkgTabsUI.follow);
    if (!smooth || (typeof lqReduced === 'function' && lqReduced())) {
        sc.scrollLeft = goal();
        pkgTabsEdges();
        return;
    }
    const t0 = performance.now();
    const step = () => {
        if (pkgTabsUI.touching) return;
        const g = goal(), d = g - sc.scrollLeft;
        if (Math.abs(d) > 0.5) sc.scrollLeft += d * 0.3;
        if (performance.now() - t0 < 700) pkgTabsUI.follow = requestAnimationFrame(step);
    };
    pkgTabsUI.follow = requestAnimationFrame(step);
}

// the list swaps in once the tab has had a moment to open
function animatePkgTabPill(key) {
    pkgTabsReveal(key, true);
    if (typeof lqReduced === 'function' && lqReduced()) return Promise.resolve();
    return new Promise(resolve => setTimeout(resolve, 260));
}

// ── Apps: leaving the list / popup ────────────────────────────────────────────
// What is on screen (the rows that are in view, or the popup card) drifts up and fades, top first, the same way a page
// leaves; only after that is it swapped. A popup that appears fades in instead of popping. While one leave is running,
// asking for another hands back the same one, so a quick second tap never flashes the rows back before they go.
const LQ_PKG_LEAVE = { dur: 150, step: 14, maxN: 7, y: -8 };
let lqPkgLeaveCur = null;
function lqPkgLeave() {
    const none = { done: Promise.resolve(), cancel() {} };
    if (lqPkgLeaveCur) return lqPkgLeaveCur;
    if (typeof lqReduced === 'function' && lqReduced()) return none;
    const list = document.getElementById('pkgList'), empty = document.getElementById('pkgEmpty');
    const vh = window.innerHeight || 800;
    const nodes = [];
    if (list && !list.hidden) lqNodesPkg().forEach(el => { const r = el.getBoundingClientRect(); if (r.height > 0 && r.bottom > 0 && r.top < vh) nodes.push(el); });
    if (empty && !empty.hidden) nodes.push(empty);
    if (!nodes.length || !nodes[0].animate) return none;
    const anims = nodes.map((el, i) => el.animate(
        [{ opacity: 1, translate: '0 0' }, { opacity: 0, translate: `0 ${LQ_PKG_LEAVE.y}px` }],
        { duration: LQ_PKG_LEAVE.dur, delay: Math.min(i, LQ_PKG_LEAVE.maxN) * LQ_PKG_LEAVE.step, easing: LQ_EXIT.ease, fill: 'both' }
    ));
    const cur = {
        done: Promise.all(anims.map(a => a.finished.catch(() => {}))),
        cancel() { anims.forEach(a => { try { a.cancel(); } catch (_) {} }); if (lqPkgLeaveCur === cur) lqPkgLeaveCur = null; }
    };
    lqPkgLeaveCur = cur;
    return cur;
}

// ── Apps: loading indicator ─────────────────────────────────────────────────────
// While a list loads, the old list simply stays where it is and a small round popup floats in the middle of the screen
// (outside the list) holding only the M3 loading shape. It is shown only when loading takes longer than a blink.
const lqPkgBusy = { want: false, el: null };
function lqPkgBusyApply(page) {
    const on = lqPkgBusy.want && (page || currentPage) === 'packages';
    if (!lqPkgBusy.el) {
        if (!on) return;
        const el = document.createElement('div');
        el.className = 'lq-pkg-busy';
        el.setAttribute('role', 'status');
        el.setAttribute('aria-label', 'Loading packages');
        el.innerHTML = lqMorphLoaderHTML();
        document.body.appendChild(el);
        lqPkgBusy.el = el;
        void el.offsetWidth;   // so the first show animates instead of appearing already open
    }
    lqPkgBusy.el.classList.toggle('is-on', on);
}
function lqPkgBusySet(on) { lqPkgBusy.want = !!on; lqPkgBusyApply(); }

function pkgShowEmpty(html) {
    const empty = document.getElementById('pkgEmpty');
    if (!empty) return;
    const wasHidden = empty.hidden;
    empty.hidden = false;
    empty.innerHTML = html;
    // The card is also one of the page's own entrance cards (lqPkgSurfaceEnter). If that entrance is running or waiting on it,
    // it already brings the card in: a second fade on top made it fade in, vanish, then come in again.
    const pageEntering = empty.classList.contains('lq-pkg-surface-anim') || empty.classList.contains('lq-pkg-surface-prep')
        || /lqPkgSurfaceEnter/.test(empty.style.animation || '');
    if (wasHidden && !pageEntering && !(typeof lqReduced === 'function' && lqReduced()) && empty.animate) {
        empty.animate(
            [{ opacity: 0, translate: '0 8px' }, { opacity: 1, translate: '0 0' }],
            { duration: 280, easing: 'cubic-bezier(.16,1,.3,1)' }
        );
    }
}

function switchPkgTab(key, options = {}) {
    const force = !!options.force;
    if (!pkgSources[key] || (!force && pkgState.active === key)) return;
    const skipNavAnimation = !!options.skipNavAnimation;

    pkgState.renderToken = (pkgState.renderToken || 0) + 1;
    pkgState.active = key;
    try { lqPkgScanSync(); } catch (_) {}
    pkgState.query = '';
    pkgState.expanded = null;
    const navToken = (pkgState.navAnimToken || 0) + 1;
    pkgState.navAnimToken = navToken;

    const input = document.getElementById('pkgSearchInput');
    const clear = document.getElementById('pkgSearchClear');
    const empty = document.getElementById('pkgEmpty');
    const list = document.getElementById('pkgList');

    if (input) input.value = '';
    if (clear) clear.classList.remove('visible');
    setPkgAddVisible(false);

    document.querySelectorAll('.pkg-tab[data-pkg-tab]').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.pkgTab === key);
        tab.setAttribute('aria-selected', String(tab.dataset.pkgTab === key));
    });

    // the old list stays on screen while the new one loads; it only stops reacting to touches, because its rows belong to the other tab
    if (list) list.classList.add('is-switching');

    const requestedKey = key;
    const token = pkgState.renderToken;
    const stale = () => pkgState.navAnimToken !== navToken || pkgState.active !== requestedKey || pkgState.renderToken !== token;
    // Game / Preload / Whitelist are read once at start-up (initPackageList): reopening the tab draws what is already in memory and
    // re-reads the file in the background afterwards, instead of waiting for the disk every time. A scan commit clears `loaded`.
    const fromMemory = requestedKey !== 'user' && !!pkgState.loaded[requestedKey];
    const dataPromise = (async () => {
        if (requestedKey === 'user') await loadPkgUserFast();
        else if (!fromMemory) await loadPkgTab(requestedKey);
        await loadPkgStatus();
        await lqLabelsEnsure(lqLabelCandidates(pkgState.data[requestedKey], requestedKey), 2500);
    })();
    const navPromise = skipNavAnimation ? Promise.resolve() : animatePkgTabPill(key);

    // the old content leaves, then the new list comes in; the loading popup goes away together with the leave
    const swapIn = async () => {
        lqPkgBusySet(false);
        const leave = lqPkgLeave();
        await leave.done;
        if (stale()) return false;
        leave.cancel();
        if (list) { list.replaceChildren(); list.classList.remove('is-switching'); }
        if (empty) empty.hidden = true;
        return true;
    };

    (async () => {
        try {
            // data that is already on disk comes back within a blink: then the popup is not shown at all
            let settled = false;
            dataPromise.then(() => { settled = true; }, () => { settled = true; });
            await Promise.race([dataPromise.catch(() => {}), new Promise(r => setTimeout(r, 120))]);
            if (stale()) return;
            if (!settled) lqPkgBusySet(true);

            await Promise.all([dataPromise, navPromise]);
            if (stale()) return;

            if (!(await swapIn())) return;
            renderPkgList(true);
            if (fromMemory) lqPkgBgRefresh(requestedKey);
        } catch (err) {
            if (stale()) return;
            console.error('Li Qinghe package list load failed:', err);
            if (!(await swapIn())) return;
            if (list) list.hidden = true;
            pkgShowEmpty(`${iconSVG('error_outline')}Failed to load packages.`);
        }
    })();
}

function initPackageTabs() {
    const { sc, btns } = pkgTabsParts();
    if (!sc) return;

    // a tap opens that tab; the strip only scrolls by hand (or to keep the opened tab in view), it never changes the open list by itself
    btns.forEach(tab => tab.addEventListener('click', () => {
        const key = tab.dataset.pkgTab;
        if (key === pkgState.active) { pkgTabsReveal(key, true); return; }
        switchPkgTab(key);
    }));

    sc.addEventListener('scroll', () => {
        if (!pkgTabsUI.raf) pkgTabsUI.raf = requestAnimationFrame(() => { pkgTabsUI.raf = 0; pkgTabsEdges(); });
    }, { passive: true });
    sc.addEventListener('touchstart', () => { pkgTabsUI.touching = true; cancelAnimationFrame(pkgTabsUI.follow); }, { passive: true });
    const lift = () => { pkgTabsUI.touching = false; };
    sc.addEventListener('touchend', lift, { passive: true });
    sc.addEventListener('touchcancel', lift, { passive: true });

    // the page is display:none while another page is open, which resets the strip: bring the active tab back into view when it shows
    const refit = () => { if (sc.clientWidth) pkgTabsReveal(pkgState.active, false); };
    if (typeof ResizeObserver === 'function') new ResizeObserver(refit).observe(sc);
    window.addEventListener('resize', refit, { passive: true });
    refit();
    pkgTabsEdges();
}

function initPackageSearch() {
    const input = document.getElementById('pkgSearchInput');
    const clear = document.getElementById('pkgSearchClear');
    if (!input || !clear) return;

    const releaseClearPress = () => clear.classList.remove('is-pressed');

    ['pointerup','pointercancel','pointerleave','blur'].forEach(type => {
        clear.addEventListener(type, releaseClearPress);
    });

    clear.addEventListener('pointerdown', (event) => {
        if (event.pointerType !== 'mouse') event.preventDefault();
        clear.classList.add('is-pressed');
    });

    clear.addEventListener('keydown', (event) => {
        if (event.key === ' ' || event.key === 'Enter') clear.classList.add('is-pressed');
    });

    clear.addEventListener('keyup', (event) => {
        if (event.key === ' ' || event.key === 'Enter') releaseClearPress();
    });

    const syncSearchQuery = () => {
        pkgState.query = input.value;
        clear.classList.toggle('visible', !!input.value);
        // Add only appears while there is something typed; the search card
        // makes room for it via the row's has-add state.
        updatePkgAddVisibility();

        if (pkgState.searchFrame) cancelAnimationFrame(pkgState.searchFrame);
        pkgState.searchFrame = requestAnimationFrame(() => {
            pkgState.searchFrame = 0;
            // Never replace/recreate the input while it is focused. Only
            // update the already-rendered package rows so Android WebView's
            // IME keeps its composing/input state intact.
            filterRenderedPkgList();
        });
    };

    const searchToggle = document.getElementById('pkgSearchToggle');
    if (searchToggle) {
        searchToggle.addEventListener('click', () => setPkgSearchOpen(!pkgState.searchOpen));
    }

    const addBtn = document.getElementById('pkgSearchAdd');
    if (addBtn) {
        // keep the IME open and the caret in place while tapping Add
        addBtn.addEventListener('pointerdown', event => {
            if (event.pointerType !== 'mouse') event.preventDefault();
        });
        addBtn.addEventListener('click', () => {
            if (addBtn.disabled) return;
            addTypedPackage(input.value);
        });
    }

    input.addEventListener('input', syncSearchQuery);
    // Android WebView/IME can keep text in a composition session briefly;
    // make sure the committed value is applied as soon as composition ends.
    input.addEventListener('compositionend', syncSearchQuery);

    clear.addEventListener('click', () => {
        releaseClearPress();
        // nothing typed: the X closes the search (morphs back to the icon)
        if (!input.value) {
            setPkgSearchOpen(false);
            return;
        }
        input.value = '';
        pkgState.query = '';
        clear.classList.remove('visible');
        setPkgAddVisible(false);
        input.focus();
        // Clearing the query must rebuild the full list. The current DOM may
        // only contain the previously filtered subset, so filtering in-place
        // cannot restore packages that were removed by a narrower search.
        renderPkgList(false);
    });
}

async function initPackageList() {
    initPackageTabs();
    initPackageSearch();
    initPkgSort();
    window.addEventListener('resize', () => renderPkgList(false), { passive: true });

    lqPkgBusySet(true);
    try {
        await loadPkgUserFast();
        await loadPkgStatus();
        await lqLabelsEnsure(pkgState.data.user, 2500);
        await lqLabelsEnsure(lqLabelCandidates(pkgState.data.game, 'game'), 2500);
    } finally {
        lqPkgBusySet(false);
    }
    renderPkgList(false);
}

// ── Pull to refresh ───────────────────────────────────────────
// Drag down while the page is already at the top: a round refresh indicator (Material 3)
// follows the finger, and letting go past the trigger refreshes ONLY what the page you
// are on shows. Settings has nothing to refresh, so it does not react.
const LQ_PTR_TRIGGER = 64, LQ_PTR_MAX = 100, LQ_PTR_HOLD_Y = 14, LQ_PTR_HIDE_Y = -68, LQ_PTR_MIN_MS = 700;
const lqPtr = { rot: 0, raf: 0, el: null, y0: 0, x0: 0, dist: 0, tracking: false, engaged: false, refreshing: false, scroller: null, frame: 0 };

const LQ_PAGE_REFRESH = {
    dashboard: () => Promise.allSettled([checkConflict(), lqUptimeRead(), lqPullTweakState()]),
    // CPU and temperature already follow themselves while this page is open; only the
    // slow numbers (RAM, swap, storage, battery) are refreshed here.
    monitor:   () => tickSystemSlow(),
    tweaks:    () => lqPullTweakState(),
    packages:  async () => {
        if (pkgState.busy && pkgState.busy.size) return;
        // Pull down on the User tab = scan the installed apps again (what the Action button did), no trip to the manager needed
        if (pkgState.active === 'user') {
            const before = new Set(pkgState.data.user || []);
            const [res] = await Promise.all([lqUserRescan({ repaint: false }), loadPkgStatus(true).catch(() => {})]);
            if (pkgState.active !== 'user') return;
            const now = pkgState.data.user || [];
            const added = now.filter(p => !before.has(p)).length;
            const removed = [...before].filter(p => !now.includes(p)).length;
            if (added || removed) {
                // what changed leaves and comes back the way a tab switch does
                const list = document.getElementById('pkgList');
                const leave = lqPkgLeave();
                await leave.done;
                leave.cancel();
                if (list) list.replaceChildren();
                renderPkgList(true);
            } else renderPkgList(false);
            if (!res.ok) lqToastShow({ title: 'User apps', text: res.reason || 'The scan failed', state: 'err' });
            else lqToastShow({ title: 'User apps', text: (added || removed)
                ? [added ? `${added} new` : '', removed ? `${removed} removed` : ''].filter(Boolean).join(', ')
                : `Up to date, ${now.length} apps`, state: 'ok' });
            return;
        }
        await Promise.allSettled([loadPkgStatus(true)]);
        renderPkgList(false);
    }
};

// Material 3 Expressive loading indicator: one filled shape that morphs through the
// M3 shape family (soft burst, cookie, pentagon, pill, sunny, clover, oval) while it
// turns. Each shape is a radius table over the same angles, so any two can be blended.
const LQ_MORPH_N = 72;
const LQ_MORPH_SHAPES = (() => {
    const N = LQ_MORPH_N;
    const mk = f => {
        const a = [];
        for (let i = 0; i < N; i++) a.push(f(i / N * 2 * Math.PI));
        const m = Math.max(...a);
        return a.map(v => v / m);
    };
    const lobes = (k, amp) => t => 1 + amp * Math.cos(k * t);
    const ellipse = (a, b) => t => { const c = Math.cos(t), s = Math.sin(t); return 1 / Math.sqrt(c * c / (a * a) + s * s / (b * b)); };
    const superE = (a, b, n) => t => { const c = Math.abs(Math.cos(t)), s = Math.abs(Math.sin(t)); return Math.pow(Math.pow(c / a, n) + Math.pow(s / b, n), -1 / n); };
    return [
        mk(lobes(10, .07)),        // soft burst
        mk(lobes(9, .06)),         // 9-sided cookie
        mk(lobes(5, .12)),         // pentagon
        mk(superE(1, .62, 3.2)),   // pill
        mk(lobes(8, .16)),         // sunny
        mk(lobes(4, .10)),         // clover
        mk(ellipse(1, .7))         // oval
    ];
})();

function lqMorphPath(a, b, t) {
    let d = '';
    for (let i = 0; i < LQ_MORPH_N; i++) {
        const th = i / LQ_MORPH_N * 2 * Math.PI;
        const r = (a[i] + (b[i] - a[i]) * t) * 0.95;
        d += (i ? 'L' : 'M') + (r * Math.cos(th)).toFixed(3) + ' ' + (r * Math.sin(th)).toFixed(3);
    }
    return d + 'Z';
}

// The morph runs as an SVG <animate> (SMIL) and the turn as a CSS animation, so neither
// needs the JS thread: a refresh that is busy loading keeps the indicator moving smoothly.
// A requestAnimationFrame loop is only the fallback when SMIL is missing.
const LQ_MORPH_STEP = 620;
function lqMorphBuildAnim(path) {
    const SH = LQ_MORPH_SHAPES, n = SH.length;
    const vals = [], kt = [], ks = [];
    for (let i = 0; i <= n; i++) {
        vals.push(lqMorphPath(SH[i % n], SH[i % n], 0));
        kt.push((i / n).toFixed(5));
        if (i < n) ks.push('.4 0 .2 1');
    }
    const an = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
    an.setAttribute('attributeName', 'd');
    an.setAttribute('dur', (n * LQ_MORPH_STEP) + 'ms');
    an.setAttribute('repeatCount', 'indefinite');
    an.setAttribute('calcMode', 'spline');
    an.setAttribute('keyTimes', kt.join(';'));
    an.setAttribute('keySplines', ks.join(';'));
    an.setAttribute('values', vals.join(';'));
    an.setAttribute('begin', 'indefinite');
    path.appendChild(an);
    return an;
}

// The same Material 3 Expressive loading shape as the pull-to-refresh, for a loading state that sits in the page.
// It is plain markup: the morph is an SVG <animate> and the turn is a CSS animation, so it keeps moving while the
// JS thread is busy loading. The long keyframe strings are built once and reused for every instance.
let lqMorphMarkup = null;
function lqMorphLoaderHTML(extraClass = '') {
    if (!lqMorphMarkup) {
        const SH = LQ_MORPH_SHAPES, n = SH.length, vals = [], kt = [], ks = [];
        for (let i = 0; i <= n; i++) {
            vals.push(lqMorphPath(SH[i % n], SH[i % n], 0));
            kt.push((i / n).toFixed(5));
            if (i < n) ks.push('.4 0 .2 1');
        }
        lqMorphMarkup = `<animate attributeName="d" dur="${n * LQ_MORPH_STEP}ms" repeatCount="indefinite" calcMode="spline" ` +
            `keyTimes="${kt.join(';')}" keySplines="${ks.join(';')}" values="${vals.join(';')}"/>`;
    }
    return `<svg class="lq-morph-ic turn${extraClass ? ' ' + extraClass : ''}" viewBox="-1.1 -1.1 2.2 2.2" aria-hidden="true">` +
        `<path fill="currentColor" d="${lqMorphPath(LQ_MORPH_SHAPES[0], LQ_MORPH_SHAPES[0], 0)}">${lqMorphMarkup}</path></svg>`;
}

function lqPtrSpinStart() {
    const svg = lqPtr.el.firstElementChild, path = svg.firstElementChild;
    // hand the turn over from the finger to the CSS animation without a jump
    svg.style.setProperty('--r0', (lqPtr.rot % 360) + 'deg');
    svg.style.transform = '';
    svg.classList.add('turn');
    if (!lqPtr.anim) lqPtr.anim = lqMorphBuildAnim(path);
    if (lqPtr.anim && typeof lqPtr.anim.beginElement === 'function') {
        try { lqPtr.anim.beginElement(); lqPtr.useSmil = true; return; } catch (_) {}
    }
    lqPtr.useSmil = false;
    const SH = LQ_MORPH_SHAPES, t0 = performance.now();
    const step = now => {
        const el = now - t0, idx = Math.floor(el / LQ_MORPH_STEP), f = (el % LQ_MORPH_STEP) / LQ_MORPH_STEP;
        const e = f < .5 ? 2 * f * f : 1 - Math.pow(-2 * f + 2, 2) / 2;
        path.setAttribute('d', lqMorphPath(SH[idx % SH.length], SH[(idx + 1) % SH.length], e));
        lqPtr.raf = requestAnimationFrame(step);
    };
    cancelAnimationFrame(lqPtr.raf);
    lqPtr.raf = requestAnimationFrame(step);
}

function lqPtrSpinStop() {
    cancelAnimationFrame(lqPtr.raf);
    lqPtr.raf = 0;
    const svg = lqPtr.el && lqPtr.el.firstElementChild;
    if (svg) svg.classList.remove('turn');
    if (lqPtr.anim && typeof lqPtr.anim.endElement === 'function') { try { lqPtr.anim.endElement(); } catch (_) {} }
}

function lqPtrAtTop(host) {
    return host.scrollTop <= 0 && (!lqPtr.scroller || lqPtr.scroller.scrollTop <= 0);
}

function lqPtrPaint(d) {
    lqPtr.dist = d;
    if (lqPtr.frame) return;
    lqPtr.frame = requestAnimationFrame(() => {
        lqPtr.frame = 0;
        const el = lqPtr.el; if (!el) return;
        const dd = lqPtr.dist, p = Math.min(1, dd / LQ_PTR_TRIGGER);
        el.style.opacity = '1';
        el.style.transform = `translate3d(0,${LQ_PTR_HIDE_Y + dd * 1.3}px,0) scale(${0.85 + 0.15 * p})`;
        lqPtr.rot = Math.round(dd * 4.5);
        el.firstElementChild.style.transform = `rotate(${lqPtr.rot}deg)`;
        const SH = LQ_MORPH_SHAPES, q = Math.round(p * 10) / 10;
        if (q !== lqPtr.lastQ) { lqPtr.lastQ = q; el.firstElementChild.firstElementChild.setAttribute('d', lqMorphPath(SH[0], SH[1], q)); }
    });
}

function lqPtrRetract() {
    const el = lqPtr.el; if (!el) return;
    el.classList.add('snap');
    el.classList.remove('spin');
    el.style.transform = `translate3d(0,${LQ_PTR_HIDE_Y}px,0) scale(.85)`;
}

async function lqPtrRun() {
    const el = lqPtr.el, page = currentPage, fn = LQ_PAGE_REFRESH[page];
    if (!el || !fn) { lqPtrRetract(); return; }
    lqPtr.refreshing = true;
    el.classList.add('snap', 'spin');
    el.style.opacity = '1';
    el.style.transform = `translate3d(0,${LQ_PTR_HOLD_Y}px,0) scale(1)`;
    lqPtrSpinStart();
    // two frames so the indicator is already moving before the refresh work blocks the thread
    await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
    const t0 = performance.now();
    try {
        await Promise.race([fn(), new Promise(r => setTimeout(r, 25000))]);
    } catch (_) {}
    const rest = LQ_PTR_MIN_MS - (performance.now() - t0);
    if (rest > 0) await new Promise(r => setTimeout(r, rest));
    lqPtrRetract();
    setTimeout(() => { lqPtr.refreshing = false; lqPtrSpinStop(); lqPtr.rot = 0; lqPtr.lastQ = -1; lqPtr.el.firstElementChild.firstElementChild.setAttribute('d', lqMorphPath(LQ_MORPH_SHAPES[0], LQ_MORPH_SHAPES[0], 0)); }, 280);
}

function lqPtrInit() {
    const host = document.getElementById('mainContent');
    if (!host) return;
    const el = document.createElement('div');
    el.className = 'lq-ptr';
    el.setAttribute('aria-hidden', 'true');
    el.innerHTML = '<svg class="lq-ptr-ic" viewBox="-1.1 -1.1 2.2 2.2"><path fill="currentColor"/></svg>';
    el.firstElementChild.firstElementChild.setAttribute('d', lqMorphPath(LQ_MORPH_SHAPES[0], LQ_MORPH_SHAPES[0], 0));
    // the indicator lives in a clip box that starts at the header's bottom edge, so it
    // slides out from underneath the header like a layer
    const clip = document.createElement('div');
    clip.className = 'lq-ptr-clip';
    clip.appendChild(el);
    document.body.appendChild(clip);
    lqPtr.el = el; lqPtr.clip = clip;

    host.addEventListener('touchstart', e => {
        lqPtr.tracking = false; lqPtr.engaged = false;
        if (lqPtr.refreshing || navBusy || e.touches.length !== 1) return;
        if (!LQ_PAGE_REFRESH[currentPage]) return;
        if (e.target.closest && e.target.closest('input,textarea,select,#pkgTabs,[data-no-ptr]')) return;
        lqPtr.scroller = currentPage === 'packages' ? document.querySelector('#page-packages .pkg-list-scroll') : null;
        if (!lqPtrAtTop(host)) return;
        lqPtr.y0 = e.touches[0].clientY; lqPtr.x0 = e.touches[0].clientX;
        lqPtr.tracking = true;
    }, { passive: true });

    host.addEventListener('touchmove', e => {
        if (!lqPtr.tracking) return;
        const t = e.touches[0], dy = t.clientY - lqPtr.y0, dx = t.clientX - lqPtr.x0;
        if (!lqPtr.engaged) {
            if (dy < -4 || (Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy))) { lqPtr.tracking = false; return; }
            if (dy < 8) return;
            if (!lqPtrAtTop(host)) { lqPtr.tracking = false; return; }
            lqPtr.engaged = true;
            const bar = document.querySelector('.top-app-bar');
            lqPtr.clip.style.top = (bar ? bar.getBoundingClientRect().bottom : 44) + 'px';
            lqPtr.el.classList.remove('snap', 'spin');
        }
        if (e.cancelable) e.preventDefault();
        lqPtrPaint(Math.max(0, Math.min(LQ_PTR_MAX, (dy - 8) * 0.5)));
    }, { passive: false });

    const end = () => {
        if (!lqPtr.engaged) { lqPtr.tracking = false; return; }
        lqPtr.tracking = false; lqPtr.engaged = false;
        if (lqPtr.frame) { cancelAnimationFrame(lqPtr.frame); lqPtr.frame = 0; }
        if (lqPtr.dist >= LQ_PTR_TRIGGER) lqPtrRun(); else lqPtrRetract();
    };
    host.addEventListener('touchend', end, { passive: true });
    host.addEventListener('touchcancel', end, { passive: true });
}

// ── Boot ──────────────────────────────────────────────────────

// One-line subtitles that do not fit (the cards on the Settings page) can be swiped sideways to read the rest. A "…" shows on every side that
// still has hidden text, and goes away when that end is reached.
function lqHScrollInit(root) {
    (root || document).querySelectorAll('.lq-mon-entry-sub:not(.lq-hs)').forEach(sub => {
        const text = sub.textContent;
        sub.textContent = '';
        const inn = document.createElement('span'); inn.className = 'lq-hs-in'; inn.textContent = text;
        const dl = document.createElement('i'), dr = document.createElement('i');
        dl.className = 'lq-hs-dot l'; dr.className = 'lq-hs-dot r';
        dl.textContent = dr.textContent = '\u2026'; dl.setAttribute('aria-hidden', 'true'); dr.setAttribute('aria-hidden', 'true');
        sub.classList.add('lq-hs');
        sub.append(inn, dl, dr);
        const upd = () => {
            const max = inn.scrollWidth - inn.clientWidth;
            sub.classList.toggle('has-l', inn.scrollLeft > 1);
            sub.classList.toggle('has-r', max > 1 && inn.scrollLeft < max - 1);
        };
        inn.addEventListener('scroll', upd, { passive: true });
        window.addEventListener('resize', upd);
        if ('ResizeObserver' in window) new ResizeObserver(upd).observe(inn);
        upd();
    });
}

// The splash (and its compositor animations) gets painted first: the heavy init below (maps, shaders, canvases, state reads) used to start in the
// very same task as the first frame, so the liquid stood still or stuttered at the start. It is hidden under the splash anyway.
let lqBootStarted = false;
function lqBootGo() { if (lqBootStarted) return; lqBootStarted = true; lqBoot(); }
// Single-line texts that end in "…" can be dragged sideways to read the rest. The ones that are plain elements scroll natively (see the CSS at the end of styles.css);
// the toasts take the finger themselves (the card is dragged), so their lines are scrolled by hand (see lqToastWire). Either way the left edge fades
// out once the line has been scrolled, so it is clear there is text before it too (the "…" on the right is the plain ellipsis).
function lqHsMark(el) { el.classList.toggle('hs-l', el.scrollLeft > 1); }
document.addEventListener('scroll', e => {
    const t = e.target;
    if (t && t.nodeType === 1 && t.matches && t.matches('.lq-bk-stage-name, .ui-custom-seed-code, .pkg-action-label, .header-left .wm-name')) lqHsMark(t);
}, true);

window.addEventListener('DOMContentLoaded', () => {
    lqSplashFillStart();
    requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(lqBootGo, 0)));
    setTimeout(lqBootGo, 400);       // a hidden WebView does not run frames: never wait for one
});
function lqBoot() {

    // saved look first, so nothing below can keep it from being applied
    lqSafeInit('radius', initUIRadiusSettings);
    lqSafeInit('sizeFont', initUIScaleSettings);
    lqSafeInit('glass', initUILiquidGlassSettings);
    lqSafeInit('frost', initUIFrostedGlassSettings);
    lqSafeInit('angletex', initAngleTexturePage);
    lqSafeInit('glassFx', initGlassEffectModes);
    lqSafeInit('navSettings', initNavSettings);
    lqSafeInit('palette', initUIPaletteSettings);
    lqSafeInit('navigation', initNavigation);
    lqSafeInit('packages', initPackageList);
    lqSafeInit('syncNotice', lqUpdateSyncNotice);
    lqSafeInit('tweaks', initTweaksPage);
    lqSafeInit('hscroll', lqHScrollInit);
    lqSafeInit('banner', initUIBannerSettings);
    lqSafeInit('backup', initUIBackupSettings);
    lqSafeInit('skeleton', initUISkeleton);
    lqSafeInit('toastWarm', lqToastWarmUp);
    lqSafeInit('glassPreview', lqGlassPreviewWarm);
    lqSafeInit('atxPreview', lqAtxWarm);
    lqSafeInit('assets', lqWarmAssets);

    lqSafeInit('dashboard', lqResetDashboard);
    lqSafeInit('splash', () => runSplash(1200));
    lqSafeInit('deviceInfo', loadDeviceInfo);
    lqSafeInit('deviceToggle', initDeviceToggle);
    lqSafeInit('about', initAbout);
    lqSafeInit('aboutPhone', lqAboutWarm);
    lqSafeInit('environment', loadEnvironment);
    lqSafeInit('verify', lqVerifyLoad);
    lqSafeInit('cpu', tickCPU);
    lqSafeInit('temp', tickTemp);
    lqSafeInit('system', tickSystemSlow);
    lqSafeInit('uptime', lqUptimeRead);
    setInterval(() => { if (document.hidden || (typeof currentPage !== 'undefined' && currentPage !== 'dashboard')) return; lqPaintUptime(); if (Date.now() - lqUptime.at > 300000) lqUptimeRead(); }, 1000);
    setInterval(() => lqWhenCalm('cpu', tickCPU), 6000);
    setInterval(() => lqWhenCalm('temp', tickTemp), 3000);
    setInterval(() => lqWhenCalm('sys', tickSystemSlow), 30000);
    lqSafeInit('conflict', async () => {
        lqSplashNote('Checking service status...');
        for (let i = 0; i < 6; i++) {
            lqBootStep('conflict', 'run', i ? `try ${i + 1}/6` : '');
            if ((await checkConflict()) === true) break;
            await new Promise(r => setTimeout(r, 400 + i * 400));
        }
        if (!lqStatusVerified) {
            const lbl = document.getElementById('statusLabel');
            if (lbl && lbl.textContent === 'Checking...') lbl.textContent = 'Unknown';
        }
        lqSplashNote('');
        return lqStatusVerified ? (document.getElementById('statusLabel')?.textContent || true) : false;
    });
    // offset from the temperature poll so the two never land on the same frame
    setTimeout(() => setInterval(() => lqWhenCalm('conflict', checkConflict), 3000), 1500);
    lqSafeInit('pullRefresh', lqPtrInit);

    // coming back to the app: catch up right away instead of waiting a full interval
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) return;
        lqWhenCalm('conflict', checkConflict);
        lqRefreshDashboard();
        lqUptimeRead();
    });

    // If the WebUI storage was wiped (fresh flash), bring the saved look back
    // from the module's own folder. One reload applies everything cleanly.
    // the sync part of the boot is over: the home page gets built under the splash now, while the liquid rises
    requestAnimationFrame(() => setTimeout(lqSplashPrebuild, 80));
    setTimeout(lqSplashPrebuild, 700);       // (a hidden WebView runs no frames)

    lqSafeInit('restorePrefs', async () => {
        const r = await lqRestoreUIPrefs();
        if (r === 'wait') { lqRestoreRetry(); return false; }      // the saved copy has not answered yet: nothing is written over it, and it is asked again
        if (r === 'restored') await lqRepaintUIPrefs();      // something was missing and the module's own copy was put back: repaint live, no reload
    });
}

// ── Liquid accordion (Color Palette, Radius, Banner, Trace Guard, ...) ─────
// The opened content drops out from behind its header card and overshoots a
// little at the bottom before it settles; closing slides it all the way back
// in behind the header. The slot (height + gap) is animated so the cards below
// follow; the surface and the content move rigidly with the slot's bottom edge.
// Sampled from a spring ahead of time and played with WAAPI.
function initLiquidAccordions() {
    const SEL = '.lq-split > .ui-settings-expand-wrap, .lq-split > .tk-trace-body-wrap';
    const OPEN_MS = 760, CLOSE_MS = 540, OVERSHOOT_PX = 6;
    const ease = t => { t = Math.max(0, Math.min(1, t)); return t * t * t * (t * (6 * t - 15) + 10); };
    const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
    const lerp = (a, b, k) => a + (b - a) * k;
    // leaves right away (responsive), glides in, then a small overshoot that settles exactly
    const drop = (u, bump) => {
        const base = 1 - Math.pow(1 - Math.min(u / 0.55, 1), 2.6);
        const over = bump * Math.sin(Math.PI * Math.max(0, Math.min(1, (u - 0.4) / 0.6))) * sm((u - 0.35) / 0.15);
        return base + over;
    };
    const reduced = () => !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);

    function stop(w) {
        (w._lqAnims || []).forEach(a => { a.onfinish = null; a.cancel(); });
        w._lqAnims = [];
    }
    function finish(w, card, closing) {
        stop(w);
        w.classList.remove('lq-animating');
        card.classList.remove('lq-dropping');
        w.style.removeProperty('--drop-h');
        w.style.removeProperty('grid-template-rows');
        if (w.firstElementChild) w.firstElementChild.style.willChange = '';
    }

    // Cards around the one that opens / closes react to it: the nearest card moves
    // first and the most, every card further away starts a little later and moves
    // less, so the feedback is only felt right around the card, like a ripple that
    // dies out. Only the cards below react (pushed when opening, tugged when
    // closing); the cards above stay still. Hidden cards don't take a slot, so the
    // order stays gap-free. Layout position itself is untouched, this is only a
    // transient `translate` that settles back to 0.
    const NUDGE = { below: { open: 13, close: -8 } };
    const NUDGE_FALLOFF = 0.52, NUDGE_STEP_MS = 62, NUDGE_MS = 680, NUDGE_REACH = 5;
    function nudgeRing(card) {
        const out = [];
        let el = card.nextElementSibling;
        while (el && out.length < NUDGE_REACH) {
            if (el.offsetHeight > 0 && el.animate) out.push(el);
            el = el.nextElementSibling;
        }
        return out;
    }
    function nudge(card, open) {
        if (reduced()) return;
        {
            const base = NUDGE.below[open ? 'open' : 'close'];
            nudgeRing(card).forEach((el, i) => {
                const A = base * Math.pow(NUDGE_FALLOFF, i);       // further away = smaller move
                if (Math.abs(A) < 0.4) return;
                const frames = [];
                for (let k = 0; k <= 16; k++) {
                    const u = k / 16;
                    frames.push({ offset: u, translate: `0 ${(A * Math.sin(Math.PI * u) * (1 - 0.25 * u)).toFixed(2)}px` });
                }
                const a = el.animate(frames, { duration: NUDGE_MS, delay: 30 + i * NUDGE_STEP_MS, easing: 'linear', fill: 'backwards' });
                a.onfinish = a.oncancel = () => {};
            });
        }
    }

    function run(w, open) {
        const card = w.parentElement, content = w.firstElementChild;
        if (!card || !content) return;
        if (!w.offsetParent || reduced() || !w.animate) { finish(w, card, !open); return; }
        const gap = parseFloat(getComputedStyle(card).getPropertyValue('--split-gap')) || 4;
        // where the slot is right now (it may be mid-way through the other move)
        const h0 = w._lqAnims && w._lqAnims.length ? w.getBoundingClientRect().height : (open ? 0 : w._lqH || content.scrollHeight);
        const m0 = w._lqAnims && w._lqAnims.length ? parseFloat(getComputedStyle(w).marginTop) || 0 : (open ? 0 : gap);
        stop(w);
        const H = content.scrollHeight;                    // the content's full height
        w._lqH = H;
        if (H < 4) { finish(w, card, !open); return; }
        w.style.setProperty('--drop-h', `${H}px`);
        w.style.setProperty('grid-template-rows', '1fr', 'important');   // keep it laid out while it slides back
        w.classList.add('lq-animating');
        card.classList.add('lq-dropping');
        content.style.willChange = 'transform, opacity';

        const N = 34, slot = [], inner = [];
        const ms = open ? OPEN_MS : CLOSE_MS;
        for (let i = 0; i <= N; i++) {
            const u = i / N;
            let h, m, op;
            if (open) {
                const dist = Math.max(1, H - h0);
                const x = drop(u, Math.min(0.06, OVERSHOOT_PX / dist));
                h = h0 + (H - h0) * x;
                m = lerp(m0, gap, sm((u - 0.3) / 0.4));                                    // the gap opens once it has dropped out
                op = sm((u - 0.02) / 0.3);
            } else {
                const swell = 0.008 * Math.sin(Math.PI * Math.min(u / 0.08, 1)) * (u < 0.08 ? 1 : 0);   // a small pull before it goes
                h = h0 * (1 - ease((u - 0.04) / 0.96)) * (1 + swell);
                m = lerp(m0, 0, sm(u / 0.3));                                                // the gap closes first
                op = 1 - sm((u - 0.05) / 0.4);
            }
            slot.push({ offset: u, height: `${Math.max(0, h).toFixed(2)}px`, marginTop: `${m.toFixed(2)}px` });
            // the content rides with the bottom edge of the slot
            inner.push({ offset: u, transform: `translate3d(0,${(-Math.max(0, H - h) * 0.7).toFixed(2)}px,0)`, opacity: op });
        }
        const a1 = w.animate(slot, { duration: ms, easing: 'linear' });
        const a2 = content.animate(inner, { duration: ms, easing: 'linear' });
        w._lqAnims = [a1, a2];
        nudge(card, open);
        a1.onfinish = () => finish(w, card, !open);
    }

    function setup(w) {
        if (w._lqDrop) return;
        w._lqDrop = true;
        w.classList.add('lq-drop');
        w._lqOpen = w.classList.contains('is-open');
        new MutationObserver(() => {
            const open = w.classList.contains('is-open');
            if (open === w._lqOpen) return;
            w._lqOpen = open;
            run(w, open);
        }).observe(w, { attributes: true, attributeFilter: ['class'] });
    }
    document.querySelectorAll(SEL).forEach(setup);
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initLiquidAccordions);
else initLiquidAccordions();

// ── Warm-up for the first toast ─────────────────────────────────────────────────────────────────────────────────────────────
// The first toast used to pay for everything at once while it was already animating: making the WebGL context, compiling and linking
// the liquid shader, allocating the big canvas, the first colour read, building the toast layer. That is what made the first
// appearance stutter. It is a boot step now: it runs while the splash is on screen (the splash waits for it, like for every other
// init step), so by the time the app shows, the toast only has to use what is ready. Nothing is shown and no toast is created; a
// failure only means the first toast pays for it as before.
// The glass part of the warm-up: everything the first Liquid Glass toast would otherwise do while it is already moving. Two bend filters
// are built and put in the pool, and a hidden card and a hidden sheet (the same classes and the same backdrop filter as the real ones,
// at 1% opacity, nobody can see them) are put on screen for a few frames, which makes the browser build the blur + bend pipeline and
// decode the map now. Done under the splash at start-up, and again (debounced) whenever Liquid Glass is applied.
let lqGlassWarmT = 0;
document.addEventListener('visibilitychange', () => { if (!document.hidden) lqToastGlassWarmLater(); }, { passive: true });
function lqToastGlassWarmLater() {
    clearTimeout(lqGlassWarmT);
    lqGlassWarmT = setTimeout(() => { lqToastGlassWarm().catch(() => {}); }, 450);
}
async function lqToastGlassWarm() {
    const root = document.documentElement;
    if (!root.classList.contains('lq-glass-on')) return false;
    const src = LQ_GXF.get('lqf-toast');
    if (!src || !src.o) return false;
    const frame = () => new Promise(r => requestAnimationFrame(() => r()));
    const ids = [];
    while (LQ_LIQ.pool.length + ids.length < 2) ids.push(lqLiqFilterTake(src));     // two ready filters
    ids.forEach(lqLiqFilterGive);
    const fid = LQ_LIQ.pool[LQ_LIQ.pool.length - 1];
    const card = document.createElement('div');
    card.className = 'lq-toast';
    card.setAttribute('aria-hidden', 'true');
    const wW = Math.max(120, Math.min(window.innerWidth - 24, 420));        // as big as a real toast and its body, not a token square
    card.style.cssText = `position:fixed;left:0;top:0;right:auto;bottom:auto;width:${wW}px;height:${LQ_TOAST_H}px;opacity:.01;pointer-events:none;transition:none;z-index:1`;
    const sheet = document.createElement('div');
    sheet.setAttribute('aria-hidden', 'true');
    sheet.style.cssText = `position:fixed;left:0;top:${LQ_TOAST_H + 8}px;width:${wW}px;height:150px;opacity:.01;pointer-events:none;z-index:1`;
    document.body.appendChild(card);
    try {
        const cst = getComputedStyle(card);
        const bf = (cst.backdropFilter || cst.webkitBackdropFilter || '').trim();
        const bfT = bf && bf !== 'none' ? bf.replace(/url\(['"]?#lqf-toast['"]?\)/, `url(#${fid})`) : '';
        if (bfT) { sheet.style.backdropFilter = bfT; sheet.style.webkitBackdropFilter = bfT; }
        document.body.appendChild(sheet);
        await frame(); await frame(); await frame();
    } finally {
        card.remove(); sheet.remove();
    }
    return true;
}

// The code a toast runs on every frame (the body's numbers, the field, the outline found row by row with a bisection per edge, the neck's
// metrics) is a few thousand field reads per frame, and a function that has just been loaded runs it several times slower for its first
// hundreds of calls, until the engine has compiled it: that was the hitch at the start of the first toast, which later toasts did not
// have. It is run here on made-up numbers (the same path of a Pill toast going into the bar), a few frames' worth at a time under the
// splash, so by the time a real toast moves the engine has already compiled it. No DOM, nothing is shown.
async function lqToastJsWarm() {
    const frame = () => new Promise(r => requestAnimationFrame(() => r()));
    const t = { _ca: [0.1, 0.1, 0.1, 0.3], _cb: [0.1, 0.1, 0.1, 0.3], _ring: [1, 1, 1, 0.2], _gx: null, _glass: true };
    const kinds = ['float', 'bubble'];
    const N = 72, STEP = 12;
    for (let i = 0; i < N; i++) {
        const u = i / (N - 1), kind = kinds[i % 2];
        const g = { top: 0, top0: 0, ty: -22, kf: kind === 'float' ? 28 : 16, fh: kind === 'float' ? 120 : 17, dx: 0, by: kind === 'float' ? 28 : 26, bhw: kind === 'float' ? 150 : 26, bhh: kind === 'float' ? 29 : 26, br: kind === 'float' ? 28 : 26, kind, cut: kind === 'float' ? 1 : 5 };
        const a = lqSmooth(u / 0.45), yb = lqLerp(g.ty, g.top, a), chv = 64, cwv = lqLerp(300, kind === 'float' ? 220 : 24, lqSmooth(u / 0.55));
        const p = { yb, dx: 0, cy: yb - chv / 2, cwv, chv, r: 24, u };
        const b = lqToastLiqBody(t, g, p, lqSmooth(u / 0.12), 0, null);
        const o = lqLiqOutline(b);
        if (o) lqNeckMetrics(b, o);
        if (i % STEP === STEP - 1) await frame();      // a few frames' work per frame, never a long task on the splash
    }
    return true;
}
async function lqToastWarmUp() {
    const frame = () => new Promise(r => requestAnimationFrame(() => r()));
    for (let i = 0; i < 20 && !document.getElementById('navPill'); i++) await new Promise(r => setTimeout(r, 100));   // the nav is built by now; this is only a guard
    if (!document.getElementById('navPill')) return false;
    lqToastEnsureLayer();
    lqColor('#000');
    await frame();                                   // one step per frame, so the splash keeps painting between them
    if (!lqLiqInit()) return false;
    const L = LQ_LIQ, gl = L.gl;
    const dpr = Math.min(window.devicePixelRatio || 1, LQ_LIQ_DPR);
    const W = Math.round(L.CW * dpr), H = Math.round(L.CH * dpr);
    if (L.cv.width !== W || L.cv.height !== H) { L.cv.width = W; L.cv.height = H; }          // the same size the first real frame asks for
    await frame();
    gl.viewport(0, 0, W, H);
    gl.enable(gl.SCISSOR_TEST);
    gl.scissor(0, 0, 1, 1);                                                                  // one pixel is enough to make the driver build the program
    const u = L.loc;
    gl.uniform2f(u.uSize, L.CW, L.CH); gl.uniform1f(u.uNY, L.NY); gl.uniform1f(u.uPx, 1 / dpr);
    gl.uniform4f(u.uA, 0, 0, 10, 10); gl.uniform1f(u.uAr, 5);
    gl.uniform4f(u.uB, 0, 40, 10, 10); gl.uniform1f(u.uBr, 5);
    gl.uniform4f(u.uS1, 0, 0, 0, 1); gl.uniform2f(u.uS2, 0, 0);
    gl.uniform4f(u.uT1, 0, 0, 0, 1); gl.uniform2f(u.uT2, 0, 0);
    gl.uniform1f(u.uK, 0); gl.uniform1f(u.uKc, 0); gl.uniform1f(u.uCut, 0);
    gl.uniform4f(u.uRing, 0, 0, 0, 0); gl.uniform4f(u.uP, 1, 1, 0, 0); gl.uniform2f(u.uQ, 0, 0);
    gl.uniform1f(u.uFade, 0); gl.uniform1f(u.uSoft, LQ_NECK_SOFT); gl.uniform1f(u.uZone, LQ_NECK_ZONE);
    gl.uniform3f(u.uCt, 0, 0, 1);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    gl.readPixels(0, 0, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array(4));                // waits for the GPU: the program really is built now
    gl.disable(gl.SCISSOR_TEST);
    gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
    try { await lqToastJsWarm(); } catch (_) {}            // the per-frame code of a toast, compiled before the first one
    try { await lqToastGlassWarm(); } catch (_) {}        // Liquid Glass on: its filters and their first draw too
    return true;
}


// ── About card (Settings) ─────────────────────────────────────────────────────
// Name, version and build date come from module.prop; the dummy phone clock follows the device time.
let lqAboutTimer = 0;
function lqAboutTick() {
    const h = document.getElementById('lqAbH'), m = document.getElementById('lqAbM');
    if (!h || !m) return;
    const now = new Date(), p2 = n => String(n).padStart(2, '0');
    // every digit is its own element (its own colour and outline)
    const put = (el, v) => { if (el.dataset.v === v) return; el.dataset.v = v; el.innerHTML = [...v].map(c => '<i data-t="' + c + '">' + c + '</i>').join(''); };
    put(h, p2(now.getHours()));
    put(m, p2(now.getMinutes()));
}
async function lqAboutLoadInfo() {
    let raw = '';
    try { raw = String(await execBg(`cat ${LQ_MODULE_DIR}/module.prop 2>/dev/null || cat /data/adb/modules/LQlzy/module.prop 2>/dev/null`)); } catch (_) {}
    const prop = {};
    raw.split(/\r?\n/).forEach(l => { const i = l.indexOf('='); if (i > 0) prop[l.slice(0, i).trim()] = l.slice(i + 1).trim(); });
    const set = (id, v) => { const el = document.getElementById(id); if (el && v) el.textContent = v; };
    set('lqAbName', prop.name);
    set('lqAbVer', prop.version && prop.version.replace(/^v/i, ''));
    set('lqAbDate', prop.buildDate && prop.buildDate.split(' ')[0]);
    const dEl = document.getElementById('lqAbDate');
    if (dEl && prop.buildDate) dEl.title = prop.buildDate;
}
function initAbout() {
    if (!document.getElementById('lqAbout')) return;
    lqAboutTick();
    lqAboutLoadInfo();
    clearInterval(lqAboutTimer);
    lqAboutTimer = setInterval(() => { if (!document.hidden && currentPage === 'settings') lqAboutTick(); }, 10000);
}
// Boot step: the dummy phone is first painted when Settings opens, and that first paint was the hitch: the wallpaper is loaded and decoded, and the
// blurred shadows, the rotated layers and the clock's drop shadow are rasterised, all while the page is already sliding in. So it is done here, under
// the splash: the wallpaper is decoded, then a copy of the card (no ids, 1% opacity, nobody sees it) is on screen for a few frames. Nothing is
// shown; a failure only means the first opening pays for it as before.
async function lqAboutWarm() {
    const card = document.querySelector('#lqAbout .lq-ab-phone');
    if (!card) return false;
    const frame = () => new Promise(r => requestAnimationFrame(() => r()));
    try { const img = new Image(); img.src = 'about-wallpaper.jpg'; await img.decode(); } catch (_) {}
    const copy = card.cloneNode(true);
    copy.querySelectorAll('[id]').forEach(e => e.removeAttribute('id'));      // the real card keeps lqAbH / lqAbM
    copy.setAttribute('aria-hidden', 'true');
    copy.style.cssText = 'position:fixed;left:0;top:0;width:200px;opacity:.01;pointer-events:none;transition:none;animation:none;z-index:1';
    document.body.appendChild(copy);
    try { await frame(); await frame(); await frame(); }
    finally { copy.remove(); }
    return true;
}
